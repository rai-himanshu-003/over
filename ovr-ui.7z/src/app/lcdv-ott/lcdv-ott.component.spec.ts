import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcdvOttComponent } from './lcdv-ott.component';

describe('LcdvOttComponent', () => {
  let component: LcdvOttComponent;
  let fixture: ComponentFixture<LcdvOttComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcdvOttComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcdvOttComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
