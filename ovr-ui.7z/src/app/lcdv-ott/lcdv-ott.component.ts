import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';

import { GetSelectedVinService } from '../service/getVin.service';
import { AuthenticationService } from '../service/authentication.service';


import { TranslateService } from '@ngx-translate/core';

import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Message, LazyLoadEvent } from 'primeng/components/common/api';

import * as lodash from 'lodash';
import { ITableParameters } from '../models/vehicle-details';

import { OVR_PRD } from '../constant/auth-constant';
import { LcdvOTTService } from '../service/lcdv-ott.service';
import { ExportToCSV } from '../service/exportToCSV.service';
import { ProccessResponseService } from '../service/proccessResponse.service';
import { CompareMaxLimit } from '../shared/services/compareMaxLimit';


@Component({
  selector: 'app-lcdv-ott',
  templateUrl: './lcdv-ott.component.html',
  styleUrls: ['./lcdv-ott.component.scss'],
  providers: [MessageService, ConfirmationService,ProccessResponseService,ExportToCSV,CompareMaxLimit],
  encapsulation: ViewEncapsulation.None,
})
export class LcdvOttComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table

  vinForHistory: string;
  vinForLcdvOTT:string;
  errorMessage: string;

  // variable for Admin access 
  isAdmin: boolean;
  isPFA:boolean;
  isReader:boolean;

  // Variable to show data
  tableHeaders:any[] = [];
  tableRecords:ITableParameters[] = [];
  updatedRecords:ITableParameters[] = [];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  today = new Date();
  fileTimeStamp = '';
  browserLang: string;
  langSelector: string;

  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  // Add records variables
  displayDialog: boolean;
  newRow: boolean;
  newRecords: ITableParameters[] = [];
  newRecord:any = {};
  selectedRecord:ITableParameters;
  isNewRecord: boolean;

  // Variable for Error message for adding new row
  errorMessageForCharacteristic:boolean;
  errorMessageForIndicator:boolean;
  errorMessageForNature:boolean;
  errorMessageForValue:boolean;
  
  // Pagination while adding new records
  totalRecords: number = 0;
  rowsPerPage: number;
  lastRowPage: number;

  // Update records variables

  editedRecords: ITableParameters[];
  clonedRecords: { [s: string]: any; } = {};

  // Validate records Variable
  postData: ITableParameters[] = [];

  // Delete records variables

  deleteRecord: any;
  msgs: Message[] = [];

  characteristic:string;
  indicator:string;
  nature:string;
  value:string;
  id:string;

  disableSave:boolean = false;
  
  // Variable for max limit of rpo
  maxLimit:any;
  isAddDisable:boolean;
  addBtnTooltip:string;

    constructor(
      private getSelectedVinService:GetSelectedVinService,
      private lcdvOTTService:LcdvOTTService,
      private translate: TranslateService,
      public messageService: MessageService,
      private confirmationService: ConfirmationService,
      private _authService: AuthenticationService,
      private proccessResponseService:ProccessResponseService,
      private exportToCSV:ExportToCSV,
      private compareMaxLimit:CompareMaxLimit
    ) {}

    ngOnInit() {
      // To verify User is Admin or Not
      this.isAdmin = this._authService.isAdmin();
      this.isPFA = this._authService.isPFA();
      this.isReader = this._authService.isReader();
      
      this.tableHeaders = [
        { field: 'id', header: 'ID' },
        { field: 'characteristic', header: 'Characteristic' },
        { field: 'value', header: 'Value' },
        { field: 'nature', header: 'Nature' },
        { field: 'indicator', header: 'Indicator' },
        
      ]
      
      
      //this.getRecordsFromDB();
      this.storeVin();

      // export To CSV variables initialise
      this.prdName = OVR_PRD;
      this.exportFile = "_Lcdv-OTT";


      // Header list for export to csv
      for(let i in this.tableHeaders){
        this.headerList.push(this.tableHeaders[i].header);
      }

      // Field list for export to csv
      for(let j in this.tableHeaders){
        this.fieldList.push(this.tableHeaders[j].field);
      }


    }

    storeVin() {
  
      // Set the value of Vin number in variable
      this.vinForLcdvOTT = window.localStorage.getItem("vinSearch");

      // If value is not null or undefined then call get data
      if(this.vinForLcdvOTT !=null && this.vinForLcdvOTT != undefined){
        window.localStorage.setItem("vinForLcdvOTT",this.vinForLcdvOTT);
        this.getRecordsFromDB();
      }
      
    }

    getRecordsFromDB(){


      let vinNumber:string =  window.localStorage.getItem("vinForLcdvOTT");

      if(vinNumber !=null && vinNumber != undefined){
        //console.log("vin"+ vinNumber);
        this.vinForHistory = vinNumber;
        //console.log(this.vinForHistory);
      }
  
      else{
        console.log("no Vin found");
      }

      this.lcdvOTTService.getRecords(this.vinForHistory).subscribe(
        //(data:any) => console.log(data),
        (data:any) => {
          this.tableRecords = data.datalist;
          this.updatedRecords = lodash.cloneDeep(this.tableRecords);
          
          // Compare for max limit
          this.maxLimit = data.totalNumberOfRecords;
          this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
          this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);
        },
        (error:any) => this.errorMessage = <any> error

      )


    }
  //======================== Reset records Start=========================

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {

      // Reset all error messages to false
      this.errorMessageForCharacteristic = false;
      this.errorMessageForIndicator = false;
      this.errorMessageForNature = false;
      this.errorMessageForValue = false;

      // Disable Validate
      this.isNewRecord = false;
      this.getRecordsFromDB();

      // Go to first page
      this.first = 0;
    }

  //======================== Reset records Ends=========================
  //=========================== Add Start===============================

    showDialogToAdd() {
      //console.log("showDialogToAdd");
  
      // Reset all error messages to false
      this.errorMessageForCharacteristic = false;
      this.errorMessageForIndicator = false;
      this.errorMessageForNature = false;
      this.errorMessageForValue = false;
  
      // Set new record to null / empty
      this.newRecord = {};
  
      // Set flag of new record
      this.newRow = true;
  
      // Display Dialoug box
      this.displayDialog = true;

      if(this.tableRecords.length == this.updatedRecords.length){

        // Reset Sort 
        if(this.table.sortOrder != 0){
          this.table.sortOrder = 0;
          this.table.sortField = '';
          this.table.reset();
          this.getRecordsFromDB();
        }

        // Reset Filter 

        if(this.table.filteredValue !== undefined){
          this.characteristic = undefined;
          this.indicator = undefined;
          this.nature = undefined;
          this.value = undefined;
          this.id = undefined;
          this.table.reset();

        }

      }


    }

    save(){
  
      // copy all previous records in new list
      this.newRecords = [...this.tableRecords];

      // Reset all error messages to false
      this.errorMessageForCharacteristic = false;
      this.errorMessageForIndicator = false;
      this.errorMessageForNature = false;
      this.errorMessageForValue = false;

      // Reset all filter fields
      // this.characteristic = undefined;
      // this.indicator = undefined;
      // this.nature = undefined;
      // this.value = undefined;

      // this.table.reset();
  
      // For new Record
      if (this.newRow) {
        // check for Null and Blank record
        console.log(this.newRow);
        console.log(this.newRecord);
        this.newRecord.vin = this.vinForHistory;
        this.newRecord.id = null;
  
        if (this.newRecord.characteristic == null || this.newRecord.characteristic == "" || this.newRecord.characteristic == "") {
  
          this.displayDialog = true;
          this.errorMessageForCharacteristic = true;
        }
        else if (this.newRecord.indicator == null || this.newRecord.indicator == "" || this.newRecord.indicator == "") {
  
          this.displayDialog = true;
          this.errorMessageForIndicator = true;
        }

        else if (this.newRecord.nature == null || this.newRecord.nature == "" || this.newRecord.nature == "") {
  
          this.displayDialog = true;
          this.errorMessageForNature = true;
        }


        else if (this.newRecord.value == null || this.newRecord.value == "" || this.newRecord.value == "") {
  
          this.displayDialog = true;
          this.errorMessageForValue = true;
        }
  
        else{
  
          // claculate last row of total records before pushing the new record in table
          this.totalRecords = this.table.totalRecords;
          this.rowsPerPage = this.rows;
  
          if (this.totalRecords < 10) {
            this.lastRowPage = 0;
            console.log(this.lastRowPage);
          }
          else {
            this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
            console.log(this.lastRowPage);
          }
  
          this.first = this.rowsPerPage * this.lastRowPage;
  
          // Insert New record after claculating last row
          this.newRecords.push(this.newRecord);
          this.displayDialog = false;
          this.newRecord.isNew = true;
          this.isNewRecord = true;
  
          this.tableRecords = this.newRecords;
          console.log(this.newRecord);
          console.log(this.tableRecords);
  
        }

        // Check for max limit

        this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
        this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);
      }
  
    }
  
    cancel(){
      let index = this.newRecords.indexOf(this.selectedRecord);
      this.newRecords = this.newRecords.filter((val, i) => i != index);
      this.newRecord = null;
      this.displayDialog = false;
    }
  
  //=========================== Add Ends================================
  //======================== Update Start===============================

    onRowEditInit(editedRecord: ITableParameters) {
        this.clonedRecords[editedRecord.id] = {...editedRecord};
    }

    onRowEditSave(editedRecord: ITableParameters,index: number) {

      editedRecord.dirty = true;
      this.isNewRecord = true;
      editedRecord.vin = this.vinForHistory;

      this.clonedRecords[editedRecord.id] = { ...editedRecord }; 

    }

    onRowEditCancel(editedRecord: ITableParameters,index: number) {

      // Reset all error messages to false
      this.errorMessageForCharacteristic = false;
      this.errorMessageForIndicator = false;
      this.errorMessageForNature = false;
      this.errorMessageForValue = false;

      this.editedRecords = this.tableRecords;
      this.editedRecords[index] = this.clonedRecords[editedRecord.id];
      delete this.clonedRecords[editedRecord.id];
    }


  //======================== Update Ends===============================
  //======================== Validate Start=============================
    validateRecord(event: Event) {
      console.log("validateRecord");
      // This will reset the Post data
      this.postData = [];
      // This function will compare the prvious value & updated value
      // for (let i = 0; i < this.tableRecords.length; i++) {
      //   if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.tableRecords[i])) {
      //     this.postData.push(this.tableRecords[i]);
      //     console.log(this.postData);
      //   }
  
      // }

      for (let i = 0; i < this.tableRecords.length; i++) {
        if(this.tableRecords[i].dirty == true || this.tableRecords[i].isNew == true){
          // console.log(this.tableRecords[i].id);
          this.postData.push(this.tableRecords[i]);
        }
      }
  
      let updatedData: any = this.postData;
  
      // This method will update the records in DB on click of validate button
      this.lcdvOTTService.updateRecords(this.postData).subscribe(
  
        (data: any) => {
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();

          // This will refresh the whole Page => code to solve version issue
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        },
        //(data:any) => console.log(data),
  
        (error: any) => console.log(error)
      )

      this.isNewRecord = false;
    }

    valueChanged(changedRecord: ITableParameters){

      // Reset all error messages to false
      this.errorMessageForCharacteristic = false;
      this.errorMessageForIndicator = false;
      this.errorMessageForNature = false;
      this.errorMessageForValue = false;
      this.disableSave = false;

      if(changedRecord.characteristic == ""){
        this.disableSave = true;
        this.errorMessageForCharacteristic = true;
      }

      else if(changedRecord.indicator == ""){
        this.disableSave = true;
        this.errorMessageForIndicator = true;
      }
      else if(changedRecord.nature == ""){
        this.disableSave = true;
        this.errorMessageForNature = true;
      }
      else if(changedRecord.value == ""){
        this.disableSave = true;
        this.errorMessageForValue = true;
      }

      else{
        // Reset all error messages to false
        this.errorMessageForCharacteristic = false;
        this.errorMessageForIndicator = false;
        this.errorMessageForNature = false;
        this.errorMessageForValue = false;
        this.disableSave = false;

      }

    }
  
  //======================== Validate Ends=============================

  //=========================== Delete Starts=========================

    // This method will Delete row in table
    deleteRow(tableRow: any, index: number) {

      this.deleteRecord = tableRow;
      console.log(this.deleteRecord);

      // This method will update the records in DB on click of validate button
      //this.deleteRecordsFromDB();

      this.lcdvOTTService.deleteRecords(this.deleteRecord).subscribe(

        (data: any) => {
          console.log(data);
          let res ={...data.responseList};
          console.log(res);
          let resMsg = res[0].msg;
          console.log(resMsg);

          let tableRow = this.deleteRecord;

          if (resMsg == true) {

            // this.msgs = [{severity:'error', summary:'Warning', detail:`${tableRow.id} is  deleted`}];
            this.messageService.add({ severity: 'error', summary: 'Deleted', detail: `${tableRow.id}` });
            this.getRecordsFromDB();
          }
          else {
            this.msgs = [{ severity: 'error', summary: 'Error', detail: `${tableRow.id} not found` }];
            this.getRecordsFromDB();
          }

          this.proccessResponseService.clearMessage();

        },
        (error: any) => console.log(error)
      )


    }

    // Show confirmation box before delete function

    confirmDelete(tableRow: any, index: number) {
      //console.log("Confirm Delete");
      this.confirmationService.confirm({


        accept: () => {
          this.deleteRow(tableRow, index);

        },
        reject: () => {
          //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
      });
    }

  //=========================== Delete Ends=========================

    exportCSVCommon(){
      // This will add time stamp in the filename while exporting the file    
      this.fileTimeStamp = this.exportToCSV.formatDateForExport();

      console.log(this.vinForHistory);

      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}${this.vinForHistory}${this.fileTimeStamp}`;

      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }

      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      console.log(this.exportedRecords);


      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);

    }

    // compareForLimit(actualRecords,maxlimit){

    //   console.log(actualRecords);
    //   console.log(maxlimit);

    //   if(actualRecords >= maxlimit){
    //     this.isAddDisable = true;
    //     this.addBtnTooltip = "Total number of records are more than max limit";
    //   }

    //   else{
    //     this.isAddDisable = false;
    //     this.addBtnTooltip = "Add new record";
    //   }

    //   console.log(this.isAddDisable);

    // }

}
