import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';
import { AuthGuard } from '../guards/auth.guard';
import { CheckReaderGuard } from '../guards/checkReader.guard';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        
        children: [
            { path: '', redirectTo: 'error-management', pathMatch: 'prefix' },
            // { path: 'dashboard', canActivate:[AuthGuard], loadChildren: '../dashboard/dashboard.module#DashboardModule'},
            { path: 'error-management',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../error-management/error-management.module#ErrorManagementModule'},
            { path: 'technical-management',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../technical-management/technical-management.module#TechnicalManagementModule'},
            { path: 'flowState-management',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../flowState-management/flowState-management.module#FlowStateManagementModule'},
            { path: 'vehicle-search',canActivate:[AuthGuard], loadChildren: '../vehicle-search/vehicle-search.module#VehicleSearchModule'},
            { path: 'interface-audit',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../interface-audit/interface-audit.module#InterfaceAuditModule'},            
            { path: 'vehicle-details/:vin',canActivate:[AuthGuard], loadChildren: '../vehicle-history/vehicle-history.module#VehicleHistoryModule'},
            { path: 'interface-management',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../interface-management/interface-management.module#InterfaceManagementModule'},
            { path: 'mapping-ovpsa',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../mapping-ovpsa/mapping-ovpsa.module#MappingOVPSAModule'},
            { path: 'flows-management',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../flows-management/flows-management.module#FlowsManagementModule'},
            { path: 'format-management',canActivate:[AuthGuard,CheckReaderGuard], loadChildren: '../format-management/format-management.module#FormatManagementModule'},
            { path: 'mass-treatment', canActivate:[AuthGuard,CheckReaderGuard],loadChildren: '../mass-treatment/mass-treatment.module#MassTreatmentModule'},
            { path: 'track-changes', canActivate:[AuthGuard,CheckReaderGuard],loadChildren: '../track-changes/track-changes.module#TrackChangesModule'}


            
            
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule {}
