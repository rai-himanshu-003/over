import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import LocalStorage from '../../../util/local-storage';
import { LOCAL_STORAGE_USER_NAME } from '../../../constant/auth-constant';
import { userData } from 'src/app/models/userData';

import { AuthenticationService } from 'src/app/service/authentication.service';
import { MessageService } from 'primeng/api';
import { EnvService } from 'src/app/env-service/env.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { appVersion } from 'src/assets/txtFiles/versionConfig.json'

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
    providers: [MessageService],
})
export class HeaderComponent implements OnInit {
    pushRightClass: string = 'push-right';

    
    welcomeMessage : string;
    updatedUser:userData;
    userDeatils:userData;
    username:string;

    response:any;
    responseMsg:boolean;

    versionNo:string;


    constructor(
        private translate: TranslateService,
        public router: Router,
        public authenticationService:AuthenticationService,
        public messageService: MessageService,
        private env: EnvService,
        private _http: HttpClient
    ) {
        this.getVersion();

        this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de', 'zh-CHS']);
        // this.translate.setDefaultLang('en');
        // const browserLang = this.translate.getBrowserLang();
        // this.translate.use(browserLang.match(/en|fr|ur|es|it|fa|de|zh-CHS/) ? browserLang : 'en');

        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            }
        });
    }

    ngOnInit() {
        // let version = "4.0.54";

        // console.log(this.env.debugEnabled);  

        // this.versionNo = `v : ${version}`
        const user : any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
       // console.log(LocalStorage.readToken());
        this.welcomeMessage = ` ${user.firstName} ${user.lastName} (${user.userRole})`;

        // Get user details
        this.getUserData();

        // console.log("Refresh");
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    rltAndLtr() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle('rtl');
    }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }

    changeLang(language: string) {
        this.translate.use(language);
        this.updateUserLang(language)

    }

    // Get required User details
    getUserData(){

        const user : any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
        this.username = user.uid;

        let browserLang = this.translate.getBrowserLang();
        
        this.authenticationService.getUserData(this.username,"LANGUAGE",browserLang).subscribe(
            (data:any) => {
                // console.log(data);
                this.userDeatils = data;
                // console.log(this.userDeatils);

                let selectedLang = this.userDeatils.value;


                // console.log(selectedLang);
        // this.translate.setDefaultLang(selectedLang);
                // this.translate.use(selectedLang.match(/en|fr|ur|es|it|fa|de|zh-CHS/) ? selectedLang : 'en');
                this.translate.use(selectedLang);
            },
            (error: any) => console.log(error)
          )
    }

    updateUserLang(lang){
debugger
        const user : any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);

        // Create temp object of user
        let tempObj = {} as  userData;

        tempObj.id = this.userDeatils.id;
        tempObj.userId = user.uid
        tempObj.type = "LANGUAGE";
        tempObj.value = lang;

        let selectedLang = lang;
        // this.translate.use(selectedLang.match(/en|fr|ur|es|it|fa|de|zh-CHS/) ? selectedLang : 'en');
        this.translate.use(selectedLang);

        this.authenticationService.updateUserData(tempObj).subscribe(
            (data:any) => {
                console.log(data);
                this.response = data.responseList;
                console.log(this.response);
                this.responseMsg = this.response[0].msg;

                console.log(this.responseMsg);

                if(this.responseMsg == true){
                    // setTimeout(function(){ alert("Hello"); }, 3000);
                     this.messageService.add({ severity: 'success', summary: "Success", 
                     detail: `<div>The Language for user ${tempObj.userId} is updated to ${tempObj.value}</div>` });
                }
                else if (this.responseMsg == false) {
                    this.messageService.add({severity: 'error', summary: "Error Message",
                    detail: `<div>The Language for user ${tempObj.userId} is not updated</div>`
                    })
                }

                this.clearMessage();

                // Refresh the page
                this.ngOnInit();
            },
            (error:any) => console.log(error)
        )
    }

    // This will clear the message after 5 sec
    clearMessage(){
        //console.log("clearMessage");
        setTimeout(() =>{
        this.messageService.clear();
        },5000);
    }

    getVersion(){
        console.log("get version function"+appVersion);

        this.versionNo = `v @ ${appVersion}`
    }

    // getVersion(){
    //     // console.log("get version function");
    //     // this._http.get('../main/resources/test.json').subscribe(
            
    //     //     (data:any) => console.log(data)
    //     // )

    //     this._http.get('../assets/txtFiles/ovr_ihm.properties',
    //     {
    //         headers: new HttpHeaders()
    //             .set('Content-Type', 'text/xml')
    //             .append('Access-Control-Allow-Methods', 'GET')
    //             .append('Access-Control-Allow-Origin', '*')

    //             .append('Access-Control-Allow-Headers', "Access-Control-Allow-Headers, Access-Control-Allow-Origin, Access-Control-Request-Method"),

    //         responseType: 'text'
    //     })
    //     .subscribe((data:string) => {
    //           console.log(data);
            

    //           let appVersion = data;
    //           appVersion = JSON.stringify(appVersion);
    //             let version = appVersion.indexOf("version",0);
            
    //            let finalVersion =  appVersion.slice(version,appVersion.length-1);
    //         //    console.log(finalVersion);

    //            let version1 = finalVersion.indexOf("=",0);
    //         //    console.log(version1);

    //            let finalVersion1 =  finalVersion.slice(version1+1,finalVersion.length);
    //         //    console.log(finalVersion1);

    //            this.versionNo = `v @ ${finalVersion1}`

              
              

    //     });
    // }
}
