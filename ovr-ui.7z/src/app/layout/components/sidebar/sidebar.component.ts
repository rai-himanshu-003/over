import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from '../../../service/authentication.service';
import LocalStorage from '../../../util/local-storage';
import { LOCAL_STORAGE_USER_NAME } from '../../../constant/auth-constant';



@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
    
    isActive: boolean = false;
    collapsed: boolean = false;
    showMenu: string = '';
    pushRightClass: string = 'push-right';
    userRole : string;

    displayMenu:boolean;
    displayFlowMenu:boolean;
    displayMassMenu:boolean;

    @Output() collapsedEvent = new EventEmitter<boolean>();
    isAdmin: boolean;
    isPFA: boolean;
    isReader: boolean;

    constructor(private translate: TranslateService, public router: Router, private _authService: AuthenticationService) {

    }

    ngOnInit(): void {
        this.displayMenu = false;
        this.translate.addLangs(['en', 'fr']);
        // this.translate.setDefaultLang('en');
        // const browserLang = this.translate.getBrowserLang();
        // this.translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
        const user : any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
        this.userRole = user.userRole;
        console.log(this.userRole);

        // To verify User is Admin or Not
        this.isAdmin = this._authService.isAdmin();
        this.isPFA = this._authService.isPFA();
        this.isReader = this._authService.isReader();
        

        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            }
        });
    }

    eventCalled() {
        this.isActive = !this.isActive;
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }

    toggleCollapsed() {
        this.collapsed = !this.collapsed;
        this.collapsedEvent.emit(this.collapsed);
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    // changeLang(language: string) {
    //     this.translate.use(language);
    // }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }

    logout() {
        this._authService.logout();
    }

    // isReader(): boolean {
    //     return this._authService.isReader();
    // }

    // show sub menu of Interface Management

    showSubMenu(){
        console.log("Show Menu");
        this.displayMenu = !this.displayMenu;
    }

    showSubMenuOfFlows(){
        console.log("menu of flows");
        
        this.displayFlowMenu = !this.displayFlowMenu;
    }

    showSubMenuOfMass(){
        // this.subMenuofFlows = !this.subMenuofFlows;

        this.displayMassMenu = !this.displayMassMenu;
    }

    deleteStoredData(){
        console.log("delete filterred data");
        window.localStorage.removeItem("filteredData");
        window.localStorage.setItem("isBack","false");
    }

   
}
