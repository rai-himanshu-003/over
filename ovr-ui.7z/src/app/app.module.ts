// import angular specific Modules
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule, ErrorHandler, Injector } from '@angular/core';
import { HashLocationStrategy, LocationStrategy,PathLocationStrategy } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EnvService } from './env-service/env.service';


// import angular custom Modules 
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { TokenInterceptor } from './interceptor/token-interceptor';


// import external Modules 
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthGuard } from './shared';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateService } from '@ngx-translate/core';
import { NonceQueryParamInterceptor } from './shared/services/refresh.service';




// AoT requires an exported function for factories
export const createTranslateLoader = (http: HttpClient) => {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
};

export let InjectorInstance: Injector;

@NgModule({
  declarations: [
    AppComponent
          
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: createTranslateLoader,
          deps: [HttpClient]
      }
  }),
    NgbModule.forRoot()
  ],
  providers: [AuthGuard,TranslateService, EnvService,
    {provide:HTTP_INTERCEPTORS, useClass:TokenInterceptor, multi:true},
    // {provide:LocationStrategy, useClass: HashLocationStrategy}
    {provide: HTTP_INTERCEPTORS,useClass: NonceQueryParamInterceptor, multi: true}
  ],

  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(private injector: Injector) {
      InjectorInstance = this.injector;
      console.log(InjectorInstance);
  }
}
