import { Injectable } from "@angular/core";


@Injectable({
    providedIn: "root"
})

export class CompareMaxLimit{

    constructor(){}

    compareForLimit(actualRecords,maxlimit){

        console.log(actualRecords);
        console.log(maxlimit);
  
        if(actualRecords >= maxlimit){
            return true;
        }
  
        else{
            return false;
        }
  
        // console.log(this.isAddDisable);
  
    }

    showAddTooltip(compareResult){

        let tooltipText:string;

        if(compareResult == true){
            tooltipText = "Total number of records matches max limit";
        }
        else{
            tooltipText = "Add new record";
        }

        return tooltipText;
    }
}