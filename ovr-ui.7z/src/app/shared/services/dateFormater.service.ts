import { Injectable } from "@angular/core";


@Injectable({
    providedIn:'root'
})

export class DateFormatterService{
    constructor(){}

    formatDateForDataBase(dateOfUser: any) {
    
        let date = new Date(dateOfUser);
        let dd;
        let mm;
        let mbefore:number = (date.getMonth()+1);
    
        if(date.getDate() < 10){
          dd= "0"+date.getDate();
        }
        else{
          dd = date.getDate();
        }
    
        if( (date.getMonth() + 1) < 10){
          mm= "0"+ (date.getMonth()+1);
        }
    
        else{
          mm = mbefore;
        }
    
        return dd + '/'  + mm + '/' + date.getFullYear();
    }

    formatDateForExport() {
      var today = new Date();
      var day = today.getDate() + "";
      var month = (today.getMonth() + 1) + "";
      var year = today.getFullYear() + "";
      var hour = today.getHours() + "";
      var minutes = today.getMinutes() + "";
      var seconds = today.getSeconds() + "";
  
      day = this.checkZero(day);
      month = this.checkZero(month);
      year = this.checkZero(year);
      hour = this.checkZero(hour);
      minutes = this.checkZero(minutes);
      seconds = this.checkZero(seconds);
    
      return(year + "." + month + "." + day + "." + hour + "." + minutes + "." + seconds);
    }

    checkZero(data){
      if(data.length == 1){
        data = "0" + data;
      }
      return data;
    }

    nullCheckFromDate(fromDate,stringFromDate){
      if(fromDate == undefined || fromDate == null){
        //this.minfdate = new Date ("01/01/1900");
        stringFromDate = new Date ("01/01/1900").getTime();
       // console.log(this.minfdate);
      }

      else{
        stringFromDate = fromDate.getTime();
      }

      console.log(stringFromDate);
      return stringFromDate;
    }

    nullCheckToDate(toDate,stringToDate){

      if(toDate == undefined || toDate == null){
        //this.tdate = new Date (" 01/01/9999");
        stringToDate = new Date ("01/01/9999").setHours(23,59,59);
        
      }

      else{
        stringToDate = toDate.setHours(23,59,59);
      }

      return stringToDate;
    }

    showDateRange(fromDate,toDate,colName,colArray){
      let fromDateString;
      let toDateString;

      console.log(fromDate);
      console.log(toDate);

      if(this.formatDateForDataBase(fromDate) == "01/01/1900" && this.formatDateForDataBase(toDate) == "01/01/9999" ){
        fromDateString = null;
        toDateString = null;

      }

      else if(fromDate == null && toDate == null){
        fromDateString = null;
        toDateString = null;
      }

      else{

        if(this.formatDateForDataBase(fromDate) == "01/01/1900" ){
          fromDateString = "*";
        }
        else{
          fromDateString =this.formatDateForDataBase(fromDate);
        }
  
        if(this.formatDateForDataBase(toDate) == "01/01/9999"){
          toDateString = "*";
        }
        else{
          toDateString = this.formatDateForDataBase(toDate);
        }
  
      }

      colArray.forEach(col=>{
        if(col.field == colName){
          if(fromDateString == null && toDateString== null){
            col.value = null;
          }
          else{
            col.value = fromDateString + " -" + toDateString;
          }
          
          console.log(col.value);
        }

      })


    }

    convertStringToDate(dateString){
      console.log(dateString);

      let dateParts = dateString.split("/");
      // month is 0-based, that's why we need dataParts[1] - 1
      let dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 

      console.log(dateObject);

      return dateObject
    }
}