
import { Injectable } from "@angular/core";
import { HttpRequest, HttpHandler, HttpInterceptor } from "@angular/common/http";

@Injectable()

// export class NonceQueryParamInterceptor{}

export class NonceQueryParamInterceptor implements HttpInterceptor {

    isIEOrEdge:boolean;
    
    //   constructor(private utility: UtilityService) {}
      constructor() {}
    
      public intercept(req: HttpRequest<any>, next: HttpHandler) {
    
        // Checks whether this is IE, and this is a GET request
    //     if (this.utility.isNoCacheParamNeeded(req, navigator.userAgent)) {
    
    //       const modifiedRequest = req.clone(
    //           {setParams: {nocache: Date.now().toString()}}
    //       );
    
    //       return next.handle(modifiedRequest);
    
    //     } else {
    //       return next.handle(req);
    //     }

        this.isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);

        if(this.isIEOrEdge == true){
            // console.log("IE");

            const modifiedRequest = req.clone(
                  {setParams: {nocache: Date.now().toString()}}
              );



            return next.handle(modifiedRequest);

            
        }

        else{
            // console.log("Not IE");
            // Remove local storage
            // window.localStorage.removeItem("filteredData");
            // window.localStorage.removeItem("isBack");
            return next.handle(req);


        }
      }
} 


// public intercept(req: HttpRequest<any>, next: HttpHandler) {

//         // Checks whether this is IE, and this is a GET request
//         if (this.utility.isNoCacheParamNeeded(req, navigator.userAgent)) {
    
//           const modifiedRequest = req.clone(
//               {setParams: {nocache: Date.now().toString()}}
//           );
    
//           return next.handle(modifiedRequest);
    
//         } else {
//           return next.handle(req);
//         }
//       } 
// }


 

     
    
     
    