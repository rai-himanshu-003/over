import { Injectable } from "@angular/core";

@Injectable({
    providedIn:"root",
})

export class StateLabelService{
    constructor(){}

    addStateLabel(data){
        data.map(element => {
            if(element.currentState == "INIT"){
              element.currentStateLabel = "Initialized";
            }
            if(element.currentState == "IGNR"){
              element.currentStateLabel = "Ignored by rules";
            }
            if(element.currentState == "CNLD"){
              element.currentStateLabel = "Cancelled manually";
            }
  
            if(element.currentState == "CRTD"){
              element.currentStateLabel = "Created";
            }
  
            if(element.currentState == "SENT"){
              element.currentStateLabel = "Sent";
            }
  
            if(element.currentState == "ONPR"){
              element.currentStateLabel = "Translation on Progress";
            }
  
            if(element.currentState == "KOTR"){
              element.currentStateLabel = "Translation error";
            }
  
            if(element.currentState == "TRDN"){
              element.currentStateLabel = "Translation done";
            }

            if(element.currentState == "REIN"){
              element.currentStateLabel = "Re-initialized";
            }
  
          })
    }

    addStateLabelForVD(data){
        data.map(element => {
            if(element.stateId == "INIT"){
              element.currentStateLabel = "Initialized";
            }
            if(element.stateId == "IGNR"){
              element.currentStateLabel = "Ignored by rules";
            }
            if(element.stateId == "CNLD"){
              element.currentStateLabel = "Cancelled manually";
            }
  
            if(element.stateId == "CRTD"){
              element.currentStateLabel = "Created";
            }
  
            if(element.stateId == "SENT"){
              element.currentStateLabel = "Sent";
            }
  
            if(element.stateId == "ONPR"){
              element.currentStateLabel = "Translation on Progress";
            }
  
            if(element.stateId == "KOTR"){
              element.currentStateLabel = "Translation error";
            }
  
            if(element.stateId == "TRDN"){
              element.currentStateLabel = "Translation done";
            }

            if(element.stateId == "REIN"){
              element.currentStateLabel = "Re-initialized";
            }
  
          })
    }

    addStateLabelForFlow(data){
      data.map(element => {
          if(element.status == "INIT"){
            element.currentStateLabel = "Initialized";
          }
          if(element.status == "IGNR"){
            element.currentStateLabel = "Ignored by rules";
          }
          if(element.status == "CNLD"){
            element.currentStateLabel = "Cancelled manually";
          }

          if(element.status == "CRTD"){
            element.currentStateLabel = "Created";
          }

          if(element.status == "SENT"){
            element.currentStateLabel = "Sent";
          }

          if(element.status == "ONPR"){
            element.currentStateLabel = "Translation on Progress";
          }

          if(element.status == "KOTR"){
            element.currentStateLabel = "Translation error";
          }

          if(element.status == "TRDN"){
            element.currentStateLabel = "Translation done";
          }

          if(element.status == "REIN"){
            element.currentStateLabel = "Re-initialized";
          }

        })
    }
}