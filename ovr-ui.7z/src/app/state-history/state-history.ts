export interface IStateHisporyParameters{
    vin: string,
    dateCreation: number | Date,
    errCode: string,
    errComplement: string,
    errDesc: string,
    errMessage: string,
    userCreation: string,
    stateId: string,
    ccp: string,
    veh: string,
    lcdvOtt: string,
    xmlOv: string,
    version: number,
    currentStateLabel:string

}