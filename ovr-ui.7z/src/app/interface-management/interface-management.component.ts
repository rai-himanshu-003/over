import { Component, OnInit, ViewChild } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import {formatDate} from '@angular/common';

import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_USER_NAME } from '../constant/auth-constant';

import { TranslateService } from '@ngx-translate/core';

import { IInterManagementParameters } from './interface-management';
import { InterfaceList } from './interface-list';
import { InterfaceManagementService } from '../service/interface-management.service';

import { Message, LazyLoadEvent, ConfirmationService } from 'primeng/components/common/api';
import { MessageService } from 'primeng/api';

import { Table } from 'primeng/table';
import { element } from 'protractor';

import * as lodash from 'lodash';
import{OVR_PRD} from '../constant/auth-constant';
import { AuthenticationService } from '../service/authentication.service';

import { ExportToCSV } from '../service/exportToCSV.service';
import { ProccessResponseService } from '../service/proccessResponse.service';

import {SelectItem} from 'primeng/api';
import { DateFormatterService } from '../shared/services/dateFormater.service';





@Component({
  selector: 'app-interface-management',
  templateUrl: './interface-management.component.html',
  styleUrls: ['./interface-management.component.scss'],
  providers: [InterfaceManagementService,MessageService,
    ConfirmationService,ExportToCSV,ProccessResponseService,DateFormatterService],
  encapsulation: ViewEncapsulation.None
})
export class InterfaceManagementComponent implements OnInit {

  // variable to show data in table
  cols: any[];
  interFaceManagementRecords:IInterManagementParameters[]=[];
  errorMessage: string;
  //typeOfFilters:any[]=[];

  typeOfFilters: SelectItem[];
  
  typeOfFiltersForFilter: any[] = [];

  // variables for Interface selection from dropdown
  interFaceList:InterfaceList[]=[];
  selectedInterFace:InterfaceList;
 // interFaceName:string = "1";
 interFaceName:string;

  // pagination variables
  first: number = 0;
  page: number;
  rows: number;
  size: number;

  totalRecords:number = 0;
  rowsPerPage:number = 0;
  lastRowPage:number;

  // Edit records variables
  myJsonString: string;
  sucssessMessage: string;
  updatedRecords: IInterManagementParameters[] = [];
  filteredTableRecords:IInterManagementParameters[] = [];
  postData: IInterManagementParameters[] = [];
  editedInterManagementRecords:IInterManagementParameters[]; 
  clonedInterManagementRecords: { [s: string]: IInterManagementParameters; } = {};
  @ViewChild('dt', { static: false }) table: Table;
  //@ViewChild('dt') private _table: Table;

  // export To CSV variables
  prdName:string;
  exportFile:string;
  today = new Date();
  fileTimeStamp='';



  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];
  
  // Add records variables
  displayDialog: boolean;
  newRow:boolean;
  newInterManagementRecord:any = {};
  newInterManagementRecords: IInterManagementParameters[] = [];
  selectedRecord: IInterManagementParameters;

  // Delete records variables
  
  deleteInterManagementRecords: IInterManagementParameters;
  msgs: Message[] = [];

  // Error Message Variables
  errorMessageForPriority:boolean;
  duplicateMessageForPriority:boolean;
  errorMessageFortypeOfFilter:boolean;
  errorMessageForfamilyOfVehicle:boolean;
  errorMessageForproductionCentre:boolean;
  errorMessageForcountry:boolean;
  errorMessageForminEcomDate:boolean;
  errorMessageFormaxEcomDate:boolean;
  errorMessageFordateCreation:boolean;

  isAdmin: boolean;
  userRole : string;
  typeOfFilter: string;

  // Date filter variables
  minshowDateContainer: boolean = false;
  maxshowDateContainer: boolean = false;
  showDateContainer:boolean = false;
  minfdate: Date;
  mintdate: Date;
  maxfdate: Date;
  maxtdate: Date;
  fdate: Date;
  tdate: Date;

  isNewRecord:boolean;

  priority:string;
  familyOfVehicle:string;
  productionCentre:string;
  country:string;
  vin:string;
  minEcomDate:number | Date;
  maxEcomDate:number | Date;
  dateCreation:number | Date;

  interfaceTooltip:string;

  //disableSave:boolean;

  constructor(
    private interfaceManagementService:InterfaceManagementService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private translate: TranslateService,
    private _authService: AuthenticationService,
    private exportToCSV:ExportToCSV,
    private proccessResponseService:ProccessResponseService,
    private dateFormatterService:DateFormatterService
    ) {



    this.typeOfFiltersForFilter = [
      {label: 'SELECT FILTER', value: null},
      {label: 'INCLUSIVE', value: 'INCLUSIVE'},
      {label: 'EXCLUSIVE', value: 'EXCLUSIVE'}
    ]


   }

  ngOnInit() {
    this.typeOfFilters = [
      {label: 'INCLUSIVE', value: 'INCLUSIVE'},
      {label: 'EXCLUSIVE', value: 'EXCLUSIVE'}
    ]
    // Initialize required variables
    this.rows = 10;
    this.interFaceName = "1";
    
    this.isNewRecord = false;
    this.isAdmin =this._authService.isAdmin();

    this.prdName=OVR_PRD;
    this.exportFile = "_InterfaceManagement";
    

    // Headers declared with field names for table
    this.cols = [
      { field: 'priority', header: 'Priority' },
      { field: 'typeOfFilter', header: 'Type of Filter' },
      { field: 'familyOfVehicle', header: 'Family of Vehicles' },
      { field: 'productionCentre', header: 'Production Centre' },
      { field: 'country', header: 'Country' },
      { field: 'minEcomDate', header: 'Min ECOM' },
      { field: 'maxEcomDate', header: 'Max ECOM' },
      { field: 'vin', header: 'Vin' },
      { field: 'dateCreation', header: 'Date of Creation' }
    ];

    // Header list for export to csv

    for(let i in this.cols){
      this.headerList.push(this.cols[i].header);

    }

    // Field list for export to csv

    for(let j in this.cols){
      this.fieldList.push(this.cols[j].field);

    }

    this.getRecordsFromDB();

    this.setInterface();

    //console.log(this.selectedInterFace);

   // this.interfaceTooltip = this.interFaceList[0];



    this.filteredTableRecords = this.interFaceManagementRecords;
    //this.interfaceTooltip = this.selectedInterFace.interfaceName;

  }

  // This method will give interface from UI drop down

    setInterface(){
      this.interfaceManagementService.getInterfaceList().subscribe(
        (data:any) => {
          this.interFaceList = data;
          //console.log(this.interFaceList);
          //console.log(this.interFaceList[0].interfaceName);
          this.interfaceTooltip = this.interFaceList[0].interfaceName;
        },

        (error: any) => this.errorMessage = <any>error
      )
    }

    getInterface(event){
      console.log(this.selectedInterFace);
      this.interFaceName = this.selectedInterFace.id;
      this.interfaceTooltip = this.selectedInterFace.interfaceName;
      this.first = 0;
      this.getRecordsFromDB();
    }


    // This method will fetch the records from DB
    getRecordsFromDB() {
      this.interfaceManagementService.getRecords(this.interFaceName).subscribe(
        (data: any[]) => {
          console.log(data);
          this.interFaceManagementRecords = data;
          this.updatedRecords = lodash.cloneDeep(this.interFaceManagementRecords);
          this.minshowDateContainer = false;
          this.isNewRecord = false;

        },
        (error: any) => this.errorMessage = <any>error
      );
    }

    // This method will work for pagination
    paginate(event: any) {
      this.first = event.first;
      this.page = event.page;
      this.rows = event.rows;
      this.size = this.table.totalRecords;

    }

  //=========================== Edit Start================================

    // This method will Edit/Update row in table

    onRowEditInit(editedRecord: IInterManagementParameters) {
      
      this.clonedInterManagementRecords[editedRecord.id] = {...editedRecord};

    }
  
    onRowEditSave(editedRecord: IInterManagementParameters) {

      if( editedRecord.familyOfVehicle == null || editedRecord.familyOfVehicle == undefined){
        editedRecord.familyOfVehicle = editedRecord.familyOfVehicle
      }

      else{
        editedRecord.familyOfVehicle = editedRecord.familyOfVehicle.toUpperCase();
      }

      if( editedRecord.productionCentre == null || editedRecord.productionCentre == undefined){
        editedRecord.productionCentre = editedRecord.productionCentre;
      }

      else{
        editedRecord.productionCentre = editedRecord.productionCentre.toUpperCase();
      }


      if( editedRecord.country == null || editedRecord.country == undefined){
        editedRecord.country = editedRecord.country;
      }

      else{
        editedRecord.country = editedRecord.country.toUpperCase();
      }

      if( editedRecord.vin == null || editedRecord.vin == undefined){
        editedRecord.vin = editedRecord.vin;
      }

      else{
        editedRecord.vin = editedRecord.vin.toUpperCase();
      }


      if(editedRecord.typeOfFilter == 1){
        editedRecord.typeOfFilter = "INCLUSIVE";
      }
      else if(editedRecord.typeOfFilter == 2){
        editedRecord.typeOfFilter = "EXCLUSIVE";
      }

      editedRecord.dirty = true;
      this.isNewRecord = true;
      this.clonedInterManagementRecords[editedRecord.id] = {...editedRecord};

      //console.log(this.clonedInterManagementRecords[editedRecord.id]);
    }
  
    onRowEditCancel(editedRecord:IInterManagementParameters, index:number) {  
      this.editedInterManagementRecords = this.interFaceManagementRecords;
      this.editedInterManagementRecords[index] = this.clonedInterManagementRecords[editedRecord.id]
      delete this.clonedInterManagementRecords[editedRecord.id];
    }

  //=========================== Edit Ends================================

  //=========================== Add Start================================
  // This method will show Dialog box to add new row
    showDialogToAdd() {
      //console.log("Add Row");
      this.errorMessageForPriority = false;
      this.duplicateMessageForPriority= false;
      this.errorMessageFortypeOfFilter = false;
      this.errorMessageForfamilyOfVehicle = false;
      this.errorMessageForproductionCentre = false;
      this.errorMessageForcountry = false;
      this.errorMessageForminEcomDate = false;
      this.errorMessageFormaxEcomDate = false;
      this.errorMessageFordateCreation = false;
      this.newRow = true;
      this.newInterManagementRecord = {};
      this.newInterManagementRecord.interfaceId = this.interFaceName;

      this.displayDialog = true;
    }

    save() {
      //console.log("Save Row");
      // copy all previous records in new list
      this.newInterManagementRecords = [...this.interFaceManagementRecords];
      //console.log(this.newInterManagementRecords)

      // Reset all error messages to false
      this.errorMessageForPriority = false;
      this.duplicateMessageForPriority= false;
      this.errorMessageFortypeOfFilter = false;

      console.log(this.table);

      if(this.table.filteredValue !== undefined){
          
        this.priority = undefined;
        this.typeOfFilter = null;
        this.familyOfVehicle = undefined;
        this.productionCentre = undefined;
        this.country = undefined;
        this.vin = undefined;


        this.cols.forEach(col=>{
          if(col.field == 'minEcomDate'){
            col.value = undefined;
            this.minfdate = undefined;
            this.mintdate = undefined;
          }
          else if(col.field == 'maxEcomDate'){
            col.value = undefined;
            this.maxfdate = undefined;
            this.maxtdate = undefined;
            
          }

          else if(col.field == 'dateCreation'){
            col.value = undefined;
            this.fdate = undefined;
            this.tdate = undefined;
          }

        })
        this.table.reset();

      }
      

      if (this.newRow){
        
        // check for duplicate priority value
        for (let i = 0; i < this.interFaceManagementRecords.length; i++){

          if ((this.interFaceManagementRecords[i].priority) == (this.newInterManagementRecord.priority)) {
            console.log("Duplicate record");
            this.duplicateMessageForPriority = true;
          }
        }

          // check for duplication of Priority value
          if(this.duplicateMessageForPriority == true){
            console.log(this.duplicateMessageForPriority);
            this.displayDialog = true;
            //this.newTechnicalRecords = this.technicalRecords;
          }

          // check for Null and Blank record
          else if(this.newInterManagementRecord.priority == null || this.newInterManagementRecord.priority == "" || this.newInterManagementRecord.priority == " "){
            console.log("blnk input");
            this.displayDialog = true;
            this.errorMessageForPriority = true;
            this.duplicateMessageForPriority = false;
                    
          }

          else if(this.newInterManagementRecord.typeOfFilter == null || this.newInterManagementRecord.typeOfFilter == "" || this.newInterManagementRecord.typeOfFilter == " "){
            this.displayDialog = true;
            this.errorMessageFortypeOfFilter = true;
            this.duplicateMessageForPriority = false;
          }


          else{
          // console.log("Add New record after validation");
            console.log(this.newInterManagementRecord);
          // claculate last row of total records before pushing the new record in table
            this.totalRecords = this.table.totalRecords;
            this.rowsPerPage = this.rows;

            if(this.totalRecords < 10){
              this.lastRowPage = 0;
              console.log(this.lastRowPage);
            }
            else{
              this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
              console.log(this.lastRowPage);
            }

            this.first = this.rowsPerPage * this.lastRowPage;

              // Change value to uppercase

              if( this.newInterManagementRecord.familyOfVehicle == null || this.newInterManagementRecord.familyOfVehicle == undefined){
                this.newInterManagementRecord.familyOfVehicle = this.newInterManagementRecord.familyOfVehicle;
              }

              else{
                this.newInterManagementRecord.familyOfVehicle = this.newInterManagementRecord.familyOfVehicle.toUpperCase();
              }

              if( this.newInterManagementRecord.productionCentre == null || this.newInterManagementRecord.productionCentre == undefined){
                this.newInterManagementRecord.productionCentre = this.newInterManagementRecord.productionCentre;
              }
              else{
                this.newInterManagementRecord.productionCentre = this.newInterManagementRecord.productionCentre.toUpperCase();
              }

              if( this.newInterManagementRecord.country == null || this.newInterManagementRecord.country == undefined){
                this.newInterManagementRecord.country = this.newInterManagementRecord.country;
              }

              else{
                this.newInterManagementRecord.country = this.newInterManagementRecord.country.toUpperCase();
              }

              if( this.newInterManagementRecord.vin == null || this.newInterManagementRecord.vin == undefined){
                this.newInterManagementRecord.vin = this.newInterManagementRecord.vin;
              }

              else{
                this.newInterManagementRecord.vin = this.newInterManagementRecord.vin.toUpperCase();
              }

              if(this.newInterManagementRecord.typeOfFilter == 1){

              this.newInterManagementRecord.typeOfFilter = "INCLUSIVE";
              }
              else if(this.newInterManagementRecord.typeOfFilter == 2) {

                this.newInterManagementRecord.typeOfFilter = "EXCLUSIVE";
              }

            
            this.newInterManagementRecords.push(this.newInterManagementRecord);
            console.log(this.newInterManagementRecords);

            this.displayDialog = false;
            this.newInterManagementRecord.isNew = true;
            this.isNewRecord = true;

            this.interFaceManagementRecords = this.newInterManagementRecords;

          }
      }

      this.minshowDateContainer = false;
      this.maxshowDateContainer = false;
      this.showDateContainer = false;
    }

    cancel() {
      
      let index = this.newInterManagementRecords.indexOf(this.selectedRecord);
      this.newInterManagementRecords = this.newInterManagementRecords.filter((val, i) => i != index);
      this.newInterManagementRecord = null;
      this.displayDialog = false;
    }

//=========================== Add Ends================================

//=========================== Delete Starts================================

  // This method will Delete row in table
  deleteRow(tableRow: IInterManagementParameters, index: number){
    
    this.deleteInterManagementRecords = tableRow;
    console.log(this.deleteInterManagementRecords);

    // This method will update the records in DB on click of validate button
    
    this.interfaceManagementService.deleteRecords(this.deleteInterManagementRecords).subscribe(
      (data:any) =>{
        
        let res ={...data};
        let resMsg = res.msg;
        

        if(resMsg == true){
          
          this.msgs = [{severity:'error', summary:'Success', detail:`${tableRow.priority} is  deleted`}];
          this.getRecordsFromDB();
        }
        else{
          this.msgs = [{severity:'error', summary:'Error', detail:`${tableRow.priority} not found`}];
          this.getRecordsFromDB();
        }

        this.proccessResponseService.clearMessage();
        
      },
      (error: any) => console.log(error)
    )


  }
  
  // This method will show confirmation box before Delete

  confirmDelete(tableRow: IInterManagementParameters, index: number) {
    
    this.confirmationService.confirm({

        accept: () => {
           this.deleteRow(tableRow,index);            
        },
        reject: () => {
            //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
    });
  }

//=========================== Delete Ends================================

//=========================== Validate Starts================================
  validateRecord(event: Event) {

    console.log(this.updatedRecords);

    // This will reset the Post data
    this.postData = [];

    this.updatedRecords.forEach(record => {
      if(record.typeOfFilter == 1){

        record.typeOfFilter = "INCLUSIVE";
        }
        else if(record.typeOfFilter == 2){

          record.typeOfFilter = "EXCLUSIVE";
        }      

    });

    // This function will compare the prvious value & updated value
    for (let i = 0; i < this.interFaceManagementRecords.length; i++) {
      if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.interFaceManagementRecords[i])) {
            this.postData.push(this.interFaceManagementRecords[i]);
      }
    }

   

    // This will convert List of Object in to String format
    this.myJsonString = JSON.stringify(this.postData);
    
    let updatedData: any = this.postData;

    // This method will update the records in DB on click of validate button
    this.interfaceManagementService.updateRecords(this.postData).subscribe(

      (data: any) => {
        this.proccessResponseService.proccessResponse(data, updatedData);
        this.getRecordsFromDB();
      },  
      //(data:any) => console.log(data),

      (error: any) => console.log(error)
    )

    this.updatedRecords = [];
    
  }


//=========================== Validate Ends================================

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {
      this.getRecordsFromDB();
    }

    // this method will show & hide the date filter section
    showDateFilter(event, field: string) {

      if (field == 'minEcomDate') {
        this.minshowDateContainer = true;
        this.maxshowDateContainer = false;
        this.showDateContainer = false;

      }
  
      else if (field == 'maxEcomDate') {
        this.maxshowDateContainer = true;
        this.minshowDateContainer = false;
        this.showDateContainer = false;


      }

      else if (field == 'dateCreation') {
        this.showDateContainer = true;
        this.maxshowDateContainer = false;
        this.minshowDateContainer = false;
        
      }
  
  
      else if (field == 'priority' || field == 'typeOfFilter' || field == 'familyOfVehicle' || field == 'productionCentre' || field == 'country' || field == 'vin' ) {
        this.minshowDateContainer = false;
        this.maxshowDateContainer = false;
        this.showDateContainer = false;
  
      }


    }

    filterDate() {
      let filteredRecord:IInterManagementParameters[];
      
      let minfromDate:number;
      let mintoDate:number;
      

      minfromDate = this.nullCheckFromDate(this.minfdate,minfromDate);
      console.log(minfromDate);

      mintoDate = this.nullCheckToDate(this.mintdate,mintoDate);


      // This will display date in filter box

      // This will display date in filter box
      this.showDateRange(minfromDate,mintoDate,"minEcomDate");

        let minfromDateString:string;
        let mintoDateString:string;

      //===================================================

      
      let maxFromDate:number;
      let maxToDate:number;
      

      maxFromDate = this.nullCheckFromDate(this.maxfdate,maxFromDate);
      console.log(maxFromDate);


      maxToDate = this.nullCheckToDate(this.maxtdate,maxToDate);
      

      // This will display date in filter box
      this.showDateRange(maxFromDate,maxToDate,"maxEcomDate");


      let maxfromDateString:string;
      let maxtoDateString:string;


      // ============================================
      //console.log("Date Filter");

      //console.log(event);
      console.log(this.table);
  
      let fromDate:number;
      let toDate:number;
      //let filteredRecord:IInterManagementParameters[];
  

      fromDate = this.nullCheckFromDate(this.fdate,fromDate);
      console.log(fromDate);

      toDate = this.nullCheckToDate(this.tdate,toDate);

      // This will display date in filter box
      this.showDateRange(fromDate,toDate,"dateCreation");
  
           

      filteredRecord = this.updatedRecords.filter(function(record){
        return (record.dateCreation > fromDate && record.dateCreation < toDate)  
        && (record.minEcomDate > minfromDate && record.minEcomDate < mintoDate)
        && (record.maxEcomDate > maxFromDate && record.maxEcomDate < maxToDate)
      })

      console.log(filteredRecord);

      let fromDateString:string;
      let toDateString:string;


      filteredRecord.forEach(record => {
        if(record.typeOfFilter == 1){
  
          record.typeOfFilter = "INCLUSIVE";
          }
          else{
  
            record.typeOfFilter = "EXCLUSIVE";
          }      
  
      });

   
      this.interFaceManagementRecords = filteredRecord;

      this.table.filteredValue = filteredRecord;
  
    }

    nullCheckFromDate(fromDate,stringFromDate){
      if(fromDate == undefined || fromDate == null){
        //this.minfdate = new Date ("01/01/1900");
        stringFromDate = new Date ("01/01/1900").getTime();
       // console.log(this.minfdate);
      }

      else{
        stringFromDate = fromDate.getTime();
      }

      console.log(stringFromDate);
      return stringFromDate;
    }

    nullCheckToDate(toDate,stringToDate){

      if(toDate == undefined || toDate == null){
        //this.tdate = new Date (" 01/01/9999");
        stringToDate = new Date ("01/01/9999").setHours(23,59,59);
        console.log(this.tdate);
      }

      else{
        stringToDate = toDate.setHours(23,59,59);
      }

      return stringToDate;
    }

    showDateRange(fromDate,toDate,colName){
      let fromDateString;
      let toDateString;

      if(this.dateFormatterService.formatDateForDataBase(fromDate) == "01/01/1900" && this.dateFormatterService.formatDateForDataBase(toDate) == "01/01/9999" ){
        fromDateString = null;
        toDateString = null;

      }

      else{

        if(this.dateFormatterService.formatDateForDataBase(fromDate) == "01/01/1900" ){
          fromDateString = "*";
        }
        else{
          fromDateString =this.dateFormatterService.formatDateForDataBase(fromDate);
        }
  
        if(this.dateFormatterService.formatDateForDataBase(toDate) == "01/01/9999"){
          toDateString = "*";
        }
        else{
          toDateString = this.dateFormatterService.formatDateForDataBase(toDate);
        }
  
      }

      this.cols.forEach(col=>{
        if(col.field == colName){
          if(fromDateString == null && toDateString== null){
            col.value = null;
          }
          else{
            col.value = fromDateString + " -" + toDateString;
          }
          
          console.log(col.value);
        }

      })


    }



    // Export to CSV
    exportCSVForIM(){
      // This will add time stamp in the filename while exporting the file    
      //this.fileTimeStamp = this.formatDateForExport();

      this.fileTimeStamp = this.exportToCSV.formatDateForExport();

      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}${this.fileTimeStamp}`;

      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }

      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      console.log(this.exportedRecords);

      this.exportedRecords.forEach(record =>{

        delete record.id;
        delete record.interfaceId;
        delete record.version;

        console.log(record);

        if(record.minEcomDate != null){
          record.minEcomDate = this.exportToCSV.csvDateFormat(record.minEcomDate);
          console.log(record.minEcomDate);
        }
        else{
          record.minEcomDate = " ";
        }
        if(record.maxEcomDate != null){
          record.maxEcomDate = this.exportToCSV.csvDateFormat(record.maxEcomDate);
        }
        else{
          record.maxEcomDate = " ";
        }

        if(record.dateCreation != null){
          record.dateCreation = this.exportToCSV.csvDateFormat(record.dateCreation);
        }
        else{
          record.dateCreation = " ";
        }

        if(record.familyOfVehicle == null){
          record.familyOfVehicle = " ";
        }
        else{
        record.familyOfVehicle = JSON.stringify(record.familyOfVehicle);
        }

        if(record.productionCentre == null){
          record.productionCentre = " ";
        }
        else{
        record.productionCentre = JSON.stringify(record.productionCentre);
        }

        if(record.vin == null){
          record.vin = " ";
        }
        else{
        record.vin = JSON.stringify(record.vin);
        }

        if(record.country == null){
          record.country = " ";
        }
        else{
        record.country = JSON.stringify(record.country);
        }

        
      })

      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);
    }


    // Check for number input

    valueChanged(event):boolean{
      console.log(event.key);

      if((event.key <=9) || (event.key == "Backspace" ) || (event.key == "Del" ) || (event.key == "Delete" ) || (event.key == "Home") || (event.key == "End") || (event.key == "ArrowLeft") || (event.key == "Left") || (event.key == "ArrowRight") || (event.key == "Right")){
        return true;
      }

      else{
        return false;
      }



    }

    // Reset Date filter
    resetMinDate(){
      this.minfdate = null;
      this.mintdate = null;
      //let colName = minEcomDate;

      this.filterDate();
    }

    resetMaxDate(){
      this.maxfdate = null;
      this.maxtdate = null;

      this.filterDate();
    }

    resetDate(){
      this.fdate = null;
      this.tdate = null;

      this.filterDate();
    }
}
