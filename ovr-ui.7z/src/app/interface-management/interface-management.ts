export interface IInterManagementParameters{
    id: string,
    priority: number,
    interfaceId: string,
    typeOfFilter: number | string,
    familyOfVehicle: string,
    productionCentre:string,
    country: string,
    vin:string,
    minEcomDate: Date | Number,
    maxEcomDate: Date | Number,
    dateCreation: Date | Number,
    version: number
    dirty:boolean,
    isNew:boolean
}