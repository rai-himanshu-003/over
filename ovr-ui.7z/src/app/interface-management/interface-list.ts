export interface InterfaceList{
    id: string;
    interfaceName:string;
}