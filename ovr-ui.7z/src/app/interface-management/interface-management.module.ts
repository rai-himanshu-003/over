import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { InterfaceManagementComponent } from './interface-management.component';
import { InterfaceManagementRoutingModule } from './interface-management-routing.module';

import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {ToastModule} from 'primeng/toast';
import {PaginatorModule} from 'primeng/paginator';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {TooltipModule} from 'primeng/tooltip';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {CalendarModule} from 'primeng/calendar';
import { MultiSelectModule } from 'primeng/multiselect';
import { DashboardComponent } from '../dashboard/dashboard.component';

import {InputTextareaModule} from 'primeng/inputtextarea';



@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    InterfaceManagementRoutingModule,
    TranslateModule,
    TableModule,
    ButtonModule,
    TooltipModule,
    ToastModule,
    PaginatorModule,
    MessagesModule,
    MessageModule,
    DialogModule,
    ConfirmDialogModule,
    CalendarModule,
    MultiSelectModule,
    InputTextareaModule
  ],

  declarations: [InterfaceManagementComponent],
  providers: [DatePipe, DashboardComponent]

})

export class InterfaceManagementModule { }
