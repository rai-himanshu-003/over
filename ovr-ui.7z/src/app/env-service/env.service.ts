import { Injectable, Inject, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable()
export class EnvService implements OnInit {

  constructor(private httpClient: HttpClient) {
    this.loadEnvData(); 
  }

  // API url

 // public ovrMicroServiceApiUrl:string;

  ovrMicroServiceApiUrl = 'http://over.dev.inetpsa.com:9090/ovrmicroservice';
  
  
  // to dsiplay or not console logs
  public debugEnabled = true;

  ngOnInit() {    
    this.loadEnvData(); 
  }
  
  private loadEnvData() { 
    this.httpClient.get<string>('/envdata',   {responseType: 'json'}).subscribe(
      (data: any) => {
        //let ovrMicroServiceApiUrl:string
        console.log("returned response from envdata");
            
        this.ovrMicroServiceApiUrl = data.ovrMicroServiceApiUrl;

        console.log(data.ovrMicroServiceApiUrl);
        console.log(this.ovrMicroServiceApiUrl);
        
        this.debugEnabled = data.debugEnabled;
      },
      (error) => { console.log("error while loading env data from /envdata") }
      );
  }
}
