import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorManagementComponent } from './error-management.component';

const routes: Routes = [
  {
      path: '',
      component: ErrorManagementComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ErrorManagementRoutingModule { }
