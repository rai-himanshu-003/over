import { ErrorManagementModule } from './error-management.module';

describe('ErrorManagementModule', () => {
  let errorManagementModule: ErrorManagementModule;

  beforeEach(() => {
    errorManagementModule = new ErrorManagementModule();
  });

  it('should create an instance', () => {
    expect(errorManagementModule).toBeTruthy();
  });
});
