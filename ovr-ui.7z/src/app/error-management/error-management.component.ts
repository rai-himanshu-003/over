import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { ErrorRecordService } from '../service/error-management.service';
import { IErrorhParameters } from './error-management';


import { LazyLoadEvent } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/api';


import { ConfirmationService } from 'primeng/api';
import { FilterData } from '../error-management/filter-data';

import { Router } from '@angular/router';

import { GetSelectedVinService } from '../service/getVin.service';

// check for role Management
import { AuthenticationService } from '../service/authentication.service';
import { IFlowList } from '../models/flow-list';
import { DateFormatterService } from '../shared/services/dateFormater.service';


//import { InterfaceManagementComponent } from '../interface-management/interface-management.component';


@Component({
  selector: 'app-error-management',
  templateUrl: './error-management.component.html',
  styleUrls: ['./error-management.component.scss'],
  providers: [MessageService, ConfirmationService,DateFormatterService],
  encapsulation: ViewEncapsulation.None,
})
export class ErrorManagementComponent implements OnInit {

 // @ViewChild('errFilter','')

  errorRecords: IErrorhParameters[] = [];
  selectedRecords: IErrorhParameters[] = [];
  selectedRecord: IErrorhParameters[] = [];
  errorMessage: null;

  // variable for columns 
  cols: any[];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // Filter Variables
  loading: boolean;
  filterValue = {} as FilterData;

  // Date filter variables
  extshowDateContainer: boolean = false;
  errshowDateContainer: boolean = false;
  extfdate: string | Date;
  exttdate: string | Date;
  errfdate: string | Date;
  errtdate: string | Date;

  // Sort Variables
  sortData = {} as FilterData;
  sortResult: string;

  // waring message 
  msgs: Message[] = [];
  editable: boolean = true;
  totalNumberRecords:number =0;
  datePipe: any;

  // Ignored records variables
  isIgnoredRecord:boolean = false;
  ignoredRecord:IErrorhParameters;

  versionNo:number;
  vinForHistory: string;

  userRole: any;
  isAdmin: boolean;

  // Interface variable
  flowName:string;
  flowList:IFlowList[] = [];
  selectedFlow:IFlowList;
  isOTT:boolean;
  flowNameTooltip:string;

  // selectedFlow:string;

  // Back button variable
  isBack:string;

  // Variable to check output flow
  isOutputFlow:boolean;


  selectedFlowName:string;

  constructor(
    private errorRecordService: ErrorRecordService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    public router: Router,
    private getSelectedVinService:GetSelectedVinService,
    private _authService: AuthenticationService,
    private dateFormatterService:DateFormatterService

  ) { 
    this.isAdmin =this._authService.isAdmin();
    // console.log(this.isAdmin);
  }

    ngOnInit() {
    
      // set default value of variables required
      this.cols = [
        { field: 'vin', header: 'VIN' },
        { field: 'ccp', header: 'CCP' },
        { field: 'veh', header: 'VEH' },
        { field: 'extFromDate', header: 'EMON DATE' },
        { field: 'codeErr', header: 'CODE ERR' },
        { field: 'labelErr', header: 'LABEL ERR' },
        { field: 'complementErr', header: 'COMPLEMENT ERR' },
        { field: 'errFromDate', header: 'DATE ERR' },
        // { field: 'flowName', header: 'FLOW NAME' },
        

      ];

      // Get drop down values for flow
      this.setFlowName();

      // console.log(this.flowList);


      // Set default values to get data
      this.flowName = "OTT";
      this.flowNameTooltip = this.flowName;
            

      // set the default valu as null for sorting & filtering
      Object.assign(this.sortData, {
        vin: null,
        ccp: null,
        veh: null,
        extFromDate: null,
        extToDate: null,
        codeErr: null,
        labelErr: null,
        complementErr: null,
        errFromDate: null,
        errToDate: null,
        vinOrder: null,
        ccpOrder: null,
        vehOrder: null,
        codeErrOrder: null,
        labelErrOrder: null,
        complementErrOrder: null,
        extDateOrder: null,
        errDateOrder: null,
        flowName:null,
        //flowNameOrder:null,
      })
      
      // Check if back button is clicked

      // Reset the value to detect the back button event
      this.isBack = "false";

      this.getBackFlag();

      // console.log(this.isBack);

      // if(this.isBack = 'false'){
      //   this.sortResult = JSON.stringify(this.sortData);
      //   this.getRecordsFromDB();

      // }

      setTimeout(() => {

        if(this.isBack == "true"){
          // console.log("filteredData");

          // console.log(this.cols);
  
          let flowName = window.localStorage.getItem("flowName");
          let backUpData = window.localStorage.getItem("filteredData");
          let noFirst:string | number = window.localStorage.getItem("first");
          let noRows:string | number = window.localStorage.getItem("rows");
          let ignoredRecords:string = window.localStorage.getItem("ignoredRecords");
          // console.log(backUpData);
          
          this.flowName = flowName;
          // this.selectedFlow.flowName = flowName;
          this.sortResult = backUpData;
          this.first = parseInt(noFirst);
          this.rows = parseInt(noRows);
          this.isIgnoredRecord = JSON.parse(ignoredRecords);;
    
          // set flow name of drop down
  
          // console.log(this.flowList);
  
          this.flowList.forEach(element =>{
            if(element.flowName == flowName){
              this.selectedFlow = element;
            }
          })
          // console.log(this.selectedFlow);
    
          // console.log(this.flowName);
          // console.log(this.sortResult);
          // console.log(this.first);
          // console.log(this.rows);
          // console.log(this.isIgnoredRecord);
  
  
          this.getRecordsFromDB();
  
          // Set value in filter field
  
          let filteredObj:FilterData = JSON.parse(backUpData);

          if(filteredObj != null){
            this.cols.forEach(col =>{
              if(col.field == 'vin'){
                col.value =  filteredObj.vin;
              }

              else if(col.field == 'ccp'){
                col.value =  filteredObj.ccp;
              }

              else if(col.field == 'veh'){
                col.value =  filteredObj.veh;
              }

              else if(col.field == 'extFromDate'){
                if(filteredObj.extFromDate !== null && filteredObj.extToDate !== null){
                  col.value =  `${filteredObj.extFromDate} - ${filteredObj.extToDate}`;
                  // this.extfdate = new Date (filteredObj.extFromDate);
                  // this.exttdate = new Date (filteredObj.extToDate);

                 this.extfdate = this.dateFormatterService.convertStringToDate(filteredObj.extFromDate);
                 this.exttdate = this.dateFormatterService.convertStringToDate(filteredObj.extToDate);

                  

                }
                
              }

              else if(col.field == 'codeErr'){
                col.value =  filteredObj.codeErr;
              }

              else if(col.field == 'labelErr'){
                col.value =  filteredObj.labelErr;
              }

              else if(col.field == 'complementErr'){
                col.value =  filteredObj.complementErr;
              }

              else if(col.field == 'errFromDate'){
                if(filteredObj.errFromDate !== null && filteredObj.errToDate !== null){
                  col.value =  `${filteredObj.errFromDate} - ${filteredObj.errToDate}`;

                  this.errfdate = this.dateFormatterService.convertStringToDate(filteredObj.errFromDate);
                  this.errtdate = this.dateFormatterService.convertStringToDate(filteredObj.errToDate);
                }
                
              }

              else{
                col.value = null;
              }

            })
          }
  

  
        }
        else{
          this.sortResult = JSON.stringify(this.sortData);
          this.getRecordsFromDB();
        }
        
      }, 2000);


      //this.versionNo = this.errorRecords.version;


      

      if(this.flowName !== "OTT"){
        this.isOTT = false;
      }
      else{
        this.isOTT = true;
      }
   
      
    }

  // This method will give interface from UI drop down

    setFlowName(){
      this.errorRecordService.getFlowList().subscribe(
        (data:any) => {
          // console.log(data);
          this.flowList = data;

          // console.log(this.flowList);
        },

        (error: any) => this.errorMessage = <any>error
      )
    }

    getFlowName(event){
      //console.log(this.selectedInterFace);
      this.flowName = this.selectedFlow.flowName;
      this.flowNameTooltip = this.selectedFlow.flowName;
      this.first = 0;
      this.getRecordsFromDB();

      // Hide Ignore button for Output flow
      if(this.flowName == "CORVET"){
        this.isOutputFlow = true;
      }
      else{
        this.isOutputFlow = false;
      }
    }

    // This method will fetech the records from DB
    getRecordsFromDB() {
      this.loading = true;
      // console.log(this.flowName)

      if(this.flowName !== "OTT"){
        this.isOTT = false;
      }
      else{
        this.isOTT = true;
      }

      // console.log(this.sortResult);
      // console.log(this.isIgnoredRecord);
      // console.log(this.flowName);
      
      this.errorRecordService.getRecords(this.flowName,this.first, this.rows, this.sortResult,this.isIgnoredRecord).subscribe(

        
        (data: any) => {

          this.totalNumberRecords = data.totalNumberOfRecords;
          this.errorRecords = data.datalist;
          this.loading = false;
          // console.log(this.errorRecords);
        },
        (error: any) => {
          this.errorMessage = <any>error
          this.loading = false;
        }
      );

    }

    // This will fetch Ignored Records from DB
    getIgnoredRecords(){
      this.getRecordsFromDB();
    }

    onRowSelect(event: Event) {
      
      this.selectedRecords.forEach(function (selectedRecord) {
      // console.log(selectedRecord);
      });
    }

    // This method will update the selected records in DB on click of Retry button
    sendDataToOTT(event: Event) {
      this.onRowSelect(event);
      // console.log(event);
      
      let numberOfRecordsSelected = this.selectedRecords.length;
      if (numberOfRecordsSelected === 0) {
        this.showWarn();
      }

      else {
        // console.log(this.selectedRecords);
        this.selectedRecords.forEach(elememt => {
          elememt.flowName = this.flowName;
        });

        this.errorRecordService.updateRecords(this.selectedRecords).subscribe(
          (data: any) => this.proccessErrManageResponse(data),
          (error: any) => console.log(error)
          
        )

        

      }

    }

   // This method will update the selected records in DB on click of Ignore button
    ignoreRecord(event: Event) {
      this.onRowSelect(event);
      let numberOfRecordsSelected = this.selectedRecords.length;

      if (numberOfRecordsSelected === 0) {      
        this.showWarn();
      }
      else {
      // this.confirmIgnore();
      this.sendIgnoredRecordsToDb();
      }


    }


    // This method will work for pagination
    paginate(event: any) {
      this.first = event.first;
      this.page = event.page;
      this.rows = event.rows;

      
      this.getRecordsFromDB();
    }

    // This method will work for Filter
    onKeydown(event, field: string) {

      // console.log(this.sortData);

      if(this.isBack == "true"){
        console.log("backUpData");
        let backUpData = window.localStorage.getItem("filteredData");
        this.sortData = JSON.parse(backUpData);
      }

      else{
        // console.log("NO backUpData");
        this.sortResult =this.sortResult;
      }

      if (field == 'vin') {
        this.sortData.vin = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (field == 'ccp') {
        this.sortData.ccp = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }

      else if (field == 'veh') {
        this.sortData.veh = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }

      else if (field == 'codeErr') {
        this.sortData.codeErr = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }

      else if (field == 'labelErr') {
        this.sortData.labelErr = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }

      else if (field == 'complementErr') {
        this.sortData.complementErr = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }

      this.first = 0;

      // console.log(this.sortResult);

      // After reset set filtered data again
      if(this.isBack == "true"){
        // console.log("backUpData");
        window.localStorage.setItem("filteredData",this.sortResult);
      }
      else{
        this.sortResult = this.sortResult;
      }

      
      this.getRecordsFromDB();
    }

    // this method will show & hide the date filter section
    showDateFilter(event, field: string) {

      // console.log("Ext Date");

      if (field == 'extFromDate') {
        this.extshowDateContainer = true;
        this.errshowDateContainer = false;
      }




      else if (field == 'vin' || field == 'ccp' || field == 'veh' || field == 'codeErr' || field == 'labelErr' || field == 'complementErr') {
        this.extshowDateContainer = false;
        this.errshowDateContainer = false;

      }
    }

    showErrDateFilter(event, field: string){

      // console.log("Err Date");

      if (field == 'errFromDate') {
        this.errshowDateContainer = true;
        this.extshowDateContainer = false;
      }

      else if (field == 'vin' || field == 'ccp' || field == 'veh' || field == 'codeErr' || field == 'labelErr' || field == 'complementErr') {
        this.extshowDateContainer = false;
        this.errshowDateContainer = false;

      }

    }


    formatDateForDataBase(dateOfUser: any) {
      
      let date = new Date(dateOfUser);
      let dd;
      let mm;
      let mbefore:number = (date.getMonth()+1);

      if(date.getDate() < 10){
        dd= "0"+date.getDate();
      }
      else{
        dd = date.getDate();
      }

      if( (date.getMonth() + 1) < 10){
        mm= "0"+ (date.getMonth()+1);
      }

      else{
        mm = mbefore;
      }

      return dd + '/'  + mm + '/' + date.getFullYear();
    }

    // Filter function for EXt Date field
    extFilterDate() {

      if(this.extfdate != null && this.exttdate != null){
        
        if (this.extfdate > this.exttdate){
          
          this.messageService.add({ severity: 'error', summary: "Error Message", 
          detail: `The To date is Greater than From date. Please select appropriate date` });

          this.clearMessage();
    
          return false;
        }

      }
  

      let extfromDate:string;
      let exttoDate:string;

      
      this.cols.forEach(col=>{
        
        if(col.field == 'extFromDate'){
          if((this.extfdate == undefined || this.extfdate==null)){
            extfromDate = "*";
          }

          else{ 
            extfromDate = this.formatDateForDataBase(this.extfdate);
          }

          if((this.exttdate == undefined || this.exttdate==null)){
            exttoDate = "*";
          }

          else{ 
            exttoDate = this.formatDateForDataBase(this.exttdate);
          }

          col.value = extfromDate+ " -" + exttoDate;

          if((this.extfdate == undefined || this.extfdate==null) && (this.exttdate == undefined || this.exttdate==null)){
            col.value = null;
          }

        }

      });

      if((this.extfdate == undefined || this.extfdate==null)){
        this.sortData.extFromDate = null;
      }

      else{
      
      this.sortData.extFromDate = this.formatDateForDataBase(this.extfdate);
      }


      if((this.exttdate == undefined || this.exttdate==null)){
        this.sortData.extToDate = null;
      }

      else{
        
        this.sortData.extToDate = this.formatDateForDataBase(this.exttdate);
      }
    

      this.sortResult = JSON.stringify(this.sortData);
      // console.log(this.sortResult);
      this.getRecordsFromDB();


    }

    // Filter function for ERR Date field
    errFilterDate() {

        if(this.errfdate != null && this.errtdate != null){
          if (this.errfdate > this.errtdate){
            this.messageService.add({ severity: 'error', summary: "Error Message", 
            detail: `The To date is Greater than From date. Please select appropriate date` });

            this.clearMessage();
            return false;

          }

        }

        let errfromDate:string;
        let errtoDate:string;
      
        this.cols.forEach(col=>{
          
          if(col.field == 'errFromDate'){
            if((this.errfdate == undefined || this.errfdate==null)){
              errfromDate = "*";
            }
    
            else{ 
              
              errfromDate = this.formatDateForDataBase(this.errfdate);
              
            }
    
            if((this.errtdate == undefined || this.errtdate==null)){
              errtoDate = "*";
            }
    
            else{ 
            
            errtoDate = this.formatDateForDataBase(this.errtdate);
            }
    
            col.value = errfromDate+ " -" + errtoDate;
    
            if((this.errfdate == undefined || this.errfdate==null) && (this.errtdate == undefined || this.errtdate==null)){
              col.value = null;
            }
    
          }
        });
    
    
        if((this.errfdate == undefined || this.errfdate==null)){
          this.sortData.errFromDate = null;
        }
    
        else{
          this.sortData.errFromDate = this.formatDateForDataBase(this.errfdate);
        }
    
        if((this.errtdate == undefined || this.errtdate==null)){
          this.sortData.errToDate = null;
        }
    
        else{
          this.sortData.errToDate = this.formatDateForDataBase(this.errtdate);
        }
    
        this.sortResult = JSON.stringify(this.sortData);
        this.getRecordsFromDB();
    

    }

    // This method will Fetch the data  for export to csv
    exportToCSV() {
      // console.log("Export");
      this.errorRecordService.exportToCSVRecords(this.flowName,this.first, this.rows, this.sortResult,this.isIgnoredRecord).subscribe(      
        response => this.downLoadFile(response, "text/csv"),
        // response => console.log(response),
        (error: any) => console.log(error)    
      );
    }

    loadVehsLazy(event: LazyLoadEvent) {
      this.loading = true;

      // this is the method on sort of field
      if (event.multiSortMeta) {

      // let sortData = {} as FilterData;

        // set the default valu as null for sorting & filtering
        Object.assign(this.sortData, {
          vinOrder: null,
          ccpOrder: null,
          vehOrder: null,
          codeErrOrder: null,
          labelErrOrder: null,
          complementErrOrder: null,
          extDateOrder: null,
          errDateOrder: null,
        })


        if (event.multiSortMeta[0].field == 'vin' && event.multiSortMeta[0].order == 1) {
          this.sortData.vinOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);
        }
        else if (event.multiSortMeta[0].field == 'vin' && event.multiSortMeta[0].order == -1) {
          this.sortData.vinOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);
        }

        else if (event.multiSortMeta[0].field == 'ccp' && event.multiSortMeta[0].order == 1) {
          this.sortData.ccpOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'ccp' && event.multiSortMeta[0].order == -1) {
          this.sortData.ccpOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);
        }

        else if (event.multiSortMeta[0].field == 'veh' && event.multiSortMeta[0].order == 1) {
          this.sortData.vehOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'veh' && event.multiSortMeta[0].order == -1) {
          this.sortData.vehOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);

        }

      else if (event.multiSortMeta[0].field == 'codeErr' && event.multiSortMeta[0].order == 1) {
          this.sortData.codeErrOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);
        }
        else if (event.multiSortMeta[0].field == 'codeErr' && event.multiSortMeta[0].order == -1) {
          this.sortData.codeErrOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'labelErr' && event.multiSortMeta[0].order == 1) {
          this.sortData.labelErrOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'labelErr' && event.multiSortMeta[0].order == -1) {
          this.sortData.labelErrOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'complementErr' && event.multiSortMeta[0].order == 1) {
          this.sortData.complementErrOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'complementErr' && event.multiSortMeta[0].order == -1) {
          this.sortData.complementErrOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'extFromDate' && event.multiSortMeta[0].order == 1) {
          this.sortData.extDateOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'extFromDate' && event.multiSortMeta[0].order == -1) {
          this.sortData.extDateOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'errFromDate' && event.multiSortMeta[0].order == 1) {
          this.sortData.errDateOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);

        }
        else if (event.multiSortMeta[0].field == 'errFromDate' && event.multiSortMeta[0].order == -1) {
          this.sortData.errDateOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);

        }


        this.getRecordsFromDB();


      }



    }


    // This method will display the warning message box on Ignore button click
    showWarn() {
      this.msgs = [];
      this.msgs.push({ severity: 'warn', summary: 'Warn Message', detail: 'Please, select at least one vehicle.' });

      this.clearMessage();
    }

    // This method will get the data on click of  Ignore button
    sendIgnoredRecordsToDb() {
    // console.log(this.selectedRecords);

      this.selectedRecords.forEach(record => {
        // console.log(record.currentState);
        record.flowName = this.flowName;
      } )
      
      this.errorRecordService.ignoreRecords(this.selectedRecords).subscribe(

        (data: any) => this.proccessErrManageResponse(data),
        (error: any) => console.log(error)
      )
      this.selectedRecords = [];

    }


    // This method will download the csv file
    downLoadFile(data: any, type: string) {
      
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(data.image, data.filename);
      }

      else{

        const element = document.createElement('a');
        element.href = URL.createObjectURL(data.image);
        element.download = data.filename;
        document.body.appendChild(element);
        element.click();

      }
  
    }

    // This method will show the message after successful data save
    proccessErrManageResponse(data: any) {
      
      let successCount:number=0;
      let errCount:number=0;
  
      let successFiled:string="";
      let errFiled:string="";
  
      data.responseList.forEach(element => {
  
        if (element.msg == true) {
          successCount = successCount+1;
          successFiled = `<div>${successFiled} ${element.id}</div> `;
          
        }
        else if (element.msg == false){
          errCount = errCount+1;
          errFiled = `<div>${errFiled} ${element.id}</div>`
        }
  
      });
  
      if(successCount > 0){
        
        this.messageService.add({ severity: 'success', summary: "Success", 
        detail: `<div>Operation completed successfully </div>
        Updated Parameters are:
          ${successFiled}</br>` 
        });

        this.clearMessage();
      }
  
      else if(errCount > 0){
        this.messageService.add({ severity: 'error', summary: "Error Message", 
        detail: `<div>The total number of records Not updated are ${errCount}</div>
        <div> ${errFiled} </div>` });
        this.clearMessage();
      }

      this.selectedRecords = [];
      // this.ngOnInit();

      this.getRecordsFromDB();
    }


    goToPage(event,vinNumber){
      this.vinForHistory = vinNumber;
      // console.log(this.vinForHistory);
      this.getSelectedVinService.setSelectedVinNumber(this.vinForHistory);

      

      let vinSearch = window.localStorage.getItem("vinSearch");
      // console.log(vinSearch);

      if(vinSearch != null && vinSearch != undefined){
        window.localStorage.removeItem("vinSearch");
        window.localStorage.setItem("vinSearch",this.vinForHistory);
      }
  
      else{
        window.localStorage.setItem("vinSearch",this.vinForHistory);
      }
     
      if(this.vinForHistory){
        this.router.navigate(['/vehicle-details', vinNumber]);
      }

      // Store records for filter
      this.storeFilteredData();
      
    }

    // This will clear the message after 5 sec
    clearMessage(){
      //console.log("clearMessage");
      setTimeout(() =>{
        this.messageService.clear();
      },5000);
    }

    resetExtDate(){
      // this.extfdate = null;
      // this.exttdate = null;

      // this.extFilterDate();

      // console.log(this.extfdate);
      // console.log(this.exttdate);

      if(this.isBack == "true"){
        // console.log("backUpData");
        let backUpData = window.localStorage.getItem("filteredData");
        this.sortData = JSON.parse(backUpData);

        this.extfdate = null;
        this.exttdate = null;

        this.extFilterDate();

        // After reset set filtered data again
        window.localStorage.setItem("filteredData",this.sortResult);
      }

      else{
        // console.log("NO backUpData");
        this.sortResult =this.sortResult;

        this.extfdate = null;
        this.exttdate = null;

        this.extFilterDate();
      }
    }

    resetErrDate(){
      // this.errfdate = null;
      // this.errtdate = null;

      // this.errFilterDate();

      // check for other applied filters
      if(this.isBack == "true"){
        // console.log("backUpData");
        let backUpData = window.localStorage.getItem("filteredData");
        this.sortData = JSON.parse(backUpData);

        this.errfdate = null;
        this.errtdate = null;
        this.errFilterDate();

        // After reset set filtered data again
        window.localStorage.setItem("filteredData",this.sortResult);
      }

      else{
        // console.log("NO backUpData");
        this.sortResult =this.sortResult;

        this.errfdate = null;
        this.errtdate = null;
  
        this.errFilterDate();
      }

      

    }

    
    // Get back flag from Vehicle details page
    getBackFlag(){

      this.isBack = "false";
      // Set the value of Vin number in variable
      this.isBack = window.localStorage.getItem("isBack");
      // console.log(this.isBack);
    }


    storeFilteredData(){

      // console.log(this.sortResult);
      // console.log(this.versionNo);
      
      let isIngonred = `${this.isIgnoredRecord}`
      

      window.localStorage.setItem("flowName",this.flowName);
      window.localStorage.setItem("first",this.first.toString());
      window.localStorage.setItem("rows",this.rows.toString());
      window.localStorage.setItem("filteredData",this.sortResult);
      window.localStorage.setItem("ignoredRecords",isIngonred);

      
      
      let flowName:string = window.localStorage.getItem("flowName");
      let first:string | number = window.localStorage.getItem("first");
      let rows:string | number = window.localStorage.getItem("rows");
      let filteredData = window.localStorage.getItem("filteredData");    
      let ignoredRecords:string = window.localStorage.getItem("ignoredRecords");
      

      // if(filteredData != null || filteredData != undefined){
      //   window.localStorage.setItem("filteredData",this.sortResult);
      // }

      // console.log(flowName);
      // console.log(first);
      // console.log(rows);
      // console.log(filteredData);
      // console.log(ignoredRecords);

    }


}

