export class FilterData{
    vin:string;
    ccp:string;
    veh:string;
    extFromDate:string;
    extToDate:string;
    codeErr:string;
    labelErr:string;
    complementErr:string;
    errFromDate:string;
    errToDate:string;
    vinOrder:string=null;
    ccpOrder:string=null;
    vehOrder:string=null;
    codeErrOrder:string=null;
    labelErrOrder:string=null;
    complementErrOrder:string=null;
    extDateOrder:string=null;
    errDateOrder:string=null; 
    flowName:string;
    flowNameOrder:string = null;


}