export interface IErrorhParameters{
    vin:string,
    ccp:string,
    veh:string,
    extFromDate:Date,
    codeErr:string,
    labelErr:string,
    complementErr:string,
    errFromDate:Date,
    currentState:string,
    flowName:string,
    version:number
}