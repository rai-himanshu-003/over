import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackChangesComponent } from './track-changes.component';

describe('TrackChangesComponent', () => {
  let component: TrackChangesComponent;
  let fixture: ComponentFixture<TrackChangesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackChangesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackChangesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
