export class TrackChnagesHeaders{
    

    tableHeaders= [
        { field: 'dateCreation', header: 'Drop File' },
        { field: 'startDate', header: 'Start' },
        { field: 'endDate', header: 'End' },
        { field: 'duration', header: 'Process Time' },
        { field: 'fileName', header: 'File Name' },
        { field: 'totalCount', header: 'Number of lines' },
        { field: 'successCount', header: 'Number of OK' },
        { field: 'errorCount', header: 'Number of KO' },
        { field: 'userCreation', header: 'User' },
        { field: 'status', header: 'Status' },    
    ]

    statusFilter = [
        // {label: 'SELECT FILTER', value: null},
        {label: 'COMPLETED', value: 'COMPLETED'},
        {label: 'IN_PROGRESS', value: 'IN_PROGRESS'}
      ]

    
}



export interface ItrackChnageData{
  
    id: number;
    dateCreation: Date | number;
    startDate: Date | number;
    endDate: Date | number;
    duration: string;
    fileName:string;
    totalCount:number;
    successCount:number;
    errorCount:number;
    userCreation:string;
    status:string;
    
}