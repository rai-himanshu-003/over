import { Component, OnInit, ViewChild } from '@angular/core';

import { TrackChnagesHeaders, ItrackChnageData } from './track-changes';
import { TrackChnagesService } from '../service/track-changes.service';

import { Table } from 'primeng/table';
import { ExportToCSV } from '../service/exportToCSV.service';
import { OVR_PRD } from '../constant/auth-constant';
import * as lodash from 'lodash';
import { DateFilterService } from '../service/dateFilter.service';


@Component({
  selector: 'app-track-changes',
  templateUrl: './track-changes.component.html',
  styleUrls: ['./track-changes.component.scss'],
  providers:[TrackChnagesHeaders,TrackChnagesService,ExportToCSV]
})
export class TrackChangesComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table;

  // Variable to show data
  tableHeaders:any[] = [];
  tableRecords:ItrackChnageData[] = [];
  updatedRecords: ItrackChnageData[] = [];
  errorMessage: string;

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  totalRecords:number = 0;
  rowsPerPage:number = 0;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  fileTimeStamp = '';
  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  //Variable for Filter
  statusForFilter:any[] = [];

  // Date filter variables
  showDateCreationFilterBox:boolean = false;
  showStartDateFilterBox:boolean = false;
  showEndDateFilterBox:boolean = false;
  
  dateCreationfDate: Date;
  dateCreationtDate: Date;

  startDatefDate:Date;
  startDatetDate:Date;

  endDatefDate:Date;
  endDatetDate:Date;

  constructor(
    private trackChnagesHeaders:TrackChnagesHeaders,
    private trackChnagesService:TrackChnagesService,
    private exportToCSV:ExportToCSV,
    private dateFilterService:DateFilterService
     
    ) { 
      this.statusForFilter = this.trackChnagesHeaders.statusFilter;
    }

  ngOnInit() {

    console.log(this.trackChnagesHeaders.tableHeaders);

    this.tableHeaders = this.trackChnagesHeaders.tableHeaders;

    // This method will fetch records
    this.getRecordsFromDB();

    // export To CSV variables initialise
    this.prdName = OVR_PRD;
    this.exportFile = "_Track-Changes";


    // Header list for export to csv
    for(let i in this.tableHeaders){
      this.headerList.push(this.tableHeaders[i].header);
    }

    // Field list for export to csv
    for(let j in this.tableHeaders){
      this.fieldList.push(this.tableHeaders[j].field);
    }
    

  }

  //====================== Get Records Start =====================

// This method will fetch the records from DB
    getRecordsFromDB() {
      this.trackChnagesService.getRecords().subscribe(
        (data: ItrackChnageData[]) => {
          this.tableRecords = data;
          console.log(this.tableRecords);
          this.updatedRecords = lodash.cloneDeep(this.tableRecords);
          //this.editedTechRecords = data;
          //this.technicalRecords.map(element=> element.id = uuid());
          
          // this.isNewRecord = false;
        },
        (error: any) => this.errorMessage = <any>error
      );
    }
//====================== Get Records Ends =====================

// This method will work for pagination
    paginate(event: any) {
      console.log(event);
      this.first = event.first;
      this.page = event.page;
      this.rows = event.rows;
      this.size = this.table.totalRecords;

    }

//========================== Export To CSV Start ========================//
    exportCSVCommon(){
      // This will add time stamp in the filename while exporting the file    
      this.fileTimeStamp = this.exportToCSV.formatDateForExport();

      // console.log(this.vinForHistory);

      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}-${this.fileTimeStamp}`;

      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }

      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      
      // This method will check null values and replace it with blank space for exl
      this.exportedRecords.forEach(record =>{

        delete record.id;


        if(record.dateCreation != null){
          record.dateCreation = new Date(record.dateCreation as number);
          record.dateCreation = this.exportToCSV.csvDateFormat(record.dateCreation);
          
        }
        else{
          record.dateCreation = " ";
        }

        if(record.startDate != null){
          record.startDate = new Date(record.startDate as number);
          record.startDate = this.exportToCSV.csvDateFormat(record.startDate);
          
        }
        else{
          record.startDate = " ";
        }

        if(record.endDate != null){
          record.endDate = new Date(record.endDate as number);
          record.endDate = this.exportToCSV.csvDateFormat(record.endDate);
          
        }
        else{
          record.endDate = " ";
        }


        if(record.duration != null){
        //  record.duration = new Date(record.duration as number);
         // record.duration = this.exportToCSV.csvDateFormat(record.duration);
         record.duration = JSON.stringify(record.duration);
        }
        else{
          record.duration = " ";
        }

        if(record.fileName == null){
          record.fileName = " ";
        }
        else{
          record.fileName = JSON.stringify(record.fileName);
        }

        if(record.totalCount == null){
          record.totalCount = " ";
        }
        else{
          record.totalCount = JSON.stringify(record.totalCount);
        }

        if(record.successCount == null){
          record.successCount = " ";
        }
        else{
          record.successCount = JSON.stringify(record.successCount);
        }

        if(record.errorCount == null){
          record.errorCount = " ";
        }
        else{
          record.errorCount = JSON.stringify(record.errorCount);
        }

        if(record.userCreation == null){
          record.userCreation = " ";
        }
        else{
          record.userCreation = JSON.stringify(record.userCreation);
        }

        if(record.status == null){
          record.status = " ";
        }
        else{
          record.status = JSON.stringify(record.status);
        }

        
      })

      // console.log(this.exportedRecords);

      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);

    }

//========================== Export To CSV Ends ========================//

//========================== Date Filter Start ========================//

    // this method will show & hide the date filter section
    showDateFilter(event, field: string) {

      if (field == 'dateCreation') {
        this.showDateCreationFilterBox = true;
        this.showStartDateFilterBox = false;
        this.showEndDateFilterBox = false;
      }
  
      else if (field == 'startDate') {
        this.showDateCreationFilterBox = false;
        this.showStartDateFilterBox = true;
        this.showEndDateFilterBox = false;


      }

      else if (field == 'endDate') {
        this.showDateCreationFilterBox = false;
        this.showStartDateFilterBox = false;
        this.showEndDateFilterBox = true;
        
      }
  
  
      else if (field == 'fileName' || field == 'totalCount' || field == 'successCount' || field == 'errorCount' || field == 'userCreation' || field == 'status' || field == 'duration' ) {
        this.showDateCreationFilterBox = false;
        this.showStartDateFilterBox = false;
        this.showEndDateFilterBox = false;
  
      }


    }


    filterDate() {

      let filteredRecord:ItrackChnageData[];

      let dateCreationFromDate:number;
      let dateCreationToDate:number;

      let startDateFromDate:number;
      let startDateToDate:number;

      let endDateFromDate:number;
      let endDateToDate:number;


      // Date Format for Date Creation Field
      dateCreationFromDate = this.dateFilterService.nullCheckFromDate(this.dateCreationfDate,dateCreationFromDate);
          
      dateCreationToDate = this.dateFilterService.nullCheckToDate(this.dateCreationtDate,dateCreationToDate);

      // This will display date in filter box
      this.dateFilterService.showDateRange(dateCreationFromDate,dateCreationToDate,this.tableHeaders,"dateCreation");

      // Date Format for End Date Field

      startDateFromDate = this.dateFilterService.nullCheckFromDate(this.startDatefDate,startDateFromDate);
          
      startDateToDate = this.dateFilterService.nullCheckToDate(this.startDatetDate,startDateToDate);

      // This will display date in filter box
      this.dateFilterService.showDateRange(startDateFromDate,startDateToDate,this.tableHeaders,"startDate");


      // Date Format for End Date Field
      endDateFromDate = this.dateFilterService.nullCheckFromDate(this.endDatefDate,endDateFromDate);
          
      endDateToDate = this.dateFilterService.nullCheckToDate(this.endDatetDate,endDateToDate);

      // This will display date in filter box
      this.dateFilterService.showDateRange(endDateFromDate,endDateToDate,this.tableHeaders,"endDate");


      // Filter date
      filteredRecord = this.updatedRecords.filter(function(record){
        return (record.dateCreation > dateCreationFromDate && record.dateCreation < dateCreationToDate)  
        && (record.startDate > startDateFromDate && record.startDate < startDateToDate)
        && (record.endDate > endDateFromDate && record.endDate < endDateToDate)
      })

      console.log(filteredRecord);
      

      // Assigne filtered vale to table 
      this.tableRecords = filteredRecord;
      this.table.filteredValue = filteredRecord;
      

      
      
    }
   

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {
      this.getRecordsFromDB();
    }

//========================== Date Filter Ends ========================//


  downloadSelectedFile(event){

    console.log(event.target.innerHTML);

    let selectedFile= event.target.innerHTML;

    //  let selectedFile= "20210628185510_null_MM3.xlsx";

    this.trackChnagesService.downloadFileContent(selectedFile);

    this.trackChnagesService.downloadFileContent(selectedFile).subscribe(      
      response => this.downLoadFile(response, "text/csv"),
      // response => console.log(response),
      (error: any) => console.log(error)    
    );
    

  }

  // This method will download the csv file
  downLoadFile(data: any, type: string) {

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    }

    else{

      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      document.body.appendChild(element);
      element.click();

    }
  
  }

  resetDateDrop(){
    this.dateCreationfDate=null;
    this.dateCreationtDate=null;
    this.filterDate();
  }

  resetDateStart(){
  
    this.startDatefDate = null;
    this.startDatetDate = null;
    this.filterDate();
  }

  resetDateEnd(){
    this.endDatefDate=null;
    this.endDatetDate=null;

    this.filterDate();
  }

}
