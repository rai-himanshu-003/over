import { Component, OnInit } from '@angular/core';

import { EnvService } from './env-service/env.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [EnvService],
})
export class AppComponent implements OnInit {

  constructor(private env: EnvService) { }
  title = 'ovr';

  //This method will prevent default right click
  onRightClick() {
        return false;
  }

  ngOnInit() {
    this.env.ngOnInit();
  }
}

