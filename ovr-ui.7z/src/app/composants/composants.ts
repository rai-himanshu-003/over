export interface ITableParameters{
    id:number,
    data: string,
    vin:string,
    dirty:boolean,
    isNew:boolean,
    isDuplicate:boolean
}