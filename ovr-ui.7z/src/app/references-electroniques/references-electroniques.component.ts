import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';

import { GetSelectedVinService } from '../service/getVin.service';
import { AuthenticationService } from '../service/authentication.service';
import { ReferencesElectroniquesService } from '../service/references-electroniques.service';

import { TranslateService } from '@ngx-translate/core';

import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Message, LazyLoadEvent } from 'primeng/components/common/api';

import * as lodash from 'lodash';
import { ITableParameters } from '../models/vehicle-details';

import { OVR_PRD } from '../constant/auth-constant';
import { ProccessResponseService } from '../service/proccessResponse.service';
import { ExportToCSV } from '../service/exportToCSV.service';
import { CompareMaxLimit } from '../shared/services/compareMaxLimit';

@Component({
  selector: 'app-references-electroniques',
  templateUrl: './references-electroniques.component.html',
  styleUrls: ['./references-electroniques.component.scss'],
  providers: [MessageService, ConfirmationService,ExportToCSV,ProccessResponseService,CompareMaxLimit],
  encapsulation: ViewEncapsulation.None,
})
export class ReferencesElectroniquesComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table

  vinForHistory: string;
  vinForRefrences:string;
  errorMessage: string;

  // variable for Admin access 
  isAdmin: boolean;
  isPFA:boolean;
  isReader:boolean;

  // Varoable to show data
  tableHeaders:any[] = [];
  tableRecords:ITableParameters[] = [];
  updatedRecords:ITableParameters[] = [];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  today = new Date();
  fileTimeStamp = '';
  browserLang: string;
  langSelector: string;

  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];


  // Add records variables
  displayDialog: boolean;
  newRow: boolean;
  errorMessageForData:boolean;
  newRecords: ITableParameters[] = [];
  newRecord:any = {};
  selectedRecord:ITableParameters;
  isNewRecord: boolean;

  // Pagination while adding new records
  totalRecords: number = 0;
  rowsPerPage: number;
  lastRowPage: number;

  // Update records variables

  editedRecords: ITableParameters[];
  clonedRecords: { [s: string]: any; } = {};

  // Validate records Variable
  postData: ITableParameters[] = [];

  // Delete records variables

  deleteRecord: any;
  msgs: Message[] = [];

  data:string;
  id:string;
  disableSave:boolean;

  // Variable for max limit of rpo
  maxLimit:any;
  isAddDisable:boolean;
  addBtnTooltip:string;

  constructor(
    private getSelectedVinService:GetSelectedVinService,
    private referencesElectroniquesService:ReferencesElectroniquesService,
    private translate: TranslateService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService,
    private _authService: AuthenticationService,
    private proccessResponseService:ProccessResponseService,
    private exportToCSV:ExportToCSV,
    private compareMaxLimit:CompareMaxLimit
  ) {}

  ngOnInit() {

    // To verify User is Admin or Not
    this.isAdmin = this._authService.isAdmin();
    this.isPFA = this._authService.isPFA();
    this.isReader = this._authService.isReader();

    
    this.tableHeaders = [
      { field: 'id', header: 'ID' },
      { field: 'data', header: 'Value' },
    ]

    //this.vinForHistory = this.getSelectedVinService.getSelectedVinNumber();

    //this.getRecordsFromDB();

    this.storeVin();

    // export To CSV variables initialise
    this.prdName = OVR_PRD;
    this.exportFile = "_References-Electroniques";
    
    // Header list for export to csv
    for(let i in this.tableHeaders){
      this.headerList.push(this.tableHeaders[i].header);
    }

    // Field list for export to csv

    for(let j in this.tableHeaders){
      this.fieldList.push(this.tableHeaders[j].field);
    }
    



  }


  storeVin() {
    
    // Set the value of Vin number in variable
    this.vinForRefrences = window.localStorage.getItem("vinSearch");

    // If value is not null or undefined then call get data
    if(this.vinForRefrences !=null && this.vinForRefrences != undefined){
      window.localStorage.setItem("vinForRefrences",this.vinForRefrences);
      this.getRecordsFromDB();
    }
    
  }


  getRecordsFromDB(){

    let vinNumber:string =  window.localStorage.getItem("vinForRefrences");

    if(vinNumber !=null && vinNumber != undefined){
      //console.log("vin"+ vinNumber);
      this.vinForHistory = vinNumber;
      //console.log(this.vinForHistory);
    }

    else{
      console.log("no Vin found");
    }

    this.referencesElectroniquesService.getRecords(this.vinForHistory).subscribe(
      
      (data:any) => {
        this.tableRecords = data.datalist;
        this.updatedRecords = lodash.cloneDeep(this.tableRecords);

        // Compare for max limit
        this.maxLimit = data.totalNumberOfRecords;
        this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
        this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);
        
      },
      (error:any) => this.errorMessage = <any> error

    )

  }


  //======================== Reset records Start=========================

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {
      this.getRecordsFromDB();

      this.errorMessageForData = false;
      // Disable Validate
      this.isNewRecord = false;

      // Go to first page
      this.first = 0;

    }

  //======================== Reset records Ends=========================

  //=========================== Add Start===============================

    showDialogToAdd() {
      
  
      // Reset all error messages to false
      this.errorMessageForData = false;
  
      // Set new record to null / empty
      this.newRecord = {};
  
      // Set flag of new record
      this.newRow = true;
  
      // Display Dialoug box
      this.displayDialog = true;

      if(this.tableRecords.length == this.updatedRecords.length){

        // Reset Sort 
        if(this.table.sortOrder != 0){
          this.table.sortOrder = 0;
          this.table.sortField = '';
          this.table.reset();
          this.getRecordsFromDB();
        }

        // Reset Filter 

        if(this.table.filteredValue !== undefined){
          this.data = undefined;
          this.id = undefined;
          this.table.reset();

        }

      }



    }
  
    save(){
  
      // copy all previous records in new list
      this.newRecords = [...this.tableRecords];

      this.errorMessageForData = false;

      // Reset Filter Value
      // this.data = undefined;
      // this.table.reset();
  
      // For new Record
      if (this.newRow) {
        // check for Null and Blank record

        this.newRecord.vin = this.vinForHistory;
        this.newRecord.id = null;
  
        if (this.newRecord.data == null || this.newRecord.data == "" || this.newRecord.data == " ") {
  
          this.displayDialog = true;
          this.errorMessageForData = true;
        }
  
        else{
  
          // claculate last row of total records before pushing the new record in table
          this.totalRecords = this.table.totalRecords;
          this.rowsPerPage = this.rows;
  
          if (this.totalRecords < 10) {
            this.lastRowPage = 0;
            
          }
          else {
            this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
            
          }
  
          this.first = this.rowsPerPage * this.lastRowPage;
  
          // Insert New record after claculating last row
          this.newRecords.push(this.newRecord);
          this.displayDialog = false;
          this.newRecord.isNew = true;
          this.isNewRecord = true;
  
          this.tableRecords = this.newRecords;

  
        }

        // Check for max limit

        this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
        this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);
      }
  
    }
  
    cancel(){
      let index = this.newRecords.indexOf(this.selectedRecord);
      this.newRecords = this.newRecords.filter((val, i) => i != index);
      this.newRecord = null;
      this.displayDialog = false;

      this.errorMessageForData = false;
    }
  
  //=========================== Add Ends================================


  //======================== Update Start===============================

    onRowEditInit(editedRecord: ITableParameters) {
        this.clonedRecords[editedRecord.id] = {...editedRecord};
    }

    onRowEditSave(editedRecord: ITableParameters,index: number) {

      editedRecord.dirty = true;
      this.isNewRecord = true;
      editedRecord.vin = this.vinForHistory;

      this.clonedRecords[editedRecord.id] = { ...editedRecord }; 

      

    }

    onRowEditCancel(editedRecord: ITableParameters,index: number) {

      this.editedRecords = this.tableRecords;
      this.editedRecords[index] = this.clonedRecords[editedRecord.id];
      delete this.clonedRecords[editedRecord.id];

      this.errorMessageForData = false;
    }


  //======================== Update Ends===============================

    //======================== Validate Start=============================
    validateRecord(event: Event) {
      
      // This will reset the Post data
      this.postData = [];
      // This function will compare the prvious value & updated value
      // for (let i = 0; i < this.tableRecords.length; i++) {
      //   if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.tableRecords[i])) {
      //     this.postData.push(this.tableRecords[i]);
          
      //   }
  
      // }

      for (let i = 0; i < this.tableRecords.length; i++) {
        if(this.tableRecords[i].dirty == true || this.tableRecords[i].isNew == true){
          // console.log(this.tableRecords[i].id);
          this.postData.push(this.tableRecords[i]);
        }
      }
  
      let updatedData: any = this.postData;
  
      // This method will update the records in DB on click of validate button
      this.referencesElectroniquesService.updateRecords(this.postData).subscribe(
  
        (data: any) =>{ 
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();

          // This will refresh the whole Page => code to solve version issue
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        },
        
  
        (error: any) => console.log(error)
      )

      this.isNewRecord = false;
      
    }

    valueChanged(changedRecord: ITableParameters){

      this.errorMessageForData = false;
      this.disableSave = false;

      if(changedRecord.data == ""){
        this.disableSave = true;
        this.errorMessageForData = true;
      }

    }
  
    //======================== Validate Ends=============================
  //=========================== Delete Starts=========================

  // This method will Delete row in table
  deleteRow(tableRow: any, index: number) {

    this.deleteRecord = tableRow;
    
    // This method will update the records in DB on click of validate button
    //this.deleteRecordsFromDB();

    this.referencesElectroniquesService.deleteRecords(this.deleteRecord).subscribe(

      (data: any) => {
        
        let res ={...data.responseList};
        let resMsg = res[0].msg;
        let tableRow = this.deleteRecord;

        if (resMsg == true) {

          // this.msgs = [{severity:'error', summary:'Warning', detail:`${tableRow.id} is  deleted`}];
          this.messageService.add({ severity: 'error', summary: 'Deleted', detail: `${tableRow.id}` });
          this.getRecordsFromDB();
        }
        else {
          this.msgs = [{ severity: 'error', summary: 'Error', detail: `${tableRow.id} not found` }];
          this.getRecordsFromDB();
        }

        this.proccessResponseService.clearMessage();

      },
      (error: any) => console.log(error)
    )


  }

  // Show confirmation box before delete function

  confirmDelete(tableRow: any, index: number) {
    
    this.confirmationService.confirm({

      accept: () => {
        this.deleteRow(tableRow, index);
      },
      reject: () => {
        //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
      }
    });
  }

  //=========================== Delete Ends=========================

    exportCSVCommon(){
      // This will add time stamp in the filename while exporting the file    
      this.fileTimeStamp = this.exportToCSV.formatDateForExport();
  
      
      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}${this.vinForHistory}${this.fileTimeStamp}`;
  
      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }
  
      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }
  
      
      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);
  
    }

}
