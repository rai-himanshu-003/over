import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferencesElectroniquesComponent } from './references-electroniques.component';

describe('ReferencesElectroniquesComponent', () => {
  let component: ReferencesElectroniquesComponent;
  let fixture: ComponentFixture<ReferencesElectroniquesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReferencesElectroniquesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferencesElectroniquesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
