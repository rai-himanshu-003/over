export class FilterData{
    interfaceName:string;
    fileName:string;
    successCount:number;
    dateCreation:Date;
    errorCount:number;
    userCreation:string;
    interfaceOrder:string;
    fileNameOrder:string;
    successCountOrder:string;
    dateCreationOrder:string;
    errorCountOrder:string;
    userCreationOrder:string;
    fromDateCreation:string;
    toDateCreation:string;
}
