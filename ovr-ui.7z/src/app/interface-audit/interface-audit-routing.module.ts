import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InterfaceAuditComponent } from './interface-audit.component';


const routes: Routes = [
  {
      path: '',
      component: InterfaceAuditComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes,)],
  exports: [RouterModule]
})

export class InterfaceAuditRoutingModule { }