import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';

import { IAuditParameters } from './interface-audit';

import { PaginatorModule } from 'primeng/paginator';
import { ArrayIterator } from 'lodash';

import { LazyLoadEvent } from 'primeng/api';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/api';

import { ConfirmationService } from 'primeng/api';

import { TableHeaderCheckbox, Table } from 'primeng/table';

import { FilterData } from './filter-data';

import { AuditRecordService } from '../service/interface-audit.service';
import { connect } from 'net';
import { GetSelectedInterfaceService } from '../service/getInterfaceName.service';

@Component({
  selector: 'app-interface-audit',
  templateUrl: './interface-audit.component.html',
  styleUrls: ['./interface-audit.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None,
})



export class InterfaceAuditComponent implements OnInit {

 // variable for columns 
 cols: any[];

 // variable for data
 auditRecords:IAuditParameters[]= [];


 // Sort Variables
 sortData = {} as FilterData;
 sortResult: string;

 // pagination variables
 first: number = 0;
 page: number;
 rows: number = 10;
 size: number;
 totalNumberRecords:number;

 // lazy loading variable
 loading: boolean;

 // Date filter variables
 extshowDateContainer: boolean = false;
 frdate: Date;
 todate: Date;

 // Warning message
 msgs: Message[] = [];
 selectedInterfaceName:String;

 constructor(
  private auditRecordService:AuditRecordService,
  private messageService: MessageService,
  private getSelectedInterfaceService:GetSelectedInterfaceService,
) { }

ngOnInit() {
  // set default value of variables required for Header of table
  this.cols = [
    { field: 'interfaceName', header: 'INTERFACE' },
    { field: 'fileName', header: 'FILE PROCESSED' },
    { field: 'successCount', header: 'SUCCESS COUNT' },
    { field: 'errorCount', header: 'ERROR COUNT' },
    { field: 'userCreation', header: 'CREATED BY' },
    { field: 'dateCreation', header: 'CREATED ON' }
  ];

  // set the default valu as null for sorting & filtering
  Object.assign(this.sortData, {
    interfaceName:null,
    userCreation:null,
    successCount:null,
    errorCount:null,
    fileName:null,
    dateCreation:null,
    fromDateCreation:null,
    toDateCreation:null,
    interfaceOrder:null,
    fileNameOrder:null,
    successCountOrder:null,
    dateCreationOrder:null,
    errorCountOrder:null,
    userCreationOrder:null
  })
  this.sortResult = JSON.stringify(this.sortData);
  // this method will show data on page load

  this.selectedInterfaceName = this.getSelectedInterfaceService.getSelectedInterafce();
  if(this.selectedInterfaceName!=null)
  {
  this.interfaceSort(this.selectedInterfaceName);
  this.getRecordsFromDB();
  }else{
    this.getRecordsFromDB();
  }

}
  // This method will fetech the records from DB
  getRecordsFromDB() {
     this.loading = true;
    this.auditRecordService.getRecords(this.first, this.rows, this.sortResult).subscribe(

      (data: any) => {

        console.log(data);
        this.totalNumberRecords = data.totalNumberOfRecords;
        this.auditRecords = data.datalist;
        
        console.log(this.auditRecords);
        //console.log(this.totalNumberRecords);
        this.loading = false;
      },
      (error: any) => {
        console.log(error);
        // this.errorMessage = <any>error
         this.loading = false;
      }
    );

  }

  // This method will work for pagination
  paginate(event: any) {
    this.first = event.first;
    this.page = event.page;
    this.rows = event.rows;
    this.getRecordsFromDB();
  }

    // This method will Fetch the data  for export to csv


  // This method will give lazy loading and sorting method
  loadAuditLazy(event: LazyLoadEvent){
    this.loading = true;
    // this method will sort the data
    if (event.multiSortMeta) {
     // console.log(event.multiSortMeta);

      // set the default valu as null for sorting & filtering
      Object.assign(this.sortData, {
        interfaceOrder:null,
        fileNameOrder:null,
        successCountOrder:null,
        dateCreationOrder:null,
        errorCountOrder:null,
        userCreationOrder:null
      })


      if (event.multiSortMeta[0].field == 'interfaceName' && event.multiSortMeta[0].order == 1) {
        this.sortData.interfaceOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
        console.log(this.sortResult);
      }
      else if (event.multiSortMeta[0].field == 'interfaceName' && event.multiSortMeta[0].order == -1) {
        this.sortData.interfaceOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);
        console.log(this.sortResult);
      }

      else if (event.multiSortMeta[0].field == 'fileName' && event.multiSortMeta[0].order == 1) {
        this.sortData.fileNameOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'fileName' && event.multiSortMeta[0].order == -1) {
        this.sortData.fileNameOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);
      }

      else if (event.multiSortMeta[0].field == 'dateCreation' && event.multiSortMeta[0].order == 1) {
        this.sortData.dateCreationOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'dateCreation' && event.multiSortMeta[0].order == -1) {
        this.sortData.dateCreationOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'errorCount' && event.multiSortMeta[0].order == 1) {
        this.sortData.errorCountOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'errorCount' && event.multiSortMeta[0].order == -1) {
        this.sortData.errorCountOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'successCount' && event.multiSortMeta[0].order == 1) {
        this.sortData.successCountOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'successCount' && event.multiSortMeta[0].order == -1) {
        this.sortData.successCountOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'userCreation' && event.multiSortMeta[0].order == 1) {
        this.sortData.userCreationOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'userCreation' && event.multiSortMeta[0].order == -1) {
        this.sortData.userCreationOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }


      console.log(this.sortData);
      this.getRecordsFromDB();

    }
  }


    // This method will filter data on key down event
    onKeydown(event, field: string) {

      if (field == 'interfaceName') {
        this.sortData.interfaceName = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (field == 'fileName') {
        this.sortData.fileName = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }
  
      else if (field == 'successCount') {
        if(event.target.value == ""){
          this.sortData.successCount = null;
        }
        else{
          this.sortData.successCount = event.target.value;
        }
        
        this.sortResult = JSON.stringify(this.sortData);
      }
  
      else if (field == 'errorCount') {
        if(event.target.value == ""){
          this.sortData.errorCount = null;
        }
        else{
          this.sortData.errorCount = event.target.value;
        }
        
        this.sortResult = JSON.stringify(this.sortData);
      }

      else if (field == 'userCreation') {
        this.sortData.userCreation = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }
  
      else if (field == 'dateCreation') {
        this.sortData.dateCreation = event.target.value;
        this.sortResult = JSON.stringify(this.sortData);
      }
  
  
      //console.log(this.sortResult);

      this.first = 0;
      this.getRecordsFromDB();
  
    }

    // this method will show & hide the date filter section
    showDateFilter(event, field: string) {
    //console.log(field);

      if (field == 'dateCreation') {
        this.extshowDateContainer = true;
      }

      else if (field == 'interfaceName' || field == 'fileName' || field == 'successCount' || field == 'errorCount' || field == 'userCreation') {
        this.extshowDateContainer = false;  
      }
    }

    // Filter function for EXt Date field

    // Filter function for EXt Date field
    extFilterDate() {

      if(this.frdate != null && this.todate != null){
        
        if (this.frdate > this.todate){
          
          this.messageService.add({ severity: 'error', summary: "Error Message", 
          detail: `The To date is Greater than From date. Please select appropriate date` });
    
          return false;
       }
  
      }
  
      let fromDateCreation:string;
      let toDateCreation:string;
  
      this.cols.forEach(col=>{
        
        if(col.field == 'dateCreation'){
          if((this.frdate == undefined || this.frdate==null)){
            fromDateCreation = "*";
          }
  
          else{ 
            fromDateCreation = this.formatDateForDataBase(this.frdate);
          }
  
          if((this.todate == undefined || this.todate==null)){
            toDateCreation = "*";
          }
  
          else{ 
            toDateCreation = this.formatDateForDataBase(this.todate);
          }
  
          col.value = fromDateCreation+ " -" + toDateCreation;
  
          if((this.frdate == undefined || this.frdate==null) && (this.todate == undefined || this.todate==null)){
            col.value = null;
          }
  
        }
  
      });
  
      if((this.frdate == undefined || this.frdate==null)){
        this.sortData.fromDateCreation = null;
      }
  
      else{
       
       this.sortData.fromDateCreation = this.formatDateForDataBase(this.frdate);
      }
  
      if((this.todate == undefined || this.todate==null)){
        this.sortData.toDateCreation = null;
      }
  
      else{
        
        this.sortData.toDateCreation = this.formatDateForDataBase(this.todate);
      }
  
      
      this.sortResult = JSON.stringify(this.sortData);
      console.log(this.sortResult);
      this.getRecordsFromDB();
  
  
    }

    resetExtDate(){
      this.frdate = null;
      this.todate = null;

      this.extFilterDate();
    }

  

    // This method will format the input date to comapre
    formatDateForDataBase(dateOfUser: any) {
      
      let date = new Date(dateOfUser);
      let dd;
      let mm;
      let mbefore:number = (date.getMonth()+1);

      if(date.getDate() < 10){
        dd= "0"+date.getDate();
      }
      else{
        dd = date.getDate();
      }

      if( (date.getMonth() + 1) < 10){
        mm= "0"+ (date.getMonth()+1);
      }

      else{
        mm = mbefore;
      }

      return dd + '/'  + mm + '/' + date.getFullYear();
    }


    // This method will Fetch the data  for export to csv
    exportToCSV() {
      this.auditRecordService.exportToCSVRecords(this.first, this.rows, this.sortResult).subscribe(      
        response => this.downLoadFile(response, "text/csv"),
        (error: any) => console.log(error)    
      );
    }
  
    // This method will download the csv file
    downLoadFile(data: any, type: string) {
      
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
  
    }
  
    else{
      
        const element = document.createElement('a');
        element.href = URL.createObjectURL(data.image);
        element.download = data.filename;
        document.body.appendChild(element);
        element.click();
      
    }
  
  
    
    }
 
    // this method will sort the data based on interface name

    interfaceSort(interfaceName){
      this.sortData.interfaceName = interfaceName;
      this.sortResult = JSON.stringify(this.sortData);

      this.cols.forEach(col=>{
      
        if(col.field == 'interfaceName'){
          
          col.value = interfaceName;
        }

      });
      
      this.getRecordsFromDB();

      
    }


}