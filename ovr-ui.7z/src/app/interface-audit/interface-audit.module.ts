import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {PaginatorModule} from 'primeng/paginator';
import {ButtonModule} from 'primeng/button';
import {CalendarModule} from 'primeng/calendar';
import { TooltipModule } from 'primeng/tooltip';

import { InterfaceAuditRoutingModule } from './interface-audit-routing.module';
import { InterfaceAuditComponent } from './interface-audit.component';




@NgModule({
    imports:[
        CommonModule,
        InterfaceAuditRoutingModule,
        FormsModule,
        TableModule,
        PaginatorModule,
        ButtonModule,
        CalendarModule,
        TranslateModule,
        TooltipModule
    ],
    declarations:[InterfaceAuditComponent],
    providers:[],

})

export class InterfaceAuditModule {}
