export interface IAuditParameters{
    interfaceName:string,
    fileName:string,
    successCount:number,
    dateCreation:Date,
    errorCount:number,
    userCreation:string

}