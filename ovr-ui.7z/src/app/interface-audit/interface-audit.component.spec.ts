import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterfaceAuditComponent } from './interface-audit.component';

describe('InterfaceAuditComponent', () => {
  let component: InterfaceAuditComponent;
  let fixture: ComponentFixture<InterfaceAuditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterfaceAuditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterfaceAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
