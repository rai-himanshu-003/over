import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';


import * as lodash from 'lodash';
import { Table } from 'primeng/table';
import{OVR_PRD} from '../constant/auth-constant';

import { VehicleDetailsService } from '../service/vehicle-details.service';
import { ExportToCSV } from '../service/exportToCSV.service';
import { DateFormatterService } from '../shared/services/dateFormater.service';
import { IVehicleHisporyParameters, VehicleHistoryTabHeaders } from './vehicle-history-tab';

@Component({
  selector: 'app-vehicle-history-tab',
  templateUrl: './vehicle-history-tab.component.html',
  styleUrls: ['./vehicle-history-tab.component.scss'],
  providers: [VehicleHistoryTabHeaders,VehicleDetailsService,ExportToCSV,DateFormatterService],
  encapsulation: ViewEncapsulation.None
})
export class VehicleHistoryTabComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table;

  // Variable to show data
  cols: any[];
  vehicleHistoryRecords:IVehicleHisporyParameters[]=[];
  updatedRecords:any[]=[];
  errorMessage: string;
  
  vinForHistory:string;
  vinForErrorHistory:string;

  // pagination variables
  first: number = 0;
  page: number;
  rows: number;
  size: number;

  // export To CSV variables
  prdName:string;
  exportFile:string;
  today = new Date();
  fileTimeStamp='';
  browserLang:string;
  langSelector:string;
  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  // Date filter Variables
  showDateFilterContainer:boolean;
  fdate:Date;
  tdate:Date;

  constructor(
    private vehicleHistoryTabHeaders:VehicleHistoryTabHeaders,
    private vehicledetailsservice:VehicleDetailsService,
    private exportToCSV:ExportToCSV,
    private dateFormatterService: DateFormatterService
  ) { }

  ngOnInit() {

    // Initialize required variables 
    this.rows = 10;
    this.prdName = OVR_PRD;
    this.exportFile = "_VehicleHistory";

    this.cols = this.vehicleHistoryTabHeaders.tableHeaders;

    // this.cols = [
    //   { field: 'actionType', header: 'Action Type' },
    //   { field: 'typeData', header: 'Type Data' },
    //   { field: 'oldValue', header: 'Value' },
    //   { field: 'standard', header: 'Standard' },
    //   { field: 'id', header: 'ID' },
    //   { field: 'label', header: 'Label' },
    //   { field: 'part', header: 'Part' },
    //   { field: 'supplier', header: 'Supplier' },
    //   { field: 'data', header: 'Data' },
    //   { field: 'userID', header: 'User ID' },
    //   { field: 'dateOperation', header: 'Date Operation' },
    // ]

    this.storeVin();

    // Header list for export to csv

    for(let i in this.cols){
      this.headerList.push(this.cols[i].header);

    }

    // Field list for export to csv

    for(let j in this.cols){
      this.fieldList.push(this.cols[j].field);

    }

  }


    storeVin() {
      
      // Set the value of Vin number in variable
      this.vinForErrorHistory = window.localStorage.getItem("vinSearch");

      // If value is not null or undefined then call get data
      if(this.vinForErrorHistory !=null && this.vinForErrorHistory != undefined){
        window.localStorage.setItem("vinForErrorHistory",this.vinForErrorHistory);
        this.getRecordsFromDB();
      }
      
    }

    // This method will fetch the records from DB
    getRecordsFromDB() {

      let vinNumber:string =  window.localStorage.getItem("vinForErrorHistory");
  
      if(vinNumber !=null && vinNumber != undefined){
        //console.log("vin"+ vinNumber);
        this.vinForHistory = vinNumber;
        //console.log(this.vinForHistory);
      }
  
      else{
        console.log("no Vin found");
      }
  
      this.vehicledetailsservice.getRecords(this.vinForHistory).subscribe(
        (data: any) => {
          this.vehicleHistoryRecords = data.vehicleHistory;
          console.log(this.vehicleHistoryRecords);
          
          
          this.updatedRecords = lodash.cloneDeep(this.vehicleHistoryRecords);
          
  
          this.vehicleHistoryRecords.map(element => {
            element.dateOperation = new Date(element.dateOperation as number);
            // element.dateOperation = this.exportToCSV.csvDateFormat(element.dateOperation);
            if(element.oldValue == null && element.value == null){
              element.oldValue = " ";
            }
            else{
              if(element.oldValue == null){
                element.oldValue = " ";
              }
              if(element.value == null){
                element.value = " ";
              }

              element.oldValue = element.oldValue +" => " + element.value;

            }

            
          });
        },
        (error: any) => this.errorMessage = <any>error
      );
    }

    // Export to CSV
    exportCSVForAll(){

      // This will add time stamp in the filename while exporting the file    
      // this.fileTimeStamp = this.formatDateForExport(); 

      this.fileTimeStamp = this.dateFormatterService.formatDateForExport(); 
    
      // This will give file Name for exported file
      // let filename = `${this.prdName}${this.exportFile}${this.fileTimeStamp}`;
      let filename = `${this.prdName}_${this.vinForHistory}_${this.exportFile}${this.fileTimeStamp}`;


      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }
      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      console.log(this.exportedRecords);

      this.exportedRecords.forEach(record =>{

        record.dateOperation = new Date(record.dateOperation as number);

        if(record.actionType == null){
          record.actionType = " ";
        }

        if(record.typeData == null){
          record.typeData = " ";
        }

        // if(record.oldValue == null){
        //   record.oldValue = " ";
        // }

        // if(record.value == null){
        //   record.value = " ";
        // }

        if(record.standard == null){
          record.standard = " ";
        }

        if(record.id == null){
          record.id = " ";
        }

        if(record.label == null){
          record.label = " ";
        }

        if(record.part == null){
          record.part = " ";
        }

        if(record.supplier == null){
          record.supplier = " ";
        }

        if(record.data == null){
          record.data = " ";
        }

        if(record.userId == null){
          record.userId = " ";
        }

        if(record.dateOperation != null){
          record.dateOperation = this.exportToCSV.csvDateFormat(record.dateOperation);
        }
        else{
          record.dateOperation = " ";
        }
        
      })

      console.log(this.exportedRecords);
      console.log("fieldList-",this.fieldList);
      console.log("headerList-",this.headerList);
      
      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);
    }

    // This method will filter the date from UI side
    showDateFilter(event, field: string) {

      if (field == 'dateOperation') {
        this.showDateFilterContainer = true;
      }
  
      else {
        this.showDateFilterContainer = false;
      }
    }
  
    filterDate() {
  
      let fromDate:number;
      let toDate:number;
      let filteredRecord:IVehicleHisporyParameters[];
  
      fromDate = this.dateFormatterService.nullCheckFromDate(this.fdate,fromDate);
      toDate = this.dateFormatterService.nullCheckToDate(this.tdate,toDate);
            
      filteredRecord = this.updatedRecords.filter(function(record){
        return record.dateOperation > fromDate && record.dateOperation < toDate
  
      })
  
      // This will display date in filter box    
  
      let fromDateString:string;
      let toDateString:string;
  
      this.dateFormatterService.showDateRange(fromDate,toDate,"dateOperation",this.cols);
  
      this.vehicleHistoryRecords = filteredRecord
  
    }
  
    resetDate(){
  
      this.fdate = null;
      this.tdate = null;
  
      this.filterDate();
    }

}
