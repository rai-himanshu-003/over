export interface IVehicleHisporyParameters{
    actionType:string,
    typeData:string,
    value:string,
    oldValue:string,
    standard:string,
    id:string
    label:string,
    part:string,
    supplier:string,
    data:string
    userId:string,
    dateOperation: Date | number

}


export class VehicleHistoryTabHeaders{
    

    tableHeaders= [

        { field: 'actionType', header: 'Action Type' },
        { field: 'typeData', header: 'Type Data' },
        { field: 'oldValue', header: 'Value' },
        { field: 'standard', header: 'Standard' },
        { field: 'id', header: 'ID' },
        { field: 'label', header: 'Label' },
        { field: 'part', header: 'Part' },
        { field: 'supplier', header: 'Supplier' },
        { field: 'data', header: 'Data' },
        { field: 'userId', header: 'User ID' },
        { field: 'dateOperation', header: 'Date Operation' },
    ]
    
}