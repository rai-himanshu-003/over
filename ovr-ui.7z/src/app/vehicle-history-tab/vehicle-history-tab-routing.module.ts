import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VehicleHistoryTabComponent } from './vehicle-history-tab.component';


const routes: Routes = [
  {
      path: '',
      component: VehicleHistoryTabComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes,)],
  exports: [RouterModule]
})

export class VehicleHistoryTabRoutingModule { }
