import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleHistoryTabComponent } from './vehicle-history-tab.component';

describe('VehicleHistoryTabComponent', () => {
  let component: VehicleHistoryTabComponent;
  let fixture: ComponentFixture<VehicleHistoryTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehicleHistoryTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehicleHistoryTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
