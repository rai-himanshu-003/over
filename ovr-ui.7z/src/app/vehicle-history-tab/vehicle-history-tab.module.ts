import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { VehicleHistoryTabRoutingModule } from './vehicle-history-tab-routing.module';
import { VehicleHistoryTabComponent } from './vehicle-history-tab.component';


import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {TooltipModule} from 'primeng/tooltip';
import {CalendarModule} from 'primeng/calendar';
import {MultiSelectModule} from 'primeng/multiselect';


@NgModule({

  imports: [
    CommonModule,
    VehicleHistoryTabRoutingModule,
    TranslateModule,
    TableModule,
    ButtonModule,
    TooltipModule,
    CalendarModule,
    MultiSelectModule
  ],

  declarations: [VehicleHistoryTabComponent],

})

export class StateHistoryModule { }
