import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { FormGroup,FormControl, FormBuilder, Validators } from '@angular/forms'

import { TranslateService } from '@ngx-translate/core';
import * as lodash from 'lodash';

import { VehicleDetailsService } from '../service/vehicle-details.service';
import { VehicleDetailsParameters } from './vehicle-details';
import { GetSelectedVinService } from '../service/getVin.service';


import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/api';
import { AuthenticationService } from '../service/authentication.service';



@Component({
  selector: 'app-vehicle-details',
  templateUrl: './vehicle-details.component.html',
  styleUrls: ['./vehicle-details.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None
})
export class VehicleDetailsComponent implements OnInit {

  isAdmin: boolean;

  constructor(
    private vehicledetailsservice:VehicleDetailsService,
    private getSelectedVinService:GetSelectedVinService,
    private messageService: MessageService,
    private translate: TranslateService,
    private _authService: AuthenticationService,

  ) {
      //this.getCurrentStateListFromDB();

      this.isAdmin =this._authService.isAdmin();




   }

  ngOnInit() {}


}
