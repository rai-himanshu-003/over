export class VehicleDetailsParameters{
    version: string;
    vin:string;
    ccp:string;
    veh:string;
    stateId:string;
    xmlOv:string;
    lcdvOtt:string;
    isDirty:boolean
}