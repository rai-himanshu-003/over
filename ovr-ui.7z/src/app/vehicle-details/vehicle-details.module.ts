import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';
//import { ReactiveFormsModule } from '@angular/forms';

import { VehicleDetailsComponent } from './vehicle-details.component';
import { VehicleDetailsRoutingModule } from './vehicle-details-routing.module';


import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {DropdownModule} from 'primeng/dropdown';
import {ButtonModule} from 'primeng/button';
import {TooltipModule} from 'primeng/tooltip';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {PanelModule} from 'primeng/panel';
import {AccordionModule} from 'primeng/accordion';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';


import { VehicleMetadataComponent } from '../vehicle-metadata/vehicle-metadata.component';
import { OptionsComponent } from '../options/options.component';
import { ComposantsComponent } from '../composants/composants.component';
import { ReferencesElectroniquesComponent } from '../references-electroniques/references-electroniques.component';
import { ComposantsOvComponent } from '../composants-ov/composants-ov.component';
import { LcdvOttComponent } from '../lcdv-ott/lcdv-ott.component';
import { ArtLcdvComponent } from '../art-lcdv/art-lcdv.component';





@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    TooltipModule,
    //ReactiveFormsModule,
    VehicleDetailsRoutingModule,
    TranslateModule,
    TableModule,
    DropdownModule,
    ButtonModule,
    MessagesModule,
    MessageModule,
    PanelModule,
    AccordionModule,
    DialogModule,
    ConfirmDialogModule
    
  ],

  declarations: [
    VehicleDetailsComponent,
    VehicleMetadataComponent,
    ComposantsComponent,
    ReferencesElectroniquesComponent,
    ComposantsOvComponent,
    LcdvOttComponent,
    OptionsComponent,
    ArtLcdvComponent
  ],
    

})

export class VehicleDetailsModule { }
