import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';
import { Router } from '@angular/router';
import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_TOKEN_NAME, LOCAL_STORAGE_USER_NAME } from '../constant/auth-constant';
import * as jwt_decode from 'jwt-decode';
import { TranslateService } from '@ngx-translate/core';
import {MessageService} from 'primeng/api';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username: string = '';
  password: string = '';
  errorMessage: string = '';

  // variable for Admin access 
  isAdmin: boolean;
  isPFA:boolean;
  isReader:boolean;

  constructor(
    private messageService: MessageService,
    private translate: TranslateService,
    private _authService: AuthenticationService,
    private _router: Router
  ) {
    this.translate.addLangs(['en', 'fr', 'ur', 'es', 'it', 'fa', 'de', 'zh-CHS']);
  }

  ngOnInit() {

    // this.getUserDetails();    
  }

  login() {
    //console.log("I am Clicked");
    this.errorMessage = '';


    
    this._authService.login(this.username, this.password).subscribe(
      success => {
        //console.log("success");
        let token : string = success.headers.get('authorization');
        LocalStorage.addItem(LOCAL_STORAGE_TOKEN_NAME, token);
        //console.log(jwt_decode(token));
        
        // created a variable to store the jwt token value
        let decodeToken:any;
        decodeToken= jwt_decode(token);

        LocalStorage.addItem(LOCAL_STORAGE_USER_NAME, decodeToken.payload);
        console.log(decodeToken);
        

        // Get user details
        this.getUserDetails();
        
        // Check user role and then navigate
        //To verify User is Admin or Not
        this.isAdmin = this._authService.isAdmin();
        this.isPFA = this._authService.isPFA();
        this.isReader = this._authService.isReader();

        if(this.isReader == true){
          console.log("isReader");
          
          this._router.navigate(['/vehicle-search']);

        }
        else{
          console.log("isAdmin");
          //this._router.navigate(['/dashboard']);
          this._router.navigate(['/error-management']);

        }



        
      },
      error => {
        console.log(error);
        this.errorMessage = 'Login failed';       
      }
    );
  }

  getUserDetails(){

    let browserLang = this.translate.getBrowserLang();

    this._authService.getUserData(this.username,"LANGUAGE",browserLang).subscribe(
      (data:any) => {
        // console.log(data);
        let language = data.value;

        console.log(language);
        // this.translate.use(language);
      },
      (error: any) => console.log(error)
    )

  }
  
}
