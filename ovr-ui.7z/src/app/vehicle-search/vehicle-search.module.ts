import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

import { VehicleSearchComponent } from './vehicle-search.component';
import { VehicleSearchRoutingModule } from './vehicle-search-routing.module';
import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {PaginatorModule} from 'primeng/paginator';
import {ButtonModule} from 'primeng/button';
import {CalendarModule} from 'primeng/calendar';
import {MultiSelectModule} from 'primeng/multiselect';
import {TooltipModule} from 'primeng/tooltip';



@NgModule({
    imports:[
        CommonModule,
        VehicleSearchRoutingModule,
        FormsModule,
        TableModule,
        PaginatorModule,
        ButtonModule,
        CalendarModule,
        TranslateModule,
        MultiSelectModule,
        TooltipModule
    ],
    declarations:[VehicleSearchComponent],
    providers:[],

})

export class VehicleSearchModule {}
