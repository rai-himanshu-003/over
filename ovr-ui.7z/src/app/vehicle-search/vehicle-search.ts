export interface IVehSearchParameters{
    vin:string,
    ccp:string,
    veh:string,
    extDate:Date,
    currentState:string,
    version:number,
    currentStateLabel:string
}