export class FilterData{
    vin:string;
    ccp:string;
    veh:string;
    extDate:string;
    extFromDate:string;
    extToDate:string;
    // flowName:string;
    vinOrder:string;
    ccpOrder:string;
    vehOrder:string;
    extDateOrder:string;
    ottFlowOrder:string;
    ottFlow:string;
    userCreation:string;
    userCreationOrder:string;
    revottFlowOrder:string;
    thubFlowOrder:string;
    corvetFlowOrder:string;
    revottFlow:string;
    thubFlow:string;
    corvetFlow:string;
    
}