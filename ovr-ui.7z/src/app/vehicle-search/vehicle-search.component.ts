import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FilterData } from './filter-data';
import { VehicleSearchRecordService } from '../service/vehicle-search.service';
import { IVehSearchParameters } from './vehicle-search';
import { LazyLoadEvent, MessageService } from 'primeng/api';
import { GetSelectedVinService } from '../service/getVin.service';
import { Router } from '@angular/router';

import { ListOfFlows } from '../models/list-of-flows';
import { IFlowList } from '../models/flow-list';
import { element } from 'protractor';
import { StateLabelService } from '../shared/services/stateLabel.service';
import { listDto } from '../models/list-model';
import { DateFormatterService } from '../shared/services/dateFormater.service';



@Component({
  selector: 'app-vehicle-search',
  templateUrl: './vehicle-search.component.html',
  styleUrls: ['./vehicle-search.component.scss'],
  providers: [MessageService,ListOfFlows,StateLabelService,DateFormatterService],
  encapsulation: ViewEncapsulation.None,
})
export class VehicleSearchComponent implements OnInit,OnDestroy {
  // variable for columns 
  cols: any[];
  colsForFilter:any[];

  // variable for data
  vehSearchRecords:IVehSearchParameters[]= [];


  // Sort Variables
  sortData = {} as FilterData;
  sortResult: string;

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;
  totalNumberRecords:number;

  // lazy loading variable
  loading: boolean;

  // Date filter variables
  extshowDateContainer: boolean = false;
  extfdate: Date;
  exttdate: Date;

  selectedDate:string;

  // State filter
  listOfFlowForFilter: any[] = [];
  currentStatesForFilter:any[]=[];

  transformationFlowStatesForFilter:any[]=[];
  outputFlowStatesForFilter:any[]=[];

  vinForHistory: string;

  // Interface variable
  flowName:string;
  flowList:IFlowList[] = [];
  // selectedFlow:IFlowList;
  errorMessage: null;

  // Back button variable
  isBack:string;

  selectedStates1:any[];
  selectedStates2:any[];
  selectedStates:any[];
  selectedFlow:any[];


  constructor(
    private vehicleSearchRecordService:VehicleSearchRecordService,
    private getSelectedVinService:GetSelectedVinService,
    public router: Router,
    private messageService: MessageService,
    private listofflows:ListOfFlows,
    private stateLabelService:StateLabelService,
    private dateFormatterService:DateFormatterService

  ) { 
    // console.log(localStorage.getItem("appLanguage"));
  }

  ngOnInit() {
   

    // set default value of variables required for Header of table
    this.cols = [
      { field: 'vin', header: 'VIN' },
      { field: 'ccp', header: 'CCP/UP' },
      { field: 'veh', header: 'VEH/MODEL' },
      { field: 'extFromDate', header: 'DATE ECOM' },
      { field: 'ottFlow', header: 'OTT' },
      { field: 'revottFlow', header: 'REVOTT' },
      { field: 'thubFlow', header: 'THUB' },
      { field: 'corvetFlow', header: 'CORVET' },
      { field: 'userCreation', header: 'USER CREATION' }

    ];
    
    

    this.listofflows.listOfFlow.forEach( element => {
      //console.log(element.default);
      this.listOfFlowForFilter.push(element);
    });

    this.listofflows.currentStates.forEach( element => {
      //console.log(element.default);
      this.currentStatesForFilter.push(element);
    });

    this.transformationFlowStatesForFilter = this.listofflows.transformationFlowStates;
    this.outputFlowStatesForFilter = this.listofflows.outputFlowStates

    // console.log(this.currentStatesForFilter);
    // set the default valu as null for sorting & filtering
    Object.assign(this.sortData, {
      vin:null,
      ccp:null,
      veh:null,
      extDate:null,
      extFromDate:null,
      extToDate:null,
      ottFlow:null,
      vinOrder:null,
      ccpOrder:null,
      vehOrder:null,
      extDateOrder:null,
      ottFlowOrder:null,
      userCreation:null,
      userCreationOrder:null,
      revottFlowOrder:null,
      thubFlowOrder:null,
      corvetFlowOrder:null,
      revottFlow:null,
      thubFlow:null,
      corvetFlow:null
    })

    this.sortResult = JSON.stringify(this.sortData);

    this.getFlowName();

   
    // Reset the value to detect the back button event
    this.isBack = "false";

    this.getBackFlag();

    if(this.isBack == "true"){
      // console.log("filteredData");

      let backUpData = window.localStorage.getItem("filteredData");
      console.log(backUpData,"backUpData");
      
      let noFirst:string | number = window.localStorage.getItem("first");
      let noRows:string | number = window.localStorage.getItem("rows");
      // console.log(backUpData);
      
      this.sortResult = backUpData;
      this.first = parseInt(noFirst);
      this.rows = parseInt(noRows);

      this.getRecordsFromDB();

      let filteredObj:FilterData = JSON.parse(backUpData);

       console.log(filteredObj,"filteredObj");

      // this.selectedStates.push(filteredObj.ottFlow);

      if(filteredObj != null){
        this.cols.forEach(col =>{
          if(col.field == 'vin'){
            col.value =  filteredObj.vin;
          }
          else if(col.field == 'ccp'){
            col.value =  filteredObj.ccp;
          }
          else if(col.field == 'veh'){
            col.value =  filteredObj.veh;
          }

          else if(col.field == 'extFromDate'){
            if(filteredObj.extFromDate !== null && filteredObj.extToDate !== null){
              this.selectedDate =  `${filteredObj.extFromDate} - ${filteredObj.extToDate}`;

              this.extfdate = this.dateFormatterService.convertStringToDate(filteredObj.extFromDate);
              this.exttdate = this.dateFormatterService.convertStringToDate(filteredObj.extToDate);
            }
            
          }
          else if(col.field == 'ottFlow'){

            if(filteredObj.ottFlow != null){
              let tempArr = filteredObj.ottFlow.split(",");
              this.selectedStates = this.createDropDownList(tempArr);
            }

          }
          else if(col.field == 'revottFlow'){

            if(filteredObj.revottFlow != null){
              let tempArr = filteredObj.revottFlow.split(",");
              this.selectedStates1 = this.createDropDownList(tempArr);
            }

          }
          else if(col.field == 'thubFlow'){

            if(filteredObj.thubFlow != null){
              let tempArr = filteredObj.thubFlow.split(",");
              this.selectedStates2 = this.createDropDownList(tempArr);
            }

          }
          else if(col.field == 'corvetFlow'){

            if(filteredObj.corvetFlow != null){
              let tempArr = filteredObj.corvetFlow.split(",");
              this.selectedFlow = this.createDropDownList(tempArr);
            }

          }
          else if(col.field == 'userCreation'){
            col.value = filteredObj.userCreation;
            
           }
          else{
            col.value = null;
          }
        })

      }
      

      


    }

    else{
      console.log("No back button");
      
    }

  }


  ngOnDestroy(){
   
  }

  // This method will fetech the records from DB
  getRecordsFromDB() {
    this.loading=true
    this.vehicleSearchRecordService.getRecords(this.first, this.rows, this.sortResult).subscribe(

      (data: any) => {
        this.totalNumberRecords = data.totalNumberOfRecords;
        this.vehSearchRecords = data.datalist;
        this.loading = false;

        if(data != null){
          // Add label for state 
          this.stateLabelService.addStateLabel(this.vehSearchRecords);

        }


      },
      (error: any) => {
        console.log(error);
       this.loading=false
      }
    );

  }

  // This method will work for pagination
  paginate(event: any) {
    this.first = event.first;
    
    this.page = event.page;
    
    this.rows = event.rows;
    
    this.getRecordsFromDB();
  }

  // This method will give lazy loading and sorting method
  loadVehSearchLazy(event: LazyLoadEvent){
   
    

    // this method will sort the data
    if (event.multiSortMeta) {

      // set the default valu as null for sorting & filtering
      Object.assign(this.sortData, {
        vinOrder: null,
        ccpOrder: null,
        vehOrder: null,
        extDateOrder: null,
        ottFlowOrder: null,
        revottFlowOrder:null,
        thubFlowOrder:null,
        corvetFlowOrder:null,
        userCreationOrder:null

      })

     // console.log(event.multiSortMeta);
      if (event.multiSortMeta[0].field == 'vin' && event.multiSortMeta[0].order == 1) {
        this.sortData.vinOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
        // console.log(this.sortResult);
      }
      else if (event.multiSortMeta[0].field == 'vin' && event.multiSortMeta[0].order == -1) {
        this.sortData.vinOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);
        // console.log(this.sortResult);
      }

      else if (event.multiSortMeta[0].field == 'ccp' && event.multiSortMeta[0].order == 1) {
        this.sortData.ccpOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'ccp' && event.multiSortMeta[0].order == -1) {
        this.sortData.ccpOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);
      }

      else if (event.multiSortMeta[0].field == 'veh' && event.multiSortMeta[0].order == 1) {
        this.sortData.vehOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'veh' && event.multiSortMeta[0].order == -1) {
        this.sortData.vehOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'extFromDate' && event.multiSortMeta[0].order == 1) {
        this.sortData.extDateOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'extFromDate' && event.multiSortMeta[0].order == -1) {
        this.sortData.extDateOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }
      else if (event.multiSortMeta[0].field == 'ottFlow' && event.multiSortMeta[0].order == 1) {
        this.sortData.ottFlowOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'ottFlow' && event.multiSortMeta[0].order == -1) {
        this.sortData.ottFlowOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }

      else if (event.multiSortMeta[0].field == 'revottFlow' && event.multiSortMeta[0].order == 1) {
        this.sortData.revottFlowOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'revottFlow' && event.multiSortMeta[0].order == -1) {
        this.sortData.revottFlowOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'thubFlow' && event.multiSortMeta[0].order == 1) {
        this.sortData.thubFlowOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'thubFlow' && event.multiSortMeta[0].order == -1) {
        this.sortData.thubFlowOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'corvetFlow' && event.multiSortMeta[0].order == 1) {
          this.sortData.corvetFlowOrder = 'asc';
          this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'corvetFlow' && event.multiSortMeta[0].order == -1) {
          this.sortData.corvetFlowOrder = 'desc';
          this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'userCreation' && event.multiSortMeta[0].order == 1) {
        this.sortData.userCreationOrder = 'asc';
        this.sortResult = JSON.stringify(this.sortData);
      }
      else if (event.multiSortMeta[0].field == 'userCreation' && event.multiSortMeta[0].order == -1) {
        this.sortData.userCreationOrder = 'desc';
        this.sortResult = JSON.stringify(this.sortData);

      }

      // console.log(this.sortData);
      this.getRecordsFromDB();

    }
  }

  // This method will filter data on key down event
  onKeydown(event, field: string) {

    console.log("key down function",event.target.value);
    

    if (field == 'vin') {

      if(event.target.value == ""){
        console.log("in VIN if");
        
        this.sortData.vin = null;

      }
      else{
        console.log("in VIN Else");
        this.sortData.vin = event.target.value;
        
      }
      
      this.sortResult = JSON.stringify(this.sortData);
    }
    else if (field == 'ccp') {
      if(event.target.value == ""){
        this.sortData.ccp = null;

      }
      else{
        this.sortData.ccp = event.target.value;
      }
      
      this.sortResult = JSON.stringify(this.sortData);
    }

    else if (field == 'veh') {

      if(event.target.value == ""){
        this.sortData.veh = null;
      }
      else{
        this.sortData.veh = event.target.value;
      }
      
      this.sortResult = JSON.stringify(this.sortData);
    }

    else if (field == 'extDate') {

      if(event.target.value == ""){
        this.sortData.extDate = null;
      }
      else{
        this.sortData.extDate = event.target.value;
      }

      this.sortResult = JSON.stringify(this.sortData);
    }
    else if (field == 'userCreation') {

      if(event.target.value == ""){
        this.sortData.userCreation = null;
      }
      else{
        this.sortData.userCreation = event.target.value;
      }

      this.sortResult = JSON.stringify(this.sortData);
    }

    else if (field == 'ottFlow') {
      this.sortData.ottFlow = event.target.value;
      this.sortResult = JSON.stringify(this.sortData);
    }
    console.log("Filter Result-",this.sortResult);
    this.first = 0;
    this.getRecordsFromDB();

      // Store value in variable

    
  }

  // this method will show & hide the date filter section
  showDateFilter(event, field: string) {
    //console.log(field);

    if (field == 'extFromDate') {
      this.extshowDateContainer = true;
    }
  
    else if (field == 'vin' || field == 'ccp' || field == 'veh' || field == 'ottFlow') {
      this.extshowDateContainer = false;  
    }
  }

  stateFilter(event, field: string){
    // console.log(event);
    event.forEach(state => console.log(state.label));
    if(field=='ottFlow' && event.toString() ==""){
      this.sortData.ottFlow = null;
      this.sortResult = JSON.stringify(this.sortData);
  }
  else if(field=='revottFlow' && event.toString() ==""){
      this.sortData.revottFlow = null;
      this.sortResult = JSON.stringify(this.sortData);
  }
  else if(field=='thubFlow' && event.toString() ==""){
      this.sortData.thubFlow = null;
      this.sortResult = JSON.stringify(this.sortData);
  }
  else if(field=='corvetFlow' && event.toString() ==""){
      this.sortData.corvetFlow = null;
      this.sortResult = JSON.stringify(this.sortData);
  }

    else{
      let tempArr = [];
      event.forEach(state => {
        // console.log(state.label);
        tempArr.push(state.label);
      })

      // console.log(tempArr.toString());
      if(field=='ottFlow'){
      this.sortData.ottFlow = tempArr.toString();
      }
      else if(field=='revottFlow'){
        this.sortData.revottFlow = tempArr.toString();
      }
      else if(field=='thubFlow'){
        this.sortData.thubFlow = tempArr.toString();
      }
      else if(field=='corvetFlow'){
        this.sortData.corvetFlow = tempArr.toString();
      }
      
      this.sortResult = JSON.stringify(this.sortData);
    }

    this.first = 0;
    this.getRecordsFromDB();

  }
  

  // This method will format the input date to comapre
  formatDateForDataBase(dateOfUser: any) {
    
    let date = new Date(dateOfUser);
    let dd;
    let mm;
    let mbefore:number = (date.getMonth()+1);

    if(date.getDate() < 10){
      dd= "0"+date.getDate();
    }
    else{
      dd = date.getDate();
    }

    if( (date.getMonth() + 1) < 10){
      mm= "0"+ (date.getMonth()+1);
    }

    else{
      mm = mbefore;
    }

    return dd + '/'  + mm + '/' + date.getFullYear();
  }

  // Filter function for EXt Date field
  extFilterDate() {

    this.selectedDate = null;

    if(this.extfdate != null && this.exttdate != null){
      
      if (this.extfdate > this.exttdate){
        
        this.messageService.add({ severity: 'error', summary: "Error Message", 
        detail: `The To date is Greater than From date. Please select appropriate date` });
  
        return false;
     }

    }

    let extfromDate:string;
    let exttoDate:string;

    this.cols.forEach(col=>{
      
      if(col.field == 'extFromDate'){
        if((this.extfdate == undefined || this.extfdate==null)){
          extfromDate = "*";
        }

        else{ 
          extfromDate = this.formatDateForDataBase(this.extfdate);
          // console.log(extfromDate);
        }

        if((this.exttdate == undefined || this.exttdate==null)){
          exttoDate = "*";
        }

        else{ 
          exttoDate = this.formatDateForDataBase(this.exttdate);
          // console.log(exttoDate);
        }
        this.selectedDate = extfromDate+ " -" + exttoDate;


        if((this.extfdate == undefined || this.extfdate==null) && (this.exttdate == undefined || this.exttdate==null)){
          this.selectedDate = null;
        }

      }

    });

    if((this.extfdate == undefined || this.extfdate==null)){
      this.sortData.extFromDate = null;
    }

    else{
     
     this.sortData.extFromDate = this.formatDateForDataBase(this.extfdate);
    }

    if((this.exttdate == undefined || this.exttdate==null)){
      this.sortData.extToDate = null;
    }

    else{
      
      this.sortData.extToDate = this.formatDateForDataBase(this.exttdate);
    }

    
    this.sortResult = JSON.stringify(this.sortData);
    this.first = 0;
    // console.log(this.sortResult);
    this.getRecordsFromDB();


  }

  // this method will redirect page to Vehicle details page

  goToPage(event,vinNumber){
    this.vinForHistory = vinNumber;
    this.getSelectedVinService.setSelectedVinNumber(this.vinForHistory);
   
    let vinSearch = window.localStorage.getItem("vinSearch");
    if(vinSearch != null && vinSearch != undefined){
      window.localStorage.removeItem("vinSearch");
      window.localStorage.setItem("vinSearch",this.vinForHistory);

    }

    else{
      window.localStorage.setItem("vinSearch",this.vinForHistory);
    }

    
    if(this.vinForHistory){
      this.router.navigate(['/vehicle-details', vinNumber]);
    }

    // Store records for filter
    this.storeFilteredData();
    
  }

   // This method will Fetch the data  for export to csv
   exportToCSV() {
    this.vehicleSearchRecordService.exportToCSVRecords(this.first, this.rows, this.sortResult).subscribe(      
      response => this.downLoadFile(response, "text/csv"),
      (error: any) => console.log(error)    
    );
  }

    // This method will download the csv file
    downLoadFile(data: any, type: string) {
    
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(data.image, data.filename);
      }

      else{

        const element = document.createElement('a');
        element.href = URL.createObjectURL(data.image);
        element.download = data.filename;
        document.body.appendChild(element);
        element.click();

      }
    
    }


    getFlowName(){
      this.vehicleSearchRecordService.getFlowList().subscribe(
        (data:any) => {
          this.flowList = data;
        },

        (error: any) => this.errorMessage = <any>error
      )
    }

    resetExtDate(){
      this.extfdate = null;
      this.exttdate = null;

      this.extFilterDate();

    }

    // Get back flag from Vehicle details page
    getBackFlag(){

      this.isBack = "false";
      // Set the value of Vin number in variable
      this.isBack = window.localStorage.getItem("isBack");
    }

    storeFilteredData(){
      window.localStorage.setItem("filteredData",this.sortResult);
      window.localStorage.setItem("first",this.first.toString());
      window.localStorage.setItem("rows",this.rows.toString());

      let filteredData = window.localStorage.getItem("filteredData");
      let first:string | number = window.localStorage.getItem("first");
      let rows:string | number = window.localStorage.getItem("rows");

      
    }

    createDropDownList(arrToConvert:any[]){

      // Create an empty Array
      let tempArr = [];

      let arrLength = arrToConvert.length;

      let tempObject = arrToConvert;

      for(let i=0; i<arrLength;i++){

          let tempObj = {} as listDto

          tempObj.label = tempObject[i];
          tempObj.value = tempObject[i];

          tempArr.push(tempObj);

          
      }

      return tempArr;

  }





}



