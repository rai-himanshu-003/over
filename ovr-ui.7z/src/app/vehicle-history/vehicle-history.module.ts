
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { VehicleHistoryComponent } from './vehicle-history.component';
import { VehicleHistoryRoutingModule } from './vehicle-history-routing.module';

import { VehicleDetailsComponent } from '../vehicle-details/vehicle-details.component';
import { StateHistoryComponent } from '../state-history/state-history.component';
import { ErrorHistoryComponent } from '../error-history/error-history.component';
import { ErrorManagementComponent } from '../error-management/error-management.component';
import { VehicleHistoryTabComponent } from '../vehicle-history-tab/vehicle-history-tab.component';

import { TranslateModule } from '@ngx-translate/core';

import {TabViewModule} from 'primeng/tabview';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {TooltipModule} from 'primeng/tooltip';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {DropdownModule} from 'primeng/dropdown';
import {PanelModule} from 'primeng/panel';
import {CalendarModule} from 'primeng/calendar';
import {MultiSelectModule} from 'primeng/multiselect';
import {AccordionModule} from 'primeng/accordion';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';

import { ErrorManagementModule } from '../error-management/error-management.module';
import { MessageService, ConfirmationService } from 'primeng/api';
import { VehicleMetadataComponent } from '../vehicle-metadata/vehicle-metadata.component';
import { CommonTableComponent } from '../common-table/common-table.component';
import { ComposantsComponent } from '../composants/composants.component';
import { ReferencesElectroniquesComponent } from '../references-electroniques/references-electroniques.component';
import { ComposantsOvComponent } from '../composants-ov/composants-ov.component';
import { KeysOvComponent } from '../keys-ov/keys-ov.component';
import { LcdvOttComponent } from '../lcdv-ott/lcdv-ott.component';
import { OptionsComponent } from '../options/options.component';
import { ArtLcdvComponent } from '../art-lcdv/art-lcdv.component';



@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    VehicleHistoryRoutingModule,
    TranslateModule,
    TabViewModule,
    TableModule,
    ButtonModule,
    TooltipModule,
    MessagesModule,
    MessageModule,
    DropdownModule,
    PanelModule,
    CalendarModule,
    MultiSelectModule,
    AccordionModule,
    DialogModule,
    ConfirmDialogModule
  ],

  declarations: [
    VehicleHistoryComponent,
    StateHistoryComponent,
    ErrorHistoryComponent,
    VehicleDetailsComponent,
    VehicleMetadataComponent,
    CommonTableComponent,
    ComposantsComponent,
    ReferencesElectroniquesComponent,
    ComposantsOvComponent,
    KeysOvComponent,
    LcdvOttComponent,
    OptionsComponent,
    ArtLcdvComponent,
    VehicleHistoryTabComponent
  ],
  providers: [ErrorManagementComponent,MessageService,ConfirmationService]

})

export class VehicleHistoryModule { }
