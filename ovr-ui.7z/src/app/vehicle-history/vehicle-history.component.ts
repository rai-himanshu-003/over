import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ErrorManagementComponent } from '../error-management/error-management.component';

import { VehicleDetailsService } from '../service/vehicle-details.service';
import { GetSelectedVinService } from '../service/getVin.service';
import { Commondata} from '../models/commonData'
import { Location } from '@angular/common';
@Component({
  selector: 'app-vehicle-history',
  templateUrl: './vehicle-history.component.html',
  styleUrls: ['./vehicle-history.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class VehicleHistoryComponent implements OnInit {

  vinForHistory:string;
  vinForGet:string;
 // private static vinForRefresh:string;
  vehHistoryRecords:any[];
  errorMessage: string;
  composant: Commondata;
  // variable for back button
  isBack:boolean;
  //constructor() { }



   constructor(
      private errorManagementComponent : ErrorManagementComponent,
      private vehicledetailsservice:VehicleDetailsService,
      private getSelectedVinService:GetSelectedVinService,
      private location:Location,
    ) { }

    
  ngOnInit() {
    this.getVinValue();   
  }

  // This method will get Vin value from service

  getVinValue(){
   
    // Set the value of Vin number in variable
    this.vinForGet = window.localStorage.getItem("vinSearch");
    
    // If value is not null or undefined then call get data
    if(this.vinForGet !=null && this.vinForGet != undefined){
      window.localStorage.setItem("vinForGet",this.vinForGet);
      this.getRecordsFromDB();
    }
    
  }



  // This method will fetch data from database
  getRecordsFromDB() {

    let vinNumber:string =  window.localStorage.getItem("vinForGet");

    if(vinNumber !=null && vinNumber != undefined){
      //console.log("vin"+ vinNumber);
      this.vinForHistory = vinNumber;
      //console.log(this.vinForHistory);
    }

    else{
      console.log("no Vin found");
    }
   
    this.vehicledetailsservice.getRecords(this.vinForHistory).subscribe(
      (data: any) => {
        this.vehHistoryRecords = data;
        // console.log(this.vehHistoryRecords);
      },
      (error: any) => this.errorMessage = <any>error
    );
  }

  // this is the method for export to excel

  exportToExcel(event){
    this.vehicledetailsservice.exportToExcelRecords(this.vinForHistory).subscribe(      
      response => this.downLoadFile(response, "text/csv"),
      (error: any) => console.log(error)    
    );
  }

  // This method will download the csv file
  downLoadFile(data: any, type: string) {
  
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    }

    else{

      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      document.body.appendChild(element);
      element.click();

    }
  
  }


  // This method will redirect user back to previous page

  backToPage(){
    console.log("backToPage");
    this.location.back();

    // set a flag to check back button clicked
    // this.isBack = true;
    
    window.localStorage.setItem("isBack","true");
  }
  
}
