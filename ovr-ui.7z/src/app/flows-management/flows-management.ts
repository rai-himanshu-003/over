export interface IFlowsManagementParameters{
    flow:string,
    description: string,
    fileFormatId: number | string, 
    frequency: string,
    action: number | string,
    folderLocation: string,
    fileName:string,
    id:number,
    version:number,
    dirty:boolean,
    isNew:boolean,

}