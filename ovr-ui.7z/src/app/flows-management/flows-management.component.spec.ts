import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowsManagementComponent } from './flows-management.component';

describe('FlowsManagementComponent', () => {
  let component: FlowsManagementComponent;
  let fixture: ComponentFixture<FlowsManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlowsManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlowsManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
