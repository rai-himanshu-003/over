export interface AllListValues{
    id: string;
    type:string;
    value:string;
}

