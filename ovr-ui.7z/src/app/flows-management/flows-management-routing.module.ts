import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FlowsManagementComponent } from './flows-management.component';


const routes: Routes = [
  {
      path: '',
      component: FlowsManagementComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlowsManagementRoutingModule { }
