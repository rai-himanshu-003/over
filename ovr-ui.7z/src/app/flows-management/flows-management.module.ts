import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {TooltipModule} from 'primeng/tooltip';
import { MultiSelectModule } from 'primeng/multiselect';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DropdownModule} from 'primeng/dropdown';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {OverlayPanelModule} from 'primeng/overlaypanel';


import { FlowsManagementComponent } from './flows-management.component';
import { FlowsManagementRoutingModule } from './flows-management-routing.module';



@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    FlowsManagementRoutingModule,
    TranslateModule,
    TableModule,
    ButtonModule,
    TooltipModule,
    ConfirmDialogModule,
    MessagesModule,
    MessageModule,
    DialogModule,
    MultiSelectModule,
    DropdownModule,
    OverlayPanelModule

  ],

  declarations: [FlowsManagementComponent],

})

export class FlowsManagementModule { }
