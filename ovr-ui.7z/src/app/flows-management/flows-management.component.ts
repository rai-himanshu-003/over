import { Component, OnInit,  ViewEncapsulation, ViewChild  } from '@angular/core';

import { IFlowsManagementParameters } from './flows-management';
import { FlowsManagementService } from '../service/flows-management.service';


import { ConfirmationService, MessageService } from 'primeng/api';
import { Message, LazyLoadEvent } from 'primeng/components/common/api';
import { Table } from 'primeng/table';


import { ExportToCSV } from '../service/exportToCSV.service';
import { OVR_PRD } from '../constant/auth-constant';
import { AuthenticationService } from '../service/authentication.service';
import { ProccessResponseService } from '../service/proccessResponse.service';


import * as lodash from 'lodash';
import { element } from 'protractor';
import { AllListValues } from './allLists';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

// import cronstrue from 'cronstrue';
import { isValidCron } from 'cron-validator'
import { GetSelectedFlowService } from '../service/getFlow.service';

@Component({
  selector: 'app-flows-management',
  templateUrl: './flows-management.component.html',
  styleUrls: ['./flows-management.component.scss'],
  providers: [MessageService, ConfirmationService,ExportToCSV,ProccessResponseService,FlowsManagementService],
  encapsulation: ViewEncapsulation.None,
})
export class FlowsManagementComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table


  Select:string;

  flowMaxLength:number;

  // variable for Admin access 
  isAdmin: boolean;

  // variable to show data
  errorMessage: string;
  tableHeaders:any[] = [];
  tableRecords:IFlowsManagementParameters[] = [];
  updatedRecords:IFlowsManagementParameters[] = [];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  today = new Date();
  fileTimeStamp = '';
  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];


  // Add records variables
  displayDialog: boolean;
  newRow: boolean;
  newRecords: IFlowsManagementParameters[] = [];
  newRecord:any = {};
  selectedRecord:any;
  isNewRecord: boolean;

  // Pagination while adding new records
  totalRecords: number = 0;
  rowsPerPage: number;
  lastRowPage: number;

  // Update records variables

  editedRecords: IFlowsManagementParameters[];
  clonedRecords: { [s: string]: any; } = {};

  // Validate records Variable
  postData: IFlowsManagementParameters[] = [];


  // Variable for Error message
  errorMessageForFlow:boolean;
  errorMessageForDescription:boolean;
  errorMessageForFileFormat:boolean;
  errorMessageForFrequency:boolean;
  errorMessageForAction:boolean;
  errorMessageForFolderLocation:boolean;
  errorMessageForFileName:boolean;
  errorMessageForValidFrequency:boolean;
  disableSave:boolean;
  duplicateMessageForFlow:boolean;

  // Variable for filter add
  flow:string
  description:string;
  fileFormatId:string;
  frequency:string;
  action:string;
  folderLocation:string;
  fileName:string;

  // Delete records variables

  deleteRecord: any;
  msgs: Message[] = [];

  // variable for drop down values

  allListValues:AllListValues[] = [];
  listOfFileFormats: any[] = [];
  listOfEvents:any[] = [];
  listOfEventsForFilter:any[] = [];

  // Redirect to another page

  FlowToRedirect:string;

  // Variable to show frequency info
  isShowInfo:boolean;
  showFreqInfo:boolean;
  isValidFreq:boolean;

  freqResult:boolean;

  constructor(
    private getSelectedFlowService:GetSelectedFlowService,
    private flowsManagementService:FlowsManagementService,
    private _authService: AuthenticationService,
    private exportToCSV:ExportToCSV,
    private proccessResponseService:ProccessResponseService,
    public router: Router,
    private confirmationService: ConfirmationService,
    public messageService: MessageService,
    private translate: TranslateService,
  ) {
    this.listOfFileFormats = [

      {label: 'FLAT', value: "FLAT"},
      {label: 'XML', value: "XML"},
      {label: 'JSON', value: "JSON"},
      {label: 'TO_BE_DEFINED', value: "TO_BE_DEFINED"}
    ]

    this.listOfEvents = [

      {label: 'UPDATED', value: "UPDATED"},
      {label: 'CREATED', value: "CREATED"}

    ]

    this.listOfEventsForFilter = [
      {label: 'SELECT EVENT', value: null},
      {label: 'UPDATED', value: "UPDATED"},
      {label: 'CREATED', value: "CREATED"}

    ]


    console.log(this.translate.currentLang);

   }

    ngOnInit() {

      console.log(this.translate.currentLang);

      if(this.translate.currentLang== 'fr'){
        this.Select = "FR_Select";

      }

      this.flowMaxLength = 20;

      // To verify User is Admin or Not
      this.isAdmin = this._authService.isAdmin();

      this.tableHeaders = [
        { field: 'flow', header: 'Flows' },
        { field: 'description', header: 'Description' },
        { field: 'fileFormatId', header: 'Format' },
        { field: 'frequency', header: 'Frequency' },
        { field: 'action', header: 'Event' },
        { field: 'folderLocation', header: 'Folder' },
        { field: 'fileName', header: 'File Name' },
        
      ]
      
      this.getListValues();
      this.getRecordsFromDB();

      // export To CSV variables initialize
      this.prdName = OVR_PRD;
      this.exportFile = "_FlowManagement";


      // Header list for export to csv
      for(let i in this.tableHeaders){
        this.headerList.push(this.tableHeaders[i].header);
      }

      // Field list for export to csv
      for(let j in this.tableHeaders){
        this.fieldList.push(this.tableHeaders[j].field);
      }

    // this.checkFrequency();
      this.isShowInfo = false;
      this.showFreqInfo = false;
      this.isValidFreq = true;

    }


    // Get all List values for drop down

    getListValues(){
      this.flowsManagementService.getAllListsValues().subscribe(
        //(data:any) => console.log(data),
        (data:any) => {
          this.allListValues = data;

          console.log(this.allListValues);
        },
        (error: any) => this.errorMessage = <any>error
      )
    }

    // Get records from Service

    getRecordsFromDB(){

      this.flowsManagementService.getRecords().subscribe(
        //(data:any) => console.log(data),
        (data:any) => {
          this.tableRecords = data;
          this.updatedRecords = lodash.cloneDeep(this.tableRecords);
          console.log(this.tableRecords);

        },
        (error:any) => this.errorMessage = <any> error

      )

    }

    // This method will work for pagination
    paginate(event: any) {
      this.first = event.first;
      this.page = event.page;
      this.rows = event.rows;
      this.size = this.table.totalRecords;

    }


  //======================== Reset records Start=========================

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {

      // Reset all error messages to false
      this.errorMessageForFlow = false;
      this.errorMessageForDescription = false;
      this.errorMessageForFileFormat = false;
      this.errorMessageForFrequency = false;
      this.errorMessageForAction = false;
      this.errorMessageForFolderLocation = false;
      this.isNewRecord = false;

      this.getRecordsFromDB();
    }

  //======================== Reset records Ends=========================

  //======================== Update Start===============================
    onRowEditInit(editedRecord: IFlowsManagementParameters) {
      this.isShowInfo = true;
      this.clonedRecords[editedRecord.id] = {...editedRecord};
    }

    onRowEditSave(editedRecord: IFlowsManagementParameters,index: number) {

      editedRecord.dirty = true;
      this.isNewRecord = true;

      
        //console.log(record.fileFormatId);
        if(editedRecord.fileFormatId == 1){
          editedRecord.fileFormatId = "FLAT"
        }
        else if(editedRecord.fileFormatId == 2){
          editedRecord.fileFormatId = "XML"
        }
        else if(editedRecord.fileFormatId == 3){
          editedRecord.fileFormatId =  "JSON" 
        }
        else if(editedRecord.fileFormatId == 4){
          editedRecord.fileFormatId = "TO_BE_DEFINED" 
        }

        if(editedRecord.action == 27){
          editedRecord.action =  "UPDATED" 
        }
        else if(editedRecord.action == 28){
          editedRecord.action = "CREATED" 
        }

      //   if (isValidCron(editedRecord.frequency)) {
      //     console.log("Valid Frequency");
      //   }

      //   // else{
      //   //   console.log("IN Valid Frequency");
      //   // }

      //   let cornValidate:boolean;
      //   cornValidate = this.isCronValid(editedRecord.frequency);

      // console.log(cornValidate);
      this.clonedRecords[editedRecord.id] = { ...editedRecord }; 

      console.log(editedRecord);

    }

    onRowEditCancel(editedRecord: IFlowsManagementParameters,index: number) {

      // Reset all error messages to false
      this.errorMessageForFlow = false;
      this.errorMessageForDescription = false;
      this.errorMessageForFileFormat = false;
      this.errorMessageForFrequency = false;
      this.errorMessageForValidFrequency = false;
      this.errorMessageForAction = false;
      this.errorMessageForFolderLocation = false;
      this.errorMessageForFileName = false;
      this.duplicateMessageForFlow = false;

      this.editedRecords = this.tableRecords;
      this.editedRecords[index] = this.clonedRecords[editedRecord.id];
      delete this.clonedRecords[editedRecord.id];
    }

  //======================== Update Ends===============================

  //=========================== Add Start===============================

    showDialogToAdd() {
      //console.log("showDialogToAdd");
       let labelText = "Sélectionner les évnts";

      console.log(this.translate.currentLang);

      if(this.translate.currentLang== 'fr'){
        this.listOfEventsForFilter[0].label = labelText.toUpperCase();
      }
  
      

      // Reset all error messages to false
      this.errorMessageForFlow = false;
      this.errorMessageForDescription = false;
      this.errorMessageForFileFormat = false;
      this.errorMessageForFrequency = false;
      this.errorMessageForValidFrequency = false;
      this.errorMessageForAction = false;
      this.errorMessageForFolderLocation = false;
      this.errorMessageForFileName = false;
      this.duplicateMessageForFlow = false;

      // Set new record to null / empty
      this.newRecord = {};

      // Set flag of new record
      this.newRow = true;

      // Display Dialoug box
      this.displayDialog = true;

      // reset save button
      this.isValidFreq = true;

    }


    save(){

      // copy all previous records in new list
      this.newRecords = [...this.tableRecords];

      // Reset all error messages to false
      this.errorMessageForFlow = false;
      this.errorMessageForDescription = false;
      this.errorMessageForFileFormat = false;
      this.errorMessageForFrequency = false;
      this.errorMessageForValidFrequency = false;
      this.errorMessageForAction = false;
      this.errorMessageForFolderLocation = false;
      this.errorMessageForFileName = false;
      this.duplicateMessageForFlow = false;

      if(this.table.filteredValue !== undefined){
        
        // Reset all filter fields
        this.flow = undefined;
        this.description = undefined;
        this.fileFormatId = undefined;
        this.frequency = undefined;
        this.action = undefined;
        this.folderLocation = undefined;
        this.fileName = undefined;

        this.table.reset();

      }



      // For new Record
      if (this.newRow) {
        this.newRecord.id = null;
        this.newRecord.fileFormatId = "TO_BE_DEFINED";

        // check for duplicate Flow value

        // Convert the flow in uppercase
      
        let tempFlow:string = this.newRecord.flow;

        if(tempFlow == null){
          this.newRecord.flow = null;
        }
        else{
          this.newRecord.flow = tempFlow.toUpperCase();
        }
        
        

        for (let i = 0; i < this.tableRecords.length; i++){
          if ((this.tableRecords[i].flow) == (this.newRecord.flow)) {
            console.log("Duplicate record");
            this.duplicateMessageForFlow = true;
          }

        }

        // check for duplication of Flow value
        if(this.duplicateMessageForFlow == true){
          console.log(this.duplicateMessageForFlow);
          this.displayDialog = true;
          //this.newTechnicalRecords = this.technicalRecords;
        }


       else if (this.newRecord.flow == null || this.newRecord.flow == "" || this.newRecord.flow == "") {
    
          this.displayDialog = true;
          this.errorMessageForFlow = true;
        }


        else if (this.newRecord.frequency == null || this.newRecord.frequency == "" || this.newRecord.frequency == "") {

          this.displayDialog = true;
          this.errorMessageForFrequency = true;
        }


        else if (this.newRecord.action == null || this.newRecord.action == "" || this.newRecord.action == "") {
    
          this.displayDialog = true;
          this.errorMessageForAction = true;
        }

        else if (this.newRecord.folderLocation == null || this.newRecord.folderLocation == "" || this.newRecord.folderLocation == "") {

          this.displayDialog = true;
          this.errorMessageForFolderLocation = true;
        }

        else if (this.newRecord.fileName == null || this.newRecord.fileName == "" || this.newRecord.fileName == "") {

          this.displayDialog = true;
          this.errorMessageForFileName = true;
        }




        else{

        
          // claculate last row of total records before pushing the new record in table
          this.totalRecords = this.table.totalRecords;
          this.rowsPerPage = this.rows;

          if (this.totalRecords < 10) {
            this.lastRowPage = 0;
            console.log(this.lastRowPage);
          }
          else {
            this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
            console.log(this.lastRowPage);
          }

          this.first = this.rowsPerPage * this.lastRowPage;
          console.log(this.first);

          // Insert New record after claculating last row
          this.newRecords.push(this.newRecord);
          this.displayDialog = false;
          this.newRecord.isNew = true;
          this.isNewRecord = true;

          this.tableRecords = this.newRecords;
          console.log(this.newRecord);
          console.log(this.tableRecords);


        }


      }



    }

    cancel(){

      let index = this.newRecords.indexOf(this.selectedRecord);
      this.newRecords = this.newRecords.filter((val, i) => i != index);
      this.newRecord = null;
      this.displayDialog = false;

      // Reset all error messages to false
      this.errorMessageForFlow = false;
      this.errorMessageForDescription = false;
      this.errorMessageForFileFormat = false;
      this.errorMessageForFrequency = false;
      this.errorMessageForValidFrequency = false;
      this.errorMessageForAction = false;
      this.errorMessageForFolderLocation = false;
      this.errorMessageForFileName = false;
      this.duplicateMessageForFlow = false;

    }

  //=========================== Add Ends================================

  //======================== Validate Start=============================

    validateRecord(event: Event) {

      // This will reset the Post data
      this.postData = [];

      // console.log(this.postData);

      // console.log(this.updatedRecords);
      // console.log(this.tableRecords);

      // convert list ID in to Actual labels 

      this.updatedRecords.forEach(record =>{
        //console.log(record.fileFormatId);
        if(record.fileFormatId == 1){
          record.fileFormatId = "FLAT"
        }
        else if(record.fileFormatId == 2){
          record.fileFormatId = "XML"
        }
        else if(record.fileFormatId == 3){
          record.fileFormatId =  "JSON" 
        }
        else if(record.fileFormatId == 4){
          record.fileFormatId = "TO_BE_DEFINED" 
        }

        if(record.action == 27){
          record.action =  "UPDATED" 
        }
        else if(record.action == 28){
          record.action = "CREATED" 
        }

        
      });

      // This function will compare the prvious value & updated value
      for (let i = 0; i < this.tableRecords.length; i++) {
        if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.tableRecords[i])) {

          // console.log(this.updatedRecords[i]);
          // console.log(this.tableRecords[i]);

          this.postData.push(this.tableRecords[i]);
          
        }

      }

      //console.log(this.postData);

      let updatedData: any = this.postData;

      // This method will update the records in DB on click of validate button
      this.flowsManagementService.updateRecords(this.postData).subscribe(

        (data: any) => {
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();
        },
        //(data:any) => console.log(data),

        (error: any) => console.log(error)
      )

      this.isNewRecord = false;

    }

    valueChanged(changedRecord: IFlowsManagementParameters){
      console.log(" Value changed");

      // Reset all error messages to false
      
      this.errorMessageForFrequency = false;
      this.errorMessageForAction = false;
      this.errorMessageForFolderLocation = false;
      this.errorMessageForFileName = false;
      this.errorMessageForValidFrequency = false;
      this.disableSave = false;

      if(changedRecord.frequency == ""){
        this.disableSave = true;
        this.errorMessageForFrequency = true;
      }

      else if(changedRecord.folderLocation == ""){
        this.disableSave = true;
        this.errorMessageForFolderLocation = true;
      }

      else if(changedRecord.fileName == ""){
        this.disableSave = true;
        this.errorMessageForFileName = true;
      }

      else if(changedRecord.frequency != ""){

        this.validateFreq(changedRecord.frequency);

      }


    }

    validateFreq(freq){
      console.log(freq);

      this.errorMessageForValidFrequency = false;
      this.errorMessageForFrequency = false;
      let cornValidate:boolean;

      this.flowsManagementService.getFreqValidated(freq).subscribe(
        (data:boolean) => {
          console.log(data);
          this.freqResult = data;

          cornValidate = this.freqResult;

          if(cornValidate == false){
            //this.disableSave = true;
            this.isValidFreq = false;
            this.errorMessageForValidFrequency = true;
          }
    
          else{
            this.errorMessageForValidFrequency = false;
            this.errorMessageForFrequency = false;
            this.isValidFreq = true;
          }
         
        
        },
        (error:any) => this.errorMessage = <any> error
      )

    }

  //======================== Validate Ends=============================


  //=========================== Delete Starts=========================
    // This method will Delete row in table
    deleteRow(tableRow: any, index: number) {

      this.deleteRecord = tableRow;
      console.log(this.deleteRecord);

      // This method will update the records in DB on click of Delete button

      this.flowsManagementService.deleteRecords(this.deleteRecord).subscribe(

        (data: any) => {
          
          let res ={...data.responseList};
          let resMsg = res[0].msg;
          let tableRow = this.deleteRecord;

          if (resMsg == true) {

            // this.msgs = [{severity:'error', summary:'Warning', detail:`${tableRow.id} is  deleted`}];
            this.messageService.add({ severity: 'error', summary: 'Deleted', detail: `${tableRow.flow}` });
            this.getRecordsFromDB();
          }
          else {
            this.msgs = [{ severity: 'error', summary: 'Error', detail: `${tableRow.flow} not found` }];
            this.getRecordsFromDB();
          }

          this.proccessResponseService.clearMessage();

        },
        (error: any) => console.log(error)
      )


    }

    // Show confirmation box before delete function

    confirmDelete(tableRow: any, index: number) {
      //console.log("Confirm Delete");
      this.confirmationService.confirm({
        accept: () => {
          this.deleteRow(tableRow, index);
        },
        reject: () => {
          //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
      });
    }

  //=========================== Delete Ends=========================

  // Redirect to Format management
    goToPage(event,flowName){
      console.log(event);
      this.FlowToRedirect = flowName;

      this.getSelectedFlowService.setSelectedFlow( this.FlowToRedirect);

      // let fromFlowManagement = flowName;
     
      console.log(this.FlowToRedirect);

      // Set local storage 

      let flowStored = window.localStorage.getItem("flowStored");

      if(flowStored != null && flowStored != undefined){
        window.localStorage.removeItem("flowStored");
        window.localStorage.setItem("flowStored",this.FlowToRedirect);

      }
      else{
        window.localStorage.setItem("flowStored",this.FlowToRedirect);
      }


      // Redirect to page
      if(this.FlowToRedirect){
        this.router.navigate(['/format-management']);
      }


    }


    // Export to CSV
    exportCSVCommon(){
      // This will add time stamp in the filename while exporting the file    
      this.fileTimeStamp = this.exportToCSV.formatDateForExport();

      
      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}${this.fileTimeStamp}`;

      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }

      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      // console.log(this.exportedRecords);

      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);

    }



    isCronValid(freq) {
      //var cronregex = new RegExp(/^(\*|([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])|\*\/([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])) (\*|([0-9]|1[0-9]|2[0-3])|\*\/([0-9]|1[0-9]|2[0-3])) (\*|([1-9]|1[0-9]|2[0-9]|3[0-1])|\*\/([1-9]|1[0-9]|2[0-9]|3[0-1])) (\*|([1-9]|1[0-2])|\*\/([1-9]|1[0-2])) (\*|([0-6])|\*\/([0-6]))$/);
      var cronregex = new RegExp("^\\s*($|#|\\w+\\s*=|(\\?|\\*|(?:[0-5]?\\d)(?:(?:-|/|,)(?:[0-5]?\\d))?(?:,(?:[0-5]?\\d)(?:(?:-|/|,)(?:[0-5]?\\d))?)*)\\s+(\\?|\\*|(?:[0-5]?\\d)(?:(?:-|/|,)(?:[0-5]?\\d))?(?:,(?:[0-5]?\\d)(?:(?:-|/|,)(?:[0-5]?\\d))?)*)\\s+(\\?|\\*|(?:[01]?\\d|2[0-3])(?:(?:-|/|,)(?:[01]?\\d|2[0-3]))?(?:,(?:[01]?\\d|2[0-3])(?:(?:-|/|,)(?:[01]?\\d|2[0-3]))?)*)\\s+(\\?|\\*|(?:0?[1-9]|[12]\\d|3[01])(?:(?:-|/|,)(?:0?[1-9]|[12]\\d|3[01]))?(?:,(?:0?[1-9]|[12]\\d|3[01])(?:(?:-|/|,)(?:0?[1-9]|[12]\\d|3[01]))?)*)\\s+(\\?|\\*|(?:[1-9]|1[012])(?:(?:-|/|,)(?:[1-9]|1[012]))?(?:L|W)?(?:,(?:[1-9]|1[012])(?:(?:-|/|,)(?:[1-9]|1[012]))?(?:L|W)?)*|\\?|\\*|(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(?:(?:-)(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))?(?:,(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(?:(?:-)(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))?)*)\\s+(\\?|\\*|(?:[0-6])(?:(?:-|/|,|#)(?:[0-6]))?(?:L)?(?:,(?:[0-6])(?:(?:-|/|,|#)(?:[0-6]))?(?:L)?)*|\\?|\\*|(?:MON|TUE|WED|THU|FRI|SAT|SUN)(?:(?:-)(?:MON|TUE|WED|THU|FRI|SAT|SUN))?(?:,(?:MON|TUE|WED|THU|FRI|SAT|SUN)(?:(?:-)(?:MON|TUE|WED|THU|FRI|SAT|SUN))?)*)(|\\s)+(\\?|\\*|(?:|\\d{4})(?:(?:-|/|,)(?:|\\d{4}))?(?:,(?:|\\d{4})(?:(?:-|/|,)(?:|\\d{4}))?)*))$");
      return cronregex.test(freq);
    }

    // Show and Hide Frequency info Dialog
    showInfo(){
      this.showFreqInfo = true;
    }

    hideInfo(){
      this.showFreqInfo = false;
    }

    checkForSpace(event):boolean{
      console.log(event);

      if( (event.key == "Spacebar" ) || (event.key == " " ) || (event.key == "!")
       || (event.key == "@") || (event.key == "#") || (event.key == "$") 
       || (event.key == "%")|| (event.key == "^")|| (event.key == "&")
       || (event.key == "*")|| (event.key == "(")|| (event.key == ")") 
       || (event.key == "-")|| (event.key == "=")|| (event.key == "+")
       || (event.key == "~") || (event.key == "<") || (event.key == ">")
       || (event.key == "?") || (event.key == ",") || (event.key == ".")
       || (event.key == "/") || (event.key == "[") || (event.key == "]")
       || (event.key == "{") || (event.key == "}") || (event.key == "|")
       || (event.key == ";") || (event.key == ":") || (event.key == "'")
       || (event.key == '"') || (event.code == "Backslash") || (event.keyCode == 220)
       || (event.key == "`") || (event.key == "Divide") || (event.key == "Multiply")
       || (event.key == "Subtract") || (event.key == "Add") || (event.key == "Decimal") )  {
        return false;
      }
 
      else{
        return true;
      }
    }
    


}
