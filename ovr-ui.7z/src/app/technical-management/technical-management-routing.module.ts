import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TechnicalManagementComponent } from './technical-management.component';

const routes: Routes = [
  {
      path: '',
      component: TechnicalManagementComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes,)],
  
  exports: [RouterModule]
})
export class TechnicalManagementRoutingModule { }
