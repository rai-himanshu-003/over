export interface ITechParameters{
    //id: string;
    type:string,
    code:string,
    label:string,
    value:string,
    dirty:boolean,
    isNew:boolean
}