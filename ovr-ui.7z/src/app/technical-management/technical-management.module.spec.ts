import { TechnicalManagementModule } from './technical-management.module';

describe('TechnicalManagementModule', () => {
  let technicalManagementModule: TechnicalManagementModule;

  beforeEach(() => {
    technicalManagementModule = new TechnicalManagementModule();
  });

  it('should create an instance', () => {
    expect(technicalManagementModule).toBeTruthy();
  });
});
