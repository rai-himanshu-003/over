import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalManagementComponent } from './technical-management.component';

describe('TechnicalManagementComponent', () => {
  let component: TechnicalManagementComponent;
  let fixture: ComponentFixture<TechnicalManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TechnicalManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TechnicalManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
