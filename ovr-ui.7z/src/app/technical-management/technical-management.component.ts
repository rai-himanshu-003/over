import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import {formatDate} from '@angular/common';
import { ITechParameters } from './technical-management';
import { TechRecordService } from '../service/tecnical-management.service';
import * as lodash from 'lodash';

import { Message, LazyLoadEvent, ConfirmationService } from 'primeng/components/common/api';
import { MessageService } from 'primeng/api';


import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_USER_NAME } from '../constant/auth-constant';
import { TranslateService } from '@ngx-translate/core';

import { Table } from 'primeng/table';


import { AuthenticationService } from '../service/authentication.service';
import{OVR_PRD} from '../constant/auth-constant';

import { ExportToCSV } from '../service/exportToCSV.service';
import { ProccessResponseService } from '../service/proccessResponse.service';



@Component({
  selector: 'app-technical-management',
  templateUrl: './technical-management.component.html',
  styleUrls: ['./technical-management.component.scss'],
  providers: [TechRecordService, MessageService,ConfirmationService,ExportToCSV,ProccessResponseService],
  encapsulation: ViewEncapsulation.None,
})

export class TechnicalManagementComponent implements OnInit {

  technicalRecords: ITechParameters[] = [];
  updatedRecords: ITechParameters[] = [];
  postData: ITechParameters[] = [];
  tecnhicalRecord: ITechParameters;
  updatedTechParameters: ITechParameters[];

  errorMessage: string;
  sucssessMessage: string;
  tableHeader: string;
  myJsonString: any;
  cols: any[];
  router: any;
  mySubscription: any;

  // variable to count success & unsuccessful response 
  countSuccess: number = 0;
  successFields: any[] = [];
  countError: number = 0;

  // pagination variables
  first: number = 0;
  page: number;
  rows: number;
  size: number;

  totalRecords:number = 0;
  rowsPerPage:number = 0;

  // lazy loading variables
  loading: boolean;

  // export To CSV variables
  prdName:string;
  exportFile:string;
  fileTimeStamp = '';


  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];
  
  // Edit records variables
  editedTechRecords:ITechParameters[]; 
  clonedTechRecords: { [s: string]: ITechParameters; } = {};
  @ViewChild('dt', { static: false }) table: Table

  // Add records variables
  newTechnicalRecords: ITechParameters[] = [];
  newRow:boolean;
  displayDialog: boolean;
  newTechRecord:any = {};
  selectedRecord: ITechParameters;
  errorMessageForCode:boolean;
  errorMessageForLabel:boolean;
  errorMessageForValue:boolean;
  duplicateMessageForCode:boolean;
  lastRowPage:number;
  isNewRecord:boolean;
  errorMessageForType:boolean;
  errorMessageForFreq:boolean;
  

  code:string;
  label:string;
  value:string;

  // Delete records variables
 // deleteTechnicalRecords: ITechParameters[]=[];
  deleteTechnicalRecords: ITechParameters;
  msgs: Message[] = [];
  
  // variable for Admin access 
  userRole: string;
  isAdmin: boolean;

  isTableSorted:boolean;

  // Check freq validation success
  isFreqValidate:boolean;
  disableSave:boolean;

  constructor(private techRecordService: TechRecordService,
    private translate: TranslateService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService,
    private _authService: AuthenticationService,
    private exportToCSV:ExportToCSV,
    private proccessResponseService:ProccessResponseService
  ) {}



  ngOnInit() {

    this.isAdmin =this._authService.isAdmin();
   
    // Initialize required variables 
    this.rows = 10;
    this.prdName=OVR_PRD;
    this.exportFile = "_TechnicalManagement";
    
    this.isNewRecord = false;

    // Set frequency flag to true
    this.isFreqValidate = true;
   
    this.getRecordsFromDB();  

    
    // Headers declared with field names for table
    this.cols = [
      { field: 'type', header: 'Type of data' },
      { field: 'code', header: 'Parameter' },
      { field: 'label', header: 'Label' },
      { field: 'value', header: 'Value' }
    ];
    


    // Header list for export to csv

    for(let i in this.cols){
        this.headerList.push(this.cols[i].header);
    }

    // Field list for export to csv

    for(let j in this.cols){
      this.fieldList.push(this.cols[j].field);
    }

    // set error message variable to false
    this.errorMessageForCode = false;
    this.errorMessageForLabel = false;
    this.errorMessageForValue = false;
    this.duplicateMessageForCode = false;
    this.errorMessageForType = false;
    this.errorMessageForFreq = false;
    //this.onSort(event);

    this.isTableSorted = false;
    console.log(this.isTableSorted);
    
    //this.editedTechRecords = this.updatedRecords;
  }



  //====================== Get Records Start =====================

  // This method will fetch the records from DB
    getRecordsFromDB() {
      this.techRecordService.getRecords().subscribe(
        (data: ITechParameters[]) => {
          this.technicalRecords = data;
          console.log(this.technicalRecords)
          //this.editedTechRecords = data;
          //this.technicalRecords.map(element=> element.id = uuid());
          this.updatedRecords = lodash.cloneDeep(this.technicalRecords);
          this.isNewRecord = false;
        },
        (error: any) => this.errorMessage = <any>error
      );
    }
  //====================== Get Records Ends =====================

  //====================== ADD Records Start =====================
    showDialogToAdd() {
      //console.log("Add Row");
      this.errorMessageForCode = false;
      this.errorMessageForLabel = false;
      this.errorMessageForValue = false;
      this.duplicateMessageForCode = false;
      this.errorMessageForFreq = false;
      this.newRow = true;
      this.newTechRecord = {};

      this.errorMessageForType = false;
      //this.tecnhicalRecord = {}  as ITechParameters;
      this.displayDialog = true;
    }

    save() {
      console.log("Save Row");

      console.log(this.table);
      console.log(this.isTableSorted);
      if(this.isTableSorted == true){

        console.log("Sorted");

        this.table.sortOrder = 0;
        this.table.sortField = '';

        this.table.reset();
      }

      this.newTechnicalRecords = [...this.updatedRecords];
    // console.log(this.newTechnicalRecords);

      if(this.table.filteredValue !== undefined){
          
        // this will reset filter
        this.code = undefined;
        this.label = undefined;
        this.value = undefined;
        
        this.table.reset();

      }

      // Reset all error messages to false
      this.duplicateMessageForCode = false;
      this.errorMessageForCode = false;
      this.errorMessageForLabel = false;
      this.errorMessageForValue = false;
      this.errorMessageForType = false;
      this.errorMessageForFreq = false;


      //this.table.reset();

      if (this.newRow){
        console.log(this.newTechRecord);
        // check for duplicate record
        for (let i = 0; i < this.updatedRecords.length; i++){       
          if ((this.updatedRecords[i].code) == (this.newTechRecord.code)) {
            console.log("Duplicate record");
            this.duplicateMessageForCode = true;
          }
        }

        // check for duplication of Parameter value
        if(this.duplicateMessageForCode == true){
          console.log(this.duplicateMessageForCode);
          this.displayDialog = true;
          //this.newTechnicalRecords = this.technicalRecords;
        }

        // check for Null OR Blank record

        else if(this.newTechRecord.type == null || this.newTechRecord.type == "" || this.newTechRecord.type == " "){
          this.displayDialog = true;
          this.errorMessageForType = true;
          this.duplicateMessageForCode = false;
        }
        
        else if(this.newTechRecord.code == null || this.newTechRecord.code == "" || this.newTechRecord.code == " "){
          console.log("blnk input");
          this.displayDialog = true;
          this.errorMessageForCode = true;
          this.duplicateMessageForCode = false;
          //this.messageService.add({ severity: 'error', summary: 'Error Message', detail: `<p>Code is required field</p>` });
          
        }

        else if(this.newTechRecord.label == null || this.newTechRecord.label == "" || this.newTechRecord.label == " "){
          this.displayDialog = true;
          this.errorMessageForLabel = true;
          this.duplicateMessageForCode = false;
        }

        else if(this.newTechRecord.value == null || this.newTechRecord.value == "" || this.newTechRecord.value == " "){
          this.displayDialog = true;
          this.errorMessageForValue = true;
          this.duplicateMessageForCode = false;
        }



        
        else{
        // console.log("Add New record after validation");

          // Check if Parameter contains frequency word
           if(this.newTechRecord.code.toUpperCase().includes("FREQUENCY")){
             console.log("consist freq");

             this.techRecordService.getFreqValidated(this.newTechRecord.value).subscribe(
              (data:boolean) => {
                if(data == true){
                  this.isFreqValidate = true;
                }

                else{
                  this.displayDialog = true;
                  this.isFreqValidate = false;
                  this.errorMessageForFreq = true;
                }

              },

              (error:any) => this.errorMessage = <any> error
             )
             
           }

           else{
             console.log("other parameters");
             this.isFreqValidate = true;
             
           }

           setTimeout(() => {
            if( this.isFreqValidate == true){
              // calculate last row of total records before pushing the new record in table
              this.totalRecords = this.table.totalRecords;
              this.rowsPerPage = this.rows;

              if(this.totalRecords < 10){
                this.lastRowPage = 0;
                console.log(this.lastRowPage);
              }

              else{
                this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
                console.log(this.lastRowPage);
              }

              this.first = this.rowsPerPage * this.lastRowPage;

              this.newTechnicalRecords.push(this.newTechRecord);
              console.log(this.newTechnicalRecords);

              this.displayDialog = false;
              this.newTechRecord.isNew = true;
              this.isNewRecord = true;
              this.updatedRecords = this.newTechnicalRecords;

           }
             
           }, 1500);

        }


      }


    }

    cancel() {
      
      let index = this.newTechnicalRecords.indexOf(this.selectedRecord);
      this.newTechnicalRecords = this.newTechnicalRecords.filter((val, i) => i != index);
      this.newTechRecord = null;
      this.displayDialog = false;
    }
  //====================== ADD Records Ends =====================

  //====================== Update Records Start ==================
  // This method will Edit/Update row in table

    onRowEditInit(techRecord: ITechParameters) {
      console.log("Update");
      console.log(this.clonedTechRecords[techRecord.code]);
      this.clonedTechRecords[techRecord.code] = {...techRecord};
      //console.log(this.clonedTechRecords[techRecord.code]);
    }

    onRowEditSave(techRecord: ITechParameters) {
        techRecord.dirty = true;
        this.isNewRecord = true;
        this.clonedTechRecords[techRecord.code] = {...techRecord};
    }

    onRowEditCancel(techRecord:ITechParameters, index:number) {
    // this.updatedRecords = this.editedTechRecords;
      this.editedTechRecords = this.updatedRecords
      this.editedTechRecords[index] = this.clonedTechRecords[techRecord.code]
      delete this.clonedTechRecords[techRecord.code];
    }
  //====================== Update Records Ends ==================

  //====================== Delete Records Start ==================
  // This method will Delete row in table
    deleteRow(tableRow: ITechParameters, index: number){   
      this.deleteTechnicalRecords = tableRow;
      
      // This method will update the records in DB on click of validate button
      this.techRecordService.deleteRecords(this.deleteTechnicalRecords).subscribe(
        
        (data:any) =>{
          let res ={...data.responseList};
          let resMsg = res[0].msg;

          if(resMsg == true){
            
            this.msgs = [{severity:'error', summary:'Success', detail:`${tableRow.code} is  deleted`}];
            this.getRecordsFromDB();
          }
          else{
            this.msgs = [{severity:'error', summary:'Error', detail:`${tableRow.code} not found`}];  
            this.getRecordsFromDB();
          }
          
          this.proccessResponseService.clearMessage();
          
        },
        (error: any) => console.log(error)
      )


    }

    confirmDelete(tableRow: ITechParameters, index: number) {
      //console.log("Confirm Delete");
      this.confirmationService.confirm({

          accept: () => {
              this.deleteRow(tableRow,index);
            // this.getRecordsFromDB(); 
          },
          reject: () => {
              //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
          }
      });
    }

  //====================== Delete Records Ends ==================

    // This will call on Validate button
    validateRecord(event: Event) {
      this.postData = [];
      console.log(this.postData);

      if(this.isTableSorted == true){

        console.log("Sorted");

        this.table.sortOrder = 0;
        this.table.sortField = '';

        this.table.reset();
      }

  
      // This function will compare the previous value & updated value
      for (let i = 0; i < this.updatedRecords.length; i++) {
        if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.technicalRecords[i])) {
          this.postData.push(this.updatedRecords[i]);

        }
      }
      this.myJsonString = JSON.stringify(this.postData);

      let updatedData: any = this.postData;
  
      // This method will update the records in DB on click of validate button
      this.techRecordService.updateRecords(this.postData).subscribe(
  
        (data: any) => {
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();
        },
  
        (error: any) => console.log(error)
      )
  
  
    }
  
    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {
      this.getRecordsFromDB();
    }


    exportCSVCommon(){
      // This will add time stamp in the filename while exporting the file    
      this.fileTimeStamp = this.exportToCSV.formatDateForExport();
  
      
  
      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}${this.fileTimeStamp}`;
  
      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }
  
      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }
  
      console.log(this.exportedRecords);
  
      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);
  
    }

    // Check for frequency parameter

    valueChanged(changedRecord: ITechParameters){

      // Reset disable flag
      this.disableSave = false;

      // check if parameter consist frequency
      if(changedRecord.code.toUpperCase().includes("FREQUENCY")){

        this.validateFreq(changedRecord.value);

        setTimeout(() => {
          console.log( this.isFreqValidate,"after change");
          
        }, 500);
        
        
      }
      else{
        console.log("other parameters");
        this.isFreqValidate = true;

      }

      setTimeout(() => {
        if(this.isFreqValidate == true){

          this.disableSave = false;
  
        }
        else{
          this.disableSave = true;
  
        }
        
      }, 700);




    }


    validateFreq(freq){
      this.techRecordService.getFreqValidated(freq).subscribe(
        (data:boolean) => {
          this.isFreqValidate = data;
        },

        (error:any) => {

          this.errorMessage = <any> error
        }
       )
    }

  
}
