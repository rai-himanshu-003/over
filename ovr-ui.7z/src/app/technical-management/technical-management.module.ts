import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {ToastModule} from 'primeng/toast';
import {TranslateModule} from '@ngx-translate/core';
import {PaginatorModule} from 'primeng/paginator';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {TooltipModule} from 'primeng/tooltip';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';

import { TechnicalManagementRoutingModule } from './technical-management-routing.module';
import { TechnicalManagementComponent } from './technical-management.component';






@NgModule({
  imports: [
    CommonModule,
    TechnicalManagementRoutingModule,
    TableModule,
    ButtonModule,
    FormsModule,
    TranslateModule,
    MessagesModule,
    MessageModule,
    PaginatorModule,
    TooltipModule,
    ToastModule,
    DialogModule,
    ConfirmDialogModule
  ],
  declarations: [
    TechnicalManagementComponent
  ]
})
export class TechnicalManagementModule { }
