import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MassTreatmentComponent } from './mass-treatment.component';

describe('MassTreatmentComponent', () => {
  let component: MassTreatmentComponent;
  let fixture: ComponentFixture<MassTreatmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MassTreatmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MassTreatmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
