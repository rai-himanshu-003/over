import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

import { MassTreatmentComponent } from './mass-treatment.component';
import { MassTreatmentRoutingModule } from './mass-treatment-routing.module';

import { PanelModule } from 'primeng/panel';
import {FileUploadModule} from 'primeng/fileupload';
import {TooltipModule} from 'primeng/tooltip';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';

@NgModule({
    imports:[
        CommonModule,
        FormsModule,
        TranslateModule,
        MassTreatmentRoutingModule,

        PanelModule,
        FileUploadModule,
        TooltipModule,
        MessagesModule,
        MessageModule
    ],
    declarations:[MassTreatmentComponent]
})

export class MassTreatmentModule{}