import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

import { Message, MessageService } from 'primeng/api';
import { MassTreatmentService } from '../service/mass-treatment.service';
import { ProccessResponseService } from '../service/proccessResponse.service';
import { async } from '@angular/core/testing';

@Component({
  selector: 'app-mass-treatment',
  templateUrl: './mass-treatment.component.html',
  styleUrls: ['./mass-treatment.component.scss'],
  providers: [MessageService,ProccessResponseService]
})
export class MassTreatmentComponent implements OnInit {

  file: string|File|any;

  // Variable to display message
  msgs: Message[] = [];

  @ViewChild('inputFile', { static: false }) myInputVariable: ElementRef;
  

  constructor(
    public massTreatmentService:MassTreatmentService,
    public proccessResponseService:ProccessResponseService) { }

  ngOnInit() {
  }

  selectFiletoUpload(event: any): void{
    if (event.target.files && event.target.files.length > 0) {
      this.file = event.target.files[0];
    }
  }

  importFile(event){

    console.log("importFile");

    if(!this.file) {

      console.log("importFile is empty");
   
      this.msgs.push({severity:'error', summary:'Error', detail:'The file path is empty or incorrect'});
    }

    else{
      let updatedData = null;
      let errorMessage: string = "";
      let successMessage: string = "";

      this.massTreatmentService.uploadFile(this.file).subscribe(
        
        
        (data:any) => {
          successMessage = data.message;

          // if(data.msg == true){
          //   this.msgs.push({severity: 'success', summary: "Success", detail:`<div>${successMessage}</div>`});
          // }
          // else{
          //   errorMessage = data.message;

          //   this.msgs.push({severity:'error', summary:'Error', detail:`<div>${errorMessage}</div>`});
          // }

          this.proccessResponseService.processResponseForMessage(data);

          setTimeout(() => {
            this.reset();
          }, 5500);
          
        }
      )

      

    }
  }

  

  reset() {
      this.myInputVariable.nativeElement.value = '';
  }

}
