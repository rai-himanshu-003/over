import { Component, OnInit, Renderer2 } from '@angular/core';
import { routerTransition } from '../router.animations';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthenticationService } from '../service/authentication.service';
import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_USER_NAME } from '../constant/auth-constant';

const URL = '/JAXRS-FileUpload/rest/files/upload';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: [routerTransition()]
})
export class DashboardComponent implements OnInit {

  userRole : string;
    
  constructor(private _authService: AuthenticationService) { 
    const user : any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
    this.userRole = user.userRole;
  }
    

  ngOnInit() {

  }

  isReader(): boolean {
  //console.log(this._authService.isReader());
    return this._authService.isReader();
  }


}
