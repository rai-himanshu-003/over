import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard.component';
import { PageHeaderModule } from '../shared';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {NgbModal,NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';


@NgModule({
    imports: [CommonModule, DashboardRoutingModule, FormsModule, PageHeaderModule, 
        NgbModule.forRoot(), TranslateModule],
    declarations: [DashboardComponent],
    providers:[NgbActiveModal,NgbModal]
})
export class DashboardModule {}
