import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../service/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class CheckReaderGuard implements CanActivate {
  role: string;

  constructor(private authenticationService:AuthenticationService) { 
    // this.routingService.getAccessRole().subscribe((value) => {
    //   console.log(value, "Program Role")
    //   this.role = value;
    // });
  }

  canActivate(
    _next: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if (this.authenticationService.isReader() == true) {
        return false;
      }

        return true;
  }
  
}
