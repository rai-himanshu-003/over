import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComposantsOvComponent } from './composants-ov.component';

describe('ComposantsOvComponent', () => {
  let component: ComposantsOvComponent;
  let fixture: ComponentFixture<ComposantsOvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComposantsOvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComposantsOvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
