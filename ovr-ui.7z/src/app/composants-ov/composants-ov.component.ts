import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';

import { GetSelectedVinService } from '../service/getVin.service';
import { AuthenticationService } from '../service/authentication.service';


import { TranslateService } from '@ngx-translate/core';

import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Message, LazyLoadEvent } from 'primeng/components/common/api';

import * as lodash from 'lodash';
import { ITableParameters } from '../models/vehicle-details';

import { OVR_PRD } from '../constant/auth-constant';
import { ComposantOVService } from '../service/composant-ov.service';
import { ProccessResponseService } from '../service/proccessResponse.service';
import { ExportToCSV } from '../service/exportToCSV.service';
import { CompareMaxLimit } from '../shared/services/compareMaxLimit';

@Component({
  selector: 'app-composants-ov',
  templateUrl: './composants-ov.component.html',
  styleUrls: ['./composants-ov.component.scss'],
  providers: [MessageService, ConfirmationService,ExportToCSV,ProccessResponseService,CompareMaxLimit],
  encapsulation: ViewEncapsulation.None,
})
export class ComposantsOvComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table

  vinForHistory: string;
  vinForComposantOV:string;
  errorMessage: string;

  // variable for Admin access 
  isAdmin: boolean;
  isPFA:boolean;
  isReader:boolean;

  // Varoable to show data
  tableHeaders:any[] = [];
  tableRecords:ITableParameters[] = [];
  updatedRecords:ITableParameters[] = [];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  today = new Date();
  fileTimeStamp = '';


  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  // Add records variables
  displayDialog: boolean;
  newRow: boolean;
  newRecords: ITableParameters[] = [];
  newRecord:any = {};
  selectedRecord:ITableParameters;
  isNewRecord: boolean;
  isRequired:boolean;

  // Variable for Error message for adding new row
  errorMessageForData:boolean;
  errorMessageForSupplier:boolean;
  errorMessageForPart:boolean;
  errorMessageForEid:boolean;
  errorMessageForLabel:boolean;
  errorMessageForStandard:boolean;


  errorMessageForEidGM1737:boolean;

  // Pagination while adding new records
  totalRecords: number = 0;
  rowsPerPage: number;
  lastRowPage: number;

  // Update records variables

  editedRecords: ITableParameters[];
  clonedRecords: { [s: string]: any; } = {};

  // Validate records Variable
  postData: ITableParameters[] = [];

  // Delete records variables

  deleteRecord: any;
  msgs: Message[] = [];

  // Validation based on Standered
  showPlaceHolder:boolean;
  isValidPart:boolean;
  partMaxLength:number;
  eidMaxLength:number
  supplierMaxLength:number;
  dataMaxLength:number;
  labelMaxLength:number;

  standard:string;
  label:string;
  eid:string;
  data:string;
  part:string;
  supplier:string;
  disableSave:boolean;
  isOther:boolean;
  id:string;

  // variable for edit placeholder
  showPlaceHolderLabel:boolean;
  showPlaceHolderId:boolean;
  showPlaceHolderPart:boolean;
  showPlaceHolderSupplier:boolean;
  showPlaceHolderData:boolean;

  // Variable for max limit of rpo
  maxLimit:any;
  isAddDisable:boolean;
  addBtnTooltip:string;

  constructor(
    private getSelectedVinService:GetSelectedVinService,
    private composantOVService:ComposantOVService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService,
    private _authService: AuthenticationService,
    private proccessResponseService:ProccessResponseService,
    private exportToCSV:ExportToCSV,
    private compareMaxLimit:CompareMaxLimit
  ) {}

    ngOnInit() {

      this.showPlaceHolder = true;

      this.isValidPart = false;

      // To verify User is Admin or Not
      this.isAdmin = this._authService.isAdmin();
      this.isPFA = this._authService.isPFA();
      this.isReader = this._authService.isReader();

      
      this.tableHeaders = [
        { field: 'id', header: 'ID' },
        { field: 'standard', header: 'Standard' },
        { field: 'label', header: 'Label' },
        { field: 'eid', header: 'EId' },
        { field: 'part', header: 'Part' },
        { field: 'supplier', header: 'Supplier' },
        { field: 'data', header: 'Data' }
      ]

      //this.getRecordsFromDB();
      this.storeVin();

      // export To CSV variables initialise
      this.prdName = OVR_PRD;
      this.exportFile = "_Composants-OV";


      // Header list for export to csv
      for(let i in this.tableHeaders){
        this.headerList.push(this.tableHeaders[i].header);
      }

      // Field list for export to csv
      for(let j in this.tableHeaders){
        this.fieldList.push(this.tableHeaders[j].field);
      }

    }

    storeVin() {
      
      // Set the value of Vin number in variable
      this.vinForComposantOV = window.localStorage.getItem("vinSearch");

      // If value is not null or undefined then call get data
      if(this.vinForComposantOV !=null && this.vinForComposantOV != undefined){
        window.localStorage.setItem("vinForComposantOV",this.vinForComposantOV);
        this.getRecordsFromDB();
      }
      
    }
  
  
    getRecordsFromDB(){

      let vinNumber:string =  window.localStorage.getItem("vinForComposantOV");

      if(vinNumber !=null && vinNumber != undefined){
        //console.log("vin"+ vinNumber);
        this.vinForHistory = vinNumber;
        //console.log(this.vinForHistory);
      }

      else{
        console.log("no Vin found");
      }

      this.composantOVService.getRecords(this.vinForHistory).subscribe(
        
        (data:any) => {
          this.tableRecords = data.datalist;
          this.updatedRecords = lodash.cloneDeep(this.tableRecords);

          // Compare for max limit
          this.maxLimit = data.totalNumberOfRecords;
          this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
          this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);
          
        },
        (error:any) => this.errorMessage = <any> error

      )

    }
  //======================== Reset records Start=========================

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForSupplier = false;
      this.errorMessageForPart = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;

      // Disable Validate
      this.isNewRecord = false;
      this.getRecordsFromDB();

      // Go to first page
      this.first = 0;

    }

  //======================== Reset records Ends=========================
  //=========================== Add Start===============================

    showDialogToAdd() {
        
      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForSupplier = false;
      this.errorMessageForPart = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;

      this.errorMessageForEidGM1737 = false;


      // Reset Place holder value

      this.showPlaceHolder = true;

  
      // Set new record to null / empty
      this.newRecord = {};
  
      // Set flag of new record
      this.newRow = true;
  
      // Display Dialoug box
      this.displayDialog = true;

      if(this.tableRecords.length == this.updatedRecords.length){

        // Reset Sort 
        if(this.table.sortOrder != 0){
          this.table.sortOrder = 0;
          this.table.sortField = '';
          this.table.reset();
          this.getRecordsFromDB();
        }

        // Reset Filter 

        if(this.table.filteredValue !== undefined){
          // Reset all filter fields
          this.id = undefined;
          this.standard = undefined;
          this.label = undefined;
          this.eid = undefined;
          this.data = undefined;
          this.part = undefined;
          this.supplier = undefined;

          this.table.reset();

        }

      }



    }
  
    save(){

      //console.log("save");

      // copy all previous records in new list
      this.newRecords = [...this.tableRecords];

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForSupplier = false;
      this.errorMessageForPart = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;


      // For new Record
      if (this.newRow) {

        // Common validation

        this.newRecord.vin = this.vinForHistory;
        this.newRecord.id = null;

        if (this.newRecord.standard == null || this.newRecord.standard == "" || this.newRecord.standard == "") {
  
          this.displayDialog = true;
          this.errorMessageForStandard = true;
        }

        else{

          // Validation for OTHER standard
          if(this.isOther == true){
           // console.log("OTHER");

            if (this.newRecord.label == null || this.newRecord.label == "" || this.newRecord.label == "") {
  
              this.displayDialog = true;
              this.errorMessageForLabel = true;
            }

            else if (this.newRecord.data == null || this.newRecord.data == "" || this.newRecord.data == "") {
  
              this.displayDialog = true;
              this.errorMessageForData = true;
            }

            else{

            
              // claculate last row of total records before pushing the new record in table
              this.totalRecords = this.table.totalRecords;
              this.rowsPerPage = this.rows;
      
              if (this.totalRecords < 10) {
                this.lastRowPage = 0;
                
              }
              else {
                this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
                
              }
      
              this.first = this.rowsPerPage * this.lastRowPage;
      
              // Insert New record after claculating last row
              this.newRecords.push(this.newRecord);
              this.displayDialog = false;
              this.newRecord.isNew = true;
              this.isNewRecord = true;
              
              //this.showPlaceHolder = false;
              this.tableRecords = this.newRecords;
  
            }

          }
          
                  // Validation for GM1737 ans ext standard
          else{
            //console.log("GM1737");

            if (this.newRecord.eid == null || this.newRecord.eid == "" || this.newRecord.eid == "") {
    
              this.displayDialog = true;
              this.errorMessageForEid = true;
            }

            else if (this.newRecord.label == null || this.newRecord.label == "" || this.newRecord.label == "") {
  
              this.displayDialog = true;
              this.errorMessageForLabel = true;
            }

            else if (this.newRecord.part == null || this.newRecord.part == "" || this.newRecord.part == "") {
    
              this.displayDialog = true;
              this.errorMessageForPart = true;
            }

            else if (this.newRecord.supplier == null || this.newRecord.supplier == "" || this.newRecord.supplier == "") {
    
              this.displayDialog = true;
              this.errorMessageForSupplier = true;
            }
    
            else if (this.newRecord.data == null || this.newRecord.data == "" || this.newRecord.data == "") {
      
              this.displayDialog = true;
              this.errorMessageForData = true;
            }

            else{

            
              // claculate last row of total records before pushing the new record in table
              this.totalRecords = this.table.totalRecords;
              this.rowsPerPage = this.rows;
      
              if (this.totalRecords < 10) {
                this.lastRowPage = 0;
                
              }
              else {
                this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
                
              }
      
              this.first = this.rowsPerPage * this.lastRowPage;
      
              // Insert New record after claculating last row
              this.newRecords.push(this.newRecord);
              this.displayDialog = false;
              this.newRecord.isNew = true;
              this.isNewRecord = true;
              
              //this.showPlaceHolder = false;
              this.tableRecords = this.newRecords;
  
            }
    
          }


        }

        // Check for max limit

        this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
        this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);

      }

    }
  
    cancel(){
      let index = this.newRecords.indexOf(this.selectedRecord);
      this.newRecords = this.newRecords.filter((val, i) => i != index);
      this.newRecord = null;
      this.displayDialog = false;

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForSupplier = false;
      this.errorMessageForPart = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;
    }
  
    //=========================== Add Ends================================
  //======================== Update Start===============================

    onRowEditInit(editedRecord: ITableParameters) {

      // Reset the value
    // console.log(editedRecord);
      this.showPlaceHolder = true;

      if(editedRecord.standard == "OTHER"){

      // console.log("OTHER");
        if(editedRecord.eid == "" || editedRecord.eid == null){
        // console.log("1");
          this.showPlaceHolderId = false;
          this.eidMaxLength = 2;
        }
        if(editedRecord.part == "" || editedRecord.part == null){
        // console.log("2");
          this.showPlaceHolderPart = false;
          this.partMaxLength = 9;
        }
        if(editedRecord.supplier == "" || editedRecord.supplier == null){
          //console.log("3");

          this.showPlaceHolderSupplier = false;
          this.supplierMaxLength = 12;
        }


      }
      

      this.disableSave = true;
      this.clonedRecords[editedRecord.id] = {...editedRecord};
    }

    onRowEditSave(editedRecord: ITableParameters,index: number) {

      editedRecord.dirty = true;
      this.isNewRecord = true;
      editedRecord.vin = this.vinForHistory;

      // if(editedRecord.standard == "OTHER"){
      //   console.log("Edited Other");
      // }
      // else if(editedRecord.standard == "GM1737"){
      //   console.log("Edited GM1737");
      // }
      // else if(editedRecord.standard == "GMW15862"){
      //   console.log("Edited GMW15862");
      // }
      // else{
      //   console.log("Edited Else");
      // }

      this.clonedRecords[editedRecord.id] = { ...editedRecord }; 

    }

    onRowEditCancel(editedRecord: ITableParameters,index: number) {

      this.editedRecords = this.tableRecords;
      this.editedRecords[index] = this.clonedRecords[editedRecord.id];
      delete this.clonedRecords[editedRecord.id];

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForSupplier = false;
      this.errorMessageForPart = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;
    }

  //======================== Update Ends===============================
  //======================== Validate Start=============================
    validateRecord(event: Event) {
      
      // This will reset the Post data
      this.postData = [];
      
      // This function will compare the prvious value & updated value
      // for (let i = 0; i < this.tableRecords.length; i++) {
      //   if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.tableRecords[i])) {
      //     this.postData.push(this.tableRecords[i]);
          
      //   }
  
      // }

      for (let i = 0; i < this.tableRecords.length; i++) {
        if(this.tableRecords[i].dirty == true || this.tableRecords[i].isNew == true){
          // console.log(this.tableRecords[i].id);
          this.postData.push(this.tableRecords[i]);
        }
      }
  
      let updatedData: any = this.postData;
  
      // This method will update the records in DB on click of validate button
      this.composantOVService.updateRecords(this.postData).subscribe(
  
        (data: any) => {
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();

          // This will refresh the whole Page => code to solve version issue
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        },
        
  
        (error: any) => console.log(error)
      )

      this.isNewRecord = false;

    }
  
    valueChanged(rowData: any){

      // Reset the value
      // this.showPlaceHolder = true;
      // this.eidMaxLength = 18;
      // this.partMaxLength = 18;
      // this.supplierMaxLength = 18;
      // this.dataMaxLength = 255;


      this.isOther = false;

      if(this.newRecord.standard == "GM1737"){
        this.showPlaceHolder = false;
        this.labelMaxLength = 256;
        this.eidMaxLength = 2;
        this.partMaxLength = 4;
        this.supplierMaxLength = 1;
        this.dataMaxLength = 9;
        
        this.isOther = false;
      }

      else if(this.newRecord.standard == "GMW15862"){
        this.showPlaceHolder = false;
        this.labelMaxLength = 256;
        this.eidMaxLength = 15;
        this.partMaxLength = 9;
        this.supplierMaxLength = 12;
        this.dataMaxLength = 17;
      }

      else if(this.newRecord.standard == "OTHER"){
        this.showPlaceHolder = false;
        this.labelMaxLength = 256;
        this.eidMaxLength = 2;
        this.partMaxLength = 9;
        this.supplierMaxLength = 12;
        this.dataMaxLength = 255;

        this.isOther = true;

        
      }

      else{
        this.showPlaceHolder = true;
        // this.eidMaxLength = 18;
        // this.partMaxLength = 18;
        // this.supplierMaxLength = 18;
        // this.dataMaxLength = 255;

        this.isOther = false;        
        
      }



    }

    valueChangedEdit(changedRecord: ITableParameters){

      
      this.showPlaceHolder = true;

    // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForSupplier = false;
      this.errorMessageForPart = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;
      this.disableSave = false;

    // Reset max length
    // this.labelMaxLength = null;
    // this.eidMaxLength = null;
    // this.partMaxLength = null;
    // this.supplierMaxLength = null;
    // this.dataMaxLength = null;

    // this.showPlaceHolderLabel = true;
    // this.showPlaceHolderId = true;
    // this.showPlaceHolderPart = true;
    // this.showPlaceHolderSupplier = true;
    // this.showPlaceHolderData = true;


    if(changedRecord.standard == ""){
      this.disableSave = true;
      this.errorMessageForStandard = true;
    }

    else{
      if(changedRecord.standard == "OTHER"){

        console.log("Edit Other");

        if(changedRecord.label == ""){
          this.disableSave = true;
          this.errorMessageForLabel = true;
  
          this.showPlaceHolderLabel = false;
          this.labelMaxLength = 256;
        }

        if(changedRecord.eid == ""){
          this.showPlaceHolderId = false;
          this.eidMaxLength = 2;
        }
        if(changedRecord.part == ""){
          this.showPlaceHolderPart = false;
          this.partMaxLength = 9;
        }
        if(changedRecord.supplier == ""){

          this.showPlaceHolderSupplier = false;
          this.supplierMaxLength = 12;
        }

        if(changedRecord.data == ""){
          this.disableSave = true;
          this.errorMessageForData = true;

          this.showPlaceHolderData = false;
          this.dataMaxLength = 256;
        }

        else{
          
          this.labelMaxLength = 256;
          this.eidMaxLength = 2;
          this.partMaxLength = 9;
          this.supplierMaxLength = 12;
          this.dataMaxLength = 256;
        }


      }

      else if(changedRecord.standard == "GM1737"){
          
        if(changedRecord.label == ""){
          this.disableSave = true;
          this.errorMessageForLabel = true;

          this.showPlaceHolderLabel = false;
          this.labelMaxLength = 256;
        }
        if(changedRecord.eid == ""){
          this.disableSave = true;
          this.errorMessageForEid = true;

          this.showPlaceHolderId = false;
          this.eidMaxLength = 2;
        }
        if(changedRecord.part == ""){
          this.disableSave = true;
          this.errorMessageForPart = true;

          this.showPlaceHolderPart = false;
          this.partMaxLength = 4;
        }

        if(changedRecord.supplier == ""){
          this.disableSave = true;
          this.errorMessageForSupplier = true;

          this.showPlaceHolderSupplier = false;
          this.supplierMaxLength = 1;
        }

        if(changedRecord.data == ""){
          this.disableSave = true;
          this.errorMessageForData = true;

          this.showPlaceHolderData = false;
          this.dataMaxLength = 9;
        }

        else{
          this.labelMaxLength = 256;
          this.eidMaxLength = 2;
          this.partMaxLength = 4;
          this.supplierMaxLength = 1;
          this.dataMaxLength = 9;

        }



      }

      else if(changedRecord.standard == "GMW15862"){
  
        if(changedRecord.label == ""){
          this.disableSave = true;
          this.errorMessageForLabel = true;

          this.showPlaceHolderLabel = false;
          this.labelMaxLength = 256;
        }
        if(changedRecord.eid == ""){
          this.disableSave = true;
          this.errorMessageForEid = true;

          this.showPlaceHolderId = false;
          this.eidMaxLength = 15;
        }
        if(changedRecord.part == ""){
          this.disableSave = true;
          this.errorMessageForPart = true;

          this.showPlaceHolderPart = false;
          this.partMaxLength = 9;
        }
        if(changedRecord.supplier == ""){
          this.disableSave = true;
          this.errorMessageForSupplier = true;

          this.showPlaceHolderSupplier = false;
          this.supplierMaxLength = 12;
        }
        if(changedRecord.data == ""){
          this.disableSave = true;
          this.errorMessageForData = true;

          this.showPlaceHolderData = false;
          this.dataMaxLength = 17;
        }

        else{
          this.labelMaxLength = 256;
          this.eidMaxLength = 15;
          this.partMaxLength = 9;
          this.supplierMaxLength = 12;
          this.dataMaxLength = 17;

        }

      }

    }


    }

  //======================== Validate Ends=============================

  //=========================== Delete Starts=========================

    // This method will Delete row in table
    deleteRow(tableRow: any, index: number) {

      this.deleteRecord = tableRow;
      

      // This method will update the records in DB on click of validate button
      //this.deleteRecordsFromDB();

      this.composantOVService.deleteRecords(this.deleteRecord).subscribe(

        (data: any) => {
          
          let res ={...data.responseList};
          let resMsg = res[0].msg;
          let tableRow = this.deleteRecord;

          if (resMsg == true) {

            // this.msgs = [{severity:'error', summary:'Warning', detail:`${tableRow.id} is  deleted`}];
            this.messageService.add({ severity: 'error', summary: 'Deleted', detail: `${tableRow.id}` });
            this.getRecordsFromDB();
          }
          else {
            this.msgs = [{ severity: 'error', summary: 'Error', detail: `${tableRow.id} not found` }];
            this.getRecordsFromDB();
          }

          this.proccessResponseService.clearMessage();

        },
        (error: any) => console.log(error)
      )


    }

    // Show confirmation box before delete function

    confirmDelete(tableRow: any, index: number) {
      
      this.confirmationService.confirm({

        accept: () => {
          this.deleteRow(tableRow, index);
        },
        reject: () => {
          //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
      });
    }

  //=========================== Delete Ends=========================

    exportCSVCommon(){
      // This will add time stamp in the filename while exporting the file    
      this.fileTimeStamp = this.exportToCSV.formatDateForExport();


      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}${this.vinForHistory}${this.fileTimeStamp}`;

      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }

      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);

    }

}
