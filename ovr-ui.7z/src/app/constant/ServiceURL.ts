import { GlobalsService } from '../service/globals.service';

// export class ServiceURL {

//     //for viewLog in rule status
//     public static getLogServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/ruleloginfo';
//     }

//     public static getProjectServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/project';
//     }

//     public static getProjectUpdateServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/project/update';
//     }

//     public static getProjectCreateServiceURL() {
//         // TODO: replace upload by create 
//         return GlobalsService.BASE_API_URL + '/admin/project/new';
//     }

//     public static getProjectListServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/projectlist';
//     }

//     public static getSimulationUploadServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/simulation/upload';
//     }

//     public static getSimulationServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/simulation';
//     }

//     public static getDownloadServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/download/file';
//     }

//     //view Log in simulation mode  
//     public static getViewLogServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/simulation/viewLog';
//     }

//     //download log in simulation mode
//     /* public static getDownloadViewLogServiceURL() {
//        return GlobalsService.BASE_API_URL+'/admin/simulation/viewLog';//viewLogFile
//    } */

//     //new implementation of getViewLog in viewtranscodification
//     public static getTranscodificationViewLogServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/transcode/downloadLogFile'
//     }

//     public static getDownloadResultServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/transcode/downloadResultFile'
//     }

//     //view request in view transcodification
//     public static getViewRequestServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/transcode/viewRequestFile';
//     }

//     public static getDataForViewTranscodificationServiceURL() {
//         // return GlobalsService.BASE_API_URL+'/admin/transcode/getClientSystem';
//         return GlobalsService.BASE_API_URL + '/admin/projectlist';
//     }


//     public static getDataForProjectInViewTranscodificationServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/transcode/getClientSystem';
//     }

//     public static transcodeServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/transcode';
//     }

//     public static authenticationServiceURL() {
//         return GlobalsService.BASE_API_URL + '/auth/login';
//     }

//     public static lockProjectListServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/projectlist/lockprojectlist';
//     }

//     public static unLockProjectServiceURL() {
//         return GlobalsService.BASE_API_URL + '/admin/projectlist/unlock';
//     }

//     public static productLineServiceURL() {
//         return GlobalsService.BASE_API_URL + '/dictionnaries/productlinecode';
//     }

//     public static pcdFamilyDetailsServiceURL(selectedProductLine: string) {
//         return `${GlobalsService.BASE_API_URL}/dictionnaries/getfamilycodelist/${selectedProductLine}`;
//     }

//     public static ovDictionarySearchUrl(){
//         return `${GlobalsService.BASE_API_URL}/dictionnaries/ovSearch`;
//     }

//     public static ovDictionarySearchCriteriaUrl(){
//         return `${GlobalsService.BASE_API_URL}/dictionnaries/ovSearchCriteria`;
//     }

//     public static updateUserControlUrl(){
//         return `${GlobalsService.BASE_API_URL}/dictionnaries/updateUserControl`;
//     }

//     public static controlReportUrl(){
//         return `${GlobalsService.BASE_API_URL}/controlreports`;
//     }
//     public static controlReportFileUrl(id:string){
//         return `${GlobalsService.BASE_API_URL}/controlreports/${id}/download`;
//     }

//     public static techManagementUrl(){
//         return `${GlobalsService.BASE_API_URL}/techParam?locale=En`;
//     }

//     public static updatetechManagementUrl(){
//         return `${GlobalsService.BASE_API_URL}/techParam/updateParam`;
//     }

    
//     public static errorManagementUrl(){
//         return `${GlobalsService.BASE_API_URL}/resendToOtt/getErrorList`;
//     }

//     public static updateerrorManagementUrl(){
//         return `${GlobalsService.BASE_API_URL}/resendToOtt/updateStat`;
//     }

//     public static ignoreerrorManagementUrl(){
//         return `${GlobalsService.BASE_API_URL}/resendToOtt/ignore`;
//     }

//     public static exportToCSVtUrl(){
//         return `${GlobalsService.BASE_API_URL}/resendToOtt/exportToCSV`;
//     }

//     public static getAllInterfaceStatus(){
//         return `${GlobalsService.BASE_API_URL}/interfacemanagement`;
//     }

    

// }

