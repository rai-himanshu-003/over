export const LOCAL_STORAGE_TOKEN_NAME = 'access_token';
export const LOCAL_STORAGE_USER_NAME = 'ovr_user';

export const ROLE_ADMIN = 'ADMIN';
export const ROLE_RULE_MANAGER = 'RULE_MANAGER';
export const OVR_PRD = 'ovr';