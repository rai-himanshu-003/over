import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { MappingOVPSARecordService } from '../service/mapping-ovpsa.service';
import { IMappingOVPSAParameters } from "../mapping-ovpsa/mapping-ovpsa";

import * as lodash from 'lodash';
import { TranslateService } from '@ngx-translate/core';
import { OVR_PRD } from '../constant/auth-constant';

import { MessageService } from 'primeng/api';
import { Message, LazyLoadEvent, ConfirmationService } from 'primeng/components/common/api';
import { Table } from 'primeng/table';
import { AuthenticationService } from '../service/authentication.service';

import { ExportToCSV } from '../service/exportToCSV.service';
import { ProccessResponseService } from '../service/proccessResponse.service';


@Component({
  selector: 'app-mapping-ovpsa',
  templateUrl: './mapping-ovpsa.component.html',
  styleUrls: ['./mapping-ovpsa.component.scss'],
  providers: [MappingOVPSARecordService, MessageService, ConfirmationService,ProccessResponseService,ExportToCSV],
  encapsulation: ViewEncapsulation.None,
})
export class MappingOvpsaComponent implements OnInit {



  // Declare required variables here
  @ViewChild('dt', { static: false }) table: Table

  // variable for Admin access 

  isAdmin: boolean;

  // Variables require to show data in table
  cols: any[];
  ovPsaMappingRecords: IMappingOVPSAParameters[] = [];
  updatedRecords: IMappingOVPSAParameters[] = [];
  errorMessage: string;

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // Pagination while adding new records
  totalRecords: number = 0;
  rowsPerPage: number;
  lastRowPage: number;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  fileTimeStamp = '';
    
  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  // Add records variables
  newRow: boolean;
  isNewRecord: boolean;
  displayDialog: boolean;
  errorMessageForTypePSA: boolean;
  errorMessageForKeyPSA: boolean;
  errorMessageForOvStandard: boolean;
  errorMessageForkeyOV: boolean;
  errorMessageFordesc: boolean;
  duplicateMessageForOvStandard:boolean;
  duplicateMessageForkeyOV:boolean;
  newMappingRecord: any = {};
  selectedRecord: IMappingOVPSAParameters;
  newMappinglRecords: IMappingOVPSAParameters[] = [];

  // Update records variables
  
  editedMappingRecords: IMappingOVPSAParameters[];
  clonedMappingRecords: { [s: string]: IMappingOVPSAParameters; } = {};

  // Validate records Variable
  postData: IMappingOVPSAParameters[] = [];

  // Delete records variables

  deleteMappingOVRecord: IMappingOVPSAParameters;
  msgs: Message[] = [];

  disableSave:boolean = false;

  // To clear filter
  psaType:string
  psaKey:string;
  ovStandard:string;
  ovKey:string;
  description:string;

  duplicateMessage: Message[] = [];

  constructor(
    private mappingovpsaRecordService: MappingOVPSARecordService,
    private translate: TranslateService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService,
    private _authService: AuthenticationService,
    private exportToCSV:ExportToCSV,
    private proccessResponseService:ProccessResponseService
  ) { 


  }

  ngOnInit() {

    // To verify User is Admin or Not
    this.isAdmin = this._authService.isAdmin();

    // Reset Error messages
    this.errorMessageForTypePSA = false;
    this.errorMessageForKeyPSA = false;
    this.errorMessageForOvStandard = false;
    this.errorMessageForkeyOV = false;
    this.disableSave = false;

    // Headers declared with field names for table
    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'psaType', header: 'Type Of PSA Data' },
      { field: 'psaKey', header: 'Psa Key' },
      { field: 'ovStandard', header: 'OV Standard' },
      { field: 'ovKey', header: 'OV Key' },
      { field: 'description', header: 'Description' }
    ];

    // This method will fetch the records from DB
    this.getRecordsFromDB();

    // export To CSV variables initialize

    this.prdName=OVR_PRD;
    this.exportFile = "_OV_PSA_MAPPING";
    

    // Header list for export to csv

    for(let i in this.cols){
        this.headerList.push(this.cols[i].header);
    }
  
    // Field list for export to csv
  
    for(let j in this.cols){
      this.fieldList.push(this.cols[j].field);
    }
  
  
  }



  // This method will fetch the records from DB
  getRecordsFromDB() {
    this.mappingovpsaRecordService.getRecords().subscribe(
      (data: IMappingOVPSAParameters[]) => {
        this.ovPsaMappingRecords = data;
        console.log(this.ovPsaMappingRecords);
        this.updatedRecords = lodash.cloneDeep(this.ovPsaMappingRecords);
      },
      (error: any) => this.errorMessage = <any>error
    );
  }

  // This method will work for pagination
  paginate(event: any) {
    this.first = event.first;
    this.page = event.page;
    this.rows = event.rows;
    this.size = this.table.totalRecords;

  }

  //======================== Reset records Start=========================

  // This method will reset the records in HTML page on click of Cancel button
  resetRecord(event: any) {
    // Reset Error messages
    this.errorMessageForTypePSA = false;
    this.errorMessageForKeyPSA = false;
    this.errorMessageForOvStandard = false;
    this.errorMessageForkeyOV = false;

    this.disableSave = false;

    
    this.getRecordsFromDB();
    
  }

  //======================== Reset records Ends=========================

  //=========================== Add Start================================
  showDialogToAdd() {
    //console.log("showDialogToAdd");

    // Reset all error messages to false
    this.errorMessageForTypePSA = false;
    this.errorMessageForKeyPSA = false;
    this.errorMessageForOvStandard = false;
    this.errorMessageForkeyOV = false;
    this.errorMessageFordesc = false;
    this.duplicateMessageForOvStandard = false;
    this.duplicateMessageForkeyOV = false;

    // Set new record to null / empty
    this.newMappingRecord = {};

    // Display Dialoug box
    this.displayDialog = true;

    // Set flag of new record
    this.newRow = true;
  }

  // On click of Save button

  save() {
    //console.log("Save Row");

    console.log(this.table.filteredValue);

    if(this.table.filteredValue !== undefined){
        
      // this will reset filter
      this.psaType = undefined
      this.psaKey = undefined;
      this.ovStandard = undefined;
      this.ovKey = undefined;
      this.description = undefined;
      
      this.table.reset();

    }
    
    //this.resetFilter(this.table);

    // copy all previous records in new list
    this.newMappinglRecords = [...this.ovPsaMappingRecords];

    // Reset all error messages to false
    this.errorMessageForTypePSA = false;
    this.errorMessageForKeyPSA = false;
    this.errorMessageForOvStandard = false;
    this.errorMessageForkeyOV = false;
    this.errorMessageFordesc = false;
    // this.duplicateMessageForOvStandard = false;
    this.duplicateMessageForkeyOV = false;

    // For new Record
    if (this.newRow) {

      // check for duplicate value of OV Standered and OV key
      for (let i = 0; i < this.ovPsaMappingRecords.length; i++){

        if ((this.ovPsaMappingRecords[i].ovStandard) === (this.newMappingRecord.ovStandard) && (this.ovPsaMappingRecords[i].ovKey) === (this.newMappingRecord.ovKey) ) {
          console.log("Duplicate record");
          // this.duplicateMessageForOvStandard = true;
          this.duplicateMessageForkeyOV = true;
        }
      }

      // Keep Dialogue box open if duplicate records found
      if( this.duplicateMessageForkeyOV == true){
        
        console.log(this.duplicateMessageForkeyOV);
        this.displayDialog = true;
        //this.newTechnicalRecords = this.technicalRecords;
      }

      // check for Null and Blank record

      else if (this.newMappingRecord.psaType == null || this.newMappingRecord.psaType == "" || this.newMappingRecord.psaType == " ") {

        this.displayDialog = true;
        this.errorMessageForTypePSA = true;
      }

      else if (this.newMappingRecord.psaKey == null || this.newMappingRecord.psaKey == "" || this.newMappingRecord.psaKey == " ") {
        this.displayDialog = true;
        this.errorMessageForKeyPSA = true;
      }

      else if (this.newMappingRecord.ovStandard == null || this.newMappingRecord.ovStandard == "" || this.newMappingRecord.ovStandard == " ") {
        this.displayDialog = true;
        this.errorMessageForOvStandard = true;
      }

      else if (this.newMappingRecord.ovKey == null || this.newMappingRecord.ovKey == "" || this.newMappingRecord.ovKey == " ") {
        this.displayDialog = true;
        this.errorMessageForkeyOV = true;
      }

      else if (this.newMappingRecord.description == null || this.newMappingRecord.description == "" || this.newMappingRecord.description == " ") {
        this.displayDialog = true;
        this.errorMessageFordesc = true;
      }

      else {

        this.newMappingRecord.psaType = this.newMappingRecord.psaType.toUpperCase();
        this.newMappingRecord.psaKey = this.newMappingRecord.psaKey.toUpperCase();
        this.newMappingRecord.ovStandard = this.newMappingRecord.ovStandard.toUpperCase();
        this.newMappingRecord.ovKey = this.newMappingRecord.ovKey.toUpperCase();

        // calculate last row of total records before pushing the new record in table
        this.totalRecords = this.table.totalRecords;
        this.rowsPerPage = this.rows;

        if (this.totalRecords < 10) {
          this.lastRowPage = 0;
          console.log(this.lastRowPage);
        }
        else {
          this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
          console.log(this.lastRowPage);
        }

        this.first = this.rowsPerPage * this.lastRowPage;

        // Insert New record after calculating last row

        this.newMappinglRecords.push(this.newMappingRecord);
        this.displayDialog = false;
        this.newMappingRecord.isNew = true;
        this.isNewRecord = true;

        this.ovPsaMappingRecords = this.newMappinglRecords;

      }
    }
  }

  // On click of Cancel
  cancel() {

    let index = this.newMappinglRecords.indexOf(this.selectedRecord);
    this.newMappinglRecords = this.newMappinglRecords.filter((val, i) => i != index);
    this.newMappingRecord = null;
    this.displayDialog = false;
  }

  //=========================== Add Ends================================

  //======================== Update Start===============================
  // This method will Edit/Update row in table

  onRowEditInit(mappingRecord: IMappingOVPSAParameters) {

    // Reset Error messages
    this.errorMessageForTypePSA = false;
    this.errorMessageForKeyPSA = false;
    this.errorMessageForOvStandard = false;
    this.errorMessageForkeyOV = false;
    this.disableSave = true;
    
    // console.log("Update");
    // console.log(mappingRecord.id);
    // console.log(this.clonedMappingRecords[mappingRecord.id]);
    this.clonedMappingRecords[mappingRecord.id] = { ...mappingRecord };
    //console.log(this.clonedTechRecords[techRecord.code]);

    
  }


  onRowEditSave(mappingRecord: IMappingOVPSAParameters, index: number) {

    mappingRecord.psaType = mappingRecord.psaType.toUpperCase();
    mappingRecord.psaKey = mappingRecord.psaKey.toUpperCase();
    mappingRecord.ovKey = mappingRecord.ovKey.toUpperCase();
    mappingRecord.ovStandard = mappingRecord.ovStandard.toUpperCase();

    mappingRecord.dirty = true;
    this.isNewRecord = true;
    this.clonedMappingRecords[mappingRecord.id] = { ...mappingRecord };    
    
  }

  onRowEditCancel(mappingRecord: IMappingOVPSAParameters, index: number) {

    // Reset Error messages
    this.errorMessageForTypePSA = false;
    this.errorMessageForKeyPSA = false;
    this.errorMessageForOvStandard = false;
    this.errorMessageForkeyOV = false;
    this.errorMessageFordesc = false;
    this.disableSave = false;

    this.editedMappingRecords = this.ovPsaMappingRecords
    this.editedMappingRecords[index] = this.clonedMappingRecords[mappingRecord.id]
    delete this.clonedMappingRecords[mappingRecord.id];
  }


  //======================== Update Ends================================


  //=========================== Validate Starts=========================
    validateRecord(event: Event) {
      
      // This will reset the Post data
      this.postData = [];
      // This function will compare the prvious value & updated value
      for (let i = 0; i < this.ovPsaMappingRecords.length; i++) {
        if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.ovPsaMappingRecords[i])) {
          this.postData.push(this.ovPsaMappingRecords[i]);
          
        }

      }

      let updatedData: any = this.postData;

      // This method will update the records in DB on click of validate button
      this.mappingovpsaRecordService.updateRecords(this.postData).subscribe(

        (data: any) => {
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();
        },
        //(data:any) => console.log(data),

        (error: any) => console.log(error)
      )
    }

    valueChanged(mappingRecord: IMappingOVPSAParameters){
      console.log(mappingRecord);
      mappingRecord.isDuplicate = false;

      // Reset Error messages
      this.errorMessageForTypePSA = false;
      this.errorMessageForKeyPSA = false;
      this.errorMessageForOvStandard = false;
      this.errorMessageForkeyOV = false;
      this.errorMessageFordesc = false;
      this.disableSave = false;

      
      this.updatedRecords.forEach(record =>{
        if(record.id !== mappingRecord.id){
          console.log("Duplicate");
          if(record.ovStandard == mappingRecord.ovStandard){
            if(record.ovKey == mappingRecord.ovKey) {
              
              this.duplicateMessageForkeyOV = true;
              mappingRecord.isDuplicate = true;
              this.disableSave = true;

              this.duplicateMessage = [];
        this.duplicateMessage.push({severity:'error', summary:'Error Message', detail:'Duplicate Record'});
            }
          }
        }
      });

      if(mappingRecord.psaType == ""){
        this.disableSave = true;
        this.errorMessageForTypePSA = true;
      }

      else if(mappingRecord.psaKey == ""){
        this.disableSave = true;
        this.errorMessageForKeyPSA = true;
      }

      else if(mappingRecord.ovStandard == ""){
        this.disableSave = true;
        this.errorMessageForOvStandard = true;
      }

      else if(mappingRecord.ovKey == ""){
        this.disableSave = true;
        this.errorMessageForkeyOV = true;
      }

      else if(mappingRecord.description == ""){
        this.disableSave = true;
        this.errorMessageFordesc = true;
      }

      else{
        
        // Reset Error messages
        this.errorMessageForTypePSA = false;
        this.errorMessageForKeyPSA = false;
        this.errorMessageForOvStandard = false;
        this.errorMessageForkeyOV = false;
        this.errorMessageFordesc = false;
      }

      

    
    }

  //=========================== Validate Ends=========================

  //=========================== Delete Starts=========================

  // This method will Delete row in table
  deleteRow(tableRow: IMappingOVPSAParameters, index: number) {

    this.deleteMappingOVRecord = tableRow;
    

    // This method will update the records in DB on click of validate button

    this.mappingovpsaRecordService.deleteRecords(this.deleteMappingOVRecord).subscribe(
      (data: any) => {
        
        let res = { ...data };
        let resMsg = res.msg;
        

        if (resMsg == true) {

          // this.msgs = [{severity:'error', summary:'Warning', detail:`${tableRow.id} is  deleted`}];
          this.messageService.add({ severity: 'error', summary: 'Deleted', detail: `<div>${tableRow.psaType}/${tableRow.psaKey}/${tableRow.ovStandard}/${tableRow.ovKey}/</div>`, life: 5000 });
          this.getRecordsFromDB();
        }
        else {
          this.msgs = [{ severity: 'error', summary: 'Error', detail: `${tableRow.id} not found` }];
          this.getRecordsFromDB();
        }

        this.proccessResponseService.clearMessage();

      },
      (error: any) => console.log(error)
    )


  }

  // Show confirmation box before delete function

  confirmDelete(tableRow: IMappingOVPSAParameters, index: number) {
    
    this.confirmationService.confirm({

      accept: () => {
        this.deleteRow(tableRow, index);
      },
      reject: () => {
        //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
      }
    });
  }

  //=========================== Delete Ends=========================


  //======================= Export To CSV Starts=====================

  exportCSVForMappingOV(){

    // This will add time stamp in the filename while exporting the file    
    this.fileTimeStamp = this.exportToCSV.formatDateForExport();

    // This will give file Name for exported file
    let filename = `${this.prdName}${this.exportFile}${this.fileTimeStamp}`;

    if(this.table.filteredValue == undefined){
      this.exportedRecords = lodash.cloneDeep(this.table.value);
      //this.exportedRecords = this.table.value;
      
    }

    else{
      this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
      //this.exportedRecords = this.table.filteredValue;
    }


    this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);

  }

  //======================= Export To CSV Ends=====================

}
