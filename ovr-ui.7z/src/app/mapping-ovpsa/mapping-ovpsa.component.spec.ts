import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MappingOvpsaComponent } from './mapping-ovpsa.component';

describe('MappingOvpsaComponent', () => {
  let component: MappingOvpsaComponent;
  let fixture: ComponentFixture<MappingOvpsaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MappingOvpsaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MappingOvpsaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
