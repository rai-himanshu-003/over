import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


import { MappingOvpsaComponent } from './mapping-ovpsa.component';
import { MappingOVPSARoutingModule } from './mapping-ovpsa-routing.module';

import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {ToastModule} from 'primeng/toast';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {TooltipModule} from 'primeng/tooltip';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';

@NgModule({
    imports: [
      MappingOVPSARoutingModule,
      CommonModule,
      FormsModule,
      TableModule,
      ButtonModule,
      TranslateModule,

      DialogModule,
      TooltipModule,
      ToastModule,
      MessagesModule,
      MessageModule,
      ConfirmDialogModule
      

    ],
    declarations: [
        MappingOvpsaComponent
    ]
  })

export class MappingOVPSAModule { }