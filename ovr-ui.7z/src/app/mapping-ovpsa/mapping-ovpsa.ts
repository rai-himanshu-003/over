export interface IMappingOVPSAParameters{
    id:number,
    psaType: string,
    psaKey:string,
    ovStandard:string,
    ovKey:string,
    description:string,
    version:number,
    dirty:boolean,
    isNew:boolean,
    isDuplicate:boolean
}