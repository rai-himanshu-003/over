import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleMetadataComponent } from './vehicle-metadata.component';

describe('VehicleMetadataComponent', () => {
  let component: VehicleMetadataComponent;
  let fixture: ComponentFixture<VehicleMetadataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehicleMetadataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehicleMetadataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
