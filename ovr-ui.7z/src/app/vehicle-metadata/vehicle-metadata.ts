

export class VehicleMetadataParameters{
    version: string;
    vin:string;
    ccp:string;
    veh:string;
    stateId:string;
    xmlOv:string;
    lcdvOtt:string;
    oa: string;
    of: string;
    nre: string;
    tvv: string;
    up: string;
    lcdv24: string;
    apvpr: string;
    model: string;
    modelYear: string;
    dateExtension: number | Date;
    dateEcom: number | Date;
    dateEmon: number | Date;
    dateCreation: number | Date;
    dateModif: number | Date;
    userCreation:string;
    userModif:string;
    isDirty:boolean;
    multipleFlowStatusDTO: Array<multidto>;
    country:string;
    engine:string;
    modelName:string;
    transmission:string;
}

export class multidto {
    
    id: number;
    vin: string;
    version: number;
    flow: string;
    status: string
}



