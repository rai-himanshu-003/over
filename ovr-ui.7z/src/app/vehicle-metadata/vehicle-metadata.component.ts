import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';

import { GetSelectedVinService } from '../service/getVin.service';
import { AuthenticationService } from '../service/authentication.service';


import { TranslateService } from '@ngx-translate/core';

import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Message, LazyLoadEvent } from 'primeng/components/common/api';

import * as lodash from 'lodash';
import { ITableParameters } from '../models/vehicle-details';

import { OVR_PRD } from '../constant/auth-constant';
import { LcdvOTTService } from '../service/lcdv-ott.service';
import { ArtLcdvOTTService } from '../service/artLcdv-ott.service';
import { VehicleDetailsService } from '../service/vehicle-details.service';
import { FormGroup, FormControl } from '@angular/forms';
import { VehicleMetadataParameters, multidto } from './vehicle-metadata';
import { ListOfFlows } from '../models/list-of-flows';
import { element } from 'protractor';
import { StateLabelService } from '../shared/services/stateLabel.service';


@Component({
  selector: 'vehicle-metadata',
  templateUrl: './vehicle-metadata.component.html',
  styleUrls: ['./vehicle-metadata.component.scss'],
  providers: [MessageService, ConfirmationService,ListOfFlows,StateLabelService],
  encapsulation: ViewEncapsulation.None,
})
export class VehicleMetadataComponent implements OnInit {
  formData: FormGroup;

  @ViewChild('vehDetailsForm', { static: false }) form: FormControl;

  vinForHistory: string;
  errorMessage: string;

  // variable for Admin access 
  isAdmin: boolean;
  isReader:boolean;

  // variable to show data
  
  tableRecords:any;
  updatedRecords:any[] = [];

  // variable for Validation

  responseMsg:boolean;
  notValidData:boolean;
  currentStates:any[]=[];
  multipleFlowStatus:any[] = [];

  errorMessageForUp:boolean;
  errorMessageForOf:boolean;
  errorMessageForOa:boolean;
  errorMessageForApvpr:boolean;
  errorMessageForNre:boolean;
  errorMessageForTvv:boolean;
  errorMessageForModel:boolean;
  errorMessageForModelYear:boolean;
  errorMessageForLcdv:boolean;
  errorMessageForCcp:boolean;
  errorMessageForVeh:boolean;
  errorMessageFordateEmon:boolean;

  ottStates:any[] = [];
  gepicsStates:any[] = [];
  corvetStates:any[] = [];

  // New states variable
  transformationStates:any[] = [];
  transformationStates1:any[] = [];
  inputStates:any[] = [];
  outputStates:any[] = [];

  vinForMetadata:string;

  defaultDate: number | Date;

  constructor(
    private getSelectedVinService:GetSelectedVinService,
    private vehicleDetailsService:VehicleDetailsService,
    private translate: TranslateService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService,
    private _authService: AuthenticationService,
    private listofflows:ListOfFlows,
    private stateLabelService:StateLabelService
  ) {
   
    this.transformationStates = [
      {label: 'REIN', value: 'REIN',disabled: true},
      {label: 'IGNR', value: 'IGNR',disabled: true},
      {label: 'ONPR', value: 'ONPR',disabled: true},
      {label: 'TRDN', value: 'TRDN',disabled: true},
      {label: 'KOTR', value: 'KOTR',disabled: true},
      {label: 'CNLD', value: 'CNLD',disabled: true},
    ],

    this.transformationStates1 = [
      {label: 'INIT', value: 'INIT',disabled: true},
      {label: 'REIN', value: 'REIN',disabled: false},
      {label: 'IGNR', value: 'IGNR',disabled: true},
      {label: 'ONPR', value: 'ONPR',disabled: true},
      {label: 'TRDN', value: 'TRDN',disabled: true},
      {label: 'KOTR', value: 'KOTR',disabled: true},
      {label: 'CNLD', value: 'CNLD',disabled: false},
    ],

    this.inputStates = [
      {label: 'CRTD', value: 'CRTD'},
    ],

    this.outputStates = [
      {label: 'INIT', value: 'INIT',disabled: true},
      {label: 'IGNR', value: 'IGNR',disabled: true},
      {label: 'SENT', value: 'SENT',disabled: true},
      {label: 'KOTR', value: 'KOTR',disabled: true},
      {label: 'REIN', value: 'REIN'},
    ]

    // this.outputStates = [
    //   {label: 'REIN', value: 'REIN'},

    // ]

  }

  ngOnInit() {
    // To verify User is Admin or Not
    this.isAdmin = this._authService.isAdmin();
    this.isReader = this._authService.isReader();

    // For local use - Remove this code after API inegration
    // this.isReader = true;
    // this.isAdmin = false;

    console.log(this.isAdmin,"-ADMIN");
    console.log(this.isReader,"-READER");
    

    this.notValidData = true;
    this.storeVin();
  }

  storeVin() {
    
    // Set the value of Vin number in variable
    this.vinForMetadata = window.localStorage.getItem("vinSearch");

    // If value is not null or undefined then call get data
    if(this.vinForMetadata !=null && this.vinForMetadata != undefined){
      window.localStorage.setItem("vinForMetadata",this.vinForMetadata);
      this.getRecordsFromDB();
    }
    
  }

  getRecordsFromDB(){

    let vinNumber:string =  window.localStorage.getItem("vinForMetadata");

    if(vinNumber !=null && vinNumber != undefined){
      //console.log("vin"+ vinNumber);
      this.vinForHistory = vinNumber;
      //console.log(this.vinForHistory);
    }

    else{
      console.log("no Vin found");
    }
    
    
    this.vehicleDetailsService.getRecords(this.vinForHistory).subscribe(
      
      //(data:any) => console.log(data),
      (data:any) => {
        this.tableRecords = data.vehicle;
        this.updatedRecords = lodash.cloneDeep(this.tableRecords);

        console.log(data.vehicle);
        // console.log(this.tableRecords);
        //console.log(data.vehicle.multipleFlowStatusDTO);

        if(data.vehicle.dateExtension == null){
          data.vehicle.dateExtension = data.vehicle.dateExtension
        }

        else{
          data.vehicle.dateExtension = new Date(data.vehicle.dateExtension as Date);
        }

        if(data.vehicle.dateEcom == null){
          data.vehicle.dateEcom = data.vehicle.dateEcom
        }

        else{
          data.vehicle.dateEcom = new Date(data.vehicle.dateEcom as Date);
        }

        if(data.vehicle.dateCreation != null){
          // data.vehicle.dateEcom = data.vehicle.dateEcom
          data.vehicle.dateCreation = new Date(data.vehicle.dateCreation as Date);
        }

        if(data.vehicle.dateModif != null){
          // data.vehicle.dateEcom = data.vehicle.dateEcom
          data.vehicle.dateModif = new Date(data.vehicle.dateModif as Date);
        }


        //data.vehicle.dateEcom = new Date(data.vehicle.dateEcom as Date);
        data.vehicle.dateEmon = new Date(data.vehicle.dateEmon as Date);
        //data.vehicle.dateExtension = new Date(data.vehicle.dateExtension as Date);

        this.formData = data.vehicle;
        // console.log(this.formData);

        // if(data.vehicle.dateEcom == null){
        //   data.vehicle.dateEcom = "";
        // }

        this.multipleFlowStatus = data.vehicle.multipleFlowStatusDTO;

        // Sort array
        this.multipleFlowStatus.sort((a, b) => (a.flow > b.flow) ? 1 : -1)



        this.multipleFlowStatus.map(element => {
          // console.log(element.flow);

          if( element.flow == "OV_INPUT" || element.flow == "PSA_INPUT"){
            element.type = "Input";
          }

          if( element.flow == "OTT" || element.flow == "THUB" || element.flow == "REVOTT" ){
            element.type = "Transformation";
          }

          if( element.flow == "CORVET"){
            element.type = "Output";
          }


        })

        // Change options depending on state
        console.log(this.multipleFlowStatus);

        // this.multipleFlowStatus.map(element => {
        //   // console.log(element.type);

        //   if(element.type == "Transformation" && element.status != "ONPR"){

        //     this.transformationStates.map(state =>{
        //       if(state.value == "REIN" || state.value == "CNLD"){
        //         state.disabled = false;
        //       }
        //     })

        //     console.log(this.transformationStates);
            
        //   }

        //   else if(element.type == "Transformation" && element.status == "ONPR"){
        //     this.transformationStates.map(state =>{
        //       state.disabled = true;
        //     })

        //     console.log(this.transformationStates);
        //   }

          
        // })

        

        this.stateLabelService.addStateLabelForFlow(this.multipleFlowStatus)

        console.log(this.multipleFlowStatus);
      },
      
      (error:any) => this.errorMessage = <any> error

    )


  }

  validateRecord(form: any){
    //console.log(form);
    
    let updatedFormData = {} as VehicleMetadataParameters;
    updatedFormData.multipleFlowStatusDTO = []

    // Define empty arr
    let tempMuliFlowStatus =  [];   

    let arrLength = this.tableRecords.multipleFlowStatusDTO.length;

    let tempMuliFlowObj = this.tableRecords.multipleFlowStatusDTO;

    // console.log(arrLength);
    // console.log(this.tableRecords.multipleFlowStatusDTO);
    // console.log(tempMuliFlowObj);

   
    for(let i=0; i<arrLength;i++){

      let tempObj = {} as multidto;
      tempObj.vin = tempMuliFlowObj[i].vin;   
      tempObj.id = tempMuliFlowObj[i].id;
      tempObj.flow = tempMuliFlowObj[i].flow;
      tempObj.status = tempMuliFlowObj[i].status;
      tempObj.version = tempMuliFlowObj[i].version;

      tempMuliFlowStatus.push(tempObj);
      console.log(tempMuliFlowStatus);
      
    }
        
   
    updatedFormData.multipleFlowStatusDTO = tempMuliFlowStatus;

    // This will initialise the required variables
    updatedFormData.vin = this.tableRecords.vin;
    updatedFormData.version = this.tableRecords.version;

    if(form.controls['ccp'].value == null || form.controls['ccp'].value == undefined ){
      updatedFormData.ccp = form.controls['ccp'].value;
    }

    else{
      updatedFormData.ccp = form.controls['ccp'].value.trim().toUpperCase();
    }

    if(form.controls['veh'].value == null || form.controls['veh'].value == undefined ){
      updatedFormData.veh = form.controls['veh'].value;
    }

    else{
      updatedFormData.veh = form.controls['veh'].value.trim().toUpperCase();
    }

    if(form.controls['up'].value == null || form.controls['up'].value == undefined ){
      updatedFormData.up = form.controls['up'].value;
    }

    else{
      updatedFormData.up = form.controls['up'].value.trim().toUpperCase();
    }

    if(form.controls['of'].value == null || form.controls['of'].value == undefined ){
      updatedFormData.of = form.controls['of'].value;
    }

    else{
      updatedFormData.of = form.controls['of'].value.trim().toUpperCase();
    }

    if(form.controls['lcdv'].value == null || form.controls['lcdv'].value == undefined ){
      updatedFormData.lcdv24 = form.controls['lcdv'].value;
    }

    else{
      updatedFormData.lcdv24 = form.controls['lcdv'].value.trim().toUpperCase();
    }

    if(form.controls['oa'].value == null || form.controls['oa'].value == undefined ){
      updatedFormData.oa = form.controls['oa'].value;
    }

    else{
      updatedFormData.oa = form.controls['oa'].value.trim().toUpperCase();
    }

    if(form.controls['apvpr'].value == null || form.controls['apvpr'].value == undefined ){
      updatedFormData.apvpr = form.controls['apvpr'].value;
    }

    else{
      updatedFormData.apvpr = form.controls['apvpr'].value.trim().toUpperCase();
    }

    if(form.controls['nre'].value == null || form.controls['nre'].value == undefined ){
      updatedFormData.nre = form.controls['nre'].value;
      //console.log( updatedFormData.nre);
    }

    else{
      updatedFormData.nre = form.controls['nre'].value.trim();
      //console.log( updatedFormData.nre);
    }

    if(form.controls['tvv'].value == null || form.controls['tvv'].value == undefined ){
      updatedFormData.tvv = form.controls['tvv'].value;
    }

    else{
      updatedFormData.tvv = form.controls['tvv'].value.trim().toUpperCase();
    }

    if(form.controls['country'].value == null || form.controls['country'].value == undefined ){
      updatedFormData.country = form.controls['country'].value;
    }

    else{
      updatedFormData.country = form.controls['country'].value.trim().toUpperCase();
    }

    if(form.controls['engine'].value == null || form.controls['engine'].value == undefined ){
      updatedFormData.engine = form.controls['engine'].value;
    }

    else{
      updatedFormData.engine = form.controls['engine'].value.trim().toUpperCase();
    }

    if(form.controls['transmission'].value == null || form.controls['transmission'].value == undefined ){
      updatedFormData.transmission = form.controls['transmission'].value;
    }

    else{
      updatedFormData.transmission = form.controls['transmission'].value.trim().toUpperCase();
    }

    if(form.controls['modelNm'].value == null || form.controls['modelNm'].value == undefined ){
      updatedFormData.modelName = form.controls['modelNm'].value;
    }

    else{
      updatedFormData.modelName = form.controls['modelNm'].value.trim().toUpperCase();
    }


    

    //updatedFormData.nre = form.controls['nre'].value;

    // Mandate Fields
    
    updatedFormData.model = form.controls['model'].value.trim().toUpperCase();
    updatedFormData.modelYear = form.controls['modelYear'].value;

    // date Fields

    updatedFormData.dateEcom = form.controls['dateEcom'].value;
    updatedFormData.dateEmon = form.controls['dateEmon'].value;
    updatedFormData.dateExtension = form.controls['dateExtension'].value;

    // updatedFormData.dateCreation = form.controls['dateCreation'].value;
    // updatedFormData.dateModif = form.controls['dateModif'].value;

   
    
    console.log(updatedFormData);

    // Post data to DB

    this.vehicleDetailsService.updateDetails(updatedFormData).subscribe(
      (data:any) => {
        this.responseMsg = data.msg;
        console.log(this.responseMsg);
        if(this.responseMsg == true){
         // setTimeout(function(){ alert("Hello"); }, 3000);
          this.messageService.add({ severity: 'success', summary: "Success", 
          detail: `<div>Data for Vin ${updatedFormData.vin} is updated</div>` });
        
        }
        else if (this.responseMsg == false) {
          this.messageService.add({severity: 'error', summary: "Error Message",
            detail: `<div>Data for Vin ${updatedFormData.vin} is not updated</div>`
          })
        }
        this.getRecordsFromDB();

        // This will reset the form with validate disable
        this.form.reset();
        this.clearMessage();
        //this.removeMessage(updatedFormData);
        
      },
      (error:any) => console.log(error)
    )

    this.notValidData = true;

  }

  dateChanged(event){
    console.log("Date Changed");
    console.log(event.target.value);
    this.errorMessageFordateEmon = false;
    this.notValidData = false;

    if(event.target.value == ""){
      console.log("Blank");
      this.errorMessageFordateEmon = true;
      this.notValidData = true;
      
    }

    else{
      this.errorMessageFordateEmon = false;
      this.notValidData = false;
    }

  }

  dateSelected(event){
    console.log("date Selected");
    console.log(event);

    if(event != null){
      console.log("dateSelected");
      this.errorMessageFordateEmon = false;
      this.notValidData = false;
    }

    else{
      console.log("date not Selected");
    }
    // console.log(event.element.innerText);
    // this.notValidData = false;
    // this.errorMessageFordateEmon = true; 

    // if(event.element.innerText !== ""){
    //   this.errorMessageFordateEmon = false; 
    //   this.notValidData = false;
    // }
    

  }

  valueChanged(changedRecord:VehicleMetadataParameters){
     console.log("valueChanged");

     console.log(changedRecord);

    // console.log(changedRecord.dateEmon);

    // Reset error message
    this.notValidData = false;

    this.errorMessageForModel = false;
    this.errorMessageForModelYear = false;
    
    // Check for blank values 

    if(changedRecord.model == ""){
      this.notValidData = true;
      this.errorMessageForModel = true;
    }

    else if(changedRecord.modelYear == ""){
      this.notValidData = true;
      this.errorMessageForModelYear = true;
    }


    else{
      this.notValidData = false;

      this.errorMessageForModel = false;
      this.errorMessageForModelYear = false;

    }


  }


  // This method will reset the records in HTML page on click of Cancel button
  resetRecord(form: any) {
  // console.log("cancel");

    // Reset error message
    this.notValidData = false;
    this.errorMessageForUp = false;
    this.errorMessageForOf = false;
    this.errorMessageForOa = false;
    this.errorMessageForApvpr = false;
    this.errorMessageForNre = false;
    this.errorMessageForTvv = false;
    this.errorMessageForModel = false;
    this.errorMessageForModelYear = false;
    this.errorMessageForLcdv = false;
    this.errorMessageForCcp = false;
    this.errorMessageForVeh = false;
    this.errorMessageFordateEmon = false;

    this.notValidData = true;

    this.getRecordsFromDB();
  }

  // This will clear the message after 5 sec
  clearMessage(){
    //console.log("clearMessage");
    setTimeout(() =>{
      this.messageService.clear();
    },5000);
  }

  statusChanged(newStatus,record){
    console.log(newStatus);
    console.log(record);



    // Enable validate button
    this.notValidData = false;
  }

}
