import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from './url.service';
import { IStateHisporyParameters } from '../state-history/state-history';



@Injectable({
    providedIn:'root',
})

export class VehicleDetailsService{

    constructor(private httpClient:HttpClient, private urlService: URLService){}

    getRecords(selectedVin:string):Observable <any>{

     return this.httpClient.get<any>(this.urlService.vehicleDetailsUrl(),{

             params: {
                 vin: `${selectedVin}`,
             }
         }).pipe(
             map((data:any) => data),
            //tap(data => console.log('All'+ JSON.stringify(data))),
             catchError(this.handleError)
         );
     }

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    
    getCurrentStateList():Observable <any>{
        return this.httpClient.get<any>(this.urlService.currentStateListUrl()).pipe(
            map((data:any) => data),
          // tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    updateDetails(updatedVehicleParameters:any):Observable<any>{
       return this.httpClient.post<any>(this.urlService.updateVehicleDetailsUrl(),updatedVehicleParameters);
    }

    exportToExcelRecords(vinSelected:string):Observable<any>{
        return this.httpClient.get(this.urlService.exportToExcelUrl(),{
            observe: 'response',
            responseType: "blob",
            params: {
                vin: `${vinSelected}`
            }
        }).pipe(
            map((res) => {
                /*let theFile;
                theFile = new Blob([res.body], { type: 'application/octet-stream' });*/
                let data = {
                               image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                               filename: res.headers.get('filename')
                            }
              return data ;
            })
        );
    }
    
}
