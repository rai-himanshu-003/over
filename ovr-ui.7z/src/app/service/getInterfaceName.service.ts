import { Injectable } from "@angular/core";
import { BehaviorSubject} from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class GetSelectedInterfaceService{

    private readonly selectedInterface: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    constructor(){}

    getSelectedInterafce(): string{
        return  this.selectedInterface.getValue();
    }
    
    setSelectedInterafce(data: string){
        this.selectedInterface.next(data);
    }
     

}



