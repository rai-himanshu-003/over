import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse, HttpRequest} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from "./url.service";
import { ItrackChnageData } from "../track-changes/track-changes";


@Injectable({
        providedIn:'root'
})

export class TrackChnagesService{


    constructor(private httpClient:HttpClient, private urlService: URLService){}

    

    getRecords():Observable <ItrackChnageData[]>{

        return this.httpClient.get<ItrackChnageData[]>(this.urlService.getTrackRecordsUrl()).pipe(
            // map((data:ItrackChnageData[] )=>{
            //     return data.map( record => {

            //         if(record.dateCreation == null){
            //             record.dateCreation = null;
            //         }
            //         else{
            //             record.dateCreation = new Date(record.dateCreation as number);
            //         }
            //         return record;
            //     })
            // }),

            map((data:ItrackChnageData[]) => data),
          
           //tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    // Download File
    downloadFileContent(fileName:string):Observable<any>{
        return this.httpClient.get(this.urlService.downLoadFileUrl(),{
            observe: 'response',
            responseType: "blob",
            params: {
                fileName:`${fileName}`,

            }
        }).pipe(
            map((res) => {
                /*let theFile;
                theFile = new Blob([res.body], { type: 'application/octet-stream' });*/
                let data = {
                               image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                               filename: res.headers.get('filename')
                            }
              return data ;
            })
        );
    }

}