import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";

import { Observable, throwError } from 'rxjs';
import { catchError,tap,map, ignoreElements } from 'rxjs/operators';

import { URLService } from "./url.service";
import { DataEncodingService } from "./dataEncoding.service";
import { FormatManagementParameters } from "../format-management/format-management";



@Injectable({
    providedIn:"root",
})



export class FormatManagementService {
    constructor(
        private httpClient:HttpClient,
        private urlService: URLService,
        private dataEncodingService:DataEncodingService
    ){}

    // Get all Lists values

    getAllListsValues(){
        return this.httpClient.get(this.urlService.getAllLists());
    }

    // Get Records

    getRecords(flowName:string | number):Observable <FormatManagementParameters[]>{

       // console.log(flowName);

        return this.httpClient.get<FormatManagementParameters[]>(this.urlService.getFormatUrl(),{

            params: {
                
                flowId:`${flowName}`,
            }
        }).pipe(

        //tap(data => console.log('All'+ JSON.stringify(data))),
        map((data:any) =>{
            data = data;
            console.log(data);
            //console.log(data.fileFormatId);
            this.dataEncodingService.decodeObjValues(data);

            if(data.flowVhlMetadataDTOs == null){
                data.flowVhlMetadataDTOs = data.flowVhlMetadataDTOs;
            }

            else{
                this.dataEncodingService.decodeValues(data.flowVhlMetadataDTOs);
            }
            
            if(data.collectionDTOs == null){
                data.collectionDTOs = data.collectionDTOs;
            }
            else{
                this.dataEncodingService.decodeValues(data.collectionDTOs);
            }

            if(data.ovComponentDTOs == null){
                data.ovComponentDTOs = data.ovComponentDTOs;
            }
            else{
                this.dataEncodingService.decodeValues(data.ovComponentDTOs);
                this.dataEncodingService.decodeValues(data.ovComponentDTOs[0].ovComponentPartDTOs);
            }

 
           //console.log(data.ovComponentDTOs[0].ovComponentPartDTOs);
            
            //console.log(data);
            return data;
            
        }),

        catchError(this.handleError)
        );
    }

    // handle response Error

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    updateFlow(updatedFlowParameters:any):Observable<any>{

        console.log(updatedFlowParameters);

        //updatedFlowParameters = this.dataEncodingService.encodeValues(updatedFlowParameters);
        updatedFlowParameters.flow = updatedFlowParameters.flowId;
        //updatedFlowParameters.flowId = updatedFlowParameters.id;

        

        this.dataEncodingService.encodeObjValues(updatedFlowParameters);
        if(updatedFlowParameters.flowVhlMetadataDTOs == null || updatedFlowParameters.flowVhlMetadataDTOs.length == 0){
            updatedFlowParameters.flowVhlMetadataDTOs = null;
        }
        else{
            this.dataEncodingService.encodeValues(updatedFlowParameters.flowVhlMetadataDTOs);
        }

        if(updatedFlowParameters.collectionDTOs == null || updatedFlowParameters.collectionDTOs.length == 0){
            updatedFlowParameters.collectionDTOs = null;
        }
        else{
            this.dataEncodingService.encodeValues(updatedFlowParameters.collectionDTOs);
        }

        if(updatedFlowParameters.ovComponentDTOs == null || updatedFlowParameters.ovComponentDTOs.length == 0){
            updatedFlowParameters.ovComponentDTOs = null;
            
        }
        else{
            this.dataEncodingService.encodeValues(updatedFlowParameters.ovComponentDTOs);
            this.dataEncodingService.encodeValues(updatedFlowParameters.ovComponentDTOs[0].ovComponentPartDTOs);
        }
        console.log(updatedFlowParameters);

        delete updatedFlowParameters.flowId;

        return this.httpClient.post<any>(this.urlService.updateFormatUrl(),updatedFlowParameters);
    }

    // Export Flow Format
    // exportFlowFormat(flowName:string,vinList:string,exportResult:string):Observable<any>{

    //     //exportResult = exportResult.replace('+','%2B');

    //     exportResult =  exportResult.split("+").join('%2B');
        
    //     // console.log(exportResult);
    //     return this.httpClient.get(this.urlService.exportFormatUrl(),{
            
    //         observe: 'response',
    //         responseType: "blob",
    //         params: {
    //             vinList:`${vinList}`,
    //             flowName:`${flowName}`,
    //             flowFormatDetails:`${exportResult}`,
    //         }
    //     }).pipe(
    //         map((res) => {

    //             console.log(res);
    //             // let theFile;
    //             // theFile = new Blob([res.body], { type: 'application/octet-stream' });
    //             let data = {
    //                            image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
    //                            filename: res.headers.get('filename')
    //                         }
    //           return data ;
    //         })
    //     );
    // }

    // Export with Post request

    exportFlowFormat(exportResult:any){

      return this.httpClient.post(this.urlService.exportFormatUrl(),exportResult,{observe: 'response', responseType: 'blob'})
        .pipe(
            map((res) => {
                console.log(res.headers.get('filename'));

                console.log(res);
                // let theFile;
                // theFile = new Blob([res.body], { type: 'application/octet-stream' });
                let data = {
                                 image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                                //image: new Blob([new Uint8Array(res.body)], {type: res.headers.get('Content-Type')}),
                                // var blob = new Blob([new Uint8Array(request.response)], {type: 'application/pdf'});
                                filename: res.headers.get('filename')
                            }
                return data ;
            })
        );
    }
}