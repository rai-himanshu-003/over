import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { URLService } from "./url.service";

import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';


@Injectable({
    providedIn:"root",
})

export class ComposantService{
    constructor(
        private httpClient:HttpClient,
        private urlService:URLService

    ){}

    getRecords(selectedVin:string):Observable<any>{

        return this.httpClient.get<any>(this.urlService.composantsUrl(),{
            params:{ vin: `${selectedVin}`,}
        }).pipe(

           map((res) => {
            let data = {
               datalist: res.responseList,
               totalNumberOfRecords: res.totalRecords

            }
                return data ;
            }),
            catchError(this.handleError)

        );
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    updateRecords(updatedParameters:any[]):Observable<any[]>{
        // This will delete below keys while sending responce 
        console.log(updatedParameters);
        updatedParameters.map(row=> {
           delete row.isNew;
           delete row.dirty;
        });        
       return this.httpClient.post<any[]>(this.urlService.updateComposantsUrl(),updatedParameters);
    }

    deleteRecords(deletedParameter:any):Observable<any>{
        // console.log(deletedMappingParameter.id);
        delete deletedParameter.dirty;
        delete deletedParameter.isNew;

        return this.httpClient.delete<any>(this.urlService.deleteComposantsUrl()+`?composantId=${deletedParameter.id}`);
 
     }


}

