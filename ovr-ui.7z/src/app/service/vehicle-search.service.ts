import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';


import { URLService } from '../service/url.service';
import { Pagination } from '../vehicle-search/pagination';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';


@Injectable({
    providedIn:'root'
})

export class VehicleSearchRecordService{
    constructor(private httpClient:HttpClient, private urlService: URLService){}

    getFlowList(){
        return this.httpClient.get(this.urlService.getFlowList());
    }

    getRecords(offsetStartPosition:number,nbRows:number,sortResult:string):Observable <any>{

        
        return this.httpClient.get<Pagination<any[]>>(this.urlService.vehicleSearchUrl(),{

            params: {
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                rowsPerPage: `${nbRows}`,
                VehicleSearchDto:`${sortResult}`,
                getTotalRecords :"true",
               // version:`${versionNo}`
            }
        }).pipe(
            //map((data:any) => data.responseList),
            map((res) => {
                console.log(res);

                if(res == null){

                    let data = {
                    
                        datalist: null,
                        totalNumberOfRecords: null
     
                     }
                    
                     return data ;

                }

                else{

                    let data = {
                    
                        datalist: res.responseList,
                        totalNumberOfRecords: res.totalRecords
     
                     }

                     return data ;
                }

              
            })

        );
    }


    exportToCSVRecords(offsetStartPosition:number,nbRows:number,sortResult:string):Observable<any>{
        return this.httpClient.get(this.urlService.exportToCSVtUrlVS(),{
            observe: 'response',
            responseType: "blob",
            params: {
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                rowsPerPage: `${nbRows}`,
                VehicleSearchDto:`${sortResult}`,
                
            }
        }).pipe(
            map((res) => {
                /*let theFile;
                theFile = new Blob([res.body], { type: 'application/octet-stream' });*/
                let data = {
                               image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                               filename: res.headers.get('filename')
                            }
              return data ;
            })
        );
    }
}