import { Injectable } from "@angular/core";
import { IAuditParameters } from "../interface-audit/interface-audit";
//import { rootRenderNodes } from "@angular/core/src/view";
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { Pagination } from '../interface-audit/pagination';
import { URLService } from "./url.service";


@Injectable({
        providedIn:'root'
})

export class AuditRecordService{
    constructor(private httpClient:HttpClient, private urlService: URLService){}

    getRecords(offsetStartPosition:number,nbRows:number,sortResult:string):Observable <any>{

        
        return this.httpClient.get<Pagination<IAuditParameters[]>>(this.urlService.interfaceAuditUrl(),{

            params: {
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                rowsPerPage: `${nbRows}`,
                interfaceAuditDto:`${sortResult}`,
                getTotalRecords :"true"

            }
        }).pipe(
            //map((data:any) => data.responseList),
            map((res) => {
                let data = {
                   datalist: res.responseList,
                   totalNumberOfRecords: res.totalRecords
                               //image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                               //filename: res.headers.get('filename')
                            }
              return data ;
            })
            //tap(data => console.log('All'+ JSON.stringify(data))),
           // catchError(this.handleError)
        );
    }

    handleResponse(data:any){
        console.log(data);
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    exportToCSVRecords(offsetStartPosition:number,nbRows:number,sortResult:string):Observable<any>{
        return this.httpClient.get(this.urlService.exportToCSVInterfaceAudit(),{
            observe: 'response',
            responseType: "blob",
            params: {
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                rowsPerPage: `${nbRows}`,
                interfaceAuditDto:`${sortResult}`
                
            }
        }).pipe(
            map((res) => {
                /*let theFile;
                theFile = new Blob([res.body], { type: 'application/octet-stream' });*/
                let data = {
                               image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                               filename: res.headers.get('filename')
                            }
              return data ;
            })
        );
    }





    
}