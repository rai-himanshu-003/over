import { Injectable } from "@angular/core";
import { BehaviorSubject} from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class GetSelectedVinService{
    
    private readonly selectedVin: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    constructor(){}

    getSelectedVinNumber(): string{
        return  this.selectedVin.getValue();
    }
    
    setSelectedVinNumber(data: string){
        this.selectedVin.next(data);
    }
     

}



