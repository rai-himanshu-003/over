import { Injectable } from "@angular/core";
import { BehaviorSubject} from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class GetTableColsService{

    //private readonly selectedInterface: BehaviorSubject<string> = new BehaviorSubject<string>(null);

    public composantOVCols:BehaviorSubject<any[]> = new BehaviorSubject([]);
    constructor(){}

    getTableCols(): any[]{
        return  this.composantOVCols.getValue();
    }
    
    setTableCols(data: any[]){
        this.composantOVCols.next(data);
    }
     

}



