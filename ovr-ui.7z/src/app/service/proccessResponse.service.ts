import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { URLService } from "./url.service";



import { ConfirmationService, MessageService } from 'primeng/api';


@Injectable({
    providedIn:"root",
})

export class ProccessResponseService{
    constructor(
                
        public messageService: MessageService,

    ){}

    proccessResponse(data: any, updatedData: any[]) {
        console.log(data);
        //console.log(updatedData);
        let successCount: number = 0;
        let errCount: number = 0;
    
        let successFiled: string = "";
        let errFiled: string = "";
        let updatedSuccessField: string = "";
    
        data.responseList.forEach(element => {
          console.log(element);
    
          if (element.msg == true) {
            successCount = successCount + 1;
            console.log(successFiled);
            successFiled = `<div>${successFiled} ${element.id}</div> `;
            
          }
          else if (element.msg == false) {
            errCount = errCount + 1;
            errFiled = `<div>${errFiled} ${element.id}</div>`
          }
    
        });
        if (successCount > 0) {
          this.messageService.add({
            severity: 'success', summary: "Success",
            detail: `<div> Operation completed successfully </div>
            <div> The total number of records updated are ${successCount}</div>
              Updated Parameters are:
                ${successFiled} `
          });
        }
    
        else if (errCount > 0) {
          this.messageService.add({
            severity: 'error', summary: "Error Message",
            detail: `The total number of records Not updated are ${errCount}
                ${errFiled}`
          })
        }
    
        this.clearMessage();
        
        
    }

    processResponseForMessage(data){
      console.log(data);

      let errorID: string = "";
      let errorMessage: string = "";

      errorID = data.id;
      errorMessage = data.message;

      if(data.msg == true){
        this.messageService.add({severity: 'success', summary: "Success", detail:`<div>${errorID} -  ${errorMessage}</div>`});
      }
      else{
        this.messageService.add({severity:'error', summary:'Error', detail:`<div>${errorID} -  ${errorMessage}</div>`});
      }

      this.clearMessage();
    }

    clearMessage(){
      //console.log("clearMessage");
      setTimeout(() =>{
        this.messageService.clear();
      },5000);
    }

    

}