import { Injectable } from '@angular/core';
import { EnvService } from '../env-service/env.service';

@Injectable({
  providedIn: 'root'
})
export class URLService {

  constructor(private env: EnvService) { }


  // Login Page URLS
  authenticationServiceURL() {
    return this.env.ovrMicroServiceApiUrl + '/auth/login';
  }

  public userDataUrl() {
    return this.env.ovrMicroServiceApiUrl + '/userInfo/getUserData';
  }

  public updateUserDataUrl() {
    return this.env.ovrMicroServiceApiUrl + '/userInfo/updateUserData';
  }


  // Technical Management Page URLS
  public techManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/techParam?locale=En';
  }

  public updatetechManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/techParam/updateParam';
  }

  public deletetechManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/techParam/deleteParam';
  }

  public validateFreqUrl() {
    return this.env.ovrMicroServiceApiUrl + '/techParam/validateFrequency';
  }

  // Error Management Page URLS
  public errorManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/resendToOtt/getErrorList';
  }

  public updateerrorManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/resendToOtt/updateStat';
  }

  public ignoreerrorManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/resendToOtt/ignore';
  }

  public exportToCSVtUrl() {
    return this.env.ovrMicroServiceApiUrl + '/resendToOtt/exportToCSV';
  }

  public getFlowList() {
    return this.env.ovrMicroServiceApiUrl + '/resendToOtt/getFlowlist';
  }


  // Vehicle Details page URLS
  public vehicleDetailsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/getvehicledetails';
  }
  
  public currentStateListUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/getstatelist';
  }

  public updateVehicleDetailsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/updatevehicle';
  }

  public exportToExcelUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/vehicledetailsexcelexport';
  }

  // Vehicle Search page URLS

  public vehicleSearchUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle';
  }

  public exportToCSVtUrlVS() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/exporttocsv';
  }


  

  // Interface Management page URLS
  public interfaceManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/InterfaceRules/getInterfaceRules';
  }

  public deleteInterfaceManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/InterfaceRules/deleteInterfaceRule';
  }

  public updateInterfaceManagementUrl() {
    return this.env.ovrMicroServiceApiUrl + '/InterfaceRules/addUpdateIntRule';
  }

  public getInterfaceListUrl() {
    return this.env.ovrMicroServiceApiUrl + '/InterfaceRules/getinterfacelist';
  }

  
   
  // Interface Status page URLS
  public getAllInterfaceStatusUrl() {
  return this.env.ovrMicroServiceApiUrl + '/interfacemanagement';
  }

  public updateInterfaceStatusUrl() {
  return this.env.ovrMicroServiceApiUrl + '/interfacemanagement/updateinterfacestatus';
  }

  
  // Interface Audit page URLS

  public interfaceAuditUrl() {
    return this.env.ovrMicroServiceApiUrl + '/interface/getaudit';
  } 

  public exportToCSVInterfaceAudit() {
    return this.env.ovrMicroServiceApiUrl + '/interface/interfaceauditcsvexport'; 
  }

  // Mapping OV/PSA page URLs
  public mappingovpsaUrl() {
    return this.env.ovrMicroServiceApiUrl + '/OvPsaMapping/getMapping';
  }

  public updateMappingOVPSAUrl() {
    return this.env.ovrMicroServiceApiUrl + '/OvPsaMapping/addUpdateMapping';
  }

  public deleteMappingOVPSAUrl() {
    return this.env.ovrMicroServiceApiUrl + '/OvPsaMapping/deleteMapping';
  }

  // Composant OV

  public composantOVUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/composantsov/getcomposantsov';
  }

  public updateComposantOVUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/composantsov/addorupdatecomposantsov';
  }

  public deleteComposantOVUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/composantsov/deletecomposantsov';
  }

  // Key OV

  public keyOVUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/keysov/getkeysov';
  }

  public updateKeyOVUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/keysov/addorupdatekeysov';
  }

  public deleteKeyOVUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/keysov/deletekeysov';
  }

  // Composants

  public composantsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/composants/getcomposant';
  }

  public updateComposantsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/composants/addorupdatecomposant';
  }

  public deleteComposantsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/composants/deletecomposant';
  }


  // Rreferences Electroniques

  public referencesElectroniquesUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/referenceselectroniques/getreferenceselectroniques';
  }

  public updateReferencesElectroniquesUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/referenceselectroniques/addorupdatereferenceselectroniques';
  }

  public deleteReferencesElectroniquesUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/referenceselectroniques/deletereferenceselectroniques';
  }


  // LCDV OTT

  public LcdvOTTUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/lcdvott/getlcdvott';
  }

  public updateLcdvOTTUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/lcdvott/addorupdatelcdvott';
  }

  public deleteLcdvOTTUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/lcdvott/deletelcdvott';
  }

  // Options

  public OptionsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/options/getoptions';
  }

  public updateOptionsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/options/addorupdateoptions';
  }

  public deleteOptionsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/options/deleteoptions';
  }

  // Flow Management

  public getFlowsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/flowManagement/geflowDetails';

  }

  public updateFlowsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/flowManagement/addorupdateFlowDetails';
  }

  public deleteFlowsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/flowManagement/deleteFlowDetails';
  }

  public getAllLists() {
    return this.env.ovrMicroServiceApiUrl + '/flowManagement/geflowStaticMetadata';

  }

  // Format Management

  public getFormatUrl() {
    return this.env.ovrMicroServiceApiUrl + '/formatManagement/getFormatDetails';

  }

  public updateFormatUrl() {
    return this.env.ovrMicroServiceApiUrl + '/formatManagement/addorupdateFormatDetails';
  }

  public exportFormatUrl() {
    return this.env.ovrMicroServiceApiUrl + '/formatManagement/exportFile';
  }

  public checkFreqUrl() {
    return this.env.ovrMicroServiceApiUrl + '/flowManagement/validateQuartz';
  }
  
  // ART LCDV

  public artLcdvOTTUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/artlcdvott/getartlcdvott';
  }
  
  public updateartLcdvOTTUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/artlcdvott/addorupdateartlcdvott';
  }

  public deleteartLcdvOTTUrl() {
    return this.env.ovrMicroServiceApiUrl + '/vehicle/artlcdvott/deleteartlcdvott';
  }

  // Mass Treatment

  public uploadMassFileUrl() {
    return this.env.ovrMicroServiceApiUrl + '/massmovement/xlsxupload';
  }

  // Track Changes

  public getTrackRecordsUrl() {
    return this.env.ovrMicroServiceApiUrl + '/massmovement/gettrackstatus';

  }

  public downLoadFileUrl() {
    return this.env.ovrMicroServiceApiUrl + '/massmovement/downloadexcelfile';
  }
  
  

}
