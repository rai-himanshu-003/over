import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from "./url.service";


@Injectable({
    providedIn:'root'
})

export class MassTreatmentService{
    constructor(private httpClient:HttpClient, private urlService: URLService){}

    uploadFile(file): Observable<any[]> {
        let formdata = new FormData();
        formdata.append('file', file);
        
        // formdata.append('campaignUploadDTO', postData.campaignUploadDTO);
        return this.httpClient.post<any>(this.urlService.uploadMassFileUrl(), formdata);
    }

}