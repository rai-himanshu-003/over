import { Injectable } from "@angular/core";
import { BehaviorSubject} from 'rxjs';

@Injectable({
    providedIn: 'root',
})

export class GetSelectedFlowService{
    
    private readonly selectedFlow: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    constructor(){}

    getSelectedFlow(): string{
        return  this.selectedFlow.getValue();
    }
    
    setSelectedFlow(data: string){
        this.selectedFlow.next(data);
    }
     

}



