import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";

import { DateFormatterService } from "../shared/services/dateFormater.service";

@Injectable({
    providedIn:"root",
})

export class DateFilterService{
    constructor(
        private dateFormatterService:DateFormatterService
    ){}

    // Check if From date is Null or defined 

    nullCheckFromDate(fromDate,stringFromDate){
        if(fromDate == undefined || fromDate == null){
          //this.minfdate = new Date ("01/01/1900");
          stringFromDate = new Date ("01/01/1900").getTime();
         // console.log(this.minfdate);
        }
  
        else{
          stringFromDate = fromDate.getTime();
        }
  
        console.log(stringFromDate);
        return stringFromDate;
    }

    // Check if To date is Null or defined

    nullCheckToDate(toDate,stringToDate){

        if(toDate == undefined || toDate == null){
          //this.tdate = new Date (" 01/01/9999");
          stringToDate = new Date ("01/01/9999").setHours(23,59,59);
        //   console.log(this.tdate);
        }
  
        else{
          stringToDate = toDate.setHours(23,59,59);
        }

        console.log(stringToDate);
  
        return stringToDate;
    }


    // Show selected in date input field

    showDateRange(fromDate,toDate,tableFields,colName){
        let fromDateString;
        let toDateString;
  
        if(this.dateFormatterService.formatDateForDataBase(fromDate) == "01/01/1900" && this.dateFormatterService.formatDateForDataBase(toDate) == "01/01/9999" ){
          fromDateString = null;
          toDateString = null;
  
        }
  
        else{
  
          if(this.dateFormatterService.formatDateForDataBase(fromDate) == "01/01/1900" ){
            fromDateString = "*";
          }
          else{
            fromDateString =this.dateFormatterService.formatDateForDataBase(fromDate);
          }
    
          if(this.dateFormatterService.formatDateForDataBase(toDate) == "01/01/9999"){
            toDateString = "*";
          }
          else{
            toDateString = this.dateFormatterService.formatDateForDataBase(toDate);
          }
    
        }
  
        tableFields.forEach(col=>{
          if(col.field == colName){
            if(fromDateString == null && toDateString== null){
              col.value = null;
            }
            else{
              col.value = fromDateString + " -" + toDateString;
            }
            
            console.log(col.value);
          }
  
        })
  
  
    }
}