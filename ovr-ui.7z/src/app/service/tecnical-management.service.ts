import { Injectable } from "@angular/core";
import { ITechParameters } from "../technical-management/technical-management";
//import { rootRenderNodes } from "@angular/core/src/view";
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse, HttpRequest} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from "./url.service";


@Injectable({
        providedIn:'root'
})


export class TechRecordService{

    getMessage:ITechParameters[]=[];
    
 
    constructor(private httpClient:HttpClient, private urlService: URLService){}

    getRecords():Observable <ITechParameters[]>{

        return this.httpClient.get<ITechParameters[]>(this.urlService.techManagementUrl()).pipe(
            map((data:any) => data.responseList),
           //tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }
    
    

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }


    updateRecords(updatedTechParameters:ITechParameters[]):Observable<ITechParameters[]>{
        // This will delete below keys while sending responce 
        updatedTechParameters.map(row=> {
           delete row.isNew;
           delete row.dirty;
        });        
       return this.httpClient.post<ITechParameters[]>(this.urlService.updatetechManagementUrl(),updatedTechParameters);
    }

    deleteRecords(deletedTechParameters:ITechParameters):Observable<ITechParameters>{


        delete deletedTechParameters.dirty;
        delete deletedTechParameters.isNew;

        return this.httpClient.delete<ITechParameters>(this.urlService.deletetechManagementUrl()+`?techParamCode=${deletedTechParameters.code}`);

        
        //return this.httpClient.delete(ServiceURL.deleteURL() + `/deleteProjectPerRule/${id}/${RuleTableCode.ChangeState}`, {params:params,responseType:'text'}); 
 
    }

    getFreqValidated(enteredFreq:any){
        
        return this.httpClient.get<boolean>(this.urlService.validateFreqUrl(),{

            params: {
                
                frequency:`${enteredFreq}`,
            }
        }).pipe(
            // tap(data => console.log('All'+ JSON.stringify(data))),

            map((data:any) => {
                // data = data.responseList;
                console.log(data);
                
                //console.log(data);
                return data;
                
              }),

            catchError(this.handleError)
        );
    }


}