export const GlobalsService = Object.freeze({
  //BASE_API_URL: 'http://ott.dev.inetpsa.com:9090/otrmicroservice'
  //BASE_API_URL: 'http://over.dev.inetpsa.com:9090/ovrmicroservice',
 // BASE_API_URL: 'http://localhost:8080'
  //BASE_API_URL: 'http://api.ott.qualif.preprod.inetpsa.com/otrmicroservice'
  //BASE_API_URL: 'http://yval4hb0.inetpsa.com:8080/otrmicroservice' // for preprod
  //... more of your variables


 // ovrMicroServiceApiUrl: 'http://over.dev.inetpsa.com:9090/ovrmicroservice',
  //ovrMicroServiceApiUrl : 'http://localhost:9090/ovrmicroservice'
});