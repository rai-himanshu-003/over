import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";

import { Observable, throwError } from 'rxjs';
import { catchError,tap,map, ignoreElements } from 'rxjs/operators';

import { URLService } from "./url.service";
import { DataEncodingService } from "./dataEncoding.service";



@Injectable({
    providedIn:"root",
})



export class FlowsManagementService {



    constructor(
      private httpClient:HttpClient,
      private urlService: URLService,
      private dataEncodingService:DataEncodingService
    ){}


    // Get all Lists values

    getAllListsValues(){
        return this.httpClient.get(this.urlService.getAllLists());
    }


    // Get Records

    getRecords():Observable <any[]>{

        return this.httpClient.get<any[]>(this.urlService.getFlowsUrl()).pipe(
           map((data:any) => {
            data = data.responseList;
            //console.log(data);
            this.dataEncodingService.decodeValues(data);
            //console.log(data);
            return data;
            
          }),
           
           //tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }


    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }


    // Add / Update Records

    updateRecords(updatedFlowsParameters:any[]):Observable<any[]>{
       // This will delete below keys while sending response 
       updatedFlowsParameters.map(row=> {
           delete row.isNew;
           delete row.dirty;

        }); 
        
        this.dataEncodingService.encodeValues(updatedFlowsParameters);

       return this.httpClient.post<any[]>(this.urlService.updateFlowsUrl(),updatedFlowsParameters);
    }

    // Delete Records

    deleteRecords(deletedFlowsParameters:any):Observable<any>{
      console.log(deletedFlowsParameters.flowName);

        // delete deletedTechParameters.dirty;
        // delete deletedTechParameters.isNew;

        return this.httpClient.delete<any>(this.urlService.deleteFlowsUrl()+`?id=${deletedFlowsParameters.id}&flowName=${deletedFlowsParameters.flow}`);
 
    }

        // Delete Records

    validateFreq(enteredFreq:any):Observable<any>{
        console.log(enteredFreq);
    
            // delete deletedTechParameters.dirty;
            // delete deletedTechParameters.isNew;
    
            return this.httpClient.post<any[]>(this.urlService.checkFreqUrl(),enteredFreq);
    
    }

    getFreqValidated(enteredFreq:any){
        
        return this.httpClient.get<any>(this.urlService.checkFreqUrl(),{

            params: {
                
                frequency:`${enteredFreq}`,
            }
        }).pipe(
            // tap(data => console.log('All'+ JSON.stringify(data))),

            map((data:any) => {
                // data = data.responseList;
                console.log(data);
                
                //console.log(data);
                return data;
                
              }),

            catchError(this.handleError)
        );
    }





}