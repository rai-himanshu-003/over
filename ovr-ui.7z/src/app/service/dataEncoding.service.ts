import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";

import { Observable, throwError } from 'rxjs';
import { catchError,tap,map, ignoreElements } from 'rxjs/operators';

import { URLService } from "./url.service";



@Injectable({
    providedIn:"root",
})


export class DataEncodingService {
    constructor(private httpClient:HttpClient, private urlService: URLService){}

    // Get all Lists values

    getAllListsValues(){
        return this.httpClient.get(this.urlService.getAllLists());
    }

    // Decode Values for UI use

    decodeValues(data){
        data.forEach(record =>{

            
            //console.log(record.fileFormatId);
            if(record.fileFormatId == 1){
              record.fileFormatId = "FLAT";
            }
            else if(record.fileFormatId == 2){
              record.fileFormatId = "XML";
            }
            else if(record.fileFormatId == 3){
              record.fileFormatId =  "JSON";
            }
            else if(record.fileFormatId == 4){
              record.fileFormatId = "TO_BE_DEFINED";
            }

            if(record.alignment == 5 ){
              record.alignment = "LEFT" ;
            }
            else if(record.alignment == 6 ){
              record.alignment =  "RIGHT";
            }

            if(record.value == 7){
                record.value =  "VIN";
            }
            else if(record.value == 8 ){
                record.value = "CCP";
            }

            else if(record.value == 9 ){
                record.value = "VEH";
            }

            else if(record.value == 10 ){
                record.value = "UP";
            }

            else if(record.value == 11 ){
                record.value = "OF";
            }

            else if(record.value == 12 ){
                record.value = "LCDV24";
            }

            else if(record.value == 13 ){
                record.value = "DATE_EMON";
            }

            else if(record.value == 14 ){
              record.value = "DATE_ECOM";
            }

            else if(record.value == 15 ){
                record.value = "OA";
            }

            else if(record.value == 16 ){
                record.value = "APVPR";
            }

            else if(record.value == 17 ){
                record.value = "MODEL";
            }

            else if(record.value == 18 ){
                record.value = "MODELYEAR";
            }

            if(record.value == 19){
              record.value =  "ART_LCDV";
            }
            else if(record.value == 20){
              record.value = "RPO";
            }

            if(record.value == 21 ){
              record.value = "OV_COMP" ; 
            }

            if(record.standard == 22){
              record.standard =  "GM1737";
            }
            else if(record.standard == 23){
              record.standard = "GMW15862";
            }

            else if(record.standard == 24){
              record.standard = "OTHER";
            }

            if(record.value == 25){
              record.value =  "ID";
            }
            else if(record.value == 26){
              record.value = "PART";
            }

            else if(record.value == 27){
              record.value = "SUPPLIER";
            }

            else if(record.value == 28){
              record.value = "DATA";
            }

            else if(record.value == 29){
              record.value = "LABEL";
            }

            else if(record.value == 32){
              record.value = "SEP";
            }



            

            if(record.action == 30){
              record.action =  "UPDATED" 
            }
            else if(record.action == 31){
              record.action = "CREATED" 
            }


        });

    }

    // Encode Values

    encodeValues(data){

        data.forEach(row =>{

            if(row.fileFormatId == "FLAT"){
                row.fileFormatId = 1;
            }
            else if(row.fileFormatId == "XML"){
            row.fileFormatId = 2;
            }
            else if(row.fileFormatId == "JSON"){
            row.fileFormatId = 3;
            }
            else if(row.fileFormatId == "TO_BE_DEFINED"){
            row.fileFormatId = 4;
            }

            if(row.alignment == "LEFT" ){
              row.alignment =  5;
            }
            else if(row.alignment == "RIGHT" ){
                row.alignment =  6;
            }

            if(row.value == "VIN" ){
              row.value =  7;
            }
            else if(row.value == "CCP" ){
                row.value =  8;
            }

            else if(row.value == "VEH" ){
                row.value =  9;
            }

            else if(row.value == "UP" ){
                row.value =  10;
            }

            else if(row.value ==  "OF" ){
                row.value = 11;
            }

            else if(row.value == "LCDV24"  ){
                row.value = 12;
            }

            else if(row.value == "DATE_EMON" ){
                row.value =  13;
            }

            else if(row.value == "DATE_ECOM" ){
              row.value =  14;
            }

            else if(row.value == "OA" ){
                row.value =  15;
            }

            else if(row.value == "APVPR" ){
                row.value =  16;
            }

            else if(row.value == "MODEL" ){
                row.value =  17;
            }

            else if(row.value == "MODELYEAR" ){
                row.value =  18;
            }

            if(row.value == "ART_LCDV" ){
              row.value = 19; 
            }
            else if(row.value == "RPO"){
              row.value =  20;
            }

            if(row.value == "OV_COMP" ){
              row.value = 21; 
            }

            if(row.standard == "GM1737"){
              row.standard = 22;
            }
            else if(row.standard == "GMW15862"){
              row.standard = 23;
            }

            else if(row.standard == "OTHER"){
              row.standard = 24;
            }

            if(row.value == "ID"){
              row.value = 25;
            }
            else if(row.value == "PART"){
              row.value = 26;
            }

            else if(row.value == "SUPPLIER"){
              row.value = 27;
            }

            else if(row.value == "DATA"){
              row.value = 28;
            }

            else if(row.value == "LABEL"){
              row.value = 29;
            }

            else if(row.value == "SEP"){
              row.value = 32;
            }


            if(row.action ==  "UPDATED"){
              row.action = 30
            }
            else if(row.action == "CREATED" ){
            row.action = 31
            }
        });

    }

    // decode object values
    decodeObjValues(record){

        if(record.fileFormatId == 1){
            record.fileFormatId = "FLAT"
          }
          else if(record.fileFormatId == 2){
            record.fileFormatId = "XML"
          }
          else if(record.fileFormatId == 3){
            record.fileFormatId =  "JSON" 
          }
          else if(record.fileFormatId == 4){
            record.fileFormatId = "TO_BE_DEFINED" 
          }

    }

    // encode object values
    encodeObjValues(record){

      if(record.fileFormatId == "FLAT"){
        record.fileFormatId = 1;
      }
      else if(record.fileFormatId == "XML"){
        record.fileFormatId = 2;
      }
      else if(record.fileFormatId == "JSON"){
        record.fileFormatId = 3;
      }
      else if(record.fileFormatId == "TO_BE_DEFINED"){
        record.fileFormatId = 4;
      }

    }

}