import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { listDto } from "../models/list-model";

@Injectable({
    providedIn:"root",
})


export class DropDownListService {

    constructor(){}

    createDropDownList(arrToConvert:any[]){

        // Create an empty Array
        let tempArr = [];

        let arrLength = arrToConvert.length;

        let tempObject = arrToConvert;

        for(let i=0; i<arrLength;i++){

            let tempObj = {} as listDto

            tempObj.label = tempObject[i].value;
            tempObj.value = tempObject[i].value;

            tempArr.push(tempObj);

            
        }

       // console.log(tempArr);

        return tempArr;

    }

    createFlowList(arrToConvert:any[]){

        // Create an empty Array
        let tempArr = [];

        let arrLength = arrToConvert.length;

        let tempObject = arrToConvert;

        for(let i=0; i<arrLength;i++){

            let tempObj = {} as listDto

            
            tempObj.label = tempObject[i].flow;
            tempObj.value = tempObject[i].flow;

            tempArr.push(tempObj);
                        
        }

        return tempArr;
    }

}