import { Injectable } from "@angular/core";
import { IErrorhParameters } from "../error-management/error-management";
//import { rootRenderNodes } from "@angular/core/src/view";
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { Pagination } from '../error-management/pagination';
import { URLService } from "./url.service";


@Injectable({
        providedIn:'root'
})



export class ErrorRecordService{
    constructor(private httpClient:HttpClient, private urlService: URLService){}

    getFlowList(){
        return this.httpClient.get(this.urlService.getFlowList());
    }

    getRecords(flowName:string,offsetStartPosition:number,nbRows:number,sortResult:string,ignoredRecords:boolean):Observable <any>{

        
        return this.httpClient.get<Pagination<IErrorhParameters[]>>(this.urlService.errorManagementUrl(),{

            params: {
                flowName:`${flowName}`,
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                rowsPerPage: `${nbRows}`,
                ResendToOTTDto:`${sortResult}`,
                getTotalRecords :"true",
                toIgnore:`${ignoredRecords}`,
                // version:`${versionNo}`
            }
        }).pipe(
            //map((data:any) => data.responseList),
            map((res) => {
                let data = {
                   datalist: res.responseList,
                   totalNumberOfRecords: res.totalRecords
                               //image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                               //filename: res.headers.get('filename')
                            }
              return data ;
            })
            //tap(data => console.log('All'+ JSON.stringify(data))),
           // catchError(this.handleError)
        );
    }

    handleResponse(data:any){
        console.log(data);
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    updateRecords(updatedErrParameters:IErrorhParameters[]):Observable<IErrorhParameters[]>{     
        return this.httpClient.post<IErrorhParameters[]>(this.urlService.updateerrorManagementUrl(),updatedErrParameters)
     }

    ignoreRecords(ignoredErrParameters:IErrorhParameters[]):Observable<IErrorhParameters[]>{     
    return this.httpClient.post<IErrorhParameters[]>(this.urlService.ignoreerrorManagementUrl(),ignoredErrParameters)
    }




    exportToCSVRecords(flowName:string,offsetStartPosition:number,nbRows:number,sortResult:string,toIgnored:boolean):Observable<any>{
        return this.httpClient.get(this.urlService.exportToCSVtUrl(),{
            observe: 'response',
            responseType: "blob",
            params: {
                flowName:`${flowName}`,
                offsetPositionToStartFrom: `${offsetStartPosition}`,
                rowsPerPage: `${nbRows}`,
                ResendToOTTDto:`${sortResult}`,
                toIgnore:`${toIgnored}`
            }
        }).pipe(
            map((res) => {
                /*let theFile;
                theFile = new Blob([res.body], { type: 'application/octet-stream' });*/
                let data = {
                               image: new Blob([res.body], {type: res.headers.get('Content-Type')}),
                               filename: res.headers.get('filename')
                            }
              return data ;
            })
        );
    }

    
}