import { Injectable } from "@angular/core";
import { IInterfaceStatus } from "../flowState-management/flowState-management";
//import { rootRenderNodes } from "@angular/core/src/view";
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map, ignoreElements } from 'rxjs/operators';
import { URLService } from "./url.service";


@Injectable({
        providedIn:'root'
})


export class InterfaceStatusService{

    getMessage:IInterfaceStatus[]=[];
 
    constructor(private httpClient:HttpClient, private urlService: URLService){}

    getRecords(){

        return this.httpClient.get<IInterfaceStatus[]>(this.urlService.getAllInterfaceStatusUrl()).pipe(
            map((data:any) => {
               
                return data.responseList
            }),
           //tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }
    
    

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }


    updateRecords(updatedInterfaceDetails:IInterfaceStatus):Observable<IInterfaceStatus>{
        // This will delete below keys while sending responce 
        delete updatedInterfaceDetails.newStatus;
        delete updatedInterfaceDetails.dropDownOptions;
      delete updatedInterfaceDetails.id;
      
                 
       return this.httpClient.post<IInterfaceStatus>(this.urlService.updateInterfaceStatusUrl(),updatedInterfaceDetails);
    }

   


}