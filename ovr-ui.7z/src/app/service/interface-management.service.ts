import { Injectable } from "@angular/core";

//import { rootRenderNodes } from "@angular/core/src/view";
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse, HttpRequest} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from "./url.service";
import { IInterManagementParameters } from '../interface-management/interface-management';
import * as moment from 'moment';

@Injectable({
    providedIn:'root'
})

export class InterfaceManagementService{

    constructor(
        private httpClient:HttpClient,
        private urlService: URLService
    ){}

    getInterfaceList(){
        return this.httpClient.get(this.urlService.getInterfaceListUrl());
    }

    getRecords(interfaceName:string):Observable <any[]>{

        return this.httpClient.get<IInterManagementParameters[]>(this.urlService.interfaceManagementUrl(),{
            params:{
                interfaceId: interfaceName
            }
        }).pipe(
            map((data:IInterManagementParameters[]) => {
                return data.map(element => {  
                   // console.log(element.maxEcomDate);
                    //console.log(element.minEcomDate);
                    if(element.minEcomDate == null){
                        element.minEcomDate = element.minEcomDate;
                    }
                    else{
                        element.minEcomDate = new Date(element.minEcomDate as number);
                    }

                    if(element.maxEcomDate == null){
                        element.maxEcomDate = element.maxEcomDate;
                    }

                    else{
                        element.maxEcomDate = new Date(element.maxEcomDate as number);
                    }

                    if(element.dateCreation == null){
                        element.dateCreation = element.dateCreation;
                    }

                    else{
                        element.dateCreation = new Date(element.dateCreation as number); 
                    }

                    if(element.typeOfFilter == 1){
                        element.typeOfFilter = "INCLUSIVE";
                    }
                    else{
                        element.typeOfFilter = "EXCLUSIVE";
                    }
                    
                    // element.minEcomDate = new Date(element.minEcomDate as number);
                    // element.maxEcomDate = new Date(element.maxEcomDate as number);
                    // element.dateCreation = new Date(element.dateCreation as number);

                    console.log(element.maxEcomDate);
                    console.log(element.minEcomDate);           
                    return element;
                });
            }),
            catchError(this.handleError)
        );
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    updateRecords(updatedParameters:IInterManagementParameters[]):Observable<IInterManagementParameters[]>{
        // This will delete below keys while sending responce 
        updatedParameters.map(row=> {
           delete row.isNew;
           delete row.dirty;
           
           //row.maxEcomDate = (row.maxEcomDate as Date).getTime();
           row.maxEcomDate = (row.maxEcomDate as Date);
           row.minEcomDate = (row.minEcomDate as Date) ;
           row.dateCreation = (row.dateCreation as Date) = null;

           if(row.typeOfFilter == "INCLUSIVE"){
            // console.log("Inclusive");
            //this.typeOfFilter = "Inclusive"
             row.typeOfFilter = 1;
            }
            else{
             // this.typeOfFilter = "Exclusive"
              //console.log("Exclusive");
              row.typeOfFilter = 2;
            }
        });        
       return this.httpClient.post<IInterManagementParameters[]>(this.urlService.updateInterfaceManagementUrl(),updatedParameters);
    }

    deleteRecords(deletedParameters:IInterManagementParameters):Observable<IInterManagementParameters>{
        // This will delete below keys while sending responce 
        delete deletedParameters.dirty;
        delete deletedParameters.isNew;

        return this.httpClient.delete<IInterManagementParameters>(this.urlService.deleteInterfaceManagementUrl()+`?interfaceId=${deletedParameters.id}`);
 
    }

}