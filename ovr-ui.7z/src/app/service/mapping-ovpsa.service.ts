import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpResponse, HttpRequest} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap,map } from 'rxjs/operators';
import { URLService } from "./url.service";
import { IMappingOVPSAParameters } from "../mapping-ovpsa/mapping-ovpsa";

@Injectable({
    providedIn:'root'
})

export class MappingOVPSARecordService{

    constructor(private httpClient:HttpClient, private urlService: URLService){}

    getRecords():Observable <IMappingOVPSAParameters[]>{

        return this.httpClient.get<IMappingOVPSAParameters[]>(this.urlService.mappingovpsaUrl()).pipe(
            map((data:any) => data),
           //tap(data => console.log('All'+ JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage="";

        if(err.error instanceof ErrorEvent){
            errorMessage =`An error occured: ${err.error.message} `
        }
        else{
            errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
        }
        console.error(errorMessage);
        return throwError(errorMessage);

    }

    updateRecords(updatedMappingParameters:IMappingOVPSAParameters[]):Observable<IMappingOVPSAParameters[]>{
        // This will delete below keys while sending responce 
        console.log(updatedMappingParameters);
        updatedMappingParameters.map(row=> {
           delete row.isNew;
           delete row.dirty;
           delete row.isDuplicate;
        });        
       return this.httpClient.post<IMappingOVPSAParameters[]>(this.urlService.updateMappingOVPSAUrl(),updatedMappingParameters);
    }

    deleteRecords(deletedMappingParameter:IMappingOVPSAParameters):Observable<IMappingOVPSAParameters>{
        console.log(deletedMappingParameter.id);
        delete deletedMappingParameter.dirty;
        delete deletedMappingParameter.isNew;

        return this.httpClient.delete<IMappingOVPSAParameters>(this.urlService.deleteMappingOVPSAUrl()+`?mappingId=${deletedMappingParameter.id}`);
 
    }



}