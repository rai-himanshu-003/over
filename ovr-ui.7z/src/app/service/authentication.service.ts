import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import LocalStorage from '../util/local-storage';
import { LOCAL_STORAGE_TOKEN_NAME, LOCAL_STORAGE_USER_NAME } from '../constant/auth-constant';
import * as jwt_decode from 'jwt-decode';
import { Observable, throwError } from 'rxjs';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js'; 
import { URLService } from './url.service';

import { TranslateService } from '@ngx-translate/core';

import { Role } from '../models/role';
import { tap } from 'rxjs/internal/operators/tap';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private _httpClient: HttpClient,
    private _router: Router,
    private urlService: URLService,
    private translate: TranslateService) { }

  login(username: string, password: string): Observable<any> {

    let browserLang = this.translate.getBrowserLang();
    console.log(browserLang);
    
    let success: boolean = false;
    
    const body = `hjknfrdp=${encodeURIComponent(this.encrypt(username))}&ljvrdws=${encodeURIComponent(this.encrypt(btoa(password)))}&lang=${browserLang}`;

    console.log(body);

    const headers = new HttpHeaders()
      .set('Content-Type', 'application/x-www-form-urlencoded');

    return this._httpClient.post(this.urlService.authenticationServiceURL(), body, { headers, observe: 'response' });

    console.log(this.getConnectedUser().userRole);

  }


  /**
   * This method helps check if a token is expired.
   * @param token of  type string is the token
   */
  isTokenExpired(token?: string): boolean {
    if (!token) token = LocalStorage.readToken();
    if (!token) return true;

    const date = this.getTokenExpirationDate(token);
    if (date === undefined) return false;
    return !(date.valueOf() > new Date().valueOf());
  }

  /**
   * This method helps retrieve the token expiration date.
   * @param token of type string is the token
   */

   
  getTokenExpirationDate(token: string): Date {
    const decoded = jwt_decode(token);

    if (decoded['exp'] === undefined) return null;

    const date = new Date(0);
    date.setUTCSeconds(decoded['exp']);
    return date;

    
  }

  logout(): void {
    LocalStorage.removeItem(LOCAL_STORAGE_TOKEN_NAME);
    LocalStorage.removeItem(LOCAL_STORAGE_USER_NAME);
    this._router.navigate(['/login']);
  }

  getConnectedUser(): any {
    //console.log(LocalStorage.readValue(LOCAL_STORAGE_USER_NAME));
    return LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
    
  }



  isAdmin(): boolean{
    if(this.getConnectedUser().userRole.indexOf(Role.ADMIN) > -1) {
      //this.isAdmin= true;
      // console.log("admin User");
      return true;
    }
    else{
      return false;
    }
    //return this.getConnectedUser().userRole === Role.ADMIN;
  }

  isPFA(): boolean{
    if(this.getConnectedUser().userRole.indexOf(Role.PFA) > -1) {
      //this.isAdmin= true;
      // console.log("admin User");
      return true;
    }
    else{
      return false;
    }
    //return this.getConnectedUser().userRole === Role.ADMIN;
  }



  isReader(): boolean {
    if(this.getConnectedUser().userRole.indexOf(Role.READER) > -1) {
      //this.isAdmin= true;
      // console.log("admin User");
      return true;
    }
    else{
      return false;
    }
  }


  encrypt(value:string): string{
    const keys = '[+;f$*$#@$^@1ERF';
    var key = CryptoJS.enc.Utf8.parse(keys);
    var iv = CryptoJS.enc.Utf8.parse(keys);

    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(value.toString()), key,
    {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    return encrypted.toString();
  }

  // Get user details for lang
  getUserData(userId:string,type:string,lang:string):Observable<any>{
 
    return this._httpClient.get(this.urlService.userDataUrl(),{
      params:{ 
        
        userId:`${userId}`,
        type:`${type}`,
        lang:`${lang}`,
      }
    }).pipe(
      // tap(data => console.log('All'+ JSON.stringify(data))),
      map((data)=>{
        console.log(data);

        return data;

      }),
      catchError(this.handleError)
    )
  }

  // Handle Error
  private handleError(err:HttpErrorResponse){
    let errorMessage="";

    if(err.error instanceof ErrorEvent){
        errorMessage =`An error occured: ${err.error.message} `
    }
    else{
        errorMessage=`Server returned code:${err.status}, error message is:${err.message}`
    }
    return throwError(errorMessage);
    console.error(errorMessage);

  }

  // Update User preference of lang

  updateUserData(updatedUserDetails:any):Observable<any>{
    return this._httpClient.post<any[]>(this.urlService.updateUserDataUrl(),updatedUserDetails);
  }
}
