export interface IFlowList{
    id: string;
    flowName:string;
}