export class listDto {
    label:string;
    value:string
}