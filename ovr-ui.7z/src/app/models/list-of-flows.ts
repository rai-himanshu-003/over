export class ListOfFlows{
    listOfFlow = [
        {label: 'OTT', value: 'OTT', default:true},
        {label: 'OVER', value: 'OVER'},
        {label: 'CORVET', value: 'CORVET'},
        {label: 'GEPICS', value: 'GEPICS'},
        {label: 'REVOTT', value: 'REVOTT'},
        {label: 'THUB', value: 'THUB'},
        {label: 'PSA_INPUT', value: 'PSA_INPUT'},
        {label: 'OV_INPUT', value: 'OV_INPUT'},
        {label: 'NOT_YET_IN_FLOW', value: 'NOT_YET_IN_FLOW'}

    ]

    currentStates = [
        {label: 'KOTR', value: 'KOTR' },
        {label: 'TRDN', value: 'TRDN'},
        {label: 'CRTD', value: 'CRTD'},
        {label: 'ONPR', value: 'ONPR'},
        {label: 'SENT', value: 'SENT'},
        {label: 'REIN', value: 'REIN'},
        {label: 'CNLD', value: 'CNLD'},
        {label: 'IGNR', value: 'IGNR'},
        {label: 'INIT', value: 'INIT'},
        {label: 'NOT_YET_IN_FLOW', value: 'NOT_YET_IN_FLOW'}

    ]


    transformationFlowStates = [
        {label: 'KOTR', value: 'KOTR'},
        {label: 'TRDN', value: 'TRDN'},
        {label: 'ONPR', value: 'ONPR'},
        {label: 'REIN', value: 'REIN'},
        {label: 'CNLD', value: 'CNLD'},
        {label: 'IGNR', value: 'IGNR'},
        {label: 'INIT', value: 'INIT'},
        {label: 'NOT_YET_IN_FLOW', value: 'NOT_YET_IN_FLOW'}

    ]

    outputFlowStates = [
        {label: 'KOTR', value: 'KOTR'},
        {label: 'SENT', value: 'SENT'},
        {label: 'REIN', value: 'REIN'},
        {label: 'IGNR', value: 'IGNR'},
        {label: 'INIT', value: 'INIT'},
        {label: 'NOT_YET_IN_FLOW', value: 'NOT_YET_IN_FLOW'},

    ]













}