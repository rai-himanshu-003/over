export class Commondata{
    allCols(){
     
      var  keyOVCols = [
        { field: 'standard', header: 'Standard' },
        { field: 'label', header: 'Label' },
        { field: 'eid', header: 'Id' },
        { field: 'data', header: 'Data' }
      ];
      return keyOVCols;
    }


    composantCols(){
        var composantOVCols = [
            { field: 'standard', header: 'Standard' },
            { field: 'label', header: 'Label' },
            { field: 'eid', header: 'Id' },
            { field: 'part', header: 'Part' },
            { field: 'supplier', header: 'Supplier' },
            { field: 'data', header: 'Data' }
          ];
        return composantOVCols
    }
   
}