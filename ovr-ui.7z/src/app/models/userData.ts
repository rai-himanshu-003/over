import { Role } from "./role";

export class userData {
    id: number;
    userId: string;
    type: string;
    value: string;
    role: Role;
}


