export enum Role {
    PFA = 'PFA',
    ADMIN = 'ADMIN',
    READER = 'READER'
}
