export interface ITableParameters{
    id:number,
    vin:string,
    data: string,
    characteristic:string,
    indicator:string,
    nature:string,
    value:string,
    dirty:boolean,
    isNew:boolean,
    standard:string;
    label:string;
    eid:string;
    part:string;
    supplier:string;
    rpoData:string;
    idArtLcdvDto:number;
    familyArtLcdvDto:string;
    codeArtLcdvDto:string;
    valueArtLcdvDto:string;
    isDuplicate:boolean
}