import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeysOvComponent } from './keys-ov.component';

describe('KeysOvComponent', () => {
  let component: KeysOvComponent;
  let fixture: ComponentFixture<KeysOvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KeysOvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeysOvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
