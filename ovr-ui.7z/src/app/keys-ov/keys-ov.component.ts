import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';

import { GetSelectedVinService } from '../service/getVin.service';
import { AuthenticationService } from '../service/authentication.service';


import { TranslateService } from '@ngx-translate/core';

import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Message, LazyLoadEvent } from 'primeng/components/common/api';

import * as lodash from 'lodash';
import { ITableParameters } from '../models/vehicle-details';

import { OVR_PRD } from '../constant/auth-constant';
import { KeyOVService } from '../service/keys-ov.service';
import { ExportToCSV } from '../service/exportToCSV.service';
import { ProccessResponseService } from '../service/proccessResponse.service';

@Component({
  selector: 'app-keys-ov',
  templateUrl: './keys-ov.component.html',
  styleUrls: ['./keys-ov.component.scss'],
  providers: [MessageService, ConfirmationService,ExportToCSV,ProccessResponseService],
  encapsulation: ViewEncapsulation.None,
})
export class KeysOvComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table

  vinForHistory: string;
  errorMessage: string;

  // variable for Admin access 
  isAdmin: boolean;

  // Varoable to show data
  tableHeaders:any[] = [];
  tableRecords:ITableParameters[] = [];
  updatedRecords:ITableParameters[] = [];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  today = new Date();
  fileTimeStamp = '';
  browserLang: string;
  langSelector: string;

  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  // Add records variables
  displayDialog: boolean;
  newRow: boolean;
  newRecords: ITableParameters[] = [];
  newRecord:any = {};
  selectedRecord:ITableParameters;
  isNewRecord: boolean;

  // Variable for Error message for adding new row
  errorMessageForStandard:boolean;
  errorMessageForLabel:boolean;
  errorMessageForEid:boolean;
  errorMessageForData:boolean;

  disableSave:boolean;
  
  // Pagination while adding new records
  totalRecords: number = 0;
  rowsPerPage: number;
  lastRowPage: number;

  // Update records variables

  editedRecords: ITableParameters[];
  clonedRecords: { [s: string]: any; } = {};

  // Validate records Variable
  postData: ITableParameters[] = [];

  // Delete records variables

  deleteRecord: any;
  msgs: Message[] = [];

  standard:string;
  label:string;
  eid:string;
  data:string;

  constructor(
    private getSelectedVinService:GetSelectedVinService,
    private keyOVService:KeyOVService,
    private translate: TranslateService,
    public messageService: MessageService,
    private confirmationService: ConfirmationService,
    private _authService: AuthenticationService,
    private proccessResponseService:ProccessResponseService,
    private exportToCSV:ExportToCSV
  ) {}

  ngOnInit() {
    // To verify User is Admin or Not
    this.isAdmin = this._authService.isAdmin();
    this.tableHeaders = [
      { field: 'standard', header: 'Standard' },
      { field: 'label', header: 'Label' },
      { field: 'eid', header: 'Id' },
      { field: 'data', header: 'Data' },
    ]
    
    this.vinForHistory = this.getSelectedVinService.getSelectedVinNumber();

    this.getRecordsFromDB();
    // export To CSV variables initialise
    this.prdName = OVR_PRD;
    this.exportFile = "_Keys-OV";

    // Header list for export to csv
    for(let i in this.tableHeaders){
      this.headerList.push(this.tableHeaders[i].header);
    }

    // Field list for export to csv
    for(let j in this.tableHeaders){
      this.fieldList.push(this.tableHeaders[j].field);
    }
    
  }

  getRecordsFromDB(){

    this.keyOVService.getRecords(this.vinForHistory).subscribe(
      //(data:any) => console.log(data),
      (data:any) => {
        this.tableRecords = data.datalist;
        this.updatedRecords = lodash.cloneDeep(this.tableRecords);
        console.log(this.tableRecords);
      },
      (error:any) => this.errorMessage = <any> error

    )

  }
  //======================== Reset records Start=========================

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;

      this.getRecordsFromDB();
    }

  //======================== Reset records Ends=========================
  //=========================== Add Start===============================

    showDialogToAdd() {
      //console.log("showDialogToAdd");
  
      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;
  
      // Set new record to null / empty
      this.newRecord = {};
  
      // Set flag of new record
      this.newRow = true;
  
      // Display Dialoug box
      this.displayDialog = true;
    }
    save(){
  
      // copy all previous records in new list
      this.newRecords = [...this.tableRecords];

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;

      // Reset all filter fields
      this.standard = undefined;
      this.label = undefined;
      this.eid = undefined;
      this.data = undefined;

      this.table.reset();
  
      // For new Record
      if (this.newRow) {
        // check for Null and Blank record
        console.log(this.newRow);
        console.log(this.newRecord);
        this.newRecord.vin = this.vinForHistory;
        this.newRecord.id = null;
  
        if (this.newRecord.standard == null || this.newRecord.standard == "" || this.newRecord.standard == "") {
  
          this.displayDialog = true;
          this.errorMessageForStandard = true;
        }
        else if (this.newRecord.label == null || this.newRecord.label == "" || this.newRecord.label == "") {
  
          this.displayDialog = true;
          this.errorMessageForLabel = true;
        }

        else if (this.newRecord.eid == null || this.newRecord.eid == "" || this.newRecord.eid == "") {
  
          this.displayDialog = true;
          this.errorMessageForEid = true;
        }


        else if (this.newRecord.data == null || this.newRecord.data == "" || this.newRecord.data == "") {
  
          this.displayDialog = true;
          this.errorMessageForData = true;
        }


  
        else{
  
          // claculate last row of total records before pushing the new record in table
          this.totalRecords = this.table.totalRecords;
          this.rowsPerPage = this.rows;
  
          if (this.totalRecords < 10) {
            this.lastRowPage = 0;
            console.log(this.lastRowPage);
          }
          else {
            this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
            console.log(this.lastRowPage);
          }
  
          this.first = this.rowsPerPage * this.lastRowPage;
  
          // Insert New record after claculating last row
          this.newRecords.push(this.newRecord);
          this.displayDialog = false;
          this.newRecord.isNew = true;
          this.isNewRecord = true;
  
          this.tableRecords = this.newRecords;
          console.log(this.newRecord);
          console.log(this.tableRecords);
  
        }
      }
  
    }
  
    cancel(){

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;

      let index = this.newRecords.indexOf(this.selectedRecord);
      this.newRecords = this.newRecords.filter((val, i) => i != index);
      this.newRecord = null;
      this.displayDialog = false;
    }
  
  //=========================== Add Ends================================
  //======================== Update Start===============================

    onRowEditInit(editedRecord: ITableParameters) {
        this.clonedRecords[editedRecord.id] = {...editedRecord};
    }

    onRowEditSave(editedRecord: ITableParameters,index: number) {

      editedRecord.dirty = true;
      this.isNewRecord = true;
      editedRecord.vin = this.vinForHistory;

      this.clonedRecords[editedRecord.id] = { ...editedRecord }; 

    }

    onRowEditCancel(editedRecord: ITableParameters,index: number) {

      this.editedRecords = this.tableRecords;
      this.editedRecords[index] = this.clonedRecords[editedRecord.id];
      delete this.clonedRecords[editedRecord.id];

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;
    }


  //======================== Update Ends===============================
  //======================== Validate Start=============================
    validateRecord(event: Event) {
      console.log("validateRecord");
      // This will reset the Post data
      this.postData = [];
      // This function will compare the prvious value & updated value
      for (let i = 0; i < this.tableRecords.length; i++) {
        if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.tableRecords[i])) {
          this.postData.push(this.tableRecords[i]);
          console.log(this.postData);
        }
  
      }
  
      let updatedData: any = this.postData;
  
      // This method will update the records in DB on click of validate button
      this.keyOVService.updateRecords(this.postData).subscribe(
  
        (data: any) => {
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();
        },
          
        (error: any) => console.log(error)
      )

      this.isNewRecord = false;

    }

    valueChanged(changedRecord: ITableParameters){

      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;
      this.disableSave = false;

      if(changedRecord.standard == ""){
        this.disableSave = true;
        this.errorMessageForStandard = true;
      }

      else if(changedRecord.label == ""){
        this.disableSave = true;
        this.errorMessageForLabel = true;
      }
      else if(changedRecord.eid == ""){
        this.disableSave = true;
        this.errorMessageForEid = true;
      }
      else if(changedRecord.data == ""){
        this.disableSave = true;
        this.errorMessageForData = true;
      }

      else{
      // Reset all error messages to false
      this.errorMessageForData = false;
      this.errorMessageForEid = false;
      this.errorMessageForLabel = false;
      this.errorMessageForStandard = false;

      }

    }
  
  //======================== Validate Ends=============================

  //=========================== Delete Starts=========================

    // This method will Delete row in table
    deleteRow(tableRow: any, index: number) {

      this.deleteRecord = tableRow;
      console.log(this.deleteRecord);

      // This method will update the records in DB on click of validate button
      //this.deleteRecordsFromDB();

      this.keyOVService.deleteRecords(this.deleteRecord).subscribe(

        (data: any) => {
          console.log(data);
          let res ={...data.responseList};
          console.log(res);
          let resMsg = res[0].msg;
          console.log(resMsg);

          let tableRow = this.deleteRecord;

          if (resMsg == true) {

            // this.msgs = [{severity:'error', summary:'Warning', detail:`${tableRow.id} is  deleted`}];
            this.messageService.add({ severity: 'error', summary: 'Deleted', detail: `${tableRow.id}` });
            this.getRecordsFromDB();
          }
          else {
            this.msgs = [{ severity: 'error', summary: 'Error', detail: `${tableRow.id} not found` }];
            this.getRecordsFromDB();
          }

          this.proccessResponseService.clearMessage();

        },
        (error: any) => console.log(error)
      )


    }

    // Show confirmation box before delete function

    confirmDelete(tableRow: any, index: number) {
      //console.log("Confirm Delete");
      this.confirmationService.confirm({
        message: this.translate.currentLang == 'en' ? `Do you want to delete this record?
            <p style="margin-left:8%" translate="yes">Please note that this action cannot be reverted.</p>
            <p>This will be immediately deleted from application.</p>` : `Voulez-vous supprimer cet enregistrement ?
            <p style="margin-left:8%" translate="yes">Attention ! Cette action est irr�versible.</p>
            <p>Cela va �tre imm�diatement supprim� de l'application.</p>`  ,
        // header: 'Delete Confirmation',
        //icon: 'pi pi-info-circle',
        accept: () => {
          this.deleteRow(tableRow, index);
          //console.log("Confirm Delete");
          // this.getRecordsFromDB();

        },
        reject: () => {
          //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
      });
    }

  //=========================== Delete Ends=========================

  exportCSVCommon(){
    // This will add time stamp in the filename while exporting the file    
    this.fileTimeStamp = this.exportToCSV.formatDateForExport();

    console.log(this.vinForHistory);

    // This will give file Name for exported file
    let filename = `${this.prdName}${this.exportFile}${this.vinForHistory}${this.fileTimeStamp}`;

    if(this.table.filteredValue == undefined){
      this.exportedRecords = lodash.cloneDeep(this.table.value);
      //this.exportedRecords = this.table.value;
      
    }

    else{
      this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
      //this.exportedRecords = this.table.filteredValue;
    }

    console.log(this.exportedRecords);

    this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);

  }
}
