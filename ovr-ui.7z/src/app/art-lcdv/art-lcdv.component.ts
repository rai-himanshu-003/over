import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';

import * as lodash from 'lodash';
import { ITableParameters } from '../models/vehicle-details';


import { ArtLcdvOTTService } from '../service/artLcdv-ott.service';
import { ExportToCSV } from '../service/exportToCSV.service';
import { OVR_PRD } from '../constant/auth-constant';
import { ProccessResponseService } from '../service/proccessResponse.service';

import { Table } from 'primeng/table';
import { MessageService, ConfirmationService, Message } from 'primeng/api';
import { CompareMaxLimit } from '../shared/services/compareMaxLimit';
import { AuthenticationService } from '../service/authentication.service';



@Component({
  selector: 'app-art-lcdv',
  templateUrl: './art-lcdv.component.html',
  styleUrls: ['./art-lcdv.component.scss'],
  providers: [MessageService, ConfirmationService,ProccessResponseService,ExportToCSV,CompareMaxLimit],
  encapsulation: ViewEncapsulation.None,
})
export class ArtLcdvComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table

  vinForHistory: string;
  vinForArtLcdvOTT:string;
  errorMessage: string;

  // Variable to show data
  tableHeaders:any[] = [];
  tableRecords:ITableParameters[] = [];
  updatedRecords:ITableParameters[] = [];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number = 10;
  size: number;

  // export To CSV variables
  prdName: string;
  exportFile: string;
  // today = new Date();
  fileTimeStamp = '';
  // browserLang: string;
  // langSelector: string;

  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  // Update records variables

  editedRecords: ITableParameters[];
  clonedRecords: { [s: string]: any; } = {};

  // Variable for Error message
  errorMessageForFamily:boolean;
  errorMessageForCode:boolean;
  errorMessageForValue:boolean;

  // Validate records Variable
  postData: ITableParameters[] = [];

  // Add records variables
  displayDialog: boolean;
  newRow: boolean;
  newRecords: ITableParameters[] = [];
  newRecord:any = {};
  selectedRecord:ITableParameters;

  // Pagination while adding new records
  totalRecords: number = 0;
  rowsPerPage: number;
  lastRowPage: number;

  // Variables for filter fields
  familyArtLcdvDto:string;
  codeArtLcdvDto:string;
  valueArtLcdvDto:string;
  id:string;

  // Delete records variables

  deleteRecord: any;
  msgs: Message[] = [];
  

  isNewRecord: boolean;
  disableSave:boolean = false;

  newUpdatedRecords: ITableParameters[] = [];

  // Variable for max limit of rpo
  maxLimit:any;
  isAddDisable:boolean;
  addBtnTooltip:string;

  // variable for Admin access 
  isAdmin: boolean;
  isPFA:boolean;
  isReader:boolean;

  constructor(
    private artLcdvOTTService:ArtLcdvOTTService,
    private exportToCSV:ExportToCSV,
    private proccessResponseService:ProccessResponseService,
    private confirmationService: ConfirmationService,
    public messageService: MessageService,
    private compareMaxLimit:CompareMaxLimit,
    private _authService: AuthenticationService,
  ) { }

  ngOnInit() {

    // To verify User is Admin or Not
    this.isAdmin = this._authService.isAdmin();
    this.isPFA = this._authService.isPFA();
    this.isReader = this._authService.isReader();

    this.tableHeaders = [
      { field: 'idArtLcdvDto', header: 'ID' },
      { field: 'familyArtLcdvDto', header: 'Family' },
      { field: 'codeArtLcdvDto', header: 'Code' },
      { field: 'valueArtLcdvDto', header: 'Value' },      
    ]

    this.storeVin();

    // export To CSV variables initialise
    this.prdName = OVR_PRD;
    this.exportFile = "_ArtLcdv-OTT";


    // Header list for export to csv
    for(let i in this.tableHeaders){
      this.headerList.push(this.tableHeaders[i].header);
    }

    // Field list for export to csv
    for(let j in this.tableHeaders){
      this.fieldList.push(this.tableHeaders[j].field);
    }
  }

    storeVin() {
    
      // Set the value of Vin number in variable
      this.vinForArtLcdvOTT = window.localStorage.getItem("vinSearch");

      // If value is not null or undefined then call get data
      if(this.vinForArtLcdvOTT !=null && this.vinForArtLcdvOTT != undefined){
        window.localStorage.setItem("vinForArtLcdvOTT",this.vinForArtLcdvOTT);
        this.getRecordsFromDB();
      }
      
    }

    getRecordsFromDB(){


      let vinNumber:string =  window.localStorage.getItem("vinForLcdvOTT");

      if(vinNumber !=null && vinNumber != undefined){
        //console.log("vin"+ vinNumber);
        this.vinForHistory = vinNumber;
        //console.log(this.vinForHistory);
      }

      else{
        console.log("no Vin found");
      }

      this.artLcdvOTTService.getRecords(this.vinForHistory).subscribe(
        //(data:any) => console.log(data),
        (data:any) => {

          console.log(data);

          this.tableRecords = data.datalist;
          this.updatedRecords = lodash.cloneDeep(this.tableRecords);
          
          // Compare for max limit
          this.maxLimit = data.totalNumberOfRecords;
          this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
          this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);
        },
        (error:any) => this.errorMessage = <any> error

      )

    }

//======================== Reset records Start=========================//

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {

      // Reset all error messages to false
      this.resetErrorMessage();

      // Disable Validate
      this.isNewRecord = false;

      this.getRecordsFromDB();

      // Go to first page
      this.first = 0;

    }

//======================== Reset records Ends=========================//


//======================== Update Start===============================

    onRowEditInit(editedRecord: ITableParameters) {
      this.clonedRecords[editedRecord.id] = {...editedRecord};
    }

    onRowEditSave(editedRecord: ITableParameters,index: number) {

      // Reset Array
      
      editedRecord.dirty = true;
      this.isNewRecord = true;
      editedRecord.vin = this.vinForHistory;

      this.clonedRecords[editedRecord.id] = { ...editedRecord };
      this.newUpdatedRecords.push(editedRecord);

    }

    onRowEditCancel(editedRecord: ITableParameters,index: number) {

      // Reset all error messages to false
      this.resetErrorMessage();

      this.editedRecords = this.tableRecords;
      this.editedRecords[index] = this.clonedRecords[editedRecord.id];
      delete this.clonedRecords[editedRecord.id];
    }


//======================== Update Ends===============================

//=========================== Add Start===============================

    showDialogToAdd() {
      //console.log("showDialogToAdd");

      // Reset all error messages to false
      this.resetErrorMessage();

      // Set new record to null / empty
      this.newRecord = {};

      // Set flag of new record
      this.newRow = true;

      // Display Dialoug box
      this.displayDialog = true;

      if(this.tableRecords.length == this.updatedRecords.length){

        // Reset Sort 
        if(this.table.sortOrder != 0){
          this.table.sortOrder = 0;
          this.table.sortField = '';
          this.table.reset();
          this.getRecordsFromDB();
        }

        // Reset Filter 

        if(this.table.filteredValue !== undefined){
          this.familyArtLcdvDto = undefined;
          this.codeArtLcdvDto = undefined;
          this.valueArtLcdvDto = undefined;
          this.id = undefined;
          this.table.reset();

        }

      }


    }

    save(){
    
      // copy all previous records in new list
      this.newRecords = [...this.tableRecords];

      // Reset all error messages to false
      this.resetErrorMessage();



      // For new Record
      if (this.newRow) {
        // check for Null and Blank record
        // console.log(this.newRow);
        // console.log(this.newRecord);
        this.newRecord.vinArtLcdvDto = this.vinForHistory;
        this.newRecord.idArtLcdvDto = null;

        if (this.newRecord.familyArtLcdvDto == null || this.newRecord.familyArtLcdvDto == "" || this.newRecord.familyArtLcdvDto == "") {

          this.displayDialog = true;
          this.errorMessageForFamily = true;
        }
        else if (this.newRecord.codeArtLcdvDto == null || this.newRecord.codeArtLcdvDto == "" || this.newRecord.codeArtLcdvDto == "") {

          this.displayDialog = true;
          this.errorMessageForCode = true;
        }

        else if (this.newRecord.valueArtLcdvDto == null || this.newRecord.valueArtLcdvDto == "" || this.newRecord.valueArtLcdvDto == "") {

          this.displayDialog = true;
          this.errorMessageForValue = true;
        }



        else{

          // calculate last row of total records before pushing the new record in table
          this.totalRecords = this.table.totalRecords;
          this.rowsPerPage = this.rows;

          if (this.totalRecords < 10) {
            this.lastRowPage = 0;
            console.log(this.lastRowPage);
          }
          else {
            this.lastRowPage = Math.floor(this.totalRecords / this.rowsPerPage);
            console.log(this.lastRowPage);
          }

          this.first = this.rowsPerPage * this.lastRowPage;

          // Insert New record after calculating last row
          this.newRecords.push(this.newRecord);
          this.displayDialog = false;
          this.newRecord.isNew = true;
          this.isNewRecord = true;

          this.tableRecords = this.newRecords;
          console.log(this.newRecord);
          console.log(this.tableRecords);

          // New code
          this.newUpdatedRecords.push(this.newRecord);

        }

        // Check for max limit

        this.isAddDisable = this.compareMaxLimit.compareForLimit(this.tableRecords.length,this.maxLimit);
        this.addBtnTooltip = this.compareMaxLimit.showAddTooltip(this.isAddDisable);
      }

    }

    cancel(){
      let index = this.newRecords.indexOf(this.selectedRecord);
      this.newRecords = this.newRecords.filter((val, i) => i != index);
      this.newRecord = null;
      this.displayDialog = false;
    }

//=========================== Add Ends===============================

  //=========================== Delete Starts=========================

    // This method will Delete row in table
    deleteRow(tableRow: any, index: number) {

      this.deleteRecord = tableRow;
      console.log(this.deleteRecord);

      // This method will update the records in DB on click of validate button
      //this.deleteRecordsFromDB();

      this.artLcdvOTTService.deleteRecords(this.deleteRecord).subscribe(

        (data: any) => {
          // console.log(data);
          let res ={...data.responseList};
          // console.log(res);
          let resMsg = res[0].msg;
          // console.log(resMsg);

          let tableRow = this.deleteRecord;

          if (resMsg == true) {

            // this.msgs = [{severity:'error', summary:'Warning', detail:`${tableRow.id} is  deleted`}];
            this.messageService.add({ severity: 'error', summary: 'Deleted', detail: `${tableRow.idArtLcdvDto}` });
            this.getRecordsFromDB();
          }
          else {
            this.msgs = [{ severity: 'error', summary: 'Error', detail: `${tableRow.idArtLcdvDto} not found` }];
            this.getRecordsFromDB();
          }

          this.proccessResponseService.clearMessage();

        },
        (error: any) => console.log(error)
      )


    }

    // Show confirmation box before delete function

    confirmDelete(tableRow: any, index: number) {
      //console.log("Confirm Delete");
      this.confirmationService.confirm({


        accept: () => {
          this.deleteRow(tableRow, index);

        },
        reject: () => {
          //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
        }
      });
    }

  //=========================== Delete Ends=========================
//======================== Validate Start=============================
    validateRecord(event: Event) {
      // console.log("validateRecord");
      // This will reset the Post data
      this.postData = [];
      // This function will compare the prvious value & updated value
      // for (let i = 0; i < this.tableRecords.length; i++) {
      //   if (JSON.stringify(this.updatedRecords[i]) !== JSON.stringify(this.tableRecords[i])) {
      //     this.postData.push(this.tableRecords[i]);
      //     console.log(this.postData);
      //   }
  
      // }
      
      // console.log(this.newUpdatedRecords);

      for (let i = 0; i < this.tableRecords.length; i++) {
        if(this.tableRecords[i].dirty == true || this.tableRecords[i].isNew == true){
          // console.log(this.tableRecords[i].id);
          this.postData.push(this.tableRecords[i]);
        }
      }
      // this.postData = this.updatedRecords;
    

      console.log(this.postData);
      let updatedData: any = this.postData;
  
      // This method will update the records in DB on click of validate button
      this.artLcdvOTTService.updateRecords(this.postData).subscribe(
  
        (data: any) => {
          this.proccessResponseService.proccessResponse(data, updatedData);
          this.getRecordsFromDB();
          
          // This will refresh the whole Page => code to solve version issue
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        },
        //(data:any) => console.log(data),
  
        (error: any) => console.log(error)
      )

      this.isNewRecord = false;

      // Reset Array
      this.newUpdatedRecords = [];
    }

//======================== Validate Ends=============================
//========================== Export To CSV Start ========================//
    exportCSVCommon(){
      // This will add time stamp in the filename while exporting the file    
      this.fileTimeStamp = this.exportToCSV.formatDateForExport();

      console.log(this.vinForHistory);

      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}-${this.vinForHistory}-${this.fileTimeStamp}`;

      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }

      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      console.log(this.exportedRecords);


      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);

    }

//========================== Export To CSV Ends ========================//

    valueChanged(changedRecord: ITableParameters){
      console.log(changedRecord);

      // Reset all error messages to false
      // this.errorMessageForFamily = false;
      // this.errorMessageForCode = false;
      // this.errorMessageForValue = false;
      this.resetErrorMessage();
      this.disableSave = false;

      if(changedRecord.familyArtLcdvDto == ""){
        this.disableSave = true;
        this.errorMessageForFamily = true;
      }

      else if(changedRecord.codeArtLcdvDto == ""){
        this.disableSave = true;
        this.errorMessageForCode = true;
      }

      else if(changedRecord.valueArtLcdvDto == ""){
        this.disableSave = true;
        this.errorMessageForValue = true;
      }

      else{
        // Reset all error messages to false
        // this.errorMessageForFamily = false;
        // this.errorMessageForCode = false;
        // this.errorMessageForValue = false;

        this.resetErrorMessage();
        this.disableSave = false;

      }

    }

    resetErrorMessage(){
      // Reset all error messages to false
      this.errorMessageForFamily = false;
      this.errorMessageForCode = false;
      this.errorMessageForValue = false;
    }

}
