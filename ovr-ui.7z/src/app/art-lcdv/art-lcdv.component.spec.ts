import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtLcdvComponent } from './art-lcdv.component';

describe('ArtLcdvComponent', () => {
  let component: ArtLcdvComponent;
  let fixture: ComponentFixture<ArtLcdvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArtLcdvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtLcdvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
