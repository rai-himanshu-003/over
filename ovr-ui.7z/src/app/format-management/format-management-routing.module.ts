import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FormatManagementComponent } from './format-management.component';


const routes: Routes = [
  {
      path: '',
      component: FormatManagementComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormatManagementRoutingModule { }
