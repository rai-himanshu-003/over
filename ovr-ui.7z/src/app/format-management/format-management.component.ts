import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { HostListener } from '@angular/core';

import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { FormGroup, FormControl } from '@angular/forms';
import { ComposantsOVModule } from '../composants-ov/composants-ov.module';
import { FormatManagementService } from '../service/format-management.service';

import { SelectItem, MessageService, ConfirmationService } from 'primeng/api';


import * as lodash from 'lodash';


import { AllListValues } from '../flows-management/allLists';
import { listDto } from '../models/list-model';
import { DropDownListService } from '../service/dropDown-list.service';
import { FlowsManagementService } from '../service/flows-management.service';
import { DataEncodingService } from '../service/dataEncoding.service';


import { GetSelectedFlowService } from '../service/getFlow.service';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';

import 'rxjs/add/operator/filter';
import { FormatManagementParameters, VehMetadataDTO, GenericCollectionDTO, OvCompDTO, ovComponentPartDTO, ovCompCheck, IExportData } from './format-management';

import { ProccessResponseService } from '../service/proccessResponse.service';
import { element } from 'protractor';
import { AuthenticationService } from '../service/authentication.service';
import { EnvService } from '../env-service/env.service';



@Component({
  selector: 'app-format-management',
  templateUrl: './format-management.component.html',
  styleUrls: ['./format-management.component.scss'],
  providers: [FormatManagementService, MessageService, ConfirmationService, ProccessResponseService]
})
export class FormatManagementComponent implements OnInit, OnDestroy {
  formData: FormGroup;
  @ViewChild('formatDetailsForm', { static: false }) form: FormControl;

  removeSelectedItem: any[] = [];
  selectedItemList: any[] = [];

  allListValues: AllListValues[] = [];

  // variable to show data
  errorMessage: string;
  //tableHeaders:any[] = [];
  tableRecords: any;
  updatedRecords: FormatManagementParameters[] = [];

  // Variable for Flow Field
  selectedFlow: string;
  flowListFromDB: any[] = [];
  flowList: SelectItem[];


  // Variable for File format Field
  selectedFileFormat: string;
  fileFormatList: SelectItem[];
  fileFormatListFromDB: any[] = [];
  formatPresent: boolean;

  // Variable for Vehicle Data
  selectedVehData: string;
  selectedVehDataValue: string;
  newFieldToAdd: string;

  vehDataList: SelectItem[];
  vehDataListFromDB: any[] = [];
  vehDataListWithoutSep: any[] = [];
  vehDataListToShowFromDB: any[] = [];

  updatedVehDataList: any[] = [];

  activeVehicleDatas: any[] = [];
  activeVehicleData: any[] = [];
  activeGenericCollections: any[] = [];
  activeOVComponents: any[] = [];

  activeOVPartComponents: any[] = [];

  errorMessageForDateFilter: boolean;
  isVehFilterNull: boolean;
  isDataPresent: boolean;
  disableAddFlag: boolean;
  isReadOnly: boolean;

  vehSeparatorValue: string;
  // Variable for Separator
  separatorValue: string;
  newSeparatorToAdd: string;

  // Variable for Generic collection

  genericCollections: SelectItem[];
  genericCollectionsFromDB: any[] = [];
  genericCollectionsToShowFromDB: any[] = [];
  updatedCollectionList: any[] = [];

  selectedCollection: string;
  selectedMaxOccurs: string;
  collectionSeparatorValue: string;
  selectedCollectionIntSeparator: string;
  selectedCollectionFilter: string;
  selectedCollectionAlignment: string;

  errorMessageForCollectionFilter: boolean;

  isMaxOCCNull: boolean;
  isCollectionNull: boolean;
  isAlignmentNull: boolean;

  isCollectionPresent: boolean;
  disableCollectionAddFlag: boolean;

  // variable for Alignment 

  alignmentList: SelectItem[];
  alignmentListFromDB: any[] = [];

  // Variable for OV component

  ovCompList: SelectItem[];
  ovCompListFromDB: any[] = [];
  ovCompListToShowFromDB: any[] = [];

  updatedOVCompList: any[] = [];

  ovCompValue: string;
  selectedOvCompMaxOccurs: string;
  selectedOvCompIntSeparator: string;
  selectedOvCompSeparator: string;
  selectedOvCompAlignment: string;

  isOVMaxOCCNull: boolean;
  isOVAlignNull: boolean;
  errorMessageForOVData: boolean;

  isOVCompPresent: boolean;
  disableOvCompAddFlag: boolean;

  // variable for OV Comp part

  ovCompPartList: SelectItem[];
  ovCompPartListFromDB: any[] = [];
  ovCompPartListToShowFromDB: any[] = [];

  //Variable for GM1737 part
  ovCompGM1737Value: string;
  selectedOvCompValues: string[] = [];

  gm1737Checked: boolean;
  gmIDChecked: boolean;
  gmPartChecked: boolean;
  gmSupplierChecked: boolean;
  gmDataChecked: boolean
  gmLabelChecked: boolean;

  selectedgmValues: any[] = [];

  //selectedGM1737Supply:string;
  selectedGmID: string;
  selectedGmPart: string;
  selectedGmSupply: string;
  selectedGmData: string;

  isGmChecked: boolean;

  //Variable for GMW15862 part
  ovCompGMWValue: string;
  selectedGMWValues: string[] = [];
  selectedgmwValues: any[] = [];

  gmwChecked: boolean;
  gmwIDChecked: boolean;
  gmwPartChecked: boolean;
  gmwSupplierChecked: boolean;
  gmwDataChecked: boolean;
  gmwLabelChecked: boolean;


  selectedGMWID: string;
  selectedGMWPart: string;
  selectedGMWSupply: string;
  selectedGMWData: string;

  isGmwChecked: boolean;

  //Variable for Other part

  selectedOtherValues: string[] = [];

  otherChecked: boolean;
  otherIDChecked: boolean;
  otherDataChecked: boolean;
  otherLabelChecked: boolean;


  selectedOtherID: string;
  selectedOtherData: string;

  selectedOtrValues: any[] = [];

  isOtherChecked: boolean;

  // Ext variables

  isArrayDone: boolean;

  checkFlow: string;
  flowName: any;
  flowNameForDB: any;

  previousUrl: string


  // Variable for export
  displayDialog: boolean;
  vinForExport: string;
  errorMessageForExportComma: boolean;
  errorMessageForExportMandate: boolean;
  disableExport: boolean;
  errorMessageForNoExport: boolean;

  exportedData = {} as FormatManagementParameters;
  exportedResult: string;

  // Variable for validate
  responseMsg: boolean;
  notValidData: boolean;
  disableCancel: boolean;

  isFlat: boolean;
  maxSeq: number;

  // Variable for Delete
  selectedElement: string;
  selectedElementSeparator: string;
  selectedElementIndex: number;
  selectedDiv: any;
  selectedDivArr: any[] = [];

  listSelectedPart: ovCompCheck[] = [];
  stdCounter: number = 0;
  partCounter: number = 0;

  // variable for Admin access
  isAdmin: boolean;

  // Variable for Int seq
  stdCnt = 0;
  partCnt = 0;
  ovComps: ovCompCheck[] = [];

  // Variable to disable fields
  disableMetadata: boolean;

  isDate: boolean;

  isVinPresent: boolean;
  isIEOrEdge: boolean;

  tempSepValue: any = 32;

  canAddOvComp: boolean;

  isOVPartNull:boolean;

  constructor(
    private getSelectedFlowService: GetSelectedFlowService,
    private _authService: AuthenticationService,
    private formatManagementService: FormatManagementService,
    private flowsManagementService: FlowsManagementService,
    private dropDownListService: DropDownListService,
    public messageService: MessageService,
    private proccessResponseService: ProccessResponseService,
    private dataEncodingService: DataEncodingService,
    private router: Router,
    private confirmationService: ConfirmationService,
    private env: EnvService
  ) {
    // Set value for ov Comp
    this.ovCompValue = "OV_COMP";

    this.isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
  }

  ngOnInit() {

    // To verify User is Admin or Not
    this.isAdmin = this._authService.isAdmin();

    // Set value for ov Comp
    this.ovCompValue = "OV_COMP";

    // Set flow name
    this.checkFlow = null;
    this.checkFlow = this.getSelectedFlowService.getSelectedFlow();

    // Disable validate and cancel button
    this.notValidData = true;
    this.disableCancel = true;
    this.disableExport = true;

    //console.log(this.checkFlow);
    // Disable all add button
    this.isDataPresent = true;
    this.isCollectionPresent = true;
    this.isOVCompPresent = true

    // Reset value of delete
    this.resetValueOfDelete();


    this.storeFlow();
    //console.log(this.tableRecords);
    //console.log(this.checkFlow);


    this.ovCompValue = "OV_COMP";
    this.getListValues();
    this.getFlowList();

    //console.log(this.selectedVehData);
    this.resetCheckBox();


    //console.log(this.vehDataListToShowFromDB);

    //console.log(form.controls['ccp'].value);

    console.log(this.flowNameForDB);

    // Check for Flow

    if (this.flowNameForDB == null) {
      this.formatPresent = true;
      this.disableMetadata = true;

      // Disable all check boxes
      this.isGmChecked = true;
      this.isGmwChecked = true;
      this.isOtherChecked = true;
    }



  }


  ngOnDestroy() {

    console.log("ngOnDestroy");
    this.checkFlow = null;

    this.getSelectedFlowService.setSelectedFlow(this.checkFlow);
    window.localStorage.removeItem("flowStored");
    window.localStorage.setItem("flowForDB", this.checkFlow);
  }

  storeFlow() {

    this.flowName = window.localStorage.getItem("flowStored");

    //console.log(this.flowName);

    //console.log(this.checkFlow);

    if (this.checkFlow == null && this.flowName == null) {
      //console.log("checkflow null");
      this.flowNameForDB = null;
    }

    else {


      if (this.flowName != null && this.flowName != undefined) {
        window.localStorage.setItem("flowForDB", this.flowName);
        this.flowNameForDB = window.localStorage.getItem("flowForDB");
        //this.getRecordsFromDB();
      }

      this.getRecordsFromDB();
    }




    //console.log(this.flowNameForDB);


  }


  //=========================== Show Data Start==============================//
  // Get flow List for dropdown
  getFlowList() {

    this.flowsManagementService.getRecords().subscribe(
      //(data:any) => console.log(data),
      (data: any) => {
        //console.log(data);
        data.map(record => {
          //console.log(record.flow);
          this.flowListFromDB.push(record);
        })

        //console.log( this.flowListFromDB);
        this.flowList = this.dropDownListService.createFlowList(this.flowListFromDB);

        //console.log(this.flowList);
      },
      (error: any) => this.errorMessage = <any>error

    )

  }

  // Get all List values for drop down
  getListValues() {
    this.formatManagementService.getAllListsValues().subscribe(
      //(data:any) => console.log(data),
      (data: any) => {
        this.allListValues = data;

        //console.log(data);

        data.responseList.map(record => {
          if (record.type == "FILE_FORMAT") {
            //this.flowListFromDB.push(record);
            this.fileFormatListFromDB.push(record);
          }

          else if (record.type == "VHL_DATA") {
            this.vehDataListFromDB.push(record);
          }

          else if (record.type == "GEN_COL") {
            this.genericCollectionsFromDB.push(record);
          }

          else if (record.type == "ALIGN") {
            this.alignmentListFromDB.push(record);
          }

          else if (record.type == "COL") {
            this.ovCompListFromDB.push(record);
          }



        })

        //this.flowList = this.dropDownListService.createDropDownList(this.flowListFromDB);

        // Remove separator from metadata list
        // console.log(this.vehDataListFromDB);

        this.vehDataListFromDB.forEach(element => {
          // console.log(element.value);
          if (element.value != "SEPARATOR") {
            this.vehDataListWithoutSep.push(element);
          }

        })

        // console.log(this.vehDataListWithoutSep);
        this.vehDataListFromDB = this.vehDataListWithoutSep;

        this.fileFormatList = this.dropDownListService.createDropDownList(this.fileFormatListFromDB);
        this.vehDataList = this.dropDownListService.createDropDownList(this.vehDataListFromDB);
        this.genericCollections = this.dropDownListService.createDropDownList(this.genericCollectionsFromDB);
        this.alignmentList = this.dropDownListService.createDropDownList(this.alignmentListFromDB);
        this.ovCompList = this.dropDownListService.createDropDownList(this.ovCompListFromDB)

        //  console.log(this.fileFormatList);
        //  console.log(this.fileFormatListFromDB);
        // console.log(data.responseList)

        // console.log(this.allListValues);
      },
      (error: any) => this.errorMessage = <any>error
    )
  }

  // Get records from Service

  getRecordsFromDB() {

    // Set label value
    this.ovCompValue = "OV_COMP";

    // Reset error messages
    this.isOVMaxOCCNull = false;
    this.isOVAlignNull = false;
    this.isVinPresent = false;

    this.isMaxOCCNull = false;
    this.isAlignmentNull = false;

    this.isOVPartNull = false;

    // Reset all list values
    this.updatedVehDataList = [];
    this.updatedCollectionList = [];
    this.updatedOVCompList = [];



    // Check for file format
    this.formatPresent = false;


    // Disable all add button
    this.isDataPresent = true;
    this.isCollectionPresent = true;
    this.isOVCompPresent = true

    // Disable validate and cancel button
    this.notValidData = true;
    this.disableCancel = true;
    this.disableExport = true;

    // Reset all check boxes
    this.resetCheckBox();

    // Reset value of delete
    this.resetValueOfDelete();

    // Reset List
    this.ovComps = [];

    // Reset gray content array
    this.activeVehicleDatas = [];
    this.activeVehicleData = [];
    this.activeGenericCollections = [];
    this.activeOVComponents = [];
    this.activeOVPartComponents = [];

    console.log(this.activeVehicleDatas);

    //console.log(this.activeVehicleDatas);

    //console.log(this.flowNameForDB);
    this.formatManagementService.getRecords(this.flowNameForDB).subscribe(
      (data: any) => {
        console.log(data);
        this.formData = data;
        this.tableRecords = data;

        //console.log(data.fileFormatId)

        // Disable check box
        //this.isOtherChecked = true;

        // Check for flow
        if (data.flow == null) {
          this.formatPresent = false;

        }




        // Check for File Format
        if (data.fileFormatId == "TO_BE_DEFINED" || data.fileFormatId == null) {
          // Disable all buttons

          // Disable validate and export
          console.log(data.fileFormatId);

          // Enable format drop down
          this.formatPresent = false;
          this.disableMetadata = true;

          // Disable Oc comp Add button
          this.isOVCompPresent = true;

        }

        else {
          this.formatPresent = true;
          this.disableMetadata = false;
        }

        // Check for Flat File Format
        if (data.fileFormatId == "FLAT") {
          this.isFlat = true;
        }

        else {
          this.isFlat = false;
        }

        // Check for Null Value of data

        if (data.flowVhlMetadataDTOs == null) {
          this.vehDataListToShowFromDB = null;
        }

        else {
          this.vehDataListToShowFromDB = data.flowVhlMetadataDTOs;
          this.updatedVehDataList = data.flowVhlMetadataDTOs;

          // Sort array
          this.vehDataListToShowFromDB.sort((a, b) => (a.seq > b.seq) ? 1 : -1)

          //console.log(this.vehDataListToShowFromDB);
        }

        console.log(this.updatedVehDataList);

        if (data.collectionDTOs == null) {
          this.genericCollectionsToShowFromDB = null;
        }

        else {
          this.genericCollectionsToShowFromDB = data.collectionDTOs;
          this.updatedCollectionList = data.collectionDTOs;

          // Sort array
          this.genericCollectionsToShowFromDB.sort((a, b) => (a.seq > b.seq) ? 1 : -1)
        }

        if (data.ovComponentDTOs == null) {
          this.ovCompListToShowFromDB = null;
          this.ovCompPartListToShowFromDB = null;

          this.updatedOVCompList = null;
          console.log(this.updatedOVCompList);

          // check for file format
          if (data.fileFormatId == "TO_BE_DEFINED" || data.fileFormatId == null) {
            // Disable Add Button
            this.isOVCompPresent = true;
          }

          else {
            // Enable Add Button
            this.isOVCompPresent = false;
          }



        }

        else {
          this.ovCompListToShowFromDB = data.ovComponentDTOs;
          this.ovCompPartListToShowFromDB = data.ovComponentDTOs[0].ovComponentPartDTOs;

          this.updatedOVCompList = data.ovComponentDTOs;

          //console.log(this.updatedOVCompList);

          // Disable Add Button
          // this.isOVCompPresent = true;

          // Sort array
          this.ovCompListToShowFromDB.sort((a, b) => (a.seq > b.seq) ? 1 : -1);
          this.ovCompPartListToShowFromDB.sort((a, b) => (a.seq > b.seq) ? 1 : -1);
        }

        //console.log(this.ovCompListToShowFromDB);

        // Check for VIN to enable export

        console.log(this.vehDataListToShowFromDB);
        if (this.vehDataListToShowFromDB != null) {
          this.vehDataListToShowFromDB.forEach(element => {
            console.log(element);

            if (element.value == "VIN") {
              this.disableExport = false;
              //this.notValidData = false;

              this.isVinPresent = true;
            }
          })

        }


        // Set default value of Veh meta data format
        if (this.vehDataListToShowFromDB == null) {
          this.selectedVehData = null;
          this.selectedVehDataValue = null;
          //this.separatorValue = null;
          this.vehSeparatorValue = null;
        }

        else {
          //console.log(this.vehDataListToShowFromDB[0]);
          this.selectedVehData = this.vehDataListToShowFromDB[0].value;
          this.selectedVehDataValue = this.vehDataListToShowFromDB[0].filter;

          // Check for individual separator
          if (this.vehDataListToShowFromDB[0].value != "SEP") {
            this.vehSeparatorValue = this.vehDataListToShowFromDB[0].separator;
          }
          else {
            this.vehSeparatorValue = null;
          }

        }

        // Check if field is date field or Not
        if (this.selectedVehData == "DATE_EMON" || this.selectedVehData == "DATE_ECOM") {
          console.log("Date Field");
          this.isReadOnly = false;
        }

        else {
          this.isReadOnly = true;
        }
        // Set value for Generic Collection

        if (this.genericCollectionsToShowFromDB == null) {

          this.selectedCollection = null;
          this.selectedMaxOccurs = null;
          this.selectedCollectionIntSeparator = null;
          this.selectedCollectionFilter = null;
          this.selectedCollectionAlignment = null;
          this.collectionSeparatorValue = null;

        }
        else {
          this.selectedCollection = this.genericCollectionsToShowFromDB[0].value;
          this.selectedMaxOccurs = this.genericCollectionsToShowFromDB[0].maxOcc;
          this.selectedCollectionIntSeparator = this.genericCollectionsToShowFromDB[0].intSeparator;
          this.selectedCollectionFilter = this.genericCollectionsToShowFromDB[0].filter;
          this.selectedCollectionAlignment = this.genericCollectionsToShowFromDB[0].alignment;
          this.collectionSeparatorValue = this.genericCollectionsToShowFromDB[0].separator;
        }

        // Set value for OV Comp

        if (this.ovCompListToShowFromDB == null) {
          this.selectedOvCompMaxOccurs = null;
          this.selectedOvCompIntSeparator = null;
          this.selectedOvCompSeparator = null;
          this.selectedOvCompAlignment = null;
        }
        else {
          this.selectedOvCompMaxOccurs = this.ovCompListToShowFromDB[0].maxOcc;
          this.selectedOvCompIntSeparator = this.ovCompListToShowFromDB[0].intSeparator;
          this.selectedOvCompAlignment = this.ovCompListToShowFromDB[0].alignment;
          this.selectedOvCompSeparator = this.ovCompListToShowFromDB[0].separator;
        }

        // Set value for Ov Comp Part

        console.log(this.ovCompPartListToShowFromDB);


        if (this.ovCompPartListToShowFromDB == null) {

          // Check for File Format
          if (data.fileFormatId == "TO_BE_DEFINED" || data.fileFormatId == null) {
            // Disable all check boxes
            this.isGmChecked = true;
            this.isGmwChecked = true;
            this.isOtherChecked = true;
          }

          else {
            // enable all checkboxes
            this.isGmChecked = false;
            this.isGmwChecked = false;
            this.isOtherChecked = false;

          }

          // Reset All values
          this.selectedOvCompValues = null;
          this.selectedGMWValues = null;
          this.selectedOtherValues = null;

          // this.selectedOvCompAlignment = null;

          // Reset for GM1737
          this.gm1737Checked = false;
          this.gmIDChecked = false;
          this.selectedGmID = null;

          this.gmPartChecked = false;
          this.selectedGmPart = null;

          this.gmSupplierChecked = false;
          this.selectedGmSupply = null;

          this.gmDataChecked = false;
          this.selectedGmData = null;

          this.gmLabelChecked = false;

          // Reset for GMW15368

          this.gmwChecked = false;

          this.gmwIDChecked = false;
          this.selectedGMWID = null;

          this.gmwPartChecked = false;
          this.selectedGMWPart = null;

          this.gmwSupplierChecked = false;
          this.selectedGMWSupply = null;

          this.gmwDataChecked = false;
          this.selectedGMWData = null;

          this.gmwLabelChecked = false;

          // Reset for Other
          this.otherChecked = false;
          this.otherIDChecked = false;
          this.selectedOtherID = null;

          this.otherDataChecked = false;
          this.selectedOtherData = null;

          this.otherLabelChecked = false;
        }
        else {

          this.selectedOvCompValues = [];
          this.selectedGMWValues = [];
          this.selectedOtherValues = [];

          //this.resetCheckBox();

          // Disable all check boxes
          this.isGmChecked = true;
          this.isGmwChecked = true;
          this.isOtherChecked = true;

          // Sort ov comp parts before adding

          this.ovCompPartListToShowFromDB.sort((a, b) => (a.intSeq > b.intSeq) ? 1 : -1);

          this.ovCompPartListToShowFromDB.map(element => {
            //console.log(element);
            if (element.standard == "GM1737") {
              // console.log("GM1737");

              this.gm1737Checked = true;
              //this.isGmChecked = false;
              this.selectedOvCompValues.push(element.standard);

              if (element.value == "ID") {
                this.gmIDChecked = true;
                this.selectedGmID = element.filter;
                this.selectedOvCompValues.push(element.value);

              }

              if (element.value == "PART") {
                this.gmPartChecked = true;
                this.selectedGmPart = element.filter;
                this.selectedOvCompValues.push(element.value);

              }

              if (element.value == "SUPPLIER") {
                this.gmSupplierChecked = true;
                this.selectedGmSupply = element.filter;
                this.selectedOvCompValues.push(element.value);

              }

              if (element.value == "DATA") {
                this.gmDataChecked = true;
                this.selectedGmData = element.filter;
                this.selectedOvCompValues.push(element.value);

              }

              if (element.value == "LABEL") {
                this.gmLabelChecked = true;
                //this.selectedGmData = element.filter;
                this.selectedOvCompValues.push(element.value);

              }


            }

            if (element.standard == "GMW15862") {
              //console.log("GM15862");
              this.gmwChecked = true;
              //this.isGmwChecked = false;
              this.selectedGMWValues.push(element.standard);

              if (element.value == "ID") {
                this.gmwIDChecked = true;
                this.selectedGMWID = element.filter;
                this.selectedGMWValues.push(element.value);

              }

              if (element.value == "PART") {
                this.gmwPartChecked = true;
                this.selectedGMWPart = element.filter;
                this.selectedGMWValues.push(element.value);

              }

              if (element.value == "SUPPLIER") {
                this.gmwSupplierChecked = true;
                this.selectedGMWSupply = element.filter;
                this.selectedGMWValues.push(element.value);

              }

              if (element.value == "DATA") {
                this.gmwDataChecked = true;
                this.selectedGMWData = element.filter;
                this.selectedGMWValues.push(element.value);

              }

              if (element.value == "LABEL") {
                this.gmwLabelChecked = true;
                //this.selectedGmData = element.filter;
                this.selectedGMWValues.push(element.value);

              }
            }


            if (element.standard == "OTHER") {
              // console.log("OTHER");

              this.otherChecked = true;
              //this.isOtherChecked = false;
              this.selectedOtherValues.push(element.standard);

              if (element.value == "ID") {
                this.otherIDChecked = true;
                this.selectedOtherID = element.filter;
                this.selectedOtherValues.push(element.value);

              }

              if (element.value == "DATA") {
                this.otherDataChecked = true;
                this.selectedOtherData = element.filter;
                this.selectedOtherValues.push(element.value);

              }

              if (element.value == "LABEL") {
                this.otherLabelChecked = true;
                //this.selectedGmData = element.filter;
                this.selectedOtherValues.push(element.value);

              }

            }


          })



        }

        // Set the value of max sequence 

        let tempSeqArr = [];
        let tempMaxSeq: number;

        if (this.vehDataListToShowFromDB != null || this.vehDataListToShowFromDB != undefined) {
          this.vehDataListToShowFromDB.forEach(record => {
            tempSeqArr.push(record.seq);
          });
        }

        if (this.genericCollectionsToShowFromDB != null || this.genericCollectionsToShowFromDB != undefined) {
          this.genericCollectionsToShowFromDB.forEach(record => {
            tempSeqArr.push(record.seq);
          });
        }

        if (this.ovCompListToShowFromDB != null || this.ovCompListToShowFromDB != undefined) {
          this.ovCompListToShowFromDB.forEach(record => {
            tempSeqArr.push(record.seq);
          });
        }


        //console.log(tempSeqArr);
        tempMaxSeq = this.biggestNumberInArray(tempSeqArr);
        //console.log(tempMaxSeq);

        if (tempMaxSeq == null) {
          this.maxSeq = 0;
        }

        else {
          this.maxSeq = tempMaxSeq;
        }

        //console.log(this.vehDataListToShowFromDB);

        // Add in Drag and drop Veh Metadata
        if (this.vehDataListToShowFromDB == null) {
          // this.activeVehicleDatas = [];
          this.activeVehicleData = [];
        }
        else {

          //let vehMetadata = "vehMetaData";    

          this.vehDataListToShowFromDB.forEach(element => {
            let tempArr = [];
            let index = element.seq;

            // Check for individual separator
            if (element.value >= 32) {
              console.log(element.separator);
            }
            else {
              tempArr.push(element.value);
            }

            // tempArr.push(element.value);

            if (element.separator != null) {
              tempArr.push(element.separator);
            }


            this.activeVehicleDatas[index] = tempArr;


            //suits.splice(1 , 0 , 123);

            // console.log(this.activeVehicleData);

          });

          // this.activeVehicleDatas = this.activeVehicleDatas.concat(this.activeVehicleData);
        }


        // Add Content in Drag and Drop Generic Collection

        if (this.genericCollectionsToShowFromDB == null) {
          this.activeGenericCollections = [];
        }
        else {
          this.genericCollectionsToShowFromDB.forEach(element => {

            //console.log(element.seq);
            let tempArr = [];
            let index = element.seq;


            if (element.value == null || element.value == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.value);
            }

            if (element.maxOcc == null || element.maxOcc == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.maxOcc);
            }

            if (element.intSeparator == null || element.intSeparator == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.intSeparator);
            }

            if (element.filter == null || element.filter == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.filter);
            }

            if (element.alignment == null || element.alignment == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.alignment);
            }

            if (element.separator == null || element.separator == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.separator);
            }

            //console.log(this.activeVehicleDatas);

            this.activeVehicleDatas[index] = tempArr;



            //console.log(this.activeGenericCollections);

          });

          // this.activeVehicleDatas = this.activeVehicleDatas.concat(this.activeGenericCollections);

          //console.log(this.activeVehicleDatas.indexOf(this.activeGenericCollections))
        }


        // Add value in Drag and Drop area for OV Component

        if (this.ovCompListToShowFromDB == null) {
          this.activeOVComponents = null;
        }
        else {

          // Sort ov comp parts before adding

          this.ovCompPartListToShowFromDB.sort((a, b) => (a.intSeq > b.intSeq) ? 1 : -1);

          this.ovCompListToShowFromDB.forEach(element => {
            let tempArr = [];
            let index = element.seq;

            if (element.value == null || element.value == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.value);
            }

            if (element.maxOcc == null || element.maxOcc == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.maxOcc);
            }

            if (element.intSeparator == null || element.intSeparator == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.intSeparator);
            }


            if (element.alignment == null || element.alignment == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.alignment);
            }

            if (element.separator == null || element.separator == undefined) {
              tempArr = tempArr;
            }
            else {
              tempArr.push(element.separator);
            }


            //tempArr.push(ovComponentLabel);

            // Check for Ov parts

            if (Array.isArray(element.ovComponentPartDTOs)) {

              // Sort Part values based on int seq

              element.ovComponentPartDTOs.sort((a, b) => (a.intSeq > b.intSeq) ? 1 : -1);

              // Main Part Array
              let tempPartArr = [];
              // let ovPartLabel = "ovPartLabel";

              // Sub Part Array
              let tempGMArr = [];
              let tempGMWArr = [];
              let tempOtherArr = [];
              let arrForSeq = [];
              tempGMArr.push("GM1737");
              tempGMWArr.push("GMW15862");
              tempOtherArr.push("OTHER");

              element.ovComponentPartDTOs.forEach(ele => {



                if (ele.standard == "GM1737") {

                  let index = arrForSeq.indexOf(ele.standard);

                  console.log(index);

                  if (index == -1) {
                    arrForSeq.push(ele.standard);
                  }


                  if (ele.value == null || ele.value == undefined) {
                    tempGMArr = tempGMArr;
                  }
                  else {
                    tempGMArr.push(ele.value);

                  }

                  if (ele.filter == null || ele.filter == undefined) {
                    tempGMArr = tempGMArr;
                  }
                  else {
                    tempGMArr.push(ele.filter);

                  }


                  //tempGMArr.push(ovPartLabel);
                }

                if (ele.standard == "GMW15862") {

                  let index = arrForSeq.indexOf(ele.standard);

                  console.log(index);

                  if (index == -1) {
                    arrForSeq.push(ele.standard);
                  }

                  //arrForSeq.push(ele.standard);

                  if (ele.value == null || ele.value == undefined) {
                    tempGMWArr = tempGMWArr;
                  }
                  else {
                    tempGMWArr.push(ele.value);
                  }

                  if (ele.filter == null || ele.filter == undefined) {
                    tempGMWArr = tempGMWArr;
                  }
                  else {
                    tempGMWArr.push(ele.filter);
                  }

                }

                if (ele.standard == "OTHER") {

                  let index = arrForSeq.indexOf(ele.standard);

                  console.log(index);

                  if (index == -1) {
                    arrForSeq.push(ele.standard);
                  }

                  //arrForSeq.push(ele.standard);

                  if (ele.value == null || ele.value == undefined) {
                    tempOtherArr = tempOtherArr;
                  }
                  else {
                    tempOtherArr.push(ele.value);
                  }

                  if (ele.filter == null || ele.filter == undefined) {
                    tempOtherArr = tempOtherArr;
                  }
                  else {
                    tempOtherArr.push(ele.filter);
                  }

                }

              })


              // Add element Array in Main part Array

              // console.log(this.ovComps);
              console.log(arrForSeq);


              arrForSeq.forEach(element => {
                console.log(element);

                if (element == "GM1737" && tempGMArr.length != 0) {
                  tempPartArr.push(tempGMArr);
                }

                if (element == "GMW15862" && tempGMWArr.length != 0) {
                  tempPartArr.push(tempGMWArr);
                }

                if (element == "OTHER" && tempOtherArr.length != 0) {
                  tempPartArr.push(tempOtherArr);
                }

              })

              console.log(tempPartArr)

              tempArr.push(tempPartArr);
            }


            this.activeVehicleDatas[index] = tempArr;

          })

        }


        this.activeVehicleDatas = this.activeVehicleDatas.filter(Boolean);

        this.selectedOvCompValues = Array.from(new Set(this.selectedOvCompValues));
        this.selectedGMWValues = Array.from(new Set(this.selectedGMWValues));
        this.selectedOtherValues = Array.from(new Set(this.selectedOtherValues));

      },

      (error: any) => this.errorMessage = <any>error

    );
  }

  //=========================== Show Data Ends==============================//

  //========================== Change Event Start============================//

  // change event for Flow
  FlowChanged(event) {


    window.localStorage.removeItem("flowStored");

    //let changedFlow:any;
    //changedFlow = event.value;
    console.log(event.value);
    this.flowListFromDB.forEach(element => {
      if (event.value == element.flow) {
        this.flowNameForDB = element.id;
      }
    });

    console.log(this.flowNameForDB);
    this.flowName = this.flowNameForDB;

    window.localStorage.setItem("flowStored", this.flowName);
    //this.flowNameForDB = window.localStorage.getItem("changedFlow");

    console.log(this.flowNameForDB);
    // this.flowNameForDB = event.value;
    this.getRecordsFromDB();


  }

  // change event for File Format
  formatChanged(event, form) {
    console.log(event);

    // If format changed Reset all values of list
    this.updatedVehDataList = [];
    this.updatedOVCompList = [];
    this.updatedCollectionList = [];

    this.activeVehicleDatas = [];

    // Reset form values
    this.resetVehMetadata();
    this.resetCollection();
    this.resetOvComp();
    this.resetCheckBox();

    // Reset all errors
    this.isVehFilterNull = false;
    this.isCollectionNull = false;
    this.isMaxOCCNull = false;
    this.isAlignmentNull = false;
    this.isOVMaxOCCNull = false;
    this.isOVAlignNull = false;

    this.isOVPartNull = false;

    this.isFlat = false;

    // Disable all add button
    this.isDataPresent = true;
    this.isCollectionPresent = true;
    this.isOVCompPresent = true

    // On change Enable Cancel to reset
    this.disableCancel = false;


    // Check for To be defined Format

    if (event.value == "TO BE DEFINED") {

      console.log("not defined Format");

      // Disable validate and export

      this.notValidData = true;
      this.disableExport = true;

      // Disable all add button
      this.isDataPresent = true;
      this.isCollectionPresent = true;
      this.isOVCompPresent = true

      // Disable drop downs
      this.disableMetadata = true;

      // Disable all check boxes
      this.isGmChecked = false;
      this.isGmwChecked = false;
      this.isOtherChecked = false;

    }

    else {
      console.log("Defined Format");

      // Enable drop downs
      this.disableMetadata = false;

      // Check for Flat Format;
      if (event.value == "FLAT") {

        console.log("Flat Format");
        this.isFlat = true;
      }

      else {
        console.log("Other Format");
      }

      // Enable Validate
      // this.notValidData = false;

      console.log(this.updatedOVCompList);

      if (this.updatedOVCompList == null || this.updatedOVCompList.length == 0) {

        // Enable add button of ov Comp
        this.isOVCompPresent = false;

        // Enable all check boxes
        this.isGmChecked = false;
        this.isGmwChecked = false;
        this.isOtherChecked = false;

      }




    }

    console.log(this.updatedVehDataList);

  }

  // change event for veh metadata
  vehMetadetachangeEvent(event) {
    console.log(event);
    //let disableAddFlag:boolean;


    // Enable Validate and cancel button
    // this.notValidData = false;
    this.disableCancel = false;

    // Enable add Button
    this.isDataPresent = false;

    //console.log(this.isVehFilterNull);
    console.log(this.vehDataListToShowFromDB);

    // Reset Value
    this.isVehFilterNull = false;
    this.selectedVehData = null;
    this.selectedVehDataValue = null;
    this.vehSeparatorValue = null;
    this.disableAddFlag = false;

    //this.isDataPresent = true;
    this.isReadOnly = true;
    this.isDate = false;

    this.selectedVehData = event.value;

    // Check if field is Already present or not

    console.log(this.updatedVehDataList);
    console.log(this.isDataPresent);

    for (let i = 0; i < this.updatedVehDataList.length; i++) {
      if ((this.updatedVehDataList[i].value) == (this.selectedVehData)) {
        this.disableAddFlag = true;
      }
    }

    //console.log(this.disableAddFlag);

    if (this.disableAddFlag == true) {
      this.isDataPresent = true;
    }

    else {
      this.isDataPresent = false;
    }

    // Check if field is date field or Not
    if (this.selectedVehData == "DATE_EMON" || this.selectedVehData == "DATE_ECOM") {
      console.log("Date Field");
      this.isReadOnly = false;
      this.isDate = true;
    }


    // Set value of Veh meta data format after change
    if (this.updatedVehDataList == null) {
      this.selectedVehDataValue = null;
    }
    else {
      this.updatedVehDataList.map(element => {

        console.log("Value found");
        console.log()

        if (element.value == event.value) {
          this.selectedVehDataValue = element.filter;
          this.vehSeparatorValue = element.separator;
        }

      });

    }


    console.log(this.vehDataListToShowFromDB);


  }

  //change event for Generic collection
  collectionChangeEvent(event) {

    console.log(event);

    // Reset all values before change
    this.selectedCollection = null;
    this.selectedMaxOccurs = null;
    this.selectedCollectionIntSeparator = null;
    this.selectedCollectionFilter = null;
    this.selectedCollectionAlignment = null;
    this.collectionSeparatorValue = null;

    this.disableCollectionAddFlag = false;

    // Enable Add button
    this.isCollectionPresent = false;

    this.selectedCollection = event.value;

    // Check if field is Already present or not

    console.log(this.updatedCollectionList);



    for (let i = 0; i < this.updatedCollectionList.length; i++) {
      // console.log(this.selectedCollection);
      // console.log(this.updatedCollectionList[i].value);
      if ((this.updatedCollectionList[i].value) == (this.selectedCollection)) {
        // console.log("found value");
        this.disableCollectionAddFlag = true;
      }
    }

    // console.log(this.disableCollectionAddFlag);

    if (this.disableCollectionAddFlag == true) {
      this.isCollectionPresent = true;
    }

    else {

      this.isCollectionPresent = false;
    }

    // console.log(this.isCollectionPresent);

    // Set value of Generic Collection data format after change
    if (this.updatedCollectionList == null) {
      this.selectedMaxOccurs = null;
      this.selectedCollectionIntSeparator = null;
      this.selectedCollectionFilter = null;
      this.selectedCollectionAlignment = null;
      this.collectionSeparatorValue = null;

    }
    else {
      this.updatedCollectionList.map(element => {

        if (event.value == element.value) {

          this.selectedMaxOccurs = element.maxOcc;
          this.selectedCollectionIntSeparator = element.intSeparator;
          this.selectedCollectionFilter = element.filter;
          this.selectedCollectionAlignment = element.alignment;
          this.collectionSeparatorValue = element.separator;
        }
        // else{
        //   this.selectedVehDataValue = null;
        // }

      });

    }


    console.log(this.selectedCollection);
    console.log(this.selectedCollectionAlignment);

  }

  // Change event of Checkboxes

  changeGM1737($event, gmID, gmPart, gmSupply, gmData) {
    // console.log(event);
    // console.log(this.gm1737Checked);
    // console.log(this.gmIDChecked);
    // console.log(this.gmPartChecked);
    // console.log(this.gmSupplierChecked);
    // console.log(this.gmDataChecked);

    this.listSelectedPart = [];

    // let ovSelectedStandard = {} as ovCompCheck;

  }

  changeGM1737ID($event, gmID) {

    if (this.gmIDChecked == true) {
      console.log("in ID");
      this.getSeq("GM1737", "ID", gmID);

    }

    else {
      this.deleteSeq("GM1737", "ID");
    }

  }

  changeGM1737Part($event, gmPart) {
    if (this.gmPartChecked == true) {
      console.log("in Part");
      this.getSeq("GM1737", "PART", gmPart);
      console.log(this.ovComps);
    }

    else {
      this.deleteSeq("GM1737", "PART");
    }
  }

  changeGM1737Supplier($event, gmSupply) {

    if (this.gmSupplierChecked == true) {
      console.log("in Supplier");
      this.getSeq("GM1737", "SUPPLIER", gmSupply);
      console.log(this.ovComps);
    }
    else {
      this.deleteSeq("GM1737", "SUPPLIER");
    }
  }

  changeGM1737Data($event, gmData) {
    if (this.gmDataChecked == true) {
      console.log("in Data");
      this.getSeq("GM1737", "DATA", gmData);
      console.log(this.ovComps);
    }

    else {
      this.deleteSeq("GM1737", "DATA");
    }
  }

  changeGM1737Label($event) {

    if (this.gmLabelChecked == true) {
      console.log("in Label");
      this.getSeq("GM1737", "LABEL", null);
      console.log(this.ovComps);
    }

    else {
      this.deleteSeq("GM1737", "LABEL");
    }

  }

  changeGMWID($event, gmwID) {
    if (this.gmwIDChecked == true) {
      console.log("in ID");
      this.getSeq("GMW15862", "ID", gmwID);

    }
    else {
      this.deleteSeq("GMW15862", "ID");
    }
  }

  changeGMWPart($event, gmwPart) {
    if (this.gmwPartChecked == true) {
      console.log("in Part");
      this.getSeq("GMW15862", "PART", gmwPart);
      console.log(this.ovComps);
    }

    else {
      this.deleteSeq("GMW15862", "PART");
    }
  }

  changeGMWSupplier($event, gmwSupply) {
    if (this.gmwSupplierChecked == true) {
      console.log("in Supplier");
      this.getSeq("GMW15862", "SUPPLIER", gmwSupply);
      console.log(this.ovComps);
    }

    else {
      this.deleteSeq("GMW15862", "SUPPLIER");
    }
  }

  changeGMWData($event, gmwData) {
    if (this.gmwDataChecked == true) {
      console.log("in Data");
      this.getSeq("GMW15862", "DATA", gmwData);
      console.log(this.ovComps);
    }

    else {
      this.deleteSeq("GMW15862", "SUPPLIER");
    }
  }

  changeGMWLabel($event) {
    if (this.gmwLabelChecked == true) {
      console.log("in Label");
      this.getSeq("GMW15862", "LABEL", null);
      console.log(this.ovComps);
    }

    else {
      this.deleteSeq("GMW15862", "LABEL");
    }
  }


  changeOtherID(event, selectedID, selectedData) {


    if (this.otherIDChecked == true) {
      console.log("in ID");
      this.getSeq("OTHER", "ID", selectedID);

    }

    else {
      this.deleteSeq("OTHER", "ID");
    }

    console.log(this.ovComps);

    console.log(this.selectedOtrValues);


  }

  changeOtherData(event, selectedID, selectedData) {



    console.log(this.ovComps);

    if (this.otherDataChecked == true) {
      console.log("in Data");
      this.getSeq("OTHER", "DATA", selectedData);

    }

    else {
      this.deleteSeq("OTHER", "DATA");
    }


    console.log(this.ovComps);



    console.log(this.selectedOtrValues);
  }

  changeOtherLabel(event, selectedID, selectedData) {


    if (this.otherLabelChecked == true) {
      console.log("in Label");
      this.getSeq("OTHER", "LABEL", null);

    }

    else {
      this.deleteSeq("OTHER", "LABEL");
    }


    console.log(this.ovComps);

    // Remove Duplicate
    //this.ovComps = Array.from(new Set(this.ovComps));

    // this.ovComps = this.ovComps.filter(Boolean);
    // console.log(this.ovComps);

    console.log(this.selectedOtrValues);
  }

  changeGM1737IDFilter($event, gmIDFilter) {
    this.selectedgmValues.forEach(element => {
      console.log(element);

      if (element.value == "ID") {
        element.filter = gmIDFilter;
      }

    })

    console.log(this.selectedgmValues);
  }

  changeGM1737PartFilter($event, gmPartFilter) {

    console.log(gmPartFilter);
    this.selectedgmValues.forEach(element => {
      console.log(element);

      if (element.value == "PART") {
        element.filter = gmPartFilter;
      }

    })

    console.log(this.selectedgmValues);
  }

  changeGM1737SupplierFilter($event, gmSupplyFilter) {
    this.selectedgmValues.forEach(element => {
      console.log(element);

      if (element.value == "SUPPLIER") {
        element.filter = gmSupplyFilter;
      }

    })

    console.log(this.selectedgmValues);
  }

  changeGM1737DataFilter($event, gmDataFilter) {
    this.selectedgmValues.forEach(element => {
      console.log(element);

      if (element.value == "DATA") {
        element.filter = gmDataFilter;
      }

    })

    console.log(this.selectedgmValues);
  }

  changeGMWIDFilter($event, gmwIDFilter) {
    if (this.selectedgmwValues !== null) {
      this.selectedgmwValues.forEach(element => {
        console.log(element);

        if (element.value == "ID") {
          element.filter = gmwIDFilter;
        }

      })
    }

    console.log(this.selectedgmwValues);
  }

  changeGMWPartFilter($event, gmwPartFilter) {
    if (this.selectedgmwValues !== null) {
      this.selectedgmwValues.forEach(element => {
        console.log(element);

        if (element.value == "PART") {
          element.filter = gmwPartFilter;
        }

      })
    }

    console.log(this.selectedgmwValues);
  }

  changeGMWSupplierFilter($event, gmwSupplyFilter) {
    if (this.selectedgmwValues !== null) {
      this.selectedgmwValues.forEach(element => {
        console.log(element);

        if (element.value == "SUPPLIER") {
          element.filter = gmwSupplyFilter;
        }

      })
    }

    console.log(this.selectedgmwValues);
  }

  changeGMWDataFilter($event, gmwDataFilter) {

    console.log("GMW Data filter");
    if (this.selectedgmwValues !== null) {
      this.selectedgmwValues.forEach(element => {
        console.log(element);

        if (element.value == "DATA") {
          element.filter = gmwDataFilter;
        }

      })
    }

    console.log(this.selectedgmwValues);
  }

  changeOtherIDFilter($event, otherIDFilter) {
    if (this.selectedOtrValues !== null) {
      this.selectedOtrValues.forEach(element => {
        console.log(element);

        if (element.value == "ID") {
          element.filter = otherIDFilter;
        }

      })
    }

    console.log(this.selectedOtrValues);
  }

  changeOtherDataFilter($event, otherDataFilter) {
    if (this.selectedOtrValues !== null) {
      this.selectedOtrValues.forEach(element => {
        console.log(element);

        if (element.value == "DATA") {
          element.filter = otherDataFilter;
        }

      })
    }

    console.log(this.selectedOtrValues);
  }


  //========================== Change Event Ends============================//

  //======================= Show Data Gray Area Start========================//

  //======================= Show Data Gray Area Ends========================//


  // This method will reset the records in HTML page on click of Cancel button
  resetRecord(form: any) {

    // Reset all error messages
    this.isVehFilterNull = false;
    this.isMaxOCCNull = false;
    this.isCollectionNull = false;
    this.isAlignmentNull = false;

    this.isOVMaxOCCNull = false;
    this.isOVAlignNull = false;
    this.isOVPartNull = false;



    // Disable all add button
    this.isDataPresent = true;
    this.isCollectionPresent = true;
    this.isOVCompPresent = true

    // Disable validate and cancel , Export button
    this.notValidData = true;
    this.disableCancel = true;
    this.disableExport = true;

    this.getRecordsFromDB();
  }

  //============================ Export Start============================//

  showDialogToExport() {
    this.displayDialog = true;
  }

  cancel() {

    // Reset Vin value
    this.vinForExport = null;

    // reset value for error
    // this.errorMessageForExportComma = false;
    this.errorMessageForNoExport = false;
    this.errorMessageForExportMandate = false;

    // let index = this.newInterManagementRecords.indexOf(this.selectedRecord);
    // this.newInterManagementRecords = this.newInterManagementRecords.filter((val, i) => i != index);
    // this.newInterManagementRecord = null;
    this.displayDialog = false;
  }

  export(vinList, form) {
    //console.log(vinList);
    //console.log(this.flowName);
    //console.log(this.formData.flow);

    // console.log(this.exportedData);


    let exportFlow = this.tableRecords.flow;

    // console.log(this.updatedVehDataList);
    // console.log(this.updatedCollectionList);
    // console.log(this.updatedOVCompList);


    this.exportedData.id = this.tableRecords.id;
    // exportedData.id = this.tableRecords.id;

    this.exportedData.flowId = form.controls['flow'].value;
    this.exportedData.fileFormatId = form.controls['fileFormat'].value;

    // exportedData.flowId = form.controls['flow'].value;
    // exportedData.fileFormatId = form.controls['fileFormat'].value;

    this.exportedData.flowVhlMetadataDTOs = this.updatedVehDataList;
    this.exportedData.collectionDTOs = this.updatedCollectionList;
    this.exportedData.ovComponentDTOs = this.updatedOVCompList;



    // Decode result

    this.dataEncodingService.encodeObjValues(this.exportedData);

    // this.dataEncodingService.encodeObjValues(exportedData);

    if (this.exportedData.flowVhlMetadataDTOs == null || this.exportedData.flowVhlMetadataDTOs.length == 0) {
      this.exportedData.flowVhlMetadataDTOs = null;
    }
    else {
      this.dataEncodingService.encodeValues(this.exportedData.flowVhlMetadataDTOs);
    }

    if (this.exportedData.collectionDTOs == null || this.exportedData.collectionDTOs.length == 0) {
      this.exportedData.collectionDTOs = null;
    }
    else {
      this.dataEncodingService.encodeValues(this.exportedData.collectionDTOs);
    }

    if (this.exportedData.ovComponentDTOs == null || this.exportedData.ovComponentDTOs.length == 0) {
      this.exportedData.ovComponentDTOs = null;

    }
    else {
      this.dataEncodingService.encodeValues(this.exportedData.ovComponentDTOs);
      this.dataEncodingService.encodeValues(this.exportedData.ovComponentDTOs[0].ovComponentPartDTOs);
    }


    delete this.exportedData.flowId;

    console.log(this.exportedData);
    this.exportedResult = JSON.stringify(this.exportedData);



    // reset value for error
    this.errorMessageForExportComma = false;
    this.errorMessageForExportMandate = false;
    this.errorMessageForNoExport = false;

    if (vinList == null || vinList == undefined || vinList == "") {
      this.errorMessageForExportMandate = true;
      //this.errorMessageForExportComma = false;

      // Keep dialog box open
      this.displayDialog = true;
    }

    else {

      let finalDataToExport = {} as IExportData ;
      finalDataToExport.vinList = vinList;
      finalDataToExport.flowName = exportFlow;
      finalDataToExport.flowFormatDetails = this.exportedResult;

      console.log(finalDataToExport);

      // let url= this.env.ovrMicroServiceApiUrl + `/formatManagement/exportFile?vinList=${vinList}&flowName=${exportFlow}&flowFormatDetails=${JSON.stringify(this.exportedResult)}`;

      // let url= this.env.ovrMicroServiceApiUrl + `/formatManagement/exportFile`+JSON.stringify(finalDataToExport);
      // console.log(url);

      //     window.open(url);


      // this.formatManagementService.exportFlowFormat(exportFlow,vinList,this.exportedResult).subscribe(      
      //   //response => this.downLoadFile(response, "text"),
      //   response => this.downLoadFile(response, "text/csv"),
      //   (error: any) =>{
      //     console.log(error.status);
      //     console.log(error.statusText);
      //     this.errorMessageForNoExport = true;

      //     // Keep dialog box open
      //     this.displayDialog = true;
      //   }   
      // );

      // export with post request

      this.formatManagementService.exportFlowFormat(finalDataToExport).subscribe(
        response => this.downLoadFile(response, "text"),

        (error: any) =>{
              console.log(error.status);
              console.log(error.statusText);
              this.errorMessageForNoExport = true;
    
              // Keep dialog box open
              this.displayDialog = true;
            } 
      )

      // this.formatManagementService.exportFlowFormat(finalDataToExport).subscribe(
      //   (response:any) => {
      //     console.log(response);
      //     const file = new Blob([response], {type: 'text/plain'});
      //     const fileURL = URL.createObjectURL(file);
          

      //     if (window.navigator.msSaveOrOpenBlob) {
      //       // window.navigator.msSaveBlob(file, response.filename);
      //       window.navigator.msSaveOrOpenBlob(data.image, data.filename);
      //     } else {
      //         const link = document.createElement('a');
      //         link.href = fileURL;
      //         link.setAttribute('download', response.filename);
      //         link.click();
      //     }

      //     // this.exportStarted = 'none';

      //   },
      //   (error) => console.log(error)
      // )


      // Close dialog box
      this.displayDialog = false;
    }


    // Decode data again
    if (this.updatedVehDataList == null || this.updatedVehDataList.length == 0) {
      this.updatedVehDataList = null;
    }
    else {
      this.dataEncodingService.decodeValues(this.updatedVehDataList);
    }

    if (this.updatedCollectionList == null || this.updatedCollectionList.length == 0) {
      this.updatedCollectionList = null;
    }
    else {
      this.dataEncodingService.decodeValues(this.updatedCollectionList);
    }

    if (this.updatedOVCompList == null || this.updatedOVCompList.length == 0) {
      this.updatedOVCompList = null;
    }
    else {
      this.dataEncodingService.decodeValues(this.updatedOVCompList);
    }



    // Reset Vin value
    this.vinForExport = null;



    console.log(this.updatedVehDataList);
    console.log(this.updatedCollectionList);
    console.log(this.updatedOVCompList);

  }

  // This method will download the csv file
  downLoadFile(data: any, type: string) {

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(data.image, data.filename);
    }

    else {

      const element = document.createElement('a');
      element.href = URL.createObjectURL(data.image);
      element.download = data.filename;
      document.body.appendChild(element);
      element.click();

    }

  }

  //============================ Export Start============================//

  //============================ Validate Start============================//

  validateRecord(form: any) {

    //console.log(form);
    //console.log(this.tableRecords);

    let updatedFormData = {} as FormatManagementParameters;

    // Reset the object to null

    //updatedFormData = null;

    updatedFormData.id = this.tableRecords.id;

    updatedFormData.flowId = form.controls['flow'].value;
    updatedFormData.fileFormatId = form.controls['fileFormat'].value;

    //console.log(this.createVehData(this.updatedVehDataList));

    updatedFormData.flowVhlMetadataDTOs = this.createVehData(this.updatedVehDataList);

    updatedFormData.collectionDTOs = this.updatedCollectionList;

    updatedFormData.ovComponentDTOs = this.updatedOVCompList;


    // Code for internal seq
    console.log(this.updatedOVCompList);
    //console.log(this.updatedOVCompList[0].ovComponentPartDTOs);

    console.log(updatedFormData);



    // Post data to DB

    this.formatManagementService.updateFlow(updatedFormData).subscribe(
      (data: any) => {
        //console.log(data.responseList[0].msg);
        this.responseMsg = data.responseList[0].msg;
        // console.log(this.responseMsg);
        if (this.responseMsg == true) {
          // setTimeout(function(){ alert("Hello"); }, 3000);
          this.messageService.add({
            severity: 'success', summary: "Success",
            detail: `<div>Data for Flow ${updatedFormData.flow} is updated</div>`
          });

        }
        else if (this.responseMsg == false) {
          this.messageService.add({
            severity: 'error', summary: "Error Message",
            detail: `<div>Data for Flow ${updatedFormData.flow} is not updated</div>`
          })
        }
        this.getRecordsFromDB();

        // This will reset the form with validate disable
        this.form.reset();
        //this.clearMessage();
        this.proccessResponseService.clearMessage();
        //this.removeMessage(updatedFormData);

      },
      (error: any) => console.log(error)
    )

    // Disable validate and cancel
    this.notValidData = true;
    this.disableCancel = true;

  }


  //============================ Validate Ends============================//



  //================================ ADD Start============================//

  addVehData(event, fieldValue, filterValue, separatorValue) {
    // console.log(event);
    // console.log(fieldValue);
    // console.log(filterValue);
    // console.log("==="+separatorValue);



    // Reset Values
    this.isVehFilterNull = false;
    this.notValidData = true;
    this.activeVehicleData = [];

    // Check if field is date field or Not
    if (fieldValue == "DATE_EMON" || fieldValue == "DATE_ECOM") {

      console.log("filter=>" + filterValue);
      //console.log("Date Field");
      if (filterValue == null || filterValue == undefined || filterValue == "") {
        this.isVehFilterNull = true;
        // this.notValidData = true;

      }
      else {
        this.isVehFilterNull = false;
        // this.notValidData = false;

      }
    }

    // Create sequence

    let tempMaxSeq;

    if (this.maxSeq == 0) {
      tempMaxSeq = this.maxSeq + 1;
    }

    // Check for Error

    console.log(this.isVehFilterNull);
    // Check for file format
    if (this.isVehFilterNull == true) {
      // Disable add Button
      this.isDataPresent = false;

    }
    else {

      // Add in Sequence value
      tempMaxSeq = this.maxSeq + 1;

      // Create Object for validate
      let tempObj = {} as VehMetadataDTO;

      tempObj.id = null;
      tempObj.flowId = this.flowName;
      tempObj.value = fieldValue;
      tempObj.filter = filterValue;
      //tempObj.separator = separatorValue;
      tempObj.seq = tempMaxSeq;

      // Assign max sequence back
      this.maxSeq = tempMaxSeq;

      console.log(tempObj);

      this.updatedVehDataList.push(tempObj);

      // Code for gray area content

      this.activeVehicleData.push(tempObj.value);

      // Check for Null Separator

      console.log("sep1=>" + tempObj.separator);

      if (separatorValue == null || separatorValue == undefined || separatorValue == "") {

        tempObj.separator = null;
      }
      else {

        // tempArr.push(sep);
        tempObj.separator = separatorValue;
        this.activeVehicleData.push(tempObj.separator);
      }


      console.log(this.isIEOrEdge);

      this.activeVehicleDatas.push(this.activeVehicleData);

      console.log(this.activeVehicleDatas);

      // Disable add Button
      this.isDataPresent = true;

      // Enable Export if Vin is added
      if (fieldValue == "VIN") {
        this.disableExport = false;
        this.notValidData = false;
        this.isVinPresent = true;
      }
    }

    // Check if Vin is present to Enable validate
    if (this.isVinPresent == true) {
      this.notValidData = false;
    }
    else {
      this.notValidData = true;
    }


  }

  addCollectionData(event, fieldValue, maxOcc, intSep, filter, alignment, sep) {
    // console.log(fieldValue);
    // console.log(maxOcc);
    // console.log(intSep);
    // console.log(filter);
    // console.log(alignment);
    // console.log(sep);

    // console.log(this.selectedFileFormat);

    this.isCollectionNull = false;
    this.isMaxOCCNull = false;
    this.isAlignmentNull = false;

    // Create Object for validate

    let tempObj = {} as GenericCollectionDTO;

    let tempArr = [];

    tempObj.id = null;
    tempObj.flowId = this.flowName;
    tempObj.seq = this.maxSeq + 1;

    // Check if Collection is Null
    if (fieldValue == null || fieldValue == undefined || fieldValue == "") {
      this.isCollectionNull = true;
    }
    else {

      tempArr.push(fieldValue);
      tempObj.value = fieldValue;

    }

    // Check if Max OCC is Null
    if (maxOcc == null || maxOcc == undefined || maxOcc == "") {
      console.log("maxOcc");
      this.isMaxOCCNull = true;
    }
    else {

      tempArr.push(maxOcc);
      tempObj.maxOcc = maxOcc;
    }

    // Check if Internal Separator is Null
    if (intSep == null || intSep == undefined || intSep == "") {

      tempObj.intSeparator = null;
    }
    else {
      //this.activeGenericCollections.push(sep);
      tempArr.push(intSep);
      tempObj.intSeparator = intSep;
    }

    // Check if Filter is Null
    if (filter == null || filter == undefined || filter == "") {

      tempObj.filter = null;
    }
    else {

      tempArr.push(filter);
      tempObj.filter = filter;
    }

    // Check if Alignment is Null
    if (alignment == null || alignment == undefined || alignment == "") {
      //console.log("maxOcc");
      this.isAlignmentNull = true;
    }
    else {

      tempArr.push(alignment);
      tempObj.alignment = alignment;
    }


    // Check if Separator is Null
    if (sep == null || sep == undefined || sep == "") {

      tempObj.separator = null;
    }
    else {

      tempArr.push(sep);
      tempObj.separator = sep;
    }


    // Enable Validate and cancel button
    // this.notValidData = false;
    this.disableCancel = false;

    // Disable add Button
    // this.isCollectionPresent = true;

    // Assign value to max sequence
    this.maxSeq = tempObj.seq;


    console.log(this.updatedCollectionList);


    // Check if file format is Flat
    if (this.isFlat == true) {
      console.log("Flat");

      // Check for error

      if (this.isMaxOCCNull == true || this.isAlignmentNull == true) {
        this.updatedCollectionList = this.updatedCollectionList;
        this.activeVehicleDatas = this.activeVehicleDatas;

        // Reset temp Array and object
        tempObj = null;
        tempArr = [];

        //Keep add Button Enable
        this.isCollectionPresent = false;

      }
      else {
        this.updatedCollectionList.push(tempObj);
        this.activeVehicleDatas.push(tempArr);

        // Disable add Button
        this.isCollectionPresent = true;
      }

    }

    else {
      console.log("Not Flat");

      this.updatedCollectionList.push(tempObj);
      this.activeVehicleDatas.push(tempArr);

      // Disable add Button
      this.isCollectionPresent = true;
    }

    console.log(tempArr);

    //console.log(this.activeVehicleDatas);

    // Check if Vin is present to Enable validate
    if (this.isVinPresent == true) {
      this.notValidData = false;
    }
    else {
      this.notValidData = true;
    }


  }

  addOVCompData(event, fieldValue, maxOcc, intSep, alignment, sep) {

    // Reset error messages
    this.isOVMaxOCCNull = false;
    this.isOVAlignNull = false;
    this.errorMessageForOVData = false;

    this.isOVPartNull = false;

    this.updatedOVCompList = [];

    // check for part values
    // console.log(this.selectedgmValues);
    // console.log(this.selectedgmwValues);
    // console.log(this.selectedOtrValues);

    if (this.isFlat == true) {
      console.log("Flat Format");

      // Check if Max OCC is Null
      if(maxOcc == null || maxOcc == undefined || maxOcc == ""){
        //console.log("maxOcc");
        this.isOVMaxOCCNull = true;

        // Disable vaildate
        this.notValidData = true;

        // Enable Cancel
        this.disableCancel = false;
      }

      // Check if Alignment is Null
      else if(alignment == null || alignment == undefined || alignment == ""){
        //console.log("maxOcc");
        this.isOVAlignNull = true;

        // Disable vaildate
        this.notValidData = true;

        // Enable Cancel
        this.disableCancel = false;
      }

      else if(this.selectedgmValues.length == 0 && this.selectedgmwValues.length == 0 && this.selectedOtrValues.length == 0){
        console.log("Part is empty");

        // Enable Cancel
        this.disableCancel = false;

        // Error enable
        this.isOVPartNull = true;


      }

      else{

        // Enable Validate and cancel button
        this.notValidData = false;
        this.disableCancel = false;

        this.addOVComp(event, fieldValue, maxOcc, intSep, alignment, sep);

      }
    }

    else {

      console.log("Not Flat Format");

      //Set max occ Internal separator alignment and separator to null
      maxOcc = null;
      intSep = null;
      alignment = null;
      sep = null;

      if(this.selectedgmValues.length == 0 && this.selectedgmwValues.length == 0 && this.selectedOtrValues.length == 0){
        // Disable Validate 
        this.notValidData = true;

        // Enable Cancel
        this.disableCancel = false;

        this.isOVPartNull = true;

      }
      else{
        
        // Enable Validate and cancel button
        this.notValidData = false;
        this.disableCancel = false;

        this.addOVComp(event, fieldValue, maxOcc, intSep, alignment, sep);

      }


      

    }


  }

  addSeparator(separatorValue) {
    console.log(separatorValue);

    console.log(this.tempSepValue)

    // Reset value
    this.activeVehicleData = [];

    // Create sequence

    let tempMaxSeq;

    if (this.maxSeq == 0) {
      tempMaxSeq = this.maxSeq + 1;
    }

    console.log(this.maxSeq);
    // Add in Sequence value
    tempMaxSeq = this.maxSeq + 1;

    // Create Object for validate
    let tempObj = {} as VehMetadataDTO;

    tempObj.id = null;
    tempObj.flowId = this.flowName;
    // tempObj.value = this.tempSepValue;
    tempObj.value = "SEP";
    tempObj.filter = null;
    tempObj.separator = separatorValue;
    tempObj.seq = tempMaxSeq;

    // Assign max sequence back
    this.maxSeq = tempMaxSeq;

    // this.tempSepValue = this.tempSepValue+1;

    console.log(tempObj);

    this.updatedVehDataList.push(tempObj);

    console.log(this.updatedVehDataList);

    // Code for gray area content
    this.activeVehicleData.push(tempObj.value);

    this.activeVehicleData.push(tempObj.separator);

    console.log(this.activeVehicleData);


    this.activeVehicleDatas.push(this.activeVehicleData);

    console.log(this.activeVehicleDatas);



    // Enable validate button
    // Check if Vin is present to Enable validate
    if (this.isVinPresent == true) {
      this.notValidData = false;
    }
    else {
      this.notValidData = true;
    }

    // Disable add button

    // Reset temp object

    this.separatorValue = null;
  }

  //================================ ADD Ends============================//

  //================================ Delete Start==========================//
  // Select method for an Item
  selectedItem(event, index, list, selectedItem) {

    console.log(event);
    console.log(index);
    console.log(list);
    console.log(selectedItem);
    console.log(event.target);

    // Enable cancel button
    //this.notValidData = false;
    // this.disableCancel = false;
    event.stopPropagation();
    this.selectedItemList = list;
    this.selectedElement = selectedItem[0];
    this.selectedElementSeparator = selectedItem[1];
    this.selectedElementIndex = index;

    this.selectedDiv = event.target.style;

    //let tempArr = [];

    this.selectedDivArr.push(this.selectedDiv);

    // console.log(this.selectedDivArr);

    // console.log(this.removeSelectedItem);

    let greenItemIndex = this.removeSelectedItem[0];
    // console.log(greenItemIndex);

    //let greenItem = this.selectedItemList[greenItemIndex];

    // console.log(greenItem);

    // console.log(this.selectedDivArr[0]);


    console.log(this.removeSelectedItem);
    if (this.removeSelectedItem.length >= 1) {
      console.log("Select more than 1");
      // alert("can not select more than one");
      //this.removeSelectedItem = [];
      // event.target.style.backgroundColor = 'white';

      this.selectedDivArr[0].cssText = "background-color: white";
      console.log(this.selectedDiv);
      this.removeSelectedItem = [];
      this.selectedDivArr = [];
      event.target.style.backgroundColor = 'green';
      this.removeSelectedItem.push(index);
      this.selectedDivArr.push(event.target.style);
    }
    else {
      event.target.style.backgroundColor = 'green';
      this.removeSelectedItem.push(index);
    }

    console.log(this.removeSelectedItem);
    //console.log(this.updatedVehDataList);
  }

  deSelectItem() {
    console.log(event);
    // console.log(index);
    // console.log(list);
    console.log(this.selectedDiv.cssText);

    this.selectedDiv.cssText = "background-color: white";

    let deselectedIndex = this.removeSelectedItem.indexOf(this.selectedElementIndex);

    console.log(deselectedIndex);

    this.removeSelectedItem.splice(deselectedIndex, 1);

    console.log(this.removeSelectedItem);

  }

  // Delete the selected item
  deleteItem() {

    console.log("Delete Method");

    // Enable Validate and Cancel
    // this.notValidData = false;
    this.disableCancel = false;


    if (this.removeSelectedItem.length != 0) {
      this.removeSelectedItem.forEach(element => {
        console.log(element);
        this.selectedItemList.splice(element, 1);
        // this.updatedCollectionList.splice(element,1);
        // this.updatedVehDataList.splice(element,1);

      })

    }

    else {
      console.log("No Item to delete");
    }


    console.log(this.selectedItemList);

    this.activeVehicleDatas = this.selectedItemList;

    // Check if value is present

    // If Item to be deleted is Vin then Disable Export

    if (this.selectedElement == "VIN") {
      this.disableExport = true;
      this.notValidData = true;
      this.isVinPresent = false;
    }

    // Change seq after delete

    let updatedData = [];

    let tempArr = [];

    updatedData = this.selectedItemList;

    for (let i = 0; i < updatedData.length; i++) {
      let tempObj = {} as VehMetadataDTO;
      tempObj.seq = i + 1;
      tempObj.value = updatedData[i][0];
      tempObj.separator = updatedData[i][1];

      //console.log(tempObj);

      tempArr[i] = tempObj;

    }

    console.log(tempArr);

    let tempVehArr = [];

    console.log(this.selectedElement);

    if (this.updatedVehDataList != null) {
      // this.updatedVehDataList = this.updatedVehDataList.filter(item => item.value !== this.selectedElement);
      for (let i = 0; i < this.updatedVehDataList.length; i++) {
        if (this.updatedVehDataList[i].value != this.selectedElement) {
          tempVehArr.push(this.updatedVehDataList[i]);
        }
        else {
          if (this.updatedVehDataList[i].separator != this.selectedElementSeparator) {
            tempVehArr.push(this.updatedVehDataList[i]);
          }
        }

      }
    }

    console.log(tempVehArr);
    this.updatedVehDataList = tempVehArr;
    console.log(this.updatedVehDataList);

    if (this.updatedCollectionList != null) {
      this.updatedCollectionList = this.updatedCollectionList.filter(item => item.value !== this.selectedElement);
    }
    if (this.updatedOVCompList != null) {
      this.updatedOVCompList = this.updatedOVCompList.filter(item => item.value !== this.selectedElement);
    }

    // Assign sequence
    if (this.updatedVehDataList != null) {

      // this.updatedVehDataList.forEach(element =>{
      //   var result=tempArr.filter(item=> item.value == element.value);

      //   if(result.length>0) {
      //     //console.log("Match Found")
      //     element.seq = result[0].seq;
      //   }


      // })

      for (let i = 0; i < this.updatedVehDataList.length; i++) {
        for (let j = 0; j < tempArr.length; j++) {

          if (this.updatedVehDataList[i].value == tempArr[j].value) {
            // console.log(this.updatedVehDataList[i].value);
            // console.log(tempArr[j].value);

            if (this.updatedVehDataList[i].value != "SEP") {
              this.updatedVehDataList[i].seq = tempArr[j].seq;
            }

            else {
              if (this.updatedVehDataList[i].separator == tempArr[j].separator) {
                this.updatedVehDataList[i].seq = tempArr[j].seq;
              }

            }

          }
        }
      }

    }

    if (this.updatedCollectionList != null) {
      this.updatedCollectionList.forEach(element => {
        var result = tempArr.filter(item => item.value == element.value);

        if (result.length > 0) {
          //console.log("Match Found")
          element.seq = result[0].seq;
        }

      })

    }

    if (this.updatedOVCompList != null) {
      this.updatedOVCompList.forEach(element => {
        var result = tempArr.filter(item => item.value == element.value);

        if (result.length > 0) {
          //console.log("Match Found")
          element.seq = result[0].seq;
        }

      })

    }

    console.log(this.updatedVehDataList);
    console.log(this.updatedCollectionList);
    console.log(this.updatedOVCompList);

    // Set default value of Veh meta data 
    if (this.updatedVehDataList == null || this.updatedVehDataList == undefined || this.updatedVehDataList.length == 0) {
      // this.selectedVehData = null;
      // this.selectedVehDataValue = null;
      // //this.separatorValue = null;
      // this.vehSeparatorValue = null;

      this.resetVehMetadata();
    }

    else {
      //console.log(this.vehDataListToShowFromDB[0]);
      this.selectedVehData = this.updatedVehDataList[0].value;
      this.selectedVehDataValue = this.updatedVehDataList[0].filter;
      this.vehSeparatorValue = this.updatedVehDataList[0].separator;
    }

    // Check if field is date field or Not
    if (this.selectedVehData == "DATE_EMON" || this.selectedVehData == "DATE_ECOM") {
      console.log("Date Field");
      this.isReadOnly = false;
    }

    else {
      this.isReadOnly = true;
    }

    // Set value for Generic Collection

    if (this.updatedCollectionList == null || this.updatedCollectionList == undefined || this.updatedCollectionList.length == 0) {

      // this.selectedCollection = null;
      // this.selectedMaxOccurs = null;
      // this.selectedCollectionIntSeparator = null;
      // this.selectedCollectionFilter = null;
      // this.selectedCollectionAlignment = null;
      // this.collectionSeparatorValue = null;

      this.resetCollection();

    }
    else {
      this.selectedCollection = this.updatedCollectionList[0].value;
      this.selectedMaxOccurs = this.updatedCollectionList[0].maxOcc;
      this.selectedCollectionIntSeparator = this.updatedCollectionList[0].intSeparator;
      this.selectedCollectionFilter = this.updatedCollectionList[0].filter;
      this.selectedCollectionAlignment = this.updatedCollectionList[0].alignment;
      this.collectionSeparatorValue = this.updatedCollectionList[0].separator;
    }

    // Set value for OV Comp

    if (this.updatedOVCompList == null || this.updatedOVCompList == undefined || this.updatedOVCompList.length == 0) {
      // Enable Add button to insert new values
      this.isOVCompPresent = false;

      // Reset field values of OV comp
      this.selectedOvCompMaxOccurs = null;
      this.selectedOvCompIntSeparator = null;
      this.selectedOvCompSeparator = null;
      this.selectedOvCompAlignment = null;

      // Reset disable flag of check box values
      this.isGmChecked = false;
      this.isGmwChecked = false;
      this.isOtherChecked = false;

      this.resetCheckBox();
    }


    console.log(this.updatedVehDataList);
    console.log(this.updatedCollectionList);
    console.log(this.updatedOVCompList);

    // Set max seq
    this.maxSeq = tempArr.length;

    console.log(this.maxSeq);

    // Check if Vin is present to Enable validate
    if (this.isVinPresent == true) {
      this.notValidData = false;
    }
    else {
      this.notValidData = true;
    }

    // console.log(this.selectedElement);

    // Enable Validate and cancel button
    // this.notValidData = false;
    // this.disableCancel = false;
  }


  // This will listen to Delete Button press
  @HostListener('document:keyup', ['$event'])
  handleDeleteKeyboardEvent(event: KeyboardEvent) {

    console.log(event);

    if (event.key === 'Delete' || event.key == "Del") {
      // remove something... or call remove function this.remove();
      // console.log("delete");
      // console.log(this.removeSelectedItem);

      if (this.removeSelectedItem.length > 0) {
        console.log("data to remove");
        this.confirmDelete();
      }
      else {
        console.log("No data to remove");
      }



    }
  }

  confirmDelete() {
    //console.log("Confirm Delete");
    this.confirmationService.confirm({

      accept: () => {
        //this.deleteRow(tableRow,index);
        // this.getRecordsFromDB(); 

        this.deleteItem();
      },
      reject: () => {
        this.deSelectItem();
        //this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
      }
    });
  }

  //================================ Delete Ends===========================//

  //============================ Drag And Drop Starts=======================//


  drop(event: CdkDragDrop<string[]>) {

    // console.log("Drop Event");

    // console.log(this.updatedVehDataList);

    // console.log(event);

    if (event.previousContainer === event.container) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }

    let updatedData = [];

    let tempArr = [];

    updatedData = event.container.data;

    console.log(updatedData);

    for (let i = 0; i < updatedData.length; i++) {
      let tempObj = {} as VehMetadataDTO;
      tempObj.seq = i + 1;
      tempObj.value = updatedData[i][0];
      tempObj.separator = updatedData[i][1];

      //console.log(tempObj);

      tempArr[i] = tempObj;

    }

    console.log(tempArr);

    // Check value in updated

    // Check for Null List
    console.log(this.updatedVehDataList);
    if (this.updatedVehDataList != null) {

      // this.updatedVehDataList.forEach(element =>{
      //   var result=tempArr.filter(item=> item.value == element.value);
      //   console.log(result);

      //   if(result.length>0) {
      //     //console.log("Match Found")
      //     element.seq = result[0].seq;
      //   }



      // })

      for (let i = 0; i < this.updatedVehDataList.length; i++) {
        for (let j = 0; j < tempArr.length; j++) {

          if (this.updatedVehDataList[i].value == tempArr[j].value) {
            // console.log(this.updatedVehDataList[i].value);
            // console.log(tempArr[j].value);

            if (this.updatedVehDataList[i].value != "SEP") {
              this.updatedVehDataList[i].seq = tempArr[j].seq;
            }

            else {
              if (this.updatedVehDataList[i].separator == tempArr[j].separator) {
                this.updatedVehDataList[i].seq = tempArr[j].seq;
              }

            }

          }
        }
      }

    }

    console.log(this.updatedVehDataList);

    if (this.updatedCollectionList != null) {
      this.updatedCollectionList.forEach(element => {
        var result = tempArr.filter(item => item.value == element.value);

        if (result.length > 0) {
          //console.log("Match Found")
          element.seq = result[0].seq;
        }

      })

    }

    if (this.updatedOVCompList != null) {
      this.updatedOVCompList.forEach(element => {
        var result = tempArr.filter(item => item.value == element.value);

        if (result.length > 0) {
          //console.log("Match Found")
          element.seq = result[0].seq;
        }

      })

    }


    console.log(this.updatedVehDataList);
    console.log(this.updatedCollectionList);
    console.log(this.updatedOVCompList);

    // Enable Validate and cancel button
    // this.notValidData = false;
    this.disableCancel = false;

    // Check if Vin is present to Enable validate
    if (this.isVinPresent == true) {
      this.notValidData = false;
    }
    else {
      this.notValidData = true;
    }

  }


  //============================ Drag And Drop Ends=======================//



  createVehData(arrToConvert: any[]) {
    // Create an empty Array
    let tempArr = [];

    let arrLength = arrToConvert.length;

    let tempObject = arrToConvert;

    for (let i = 0; i < arrLength; i++) {

      let tempObj = {} as VehMetadataDTO;

      tempObj.id = tempObject[i].id;
      tempObj.flowId = tempObject[i].flowId;
      tempObj.value = tempObject[i].value;
      tempObj.filter = tempObject[i].filter;
      tempObj.separator = tempObject[i].separator;
      tempObj.seq = tempObject[i].seq;


      tempArr.push(tempObj);

    }

    return tempArr;

  }

  biggestNumberInArray(arr) {
    // The largest number at first should be the first element or null for empty array
    var largest = arr[0] || null;

    // Current number, handled by the loop
    var number = null;
    for (var i = 0; i < arr.length; i++) {
      // Update current number
      number = arr[i];

      // Compares stored largest number with current number, stores the largest one
      largest = Math.max(largest, number);
    }

    return largest;
  }


  getSeq(std, part, filter) {

    //let ovComp = {} as  ovCompCheck;

    // Reset List
    //this.ovComps = [];

    let ovComp = new ovCompCheck();

    let stdFlag: boolean = false;
    let partFlag: boolean = false;

    if (this.ovComps.length == 0) {
      //let ovComp = new ovCompCheck();

      console.log("in IF");

      ovComp.setStd(++this.stdCnt);
      ovComp.setStdValue(std);

      ovComp.setPart(++this.partCnt);
      ovComp.setPartValue(part);

      this.ovComps.push(ovComp);
    }


    else {
      console.log("in Else");
      console.log(this.ovComps);

      //this.ovComps = [];

      this.ovComps.forEach(ovCompObj => {

        if (ovCompObj.stdValue == std) {
          ovComp.setStd(ovCompObj.getStd());
          ovComp.setStdValue(ovCompObj.getStdValue());

          stdFlag = true;
        }

        if (ovCompObj.partValue == part) {
          ovComp.setPart(ovCompObj.getPart());
          ovComp.setPartValue(ovCompObj.getPartValue());

          partFlag = true;
        }

      })


      if (stdFlag == false) {
        ovComp.setStd(++this.stdCnt);
        ovComp.setStdValue(std);
      }

      if (partFlag == false) {
        ovComp.setPart(++this.partCnt);
        ovComp.setPartValue(part);
      }

      this.ovComps.push(ovComp);


    }

    // Remove Duplicate
    //this.ovComps = Array.from(new Set(this.ovComps));

    //this.ovComps = this.ovComps.filter(Boolean);

    console.log(ovComp);
    // Create Obj for Validate
    let tempObj = {} as ovComponentPartDTO;

    tempObj.id = null;
    tempObj.standard = std;
    tempObj.value = part;
    if (filter != null) {
      tempObj.filter = filter;
    }
    else {
      tempObj.filter = null;
    }

    tempObj.ovCompId = null;
    tempObj.intSeq = ovComp.std + "." + ovComp.part;

    if (std == "GM1737") {
      this.selectedgmValues.push(tempObj);
    }

    if (std == "GMW15862") {
      this.selectedgmwValues.push(tempObj);
    }

    if (std == "OTHER") {
      this.selectedOtrValues.push(tempObj);
    }

    console.log(tempObj);

  }

  deleteSeq(std, part) {
    console.log(this.ovComps);

    let ovComp = new ovCompCheck();

    let stdDeleteCnt = 0;
    let partDeleteCnt = 0;

    let objIndex;

    if (this.ovComps.length != 0) {
      this.ovComps.forEach((ovCompObj, index) => {

        console.log(index);
        //this.ovComps = this.ovComps.filter(function(value) { return value != ovComp });

        if (ovCompObj.stdValue == std) {
          stdDeleteCnt++;
        }

        if (ovCompObj.partValue == part) {
          partDeleteCnt++;
        }

        if (ovCompObj.stdValue == std && ovCompObj.partValue == part) {
          ovComp.setStd(ovCompObj.getStd());
          ovComp.setStdValue(std);
          ovComp.setPart(ovCompObj.getPart());
          ovComp.setPartValue(part);
          objIndex = index;
        }


        console.log(objIndex);


      })

      // get the index of element to remove
      console.log(ovComp);
      console.log(this.ovComps);


      // let index =  this.ovComps.indexOf(ovComp);

      // console.log(index);

      if (objIndex > -1) { //if found
        this.ovComps.splice(objIndex, 1);
      }


      //this.ovComps = this.ovComps.filter(function(value) { return value != ovComp });

      console.log(this.ovComps);
      //this.ovComps.remove(ovComp);

      if (stdDeleteCnt == 1) {
        this.stdCnt--;

        this.ovComps.forEach(ovCompObj => {
          if (ovCompObj.getStd() > ovComp.getStd()) {
            ovCompObj.setStd((ovCompObj.getStd() - 1));
          }
        })

      }

      if (partDeleteCnt == 1) {
        this.partCnt--;
        this.ovComps.forEach(ovCompObj => {
          if (ovCompObj.getPart() > ovComp.getPart()) {
            ovCompObj.setPart((ovCompObj.getPart() - 1));
          }
        })

      }
    }

    console.log(this.ovComps);

    this.selectedOtrValues = [];
    this.selectedgmValues = [];
    this.selectedgmwValues = [];

    for (let i = 0; i < this.ovComps.length; i++) {

      let tempObj = {} as ovComponentPartDTO;

      tempObj.id = null;
      tempObj.standard = this.ovComps[i].stdValue;
      tempObj.value = this.ovComps[i].partValue;
      tempObj.filter = null;
      tempObj.ovCompId = null;
      tempObj.intSeq = this.ovComps[i].std + "." + this.ovComps[i].part;

      console.log(tempObj);

      if (tempObj.standard == "GM1737") {
        this.selectedgmValues.push(tempObj);
      }

      if (tempObj.standard == "GMW15862") {
        this.selectedgmwValues.push(tempObj);
      }

      if (tempObj.standard == "OTHER") {
        this.selectedOtrValues.push(tempObj);
      }


    }










    // if(std == "GM1737"){
    //   this.selectedgmValues.push(tempObj);
    // }

    // if(std == "GMW15862"){
    //   this.selectedgmwValues.push(tempObj);
    // }


  }


  resetVehMetadata() {
    this.selectedVehData = null;
    this.selectedVehDataValue = null;
    this.vehSeparatorValue = null;
  }

  resetCollection() {
    this.selectedCollection = null;
    this.selectedMaxOccurs = null;
    this.selectedCollectionIntSeparator = null;
    this.selectedCollectionFilter = null;
    this.selectedCollectionAlignment = null;
    this.collectionSeparatorValue = null;
  }

  resetOvComp() {
    this.selectedOvCompMaxOccurs = null;
    this.selectedOvCompIntSeparator = null;
    this.selectedOvCompSeparator = null;
    this.selectedOvCompAlignment = null;
  }

  resetCheckBox() {

    // Reset counter of GET seq

    this.stdCnt = 0;
    this.partCnt = 0;

    this.gm1737Checked = false;
    this.gmIDChecked = false;
    this.gmPartChecked = false;
    this.gmSupplierChecked = false;
    this.gmDataChecked = false;
    this.gmLabelChecked = false;

    this.selectedGmID = null;
    this.selectedGmPart = null;
    this.selectedGmSupply = null;
    this.selectedGmData = null;

    this.gmwChecked = false;
    this.gmwIDChecked = false;
    this.gmwPartChecked = false;
    this.gmwSupplierChecked = false;
    this.gmwDataChecked = false;
    this.gmwLabelChecked = false;

    this.selectedGMWID = null;
    this.selectedGMWPart = null;
    this.selectedGMWSupply = null;
    this.selectedGMWData = null;

    this.otherChecked = false;
    this.otherIDChecked = false;
    this.otherDataChecked = false;
    this.otherLabelChecked = false;

    this.selectedOtherID = null;
    this.selectedOtherData = null;

    // Reset readonly and disable flag

    this.selectedgmValues = [];
    this.selectedgmwValues = [];
    this.selectedOtrValues = [];

  }

  resetValueOfDelete() {

    this.selectedDiv = null;
    this.selectedItemList = null;
    this.selectedElement = null;
    this.selectedElementIndex = null;
    this.removeSelectedItem = [];

  }

  getByStdValue(std: number) {

    // console.log(this.ovComps);

    let stdValue = null;

    this.ovComps.forEach(element => {
      // console.log(element.std +"======="+ std);
      if (element.std == std) {
        // console.log(element.stdValue);
        stdValue = element.stdValue;

      }
    })

    return stdValue;

  }

  addOVComp(event,fieldValue,maxOcc,intSep,alignment,sep) {

    // Create Object for validate

    let tempObj = {} as OvCompDTO;

    tempObj.id = null;
    tempObj.flowId = this.flowName;
    tempObj.value = fieldValue;
    tempObj.seq = this.maxSeq + 1;

    // Field values 
    // tempObj.maxOcc = maxOcc;
    // tempObj.alignment = alignment;

    // Create object to insert in Gray area
    let tempArr = [];


    // Add in Gray area
    tempArr.push(fieldValue);
    // tempArr.push(maxOcc);
    // tempArr.push(alignment);

    // Check if Max OCC is Null
    if(maxOcc == null || maxOcc == undefined || maxOcc == ""){
      //console.log("maxOcc");
      // this.isOVMaxOCCNull = true;
      tempObj.maxOcc = null;
    }
    else{
      //this.activeGenericCollections.push(maxOcc);
      console.log("max occ not null");
      tempArr.push(maxOcc);
      tempObj.maxOcc = maxOcc;
    }

    // Check if Alignment is Null
    if(alignment == null || alignment == undefined || alignment == ""){
      //console.log("maxOcc");
      tempObj.alignment = null;
    }
    else{
      //this.activeGenericCollections.push(alignment);
      console.log("alignment not null");
      tempArr.push(alignment);
      tempObj.alignment = alignment;
    }


    // Check if Internal Separator is Null
    if(intSep == null || intSep == undefined || intSep == ""){
      // console.log("maxOcc");
      // this.isAlignmentNull = true;
      tempObj.intSeparator = null;
    }
    else{
      //this.activeGenericCollections.push(sep);
      tempArr.push(intSep);
      tempObj.intSeparator = intSep;
    }

    // Check if Separator is Null
    if(sep == null || sep == undefined || sep == ""){
      // console.log("maxOcc");
      // this.isAlignmentNull = true;
      tempObj.separator = null;
    }
    else{
      //this.activeGenericCollections.push(sep);
      tempArr.push(sep);
      tempObj.separator = sep;
    }

    // Add Part values

    tempObj.ovComponentPartDTOs = [];

    tempObj.ovComponentPartDTOs.push(...this.selectedgmValues);
    tempObj.ovComponentPartDTOs.push(...this.selectedgmwValues);
    tempObj.ovComponentPartDTOs.push(...this.selectedOtrValues);


    // Sort Part values
    tempObj.ovComponentPartDTOs.sort((a, b) => (a.intSeq > b.intSeq) ? 1 : -1);

    console.log(tempObj.ovComponentPartDTOs);

    let tempPartArr = [];
    // Sub Part Array
    let tempGMArr = [];
    let tempGMWArr = [];
    let tempOtherArr = [];

    tempGMArr.push("GM1737");
    tempGMWArr.push("GMW15862");
    tempOtherArr.push("OTHER");

    tempObj.ovComponentPartDTOs.forEach(ele => {
      //console.log("Inside Ov Part");
      if(ele.standard == "GM1737"){
        if(ele.value == null || ele.value == undefined){
          tempGMArr = tempGMArr;
        }
        else{
          tempGMArr.push(ele.value);
        }

        if(ele.filter == null || ele.filter == undefined || ele.filter == ""){
          tempGMArr = tempGMArr;
        }
        else{
          tempGMArr.push(ele.filter);
        }

        //tempGMArr.push(ovPartLabel);
      }

      if(ele.standard == "GMW15862"){
        //console.log("GMW15672");

        if(ele.value == null || ele.value == undefined ){
          tempGMWArr = tempGMWArr;
        }
        else{
          tempGMWArr.push(ele.value);
        }

        if(ele.filter == null || ele.filter == undefined || ele.filter == ""){
          tempGMWArr = tempGMWArr;
        }
        else{
          tempGMWArr.push(ele.filter);
        }

      }

      if(ele.standard == "OTHER"){

        if(ele.value == null || ele.value == undefined ){
          tempOtherArr = tempOtherArr;
        }
        else{
          tempOtherArr.push(ele.value);
        }

        if(ele.filter == null || ele.filter == undefined || ele.filter == ""){
          tempOtherArr = tempOtherArr;
        }
        else{
          tempOtherArr.push(ele.filter);
        }

      }

    })

    // Add element Array in Main part Array
    // Check for Null value of part before adding

    for(let i=1 ; i<=3; i++){
      let stdValue:string;
      stdValue = this.getByStdValue(i);

      console.log(stdValue);

      if(stdValue == "GM1737" && tempGMArr.length != 0){
        tempPartArr.push(tempGMArr);
      }

      if(stdValue == "GMW15862" && tempGMWArr.length != 0){
        tempPartArr.push(tempGMWArr);
      }

      if(stdValue == "OTHER" && tempOtherArr.length != 0){
        tempPartArr.push(tempOtherArr);
      }
    }

      // Add Part in Main OV Component Array

      tempArr.push(tempPartArr);

      this.updatedOVCompList.push(tempObj);

      this.updatedOVCompList.sort((a, b) => (a.intSeq > b.intSeq) ? 1 : -1);

      // Assign max seq

      this.maxSeq = tempObj.seq ;

      console.log(this.updatedOVCompList);



      if(this.selectedgmValues.length == 0 && this.selectedgmwValues.length == 0 && this.selectedOtrValues.length == 0){

      }
      else{
        // Add in Drop down box
        this.activeVehicleDatas.push(tempArr);

        // Enable Validate and cancel button
        this.notValidData = false;

      }
      



    console.log(tempObj);
    console.log(tempArr);

  }



}
