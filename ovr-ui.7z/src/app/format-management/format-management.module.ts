import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {DragDropModule} from '@angular/cdk/drag-drop';

import { FormatManagementRoutingModule } from './format-management-routing.module';
import { FormatManagementComponent } from './format-management.component';

import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {TooltipModule} from 'primeng/tooltip';
import {DropdownModule} from 'primeng/dropdown';
import {CheckboxModule} from 'primeng/checkbox';
import {DialogModule} from 'primeng/dialog';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import { ConfirmDialogModule } from 'primeng/confirmdialog';



@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    FormatManagementRoutingModule,
    TranslateModule,
    TableModule,
    ButtonModule,
    TooltipModule,
    DragDropModule,
    DropdownModule,
    CheckboxModule,
    DialogModule,
    MessagesModule,
    MessageModule,
    OverlayPanelModule,
    ConfirmDialogModule
  ],

  declarations: [FormatManagementComponent],

})

export class FormatManagementModule { }
