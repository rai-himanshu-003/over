export class FormatManagementParameters{

    id: number | string;
    flow: string;
    flowId:number | string;
    fileFormatId: number | string;
    flowVhlMetadataDTOs:Array<VehMetadataDTO>;
    collectionDTOs:Array<GenericCollectionDTO>;
    ovComponentDTOs:Array<OvCompDTO>;
    

}

export class VehMetadataDTO{

    id:number;
    flowId:number | string;
    seq:number;
    value:number | string;
    filter:string;
    separator:string;
    
}

export class GenericCollectionDTO{

    id:number;
    flowId:number | string;
    seq:number;
    value:number | string;
    filter:string;
    separator:string;
    intSeparator:string;
    alignment:number;
    maxOcc:number;
}

export class OvCompDTO{

    id:number;
    flowId:number | string;
    seq:number;
    value:number | string;
    filter:string;
    separator:string;
    intSeparator:string;
    alignment:number;
    maxOcc:number;

    ovComponentPartDTOs:Array<ovComponentPartDTO>;
}

export class ovComponentPartDTO{
    id:number;
    ovCompId:number | string;
    standard:number | string;
    value:number | string;
    filter:string;
    intSeq:number | string;
}

export class ovCompCheck{
    stdValue:string;
    std:number;

    partValue:string;
    part:number;

    getStdValue():string {
        return this.stdValue;
    }

    setStdValue(stdValue:string) {
        this.stdValue = stdValue;
    }


    getStd() {
        return this.std;
    }

    setStd(std) {
        this.std = std;
    }

    getPartValue() {
        return this.partValue;
    }

    setPartValue(partValue) {
        this.partValue = partValue;
    }

    getPart() {
        return this.part;
    }

    setPart(part) {
        this.part = part;
    }

    

}

export class IExportData{
    vinList:string;
    flowName:string;
    flowFormatDetails:string;
}