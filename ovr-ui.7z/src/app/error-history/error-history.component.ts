import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import {formatDate} from '@angular/common';
import { MessageService } from 'primeng/api';

import { TranslateService } from '@ngx-translate/core';
import { VehicleDetailsService } from '../service/vehicle-details.service';
import { GetSelectedVinService } from '../service/getVin.service';
import{OVR_PRD} from '../constant/auth-constant';
import { ExportToCSV } from '../service/exportToCSV.service';

import { ListOfFlows } from '../models/list-of-flows';

import * as lodash from 'lodash';
import { Table } from 'primeng/table';
import { DateFormatterService } from '../shared/services/dateFormater.service';
import { IErrorhParameters } from '../error-management/error-management';

@Component({
  selector: 'app-error-history',
  templateUrl: './error-history.component.html',
  styleUrls: ['./error-history.component.scss'],
  providers: [VehicleDetailsService,ExportToCSV,ListOfFlows,DateFormatterService],
  encapsulation: ViewEncapsulation.None
})
export class ErrorHistoryComponent implements OnInit {

  @ViewChild('dt', { static: false }) table: Table;

  // variables to store the data
  errorHistoryRecords:any[]=[];
  updatedRecords:any[]=[];
  errorMessage: string;
  cols: any[];
  vinForHistory:string;
  vinForErrorHistory:string;

  // pagination variables
  first: number = 0;
  page: number;
  rows: number;
  size: number;

  // export To CSV variables
  prdName:string;
  exportFile:string;
  today = new Date();
  fileTimeStamp='';
  browserLang:string;
  langSelector:string;
  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];

  // Date filter Variables
  showDateContainer:boolean;
  fdate:Date;
  tdate:Date;

  // Flow filter
  listOfFlowForFilter: any[] = [];

  constructor(
    private vehicledetailsservice:VehicleDetailsService,
    private exportToCSV:ExportToCSV,
    private listofflows:ListOfFlows,
    private dateFormatterService: DateFormatterService
  ) { }

  ngOnInit() {
    // Initialize required variables 
    this.rows = 10;
    this.prdName = OVR_PRD;
    this.exportFile = "ErrorHistory";
    //this.vinForHistory = this.getSelectedVinService.getSelectedVinNumber();

    //this.getRecordsFromDB();

    this.storeVin();

    // Headers declared with field names for table
    this.cols = [
      { field: 'vin', header: 'VIN' },
      { field: 'flowName', header: 'FLOW NAME' },
      { field: 'errCode', header: 'CODE' },
      { field: 'errComplement', header: 'COMPLEMENT' },
      { field: 'errDesc', header: 'DESCRIPTION' },
      { field: 'errMessage', header: 'MESSAGE' },
      { field: 'dateCreation', header: 'DATE CREATION' },
      { field: 'userCreation', header: 'USER CREATION' },
      
    ];

    // Header list for export to csv

    for(let i in this.cols){
      this.headerList.push(this.cols[i].header);

    }

    // Field list for export to csv

    for(let j in this.cols){
      this.fieldList.push(this.cols[j].field);

    }

    this.listofflows.listOfFlow.forEach( element => {
      
      this.listOfFlowForFilter.push(element);
    });
  }

  storeVin() {
    
    // Set the value of Vin number in variable
    this.vinForErrorHistory = window.localStorage.getItem("vinSearch");

    // If value is not null or undefined then call get data
    if(this.vinForErrorHistory !=null && this.vinForErrorHistory != undefined){
      window.localStorage.setItem("vinForErrorHistory",this.vinForErrorHistory);
      this.getRecordsFromDB();
    }
    
  }

  // This method will fetch the records from DB
  getRecordsFromDB() {

    let vinNumber:string =  window.localStorage.getItem("vinForErrorHistory");

    if(vinNumber !=null && vinNumber != undefined){
      //console.log("vin"+ vinNumber);
      this.vinForHistory = vinNumber;
      //console.log(this.vinForHistory);
    }

    else{
      console.log("no Vin found");
    }

    this.vehicledetailsservice.getRecords(this.vinForHistory).subscribe(
      (data: any) => {
        this.errorHistoryRecords = data.errorHistory;
        
        this.updatedRecords = lodash.cloneDeep(this.errorHistoryRecords);
        

        this.errorHistoryRecords.map(element => {
          element.dateCreation = new Date(element.dateCreation as number);
        });
      },
      (error: any) => this.errorMessage = <any>error
    );
  }

  showDateFilter(event, field: string) {

    if (field == 'dateCreation') {
      this.showDateContainer = true;
    }

    else if (field == 'vin' || field == 'errCode' || field == 'errComplement' || field == 'errDesc' || field == 'errMessage'  || field == 'userCreation' || field == 'flowName') {
      this.showDateContainer = false;
    }
  }

  filterDate() {

    let fromDate:number;
    let toDate:number;
    let filteredRecord:IErrorhParameters[];


    fromDate = this.dateFormatterService.nullCheckFromDate(this.fdate,fromDate);
    toDate = this.dateFormatterService.nullCheckToDate(this.tdate,toDate);
          

    filteredRecord = this.updatedRecords.filter(function(record){
      return record.dateCreation > fromDate && record.dateCreation < toDate

    })

    // This will display date in filter box    

    let fromDateString:string;
    let toDateString:string;

    this.dateFormatterService.showDateRange(fromDate,toDate,"dateCreation",this.cols);
    this.errorHistoryRecords = filteredRecord

  }

  resetDate(){

    this.fdate = null;
    this.tdate = null;

    this.filterDate();
  }


  // Export to CSV
  exportCSVForAll(){

    // This will add time stamp in the filename while exporting the file    
    // this.fileTimeStamp = this.formatDateForExport(); 

    this.fileTimeStamp = this.dateFormatterService.formatDateForExport(); 
  
    // This will give file Name for exported file
    // let filename = `${this.prdName}${this.exportFile}${this.fileTimeStamp}`;
    let filename = `${this.prdName}_${this.vinForHistory}_${this.exportFile}${this.fileTimeStamp}`;


    if(this.table.filteredValue == undefined){
      this.exportedRecords = lodash.cloneDeep(this.table.value);
      //this.exportedRecords = this.table.value;
      
    }
    else{
      this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
      //this.exportedRecords = this.table.filteredValue;
    }
    this.exportedRecords.forEach(record =>{

      record.dateCreation = new Date(record.dateCreation as number);

      
 
      if(record.dateCreation != null){
        record.dateCreation = this.exportToCSV.csvDateFormat(record.dateCreation);
      }
      else{
        record.dateCreation = " ";
      }
      if(record.errCode == null){
        record.errCode = " ";
      }

      if(record.errComplement == null){
        record.errComplement = " ";
      }

      if(record.errDesc == null){
        record.errDesc = " ";
      }

      if(record.errMessage == null){
        record.errMessage = " ";
      }

      if(record.userCreation == null){
        record.userCreation = " ";
      }

      
    })
    this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);
  }
}
