import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ErrorHistoryComponent } from './error-history.component';
import { ErrorHistoryRoutingModule } from './error-history-routing.module';

import { TranslateModule } from '@ngx-translate/core';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import {TooltipModule} from 'primeng/tooltip';



@NgModule({

  imports: [
    CommonModule,
    ErrorHistoryRoutingModule,
    TranslateModule,
    TableModule,
    ButtonModule,
    TooltipModule
  ],

  declarations: [ErrorHistoryComponent],

})

export class ErrorHistoryModule { }
