import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CommonTableComponent } from './common-table.component';

import {TableModule} from 'primeng/table';

@NgModule({

    imports: [
      CommonModule,
      TableModule

    ],
    exports: [CommonTableComponent],
  
    declarations: [CommonTableComponent],
  
  })


export class CommonTableModule { }