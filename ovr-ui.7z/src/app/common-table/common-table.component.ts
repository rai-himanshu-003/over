import { Component, OnInit, Input } from '@angular/core';

import { GetSelectedVinService } from '../service/getVin.service';
import { ComposantOVService } from '../service/composant-ov.service';
import { KeyOVService } from '../service/keys-ov.service';


@Component({
  selector: 'app-common-table',
  templateUrl: './common-table.component.html',
  styleUrls: ['./common-table.component.scss']
})
export class CommonTableComponent implements OnInit {

  vinForHistory: string;
  errorMessage: string;

  //cols: any[];
  //tableRecords:any[] = [];
  composantOVCols:any[] = [];
  keyOVCols:any[] = [];
  composantOVRecords:any[] = [];
  keyOVRecords:any[] = [];

  @Input() coloumns:any[];
  @Input() records:any[];

  constructor(
    private composantOVService:ComposantOVService,
    private keyOVService:KeyOVService,
    private getSelectedVinService:GetSelectedVinService
  ) { }

  ngOnInit() {

    this.vinForHistory = this.getSelectedVinService.getSelectedVinNumber();
    this.getRecordsFromDBComposantOV();

    // Headers declared with field names for table
    

  }

  // This method will fetch the records from DB
  getRecordsFromDBComposantOV(){

    this.composantOVService.getRecords(this.vinForHistory).subscribe(
      //(data:any) => console.log(data),
      (data:any) => {
        this.composantOVRecords = data.datalist;
        console.log(this.composantOVRecords);
      },
      (error:any) => this.errorMessage = <any> error

    )

  }



}
