import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowStateManagementComponent } from './flowState-management.component';

describe('FlowStateManagementModule', () => {
  let component: FlowStateManagementComponent;
  let fixture: ComponentFixture<FlowStateManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlowStateManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlowStateManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
