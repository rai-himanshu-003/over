import { Dropdown } from "primeng/dropdown";

export interface IInterfaceStatus{
   id:number,
    interfaceName:string,
    status:string,
    newStatus:string,
    userModif:string,
    statusList:string,
    remark:string,
    dateModif:Date | number,
    version:number
    dropDownOptions:{label:string,value:string}[],
}