import { FlowStateManagementModule } from './flowState-management.module';

describe('FlowStateManagementModule', () => {
  let flowStateManagementModule: FlowStateManagementModule;

  beforeEach(() => {
    flowStateManagementModule = new FlowStateManagementModule();
  });

  it('should create an instance', () => {
    expect(flowStateManagementModule).toBeTruthy();
  });
});
