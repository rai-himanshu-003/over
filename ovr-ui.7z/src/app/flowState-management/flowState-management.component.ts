import { Component, OnInit, ViewEncapsulation, ViewChild, Input } from '@angular/core';

import { IInterfaceStatus } from './flowState-management';
import { InterfaceStatusService } from '../service/flowState-management.service';
import * as lodash from 'lodash';

import { Message, LazyLoadEvent, ConfirmationService } from 'primeng/components/common/api';
import { MessageService } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import { Table } from 'primeng/table';
import { FilterUtils } from "primeng/api";

import { Router } from '@angular/router';
import { GetSelectedInterfaceService } from '../service/getInterfaceName.service';
import{OVR_PRD} from '../constant/auth-constant';
import { AuthenticationService } from '../service/authentication.service';
import { ExportToCSV } from '../service/exportToCSV.service';
import { DateFormatterService } from '../shared/services/dateFormater.service';

@Component({
  selector: 'app-flowState-management',
  templateUrl: './flowState-management.component.html',
  styleUrls: ['./flowState-management.component.scss'],
  providers: [InterfaceStatusService, MessageService,ConfirmationService,ExportToCSV,DateFormatterService],
  encapsulation: ViewEncapsulation.None,
})

export class FlowStateManagementComponent implements OnInit {

  interfaceSttausRecords: IInterfaceStatus[] = [];
  updatedRecords: IInterfaceStatus[] = [];
  postData: IInterfaceStatus[] = [];
  versionNumber:number;
  errorMessage: string;
  sucssessMessage: string;
  tableHeader: string;
  myJsonString: any;
  cols: any[];
  colsCsv: any[];
  
  mySubscription: any;
  tempdata:string[];

  // pagination variables
  first: number = 0;
  page: number;
  rows: number;
  size: number;
  vinForHistory:string;

  // lazy loading variables
  loading: boolean;

  // export To CSV variables
  prdName:string
  exportFile:string;
  today = new Date();
  fileTimeStamp='';
  browserLang:string;
  langSelector:string;
  @Input() exportable: boolean = true;

  exportedRecords:any[];
  headerList:string[] = [];
  fieldList:string[] = [];
  
  // Edit records variables
  editedTechRecords:IInterfaceStatus[];  
  clonedTechRecords: { [s: string]: IInterfaceStatus; } = {};
  @ViewChild('dt', { read:Table, static: false }) table: Table
  
  // Date filter Variables
  showDateContainer:boolean;
  fdate:Date;
  tdate:Date;
 
  msgs: Message[] = [];

  // variable for Admin access 
  isAdmin: boolean;

  constructor(private interfaceStatusService: InterfaceStatusService,
    private _authService: AuthenticationService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private getSelectedInterfaceService:GetSelectedInterfaceService,
    public router: Router,
    private exportToCSV:ExportToCSV,
    private dateFormatterService:DateFormatterService
  ) {}

  dateFilters: any;

    ngOnInit() {
      var _self = this;

      this.isAdmin =this._authService.isAdmin();
      
      // Initialize required variables 
      this.rows = 10;
      this.prdName=OVR_PRD;
    
      this.exportFile = "_InterfaceStatus";
      this.langSelector=",";
      this.getSelectedInterfaceService.setSelectedInterafce(null);
      this.getRecordsFromDB();  
      //const user: any = LocalStorage.readValue(LOCAL_STORAGE_USER_NAME);
      
      // Headers declared with field names for table
      this.cols = [
        { field: 'interfaceName', header: 'Interface',  },
        { field: 'dateModif', header: 'Modified on' },
        { field: 'userModif', header: 'Modified by' },
        { field: 'status', header: 'Current Status' },
        { field: 'newStatus', header: 'New Status' ,exportable:false},
        { field: 'remark', header: 'Remarks' },
        { field: 'action', header: 'Action',exportable:false }
      ];

      this.colsCsv = [
        { field: 'interfaceName', header: 'Interface' },
        { field: 'dateModif', header: 'Modified on' },
        { field: 'userModif', header: 'Modified by ' },
        { field: 'status', header: 'Current Status' },
        { field: 'remark', header: 'Remarks' }
        
      ];

      // Header list for export to csv

      for(let i in this.colsCsv){
          this.headerList.push(this.colsCsv[i].header);
      }

      // Field list for export to csv

      for(let j in this.colsCsv){
        this.fieldList.push(this.colsCsv[j].field);

      }

      this.loading = true;
        
    }

    // This method will reset the records in HTML page on click of Cancel button
    resetRecord(event: any) {
      this.confirmIgnore();  
    }

    confirmIgnore() {
      console.log("inn finc");
      this.confirmationService.confirm({    
        message: 'This action will reset all changes. Do you confirm this action ?', 
        header: null,
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          
          this.getRecordsFromDB();
        },
        reject: () => {
        
        }
      });
    }

    enableFields(rowdata:IInterfaceStatus,index:number){
      this.onRowEditInit(rowdata,index);
    }


    // This method will work for pagination
    paginate(event: any) {
      
      
    }

    // This method activate lazyloading for pagination
    loadParmsLazy(event: LazyLoadEvent){
      this.loading = true;
    }


    // This method will fetch the records from DB
    getRecordsFromDB() {
      this.interfaceStatusService.getRecords().subscribe(
        (data: IInterfaceStatus[]) => {
          
          data=data.map((element)=>{
            
            let constant= element.statusList.split(",");
            
            //element.status
            let tempArr=[];
            constant.map(element1 =>{
            if(element.status.toUpperCase()!=element1){
            tempArr.push({label:element1,value:element1})  ;
            }
          //Object.assign(element, {dropDownOptions :{label:element1,value:element1}})
            // return element1;
            })
            Object.assign(element, {dropDownOptions :tempArr})

            element.dateModif =  new Date(element.dateModif as number);
            return element;  
        })
        console.log(data);
          this.interfaceSttausRecords = data;
        
        for (let index = 0; index < this.interfaceSttausRecords.length; index++) {
      
        this.tempdata= this.interfaceSttausRecords[index].statusList.split(",");
  
        }
        
          console.log(this.tempdata)
        
          this.updatedRecords = lodash.cloneDeep(this.interfaceSttausRecords);
        },
        (error: any) => this.errorMessage = <any>error
      );
    }

  //============================= Edit Start========================//
    onRowEditInit(interfaceStatus: IInterfaceStatus,index:number) {
      // console.log(interfaceStatus);
      // console.log(this.clonedTechRecords[interfaceStatus.interfaceName]);
      this.clonedTechRecords[interfaceStatus.interfaceName] = {...interfaceStatus};
      // console.log(this.clonedTechRecords);
    }

    onRowEditSave(interfaceStatus: IInterfaceStatus) {
      
      this.clonedTechRecords[interfaceStatus.interfaceName] = {...interfaceStatus};
    }

  //============================= Edit Ends========================//

  //========================== Date Filter Start======================//

    showDateFilter(event, field: string) {

      if (field == 'dateModif') {
        this.showDateContainer = true;
      }

      else if (field == 'interfaceName' || field == 'userModif' || field == 'status' || field == 'newStatus' || field == 'remark' ) {
        this.showDateContainer = false;
      }
    }

    filterDate() {
      //console.log("Date Filter");

      let fromDate:number;
      let toDate:number;
      let filteredRecord:IInterfaceStatus[];

      // if(this.fdate == undefined || this.fdate == null){
      //   //this.fdate = new Date ("01/01/1900");
      //   fromDate = new Date ("01/01/1900").getTime();
      //   console.log(this.fdate);
      // }

      // else{
      //   fromDate = this.fdate.getTime();
      // }

      fromDate = this.dateFormatterService.nullCheckFromDate(this.fdate,fromDate);

      // if(this.tdate == undefined || this.tdate == null){
      //   //this.tdate = new Date (" 01/01/9999");
      //   toDate = new Date ("01/01/9999").setHours(23,59,59);
      //   console.log(this.tdate);
      // }

      // else{
      //   toDate = this.tdate.setHours(23,59,59);
      // }
            
      toDate = this.dateFormatterService.nullCheckToDate(this.tdate,toDate);

      filteredRecord = this.updatedRecords.filter(function(record){
        return record.dateModif > fromDate && record.dateModif < toDate

      })

      // This will display date in filter box    

      let fromDateString:string;
      let toDateString:string;

      this.dateFormatterService.showDateRange(fromDate,toDate,"dateModif",this.cols);

      // if(this.formatDateForDataBase(fromDate) == "01/01/1900" && this.formatDateForDataBase(toDate) == "01/01/9999" ){
      //   fromDateString = "";
      //   toDateString = "";
      //   this.cols.forEach(col=>{
      //     if(col.field == 'dateModif'){
      //       col.value = "";
      //     }

      //   })
      // }
      
      // else{

      //   if(this.formatDateForDataBase(fromDate) == "01/01/1900" ){
      //     fromDateString = "*";
      //   }
      //   else{
      //     fromDateString =this.formatDateForDataBase(fromDate);
      //   }

      //   if(this.formatDateForDataBase(toDate) == "01/01/9999"){
      //     toDateString = "*";
      //   }
      //   else{
      //     toDateString = this.formatDateForDataBase(toDate);
      //   }

      //   this.cols.forEach(col=>{
      //     if(col.field == 'dateModif'){
      //       col.value = fromDateString+ " -" + toDateString;
      //     }

      //   })

      // }

  
      this.interfaceSttausRecords = filteredRecord

    }

    resetDate(){
      this.fdate = null;
      this.tdate = null;

      this.filterDate();
    }

  //========================== Date Filter Ends======================//

  //============================= Validate Start=======================//

    validateFunc(interfaceStatus: IInterfaceStatus){
      return interfaceStatus.newStatus!=null? false:true;
    }

    // This will call on Validate button
    validateRecord(event: Event,rowdata:IInterfaceStatus) {
      // console.log(rowdata);
      if( rowdata.remark!=null && rowdata.remark!=""){
          rowdata.status= rowdata.newStatus;
        // This method will update the records in DB on click of validate button
        this.interfaceStatusService.updateRecords(rowdata).subscribe(

          (data: any) => this.proccessTechResponse(data),

          (error: any) => console.log(error)
        )
        
      }
      else{
        this.showWarn();
      }
    
    }

  //============================= Validate Ends========================//


  //============================== Export Start=========================//
    exportCSVForIS(){

      
      // This will add time stamp in the filename while exporting the file    
      // this.fileTimeStamp = this.formatDateForExport();

      this.fileTimeStamp = this.exportToCSV.formatDateForExport();

      

      if(this.table.filteredValue == undefined){
        this.exportedRecords = lodash.cloneDeep(this.table.value);
        //this.exportedRecords = this.table.value;
        
      }

      else{
        this.exportedRecords = lodash.cloneDeep(this.table.filteredValue);
        //this.exportedRecords = this.table.filteredValue;
      }

      this.exportedRecords.forEach(record =>{

        delete record.id;
        delete record.statusList;
        delete record.version;
        delete record.action;

        console.log(record);

        if(record.dateModif != null){
          record.dateModif = this.exportToCSV.csvDateFormat(record.dateModif);
          console.log(record.dateModif);
        }
        else{
          record.dateModif = " ";
        }


        if(record.interfaceName == null){
          record.interfaceName = " ";
        }

        if(record.userModif == null){
          record.userModif = " ";
        }

        if(record.status == null){
          record.status = " ";
        }

        if(record.newStatus == null){
          record.newStatus = " ";
        }

        if(record.remark == null){
          record.remark = " ";
        }

        
      })

      // This will give file Name for exported file
      let filename = `${this.prdName}${this.exportFile}${this.fileTimeStamp}`;

      this.exportToCSV.downloadFile(this.exportedRecords,this.fieldList,this.headerList, filename);
    }
  //============================== Export Ends=========================//

    //This method will show the updated record message
    showInfo() {
      this.messageService.add({ severity: 'info', summary: 'Info Message', detail: `${this.sucssessMessage}` });
    }

    showWarn() {
      //this.msgs = [];
      //this.msgs.push({ severity: 'warn', summary: 'Warn Message', detail: 'Please enter the remarks.' });
      this.messageService.add({severity: 'warn', summary: 'Warn Message', detail: 'Please enter the remarks.'});
    }
  
    // This method will show the message after successful data save
    proccessTechResponse(data: any) {
      //console.log(data);
      let successCount: number = 0;
      let errCount: number = 0;
  
      let successFiled: string = "";
      let errFiled: string = "";
  
      data.responseList.forEach(element => {
  
        if (element.msg == true) {
          successCount =  1;
          successFiled = `${successFiled} ${element.id} `;
        }
        else if (element.msg == false) {
          errCount =  1;
          errFiled = `${errFiled} ${element.id}`
        }
        this.onRowEditSave(data);
      });
  
      if (successCount > 0) {
      
        this.messageService.add({
          severity: 'success', summary: "Success",
          detail: `Status  updated  successfully of 
           ${successFiled}`
        })
      }
  
      else if (errCount > 0) {
        this.messageService.add({
          severity: 'error', summary: "Error Message",
          detail: ` Failed to update status of 
           ${errFiled}`
        })
      }
  
      this.getRecordsFromDB();
    }

    goToPage(event,interfaceName){

      this.getSelectedInterfaceService.setSelectedInterafce(interfaceName);
    
      if(interfaceName){
        this.router.navigate(['/interface-audit']);
      }
      
    }
  
}
