import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';

import {TranslateModule} from '@ngx-translate/core';


import {TooltipModule} from 'primeng/tooltip';

import {DialogModule} from 'primeng/dialog';



import { FlowStateManagementRoutingModule } from './flowState-management-routing.module';
import { FlowStateManagementComponent } from './flowState-management.component';
import {ConfirmDialogModule} from 'primeng/confirmdialog';

import {DropdownModule} from 'primeng/dropdown';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import { MultiSelectModule } from 'primeng/multiselect';
import { CalendarModule } from 'primeng/calendar';

import {ToastModule} from 'primeng/toast';



@NgModule({
  imports: [
    CommonModule,
    FlowStateManagementRoutingModule,
    TableModule,
    ButtonModule,
    FormsModule,
    TranslateModule,
    DialogModule,
    TooltipModule,
    DropdownModule,
    MessageModule,
    MessagesModule,
    CalendarModule,
    MultiSelectModule,
    ConfirmDialogModule,
    ToastModule
    
  ],
  declarations: [
    FlowStateManagementComponent
  ]
})
export class FlowStateManagementModule { }
