
  export const environment = {
    production: false,
    ovrMicroServiceApiUrl: 'http://over.preprod.inetpsa.com/ovrmicroservice',
    name: 'preprod'
  };


  