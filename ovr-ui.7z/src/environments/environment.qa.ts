export const environment = {
    production: false,
    ovrMicroServiceApiUrl: 'http://over.dev.inetpsa.com:9090/ovrmicroservice/',
    name: 'qa'
  };