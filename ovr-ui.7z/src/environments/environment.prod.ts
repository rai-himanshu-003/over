
export const environment = {
  production: true,
  ovrMicroServiceApiUrl: 'http://over.dev.inetpsa.com:9090/ovrmicroservice/',
  name: 'prod'
};
