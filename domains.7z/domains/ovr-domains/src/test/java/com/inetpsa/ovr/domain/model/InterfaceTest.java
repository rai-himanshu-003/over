/*
 * Creation : 19 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.ArrayList;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

@RunWith(SeedITRunner.class)
public class InterfaceTest {

    Interface interfaceObj;

    @Test
    public void setterGetterTesting() {
        interfaceObj = new Interface();

        interfaceObj.setId(1l);
        interfaceObj.setInterfaceName("GEPICS");
        interfaceObj.setInterfaceRules(new ArrayList<>());
        Assertions.assertThat(interfaceObj.getInterfaceName()).isEqualToIgnoringCase("GEPICS");
        Assertions.assertThat(interfaceObj.getId()).isEqualTo(1l);
        Assertions.assertThat(interfaceObj.toString()).isNotNull();
        Assertions.assertThat(interfaceObj.getInterfaceRules()).isNotNull();

    }
}
