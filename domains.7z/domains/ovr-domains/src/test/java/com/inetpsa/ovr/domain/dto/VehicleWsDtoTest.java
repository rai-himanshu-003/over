/*
 * Creation : 22 Sep 2020
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.ws.VehicleWsDto;

public class VehicleWsDtoTest {
    @Test
    public void VehicleDTOTestFun() {

        VehicleWsDto vehicleDetailsDto = new VehicleWsDto();
        vehicleDetailsDto.setProdCenter("cc");
        vehicleDetailsDto.setLcdvOttData("abc");
        vehicleDetailsDto.setVehicle("abc");
        vehicleDetailsDto.setApvprData("apvpr");
        vehicleDetailsDto.setModelData("Model");
        vehicleDetailsDto.setNreData("NRE");
        vehicleDetailsDto.setOaData("OA");
        vehicleDetailsDto.setProdCenter("PC");
        vehicleDetailsDto.setState("IGNR");
        vehicleDetailsDto.setTvvData("TVV");
        vehicleDetailsDto.setVinNumber("ABC");
        vehicleDetailsDto.setXmlData("xml");

        Assertions.assertThat(vehicleDetailsDto.getProdCenter()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getLcdvOttData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getVehicle()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getApvprData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getModelData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getNreData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getOaData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getProdCenter()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getState()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getTvvData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getVinNumber()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getXmlData()).isNotNull();

    }
}
