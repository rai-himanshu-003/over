/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.VehicleDTO;

public class VehicleDTOTest {

    @Test
    public void VehicleDTOTestFun() {

        VehicleDTO vehicleDetailsDto = new VehicleDTO();
        vehicleDetailsDto.setCcp("cc");
        vehicleDetailsDto.setLcdvOtt("abc");
        vehicleDetailsDto.setVeh("abc");
        vehicleDetailsDto.setVersion(0);
        vehicleDetailsDto.setVinNo("test");
        vehicleDetailsDto.setXmlOv("abc");
        vehicleDetailsDto.setApvpr("TEST");
        vehicleDetailsDto.setOa("OA");
        vehicleDetailsDto.setOf("OF");
        vehicleDetailsDto.setNre("NRE");

        vehicleDetailsDto.setTvv("tvv");
        vehicleDetailsDto.setUp("up");
        vehicleDetailsDto.setLcdv24("lcdv24");
        vehicleDetailsDto.setModel("model");
        vehicleDetailsDto.setModelYear("2020");
        vehicleDetailsDto.setDateEcom(new Date());
        vehicleDetailsDto.setDateEmon(new Date());
        vehicleDetailsDto.setDateExtension(new Date());

        vehicleDetailsDto.setComposants(null);
        vehicleDetailsDto.setComposantsOv(null);
        vehicleDetailsDto.setIsIgnored(null);
        vehicleDetailsDto.setKeysOv(null);
        vehicleDetailsDto.setLcdvOtt(null);
        vehicleDetailsDto.setLcdvOttOv(null);
        vehicleDetailsDto.setOptions(null);
        vehicleDetailsDto.setReferencesElectroniques(null);

        Assertions.assertThat(vehicleDetailsDto.getComposants()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getComposantsOv()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getIsIgnored()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getKeysOv()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getLcdvOtt()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getLcdvOttOv()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getOptions()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getReferencesElectroniques()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getDateEcom()).isNotNull();

        Assertions.assertThat(vehicleDetailsDto.getDateEmon()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getDateExtension()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getTvv()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getUp()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getLcdv24()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getModel()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getModelYear()).isNotNull();

        Assertions.assertThat(vehicleDetailsDto.getVinNo()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getCurrentState()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getXmlOv()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getUserCreation()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getUserModif()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getDateModif()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getDateModif()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getVeh()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getVersion()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.toString()).isNotNull();
       

        Assertions.assertThat(vehicleDetailsDto.getOa()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getOf()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getNre()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getApvpr()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getCcp()).isEqualTo("cc");
        Assertions.assertThat(vehicleDetailsDto.getDateCreation()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getLcdvOtt()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getUserCreation()).isNull();
        Assertions.assertThat(vehicleDetailsDto.getVeh()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getVersion()).isEqualTo(0);
        Assertions.assertThat(vehicleDetailsDto.getVinNo()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getXmlOv()).isEqualTo("abc");

    }

}
