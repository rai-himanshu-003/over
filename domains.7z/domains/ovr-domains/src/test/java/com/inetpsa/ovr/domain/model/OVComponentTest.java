/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.HashSet;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;

public class OVComponentTest {

    @Test
    public void OvComposantTest() {

        OVComponent ovComponent = new OVComponent();
        OVComponent ovComponent1 = new OVComponent();

        Set<OVComponentPartDTO> componentPartDTOs = new HashSet<>();
        ovComponent.setId(1L);
        ovComponent.setFlowId(1l);
        ovComponent.setSeq(1l);
        ovComponent.setSeparator(",");
        ovComponent.setIntSeparator(";");
        ovComponent.setMaxOcc(1l);
        ovComponent.setAlignment(5l);
        ovComponent.setValue(4l);
        ovComponent.setFilter("test");

        ovComponent1.setId(1L);
        ovComponent1.setFlowId(1l);
        ovComponent1.setSeq(1l);
        ovComponent1.setSeparator(",");
        ovComponent1.setIntSeparator(";");
        ovComponent1.setMaxOcc(1l);
        ovComponent1.setAlignment(5l);
        ovComponent1.setValue(41l);
        ovComponent1.setFilter("test");

        Assertions.assertThat(ovComponent).isNotNull();
        Assertions.assertThat(ovComponent.getId()).isNotNull();
        Assertions.assertThat(ovComponent.getFlowId()).isNotNull();
        Assertions.assertThat(ovComponent.getValue()).isNotNull();
        Assertions.assertThat(ovComponent.getAlignment()).isNotNull();
        Assertions.assertThat(ovComponent.getSeq()).isNotNull();
        Assertions.assertThat(ovComponent.getSeparator()).isNotNull();
        Assertions.assertThat(ovComponent.getIntSeparator()).isNotNull();
        Assertions.assertThat(ovComponent.getFilter()).isNotNull();
        Assertions.assertThat(ovComponent.getMaxOcc()).isNotNull();
        componentPartDTOs.add(new OVComponentPartDTO());
        Assertions.assertThat(ovComponent.maptoDto()).isNotNull();
        Assertions.assertThat(ovComponent.hashCode()).isNotNull();
        Assertions.assertThat(ovComponent.toString()).isNotNull();
        Assertions.assertThat(ovComponent.equals(ovComponent1)).isNotNull();

    }

}
