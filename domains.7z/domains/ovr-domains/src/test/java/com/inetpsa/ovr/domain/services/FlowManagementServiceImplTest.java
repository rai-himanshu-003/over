package com.inetpsa.ovr.domain.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;

/*
 * Creation : 24 Jul 2019
 */
@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class FlowManagementServiceImplTest {

    @Inject
    FlowManagementDetailsService flowManagementDetailsService;

    @Inject
    private VehicleRepository vehicleRepository;

    OutputFlowDetails opflow = new OutputFlowDetails();
    List<OutputFlowDetails> details = new ArrayList<>();
    OutputFlowDetailsDTO outputFlowDetailsDTO;

    Vehicle vehicle = new Vehicle();

    @Before
    public void setData() {
        outputFlowDetailsDTO = new OutputFlowDetailsDTO();
        // outputFlowDetailsDTO.setId((long) 1);
        outputFlowDetailsDTO.setAction((long) 1);
        outputFlowDetailsDTO.setDescription("test");
        outputFlowDetailsDTO.setFrequency("test");
        outputFlowDetailsDTO.setFolderLocation("test");
        outputFlowDetailsDTO.setFlow("SAGAI");
        outputFlowDetailsDTO.setFileFormatId(1l);
        outputFlowDetailsDTO.setFileName("test");
        outputFlowDetailsDTO.setLastRun(LocalDateTime.MAX);
        outputFlowDetailsDTO.setVersion(1);
    }

    @Test
    public void outputFlowDetailsValidatorTestAllPositive() {
        Assertions.assertThat(flowManagementDetailsService.addOrUpdateflowDetails(outputFlowDetailsDTO)).isNotNull();
        Assertions.assertThat(flowManagementDetailsService.getflowDetails()).isNotNull();
        Assertions.assertThat(flowManagementDetailsService.getFlowDetailsByName("SAGAI")).isNotNull();
        outputFlowDetailsDTO.setId(1l);
        Assertions.assertThat(flowManagementDetailsService.addOrUpdateflowDetails(outputFlowDetailsDTO)).isNotNull();
        outputFlowDetailsDTO.setVersion(0);
        Assertions.assertThat(flowManagementDetailsService.addOrUpdateflowDetails(outputFlowDetailsDTO)).isNotNull();

        Assertions.assertThat(flowManagementDetailsService.getFlowDetailsByName("SAGAI")).isNotNull();

        Assertions.assertThat(flowManagementDetailsService.deleteflowDetails(1l)).isNotNull();
        Assertions.assertThat(flowManagementDetailsService.deleteflowDetails(2l)).isNotNull();
        outputFlowDetailsDTO.setId(2l);
        Assertions.assertThat(flowManagementDetailsService.addOrUpdateflowDetails(outputFlowDetailsDTO)).isNotNull();

    }

}
