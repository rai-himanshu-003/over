/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository;
import com.inetpsa.ovr.interfaces.dto.OvPsaMappingDTO;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class PsaKeyMappingServiceTest {

    @Inject
    PsaKeyMappingService psaKeyMappingService;

    @Inject
    private PsaKeyMappingRepository mappingRepository;

    PsaKeyMapping psaKeyMapping = null;
    OvPsaMappingDTO OvPsaMappingDTO = null;

    @Before
    public void setUpData() {
        psaKeyMapping = new PsaKeyMapping();
        psaKeyMapping.setDescription("Test");
        psaKeyMapping.setOvKey("test");
        psaKeyMapping.setOvStandard("test");
        psaKeyMapping.setPsaDatatype("test");
        psaKeyMapping.setPsaKey("20");
        psaKeyMapping.setVersion(1);

        OvPsaMappingDTO = new OvPsaMappingDTO();

        OvPsaMappingDTO.setOvKey("test");
        OvPsaMappingDTO.setOvStandard("test");
        OvPsaMappingDTO.setPsaType("test");
        OvPsaMappingDTO.setPsaKey("20");
        OvPsaMappingDTO.setVersion(1);

    }

    @Test
    public void addMapping() {
        ResponseDto responseDto = psaKeyMappingService.addOrUpdateMapping(OvPsaMappingDTO);
        Assertions.assertThat(responseDto).isNotNull();
    }

    @Test
    public void getPsaKeyMapping() {

        List<OvPsaMappingDTO> dtos = psaKeyMappingService.getMappingList();
        Assertions.assertThat(dtos).isNotNull();

        mappingRepository.findOvMapping("OTHER", "TEST");

        mappingRepository.findUniqueMapping("PSA_ORGAN", "10", "oOTHER", "TEST");

    }

    @Test
    public void getPsaKeyMapping1() {

        List<PsaKeyMapping> dtos = psaKeyMappingService.getPsaKeyByOvKey("1");
        Assertions.assertThat(dtos).isNotNull();

    }

    @Test
    public void getPsaKeyMapping2() {

        Optional<PsaKeyMapping> dtos = psaKeyMappingService.getPsaKeyMapping(1l);
        Assertions.assertThat(dtos).isNotNull();

    }

    @Test
    public void addOrUpdateMapping() {
        OvPsaMappingDTO.setId(2l);
        ResponseDto responseDto = psaKeyMappingService.addOrUpdateMapping(OvPsaMappingDTO);
        Assertions.assertThat(responseDto).isNotNull();
    }

    /**
     * Adds the or update M apping.
     */
    @Test
    public void addOrUpdateMApping() {
        OvPsaMappingDTO.setId(2l);
        OvPsaMappingDTO.setVersion(2);
        ResponseDto responseDto = psaKeyMappingService.addOrUpdateMapping(OvPsaMappingDTO);
        Assertions.assertThat(responseDto).isNotNull();
    }

    @Test
    public void deleteMapping() {
        mappingRepository.add(psaKeyMapping);
        psaKeyMappingService.deleteMapping(new Long(1));
        Assertions.assertThat(psaKeyMapping).isNotNull();
    }

}
