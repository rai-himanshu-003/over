/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.ResponseDto;

public class TestResponseDto {

    @Test
    public void ResponseDto() {
        ResponseDto responseDto = new ResponseDto();
        Assertions.assertThat(responseDto).isNotNull();
    }

    @Test
    public void testResponseDtoSetGet() {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setSerialVersionUID(4527943607165453814L);
        responseDto.setId("VIN");
        responseDto.setMsg(true);

        Assertions.assertThat(responseDto.getId()).isEqualTo("VIN");
        Assertions.assertThat(responseDto.getSerialVersionUID()).isEqualTo(4527943607165453814L);
        Assertions.assertThat(responseDto.isMsg()).isEqualTo(true);

        Assertions.assertThat(responseDto.toString()).isNotNull();
    }

}
