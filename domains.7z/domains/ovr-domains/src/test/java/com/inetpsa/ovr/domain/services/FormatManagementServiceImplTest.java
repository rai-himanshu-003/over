package com.inetpsa.ovr.domain.services;

import java.io.File;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.FlowVhlMetadata;
import com.inetpsa.ovr.domain.model.GenericCollection;
import com.inetpsa.ovr.domain.model.OVComponent;
import com.inetpsa.ovr.domain.model.OVComponentPart;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.AuditRepository;
import com.inetpsa.ovr.domain.repository.FlowManagementDetailsRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.impl.FormatManagementServiceImpl;
import com.inetpsa.ovr.interfaces.dto.FlowVhlMetadataDTO;
import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;

/*
 * Creation : 24 Jul 2019
 */
@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class FormatManagementServiceImplTest {

    @Inject
    FormatManagementService formatManagementService;

    @Inject
    FlowManagementDetailsService flowManagementDetailsService;

    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    private FlowManagementDetailsRepository flowRepository;

    @Inject
    private AuditRepository auditRepository;

    OutputFlowDetails opflow = new OutputFlowDetails();
    OutputFlowDetailsDTO opFlowDetailsDTO = new OutputFlowDetailsDTO();

    OutputFlowDetails opflowft = new OutputFlowDetails();

    Vehicle vehicle = new Vehicle();
    List<Vehicle> vehicles = new ArrayList<>();;

    String strFile = this.getClass().getClassLoader().getResource("OVR_DAEMON_TEST").getFile();
    OutputFlowDetailsDTO outputFlowDetailsDTO;
    Set<OVComponent> ovset;

    @Before
    public void setData() {

        vehicle.setVinNo("V123");
        vehicle.setCcp("AB");
        vehicle.setVeh("AB");
        vehicle.setUp("AB");
        vehicle.setCcp("AB");
        vehicle.setApvpr("AB");
        vehicle.setOa("AB");
        vehicle.setOf("AB");
        vehicle.setNre("AB");
        vehicle.setTvv("AB");
        vehicle.setLcdv24("AB");
        vehicle.setModel("AB");
        vehicle.setModelYear("AB");
        vehicle.setDateExtension(new Date(2020 / 01 / 01));
        vehicle.setDateEcom(new Date(2020 / 01 / 01));
        vehicle.setDateEmon(new Date(2020 / 01 / 01));
        vehicle.setMultipleFlowStatus(new ArrayList<>());
        ComposantsOv composantsOv = new ComposantsOv();
        composantsOv.setStandard("OTHER");
        composantsOv.setId(1l);
        Set<ComposantsOv> composantsOvs = new HashSet<>();
        composantsOvs.add(composantsOv);
        // vehicle.setComposantsOv(composantsOvs);

        Set<Options> optionss = new HashSet<>();
        Options options = new Options();
        options.setRpoData("AAAA");
        options.setId(2l);
        optionss.add(options);
        // vehicle.setOptions(optionss);

        opflow.setId(1L);
        opflow.setFormat(2l);
        opflow.setFlow("SAGAI");

        opflowft.setId(1L);
        opflowft.setFormat(2l);
        opflowft.setFlow("SAGAI");

        opFlowDetailsDTO.setId(1L);
        opFlowDetailsDTO.setFileFormatId(2l);
        opFlowDetailsDTO.setFlow("SAGAI");

        // Set FLow vehicle Metadata Start
        Set<FlowVhlMetadata> flowVhlMetadataSet = new HashSet<>();
        Set<FlowVhlMetadataDTO> flowVhlMetadataDTOs = new HashSet<>();

        FlowVhlMetadata obj = new FlowVhlMetadata();
        obj.setValue(7L);
        obj.setFlowId(1L);
        obj.setSeq(3L);
        obj.setFilter("V123");

        FlowVhlMetadataDTO flowVhlMetadataDTO = new FlowVhlMetadataDTO();
        flowVhlMetadataDTO.setValue(7L);
        flowVhlMetadataDTO.setFlowId(1L);
        flowVhlMetadataDTO.setSeq(3L);
        flowVhlMetadataDTO.setFilter("V123");
        flowVhlMetadataDTOs.add(flowVhlMetadataDTO);

        FlowVhlMetadata obj1 = new FlowVhlMetadata();
        obj1.setValue(8L);
        obj1.setFlowId(1L);
        obj1.setSeq(4L);

        FlowVhlMetadata obj2 = new FlowVhlMetadata();
        obj2.setValue(9L);
        obj2.setFlowId(1L);
        obj2.setSeq(5L);
        obj2.setFilter("VIN1,VIN2");

        FlowVhlMetadata obj3 = new FlowVhlMetadata();
        obj3.setValue(10L);
        obj3.setFlowId(1L);
        obj3.setSeq(6L);
        obj3.setFilter("VIN1,VIN2");

        FlowVhlMetadata obj4 = new FlowVhlMetadata();
        obj4.setValue(11L);
        obj4.setFlowId(1L);
        obj4.setSeq(7L);
        obj4.setFilter("VIN1,VIN2");

        FlowVhlMetadata obj5 = new FlowVhlMetadata();
        obj5.setValue(12L);
        obj5.setFlowId(1L);
        obj5.setSeq(8L);

        FlowVhlMetadata obj6 = new FlowVhlMetadata();
        obj6.setValue(13L);
        obj6.setFlowId(1L);
        obj6.setSeq(9L);
        // obj6.setFilter("YYYYDDMM");

        FlowVhlMetadata obj7 = new FlowVhlMetadata();
        obj7.setValue(14L);
        obj7.setFlowId(1L);
        obj7.setSeq(10L);
        // obj7.setFilter("YYYYDDMM");

        FlowVhlMetadata obj8 = new FlowVhlMetadata();
        obj8.setValue(15L);
        obj8.setFlowId(1L);
        obj8.setSeq(11L);
        obj8.setFilter("VIN1,VIN2");

        FlowVhlMetadata obj9 = new FlowVhlMetadata();
        obj9.setValue(16L);
        obj9.setFlowId(1L);
        obj9.setSeq(12L);
        obj9.setFilter("VIN1,VIN2");

        FlowVhlMetadata obj10 = new FlowVhlMetadata();
        obj10.setValue(17L);
        obj10.setFlowId(1L);
        obj10.setSeq(13L);
        obj10.setFilter("VIN1,VIN2");

        FlowVhlMetadata obj11 = new FlowVhlMetadata();
        obj11.setValue(18L);
        obj11.setFlowId(1L);
        obj11.setSeq(14L);
        obj11.setFilter("VIN1,VIN2");

        flowVhlMetadataSet.add(obj);
        flowVhlMetadataSet.add(obj1);
        flowVhlMetadataSet.add(obj2);
        flowVhlMetadataSet.add(obj3);
        flowVhlMetadataSet.add(obj4);
        flowVhlMetadataSet.add(obj5);
        flowVhlMetadataSet.add(obj6);
        flowVhlMetadataSet.add(obj7);
        flowVhlMetadataSet.add(obj8);
        flowVhlMetadataSet.add(obj9);
        flowVhlMetadataSet.add(obj10);
        flowVhlMetadataSet.add(obj11);

        opflow.setFlowVhlMetadatas(flowVhlMetadataSet);
        opflowft.setFlowVhlMetadatas(flowVhlMetadataSet);
        // Set FLow vehicle Metadata End

        // Set Gen Collection Start
        Set<GenericCollection> genSet = new HashSet<>();
        Set<GenericCollectionDTO> genericCollectionDTOs = new HashSet<>();

        GenericCollection genericCollection = new GenericCollection();
        genericCollection.setFlowId(1L);
        genericCollection.setSeq(15L);
        genericCollection.setValue(19L);
        genericCollection.setFilter("%,%");

        GenericCollection genericCollection1 = new GenericCollection();
        genericCollection1.setFlowId(1L);
        genericCollection1.setSeq(16L);
        genericCollection1.setValue(20L);
        genericCollection1.setFilter("%,%");

        genSet.add(genericCollection1);
        genSet.add(genericCollection);

        opflow.setGenericCollections(genSet);
        opflowft.setGenericCollections(genSet);
        // Set Gen Collection End

        // Set OV comp part Start
        Set<OVComponentPart> ovComponentPartSet = new HashSet<>();

        // Standard 22
        OVComponentPart ovComponentPart25 = new OVComponentPart();
        ovComponentPart25.setOvCompId(1L);
        ovComponentPart25.setStandard(22L);
        ovComponentPart25.setValue(25L);
        ovComponentPart25.setFilter("%,%");

        OVComponentPart ovComponentPart26 = new OVComponentPart();
        ovComponentPart26.setOvCompId(1L);
        ovComponentPart26.setStandard(22L);
        ovComponentPart26.setValue(26L);
        ovComponentPart26.setFilter("%,%");

        OVComponentPart ovComponentPart27 = new OVComponentPart();
        ovComponentPart27.setOvCompId(1L);
        ovComponentPart27.setStandard(22L);
        ovComponentPart27.setValue(27L);
        ovComponentPart27.setFilter("%,%");

        OVComponentPart ovComponentPart28 = new OVComponentPart();
        ovComponentPart28.setOvCompId(1L);
        ovComponentPart28.setStandard(22L);
        ovComponentPart28.setValue(28L);
        ovComponentPart28.setFilter("%,%");

        OVComponentPart ovComponentPart29 = new OVComponentPart();
        ovComponentPart29.setOvCompId(1L);
        ovComponentPart29.setStandard(22L);
        ovComponentPart29.setValue(29L);
        ovComponentPart29.setFilter("data%,dat%");

        ovComponentPartSet.add(ovComponentPart25);
        ovComponentPartSet.add(ovComponentPart26);
        ovComponentPartSet.add(ovComponentPart27);
        ovComponentPartSet.add(ovComponentPart28);
        ovComponentPartSet.add(ovComponentPart29);

        // Standard 23
        OVComponentPart ovComponentPart25_23 = new OVComponentPart();
        ovComponentPart25_23.setOvCompId(1L);
        ovComponentPart25_23.setStandard(23L);
        ovComponentPart25_23.setValue(25L);
        ovComponentPart25_23.setFilter("%,%");

        OVComponentPart ovComponentPart26_23 = new OVComponentPart();
        ovComponentPart26_23.setOvCompId(1L);
        ovComponentPart26_23.setStandard(23L);
        ovComponentPart26_23.setValue(26L);
        ovComponentPart26_23.setFilter("%,%");

        OVComponentPart ovComponentPart27_23 = new OVComponentPart();
        ovComponentPart27_23.setOvCompId(1L);
        ovComponentPart27_23.setStandard(23L);
        ovComponentPart27_23.setValue(27L);
        ovComponentPart27_23.setFilter("%,%");

        OVComponentPart ovComponentPart28_23 = new OVComponentPart();
        ovComponentPart28_23.setOvCompId(1L);
        ovComponentPart28_23.setStandard(23L);
        ovComponentPart28_23.setValue(28L);
        ovComponentPart28_23.setFilter("%,%");

        ovComponentPartSet.add(ovComponentPart25_23);
        ovComponentPartSet.add(ovComponentPart26_23);
        ovComponentPartSet.add(ovComponentPart27_23);
        ovComponentPartSet.add(ovComponentPart28_23);

        // Standard 24
        OVComponentPart ovComponentPart25_24 = new OVComponentPart();
        ovComponentPart25_24.setOvCompId(1L);
        ovComponentPart25_24.setStandard(24L);
        ovComponentPart25_24.setValue(25L);
        ovComponentPart25_24.setFilter("%,%");

        OVComponentPart ovComponentPart26_24 = new OVComponentPart();
        ovComponentPart26_24.setOvCompId(1L);
        ovComponentPart26_24.setStandard(24L);
        ovComponentPart26_24.setValue(26L);
        // ovComponentPart26_24.setFilter(",,,");

        OVComponentPart ovComponentPart27_24 = new OVComponentPart();
        ovComponentPart27_24.setOvCompId(1L);
        ovComponentPart27_24.setStandard(24L);
        ovComponentPart27_24.setValue(27L);
        // ovComponentPart27_24.setFilter(", , , , ");

        OVComponentPart ovComponentPart28_24 = new OVComponentPart();
        ovComponentPart28_24.setOvCompId(1L);
        ovComponentPart28_24.setStandard(24L);
        ovComponentPart28_24.setValue(28L);
        // ovComponentPart28_24.setFilter("");

        ovComponentPartSet.add(ovComponentPart25_24);
        ovComponentPartSet.add(ovComponentPart26_24);
        ovComponentPartSet.add(ovComponentPart27_24);
        ovComponentPartSet.add(ovComponentPart28_24);
        // Set OV comp part End

        // Set OV comp Start

        ovset = new HashSet<>();
        Set<OVComponentDTO> ovComponentDTOs = new HashSet<>();

        OVComponent oVComponent = new OVComponent();
        oVComponent.setId(1L);
        oVComponent.setFlowId(1L);
        oVComponent.setSeq(5L);
        oVComponent.setValue(21L);
        oVComponent.setOvComponentParts(ovComponentPartSet);

        oVComponent.setOvComponentParts(ovComponentPartSet);
        ovset.add(oVComponent);

        opflow.setOvComponents(ovset);
        // opflowft.setOvComponents(ovset);

        outputFlowDetailsDTO = new OutputFlowDetailsDTO();
        // outputFlowDetailsDTO.setId((long) 1);
        outputFlowDetailsDTO.setAction((long) 1);
        outputFlowDetailsDTO.setDescription("test");
        outputFlowDetailsDTO.setFrequency("test");
        outputFlowDetailsDTO.setFolderLocation("test");
        outputFlowDetailsDTO.setFlow("SAGAI");
        outputFlowDetailsDTO.setFileFormatId(2l);
        outputFlowDetailsDTO.setFileName("test");
        outputFlowDetailsDTO.setLastRun(LocalDateTime.MAX);
        outputFlowDetailsDTO.setVersion(1);
        // outputFlowDetailsDTO.setFlowVhlMetadataDTOs(flowVhlMetadataDTOs);
        // outputFlowDetailsDTO.setCollectionDTOs(genericCollectionDTOs);
        // outputFlowDetailsDTO.setOvComponentDTOs(ovComponentDTOs);

    }

    @Test
    public void outputFlowDetailsValidatorOpFlowNull() {
        opflow.setOvComponents(null);
        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isTrue();
    }

    @Test
    public void outputFlowDetailsValidatorOpFlow_flowmetadata_SeqFalse() {

        Set<FlowVhlMetadataDTO> flowVhlMetadataSet = new HashSet<>();

        FlowVhlMetadataDTO obj = new FlowVhlMetadataDTO();
        obj.setValue(7L);
        obj.setFlowId(1L);
        obj.setSeq(4L);

        FlowVhlMetadataDTO obj1 = new FlowVhlMetadataDTO();
        obj1.setValue(8L);
        obj1.setFlowId(1L);
        obj1.setSeq(4L);

        flowVhlMetadataSet.add(obj);
        flowVhlMetadataSet.add(obj1);

        outputFlowDetailsDTO.setFlowVhlMetadataDTOs(flowVhlMetadataSet);

        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isFalse();
    }

    @Test
    public void outputFlowDetailsValidatorOpFlow_flowmetadata_valFalse() {

        Set<FlowVhlMetadataDTO> flowVhlMetadataSet = new HashSet<>();

        FlowVhlMetadataDTO obj = new FlowVhlMetadataDTO();
        obj.setValue(7L);
        obj.setFlowId(1L);
        obj.setSeq(3L);

        FlowVhlMetadataDTO obj1 = new FlowVhlMetadataDTO();
        obj1.setValue(7L);
        obj1.setFlowId(1L);
        obj1.setSeq(4L);

        flowVhlMetadataSet.add(obj);
        flowVhlMetadataSet.add(obj1);

        outputFlowDetailsDTO.setFlowVhlMetadataDTOs(flowVhlMetadataSet);

        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isFalse();
    }

    @Test
    public void outputFlowDetailsValidatorOpFlow_GenColl_seqFalse() {

        Set<GenericCollectionDTO> genSet = new HashSet<>();
        GenericCollectionDTO genericCollection = new GenericCollectionDTO();
        genericCollection.setFlowId(1L);
        genericCollection.setSeq(1L);
        genericCollection.setValue(19L);

        GenericCollectionDTO genericCollection1 = new GenericCollectionDTO();
        genericCollection1.setFlowId(1L);
        genericCollection1.setSeq(1L);
        genericCollection1.setValue(20L);

        genSet.add(genericCollection1);
        genSet.add(genericCollection);

        outputFlowDetailsDTO.setCollectionDTOs(genSet);

        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isFalse();
    }

    @Test
    public void outputFlowDetailsValidatorOpFlow_GenColl_valFalse() {

        Set<GenericCollectionDTO> genSet = new HashSet<>();
        GenericCollectionDTO genericCollection = new GenericCollectionDTO();
        genericCollection.setFlowId(1L);
        genericCollection.setSeq(1L);
        genericCollection.setValue(19L);

        GenericCollectionDTO genericCollection1 = new GenericCollectionDTO();
        genericCollection1.setFlowId(1L);
        genericCollection1.setSeq(2L);
        genericCollection1.setValue(19L);

        genSet.add(genericCollection1);
        genSet.add(genericCollection);

        outputFlowDetailsDTO.setCollectionDTOs(genSet);

        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isFalse();
    }

    @Test
    public void outputFlowDetailsValidatorOpFlow_oVComp_seqFalse() {

        Set<GenericCollectionDTO> genSet = new HashSet<>();
        GenericCollectionDTO genericCollection = new GenericCollectionDTO();
        genericCollection.setFlowId(1L);
        genericCollection.setSeq(1L);
        genericCollection.setValue(19L);

        GenericCollectionDTO genericCollection1 = new GenericCollectionDTO();
        genericCollection.setFlowId(1L);
        genericCollection.setSeq(2L);
        genericCollection.setValue(20L);

        genSet.add(genericCollection1);
        genSet.add(genericCollection);

        outputFlowDetailsDTO.setCollectionDTOs(genSet);

        Set<OVComponentDTO> ovset = new HashSet<>();
        OVComponentDTO oVComponent = new OVComponentDTO();
        oVComponent.setId(1L);
        oVComponent.setFlowId(1L);
        oVComponent.setSeq(1L);
        oVComponent.setValue(21L);
        OVComponentDTO oVComponent2 = new OVComponentDTO();
        oVComponent.setId(1L);
        oVComponent.setFlowId(1L);
        oVComponent.setSeq(1L);
        oVComponent.setValue(22L);
        // oVComponent.setOvComponentPartDTOs(null);
        ovset.add(oVComponent);
        ovset.add(oVComponent2);

        outputFlowDetailsDTO.setOvComponentDTOs(ovset);

        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isTrue();
    }

    @Test
    public void outputFlowDetailsValidatorOpFlow_oVComp_valFalse() {

        Set<GenericCollectionDTO> genSet = new HashSet<>();
        GenericCollectionDTO genericCollection = new GenericCollectionDTO();
        genericCollection.setFlowId(1L);
        genericCollection.setSeq(1L);
        genericCollection.setValue(19L);

        GenericCollectionDTO genericCollection1 = new GenericCollectionDTO();
        genericCollection.setFlowId(1L);
        genericCollection.setSeq(2L);
        genericCollection.setValue(20L);

        genSet.add(genericCollection1);
        genSet.add(genericCollection);

        outputFlowDetailsDTO.setCollectionDTOs(genSet);

        Set<OVComponentDTO> ovset = new HashSet<>();
        OVComponentDTO oVComponent = new OVComponentDTO();
        oVComponent.setId(1L);
        oVComponent.setFlowId(1L);
        oVComponent.setSeq(21L);
        oVComponent.setValue(20L);
        ovset.add(oVComponent);
        outputFlowDetailsDTO.setOvComponentDTOs(ovset);

        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isFalse();

        Set<OVComponentDTO> ovSet2 = new HashSet<>();
        OVComponentDTO ovComponent2 = new OVComponentDTO();
        ovComponent2.setId(1L);
        ovComponent2.setFlowId(1L);
        ovComponent2.setSeq(22L);
        ovComponent2.setValue(21L);
        ovSet2.add(ovComponent2);
        outputFlowDetailsDTO.setOvComponentDTOs(ovSet2);
        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isTrue();
    }

    @Test
    public void outputFlowDetailsValidatorOpFlow_oVCompPaerts_valFalse() {

        Set<OVComponentDTO> ovset = new HashSet<>();
        OVComponentDTO oVComponent = new OVComponentDTO();
        oVComponent.setId(1L);
        oVComponent.setFlowId(1L);

        Set<OVComponentPartDTO> componentParts = new HashSet<>();
        OVComponentPartDTO ovComponentPart = new OVComponentPartDTO();
        ovComponentPart.setId(1l);
        ovComponentPart.setIntSeq("1.1");
        ovComponentPart.setOvCompId(1l);
        ovComponentPart.setStandard(22l);
        ovComponentPart.setValue(27l);
        componentParts.add(ovComponentPart);
        oVComponent.setOvComponentPartDTOs(componentParts);
        ovset.add(oVComponent);
        outputFlowDetailsDTO.setOvComponentDTOs(ovset);
        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isTrue();

        OVComponentPartDTO ovComponentPart2 = new OVComponentPartDTO();
        ovComponentPart2.setId(2l);
        ovComponentPart2.setIntSeq("1.1");
        ovComponentPart2.setOvCompId(1l);
        ovComponentPart2.setStandard(22l);
        ovComponentPart2.setValue(27l);
        componentParts.add(ovComponentPart2);
        oVComponent.setOvComponentPartDTOs(componentParts);
        ovset.add(oVComponent);
        outputFlowDetailsDTO.setOvComponentDTOs(ovset);
        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isFalse();

        OVComponentPartDTO ovComponentPart3 = new OVComponentPartDTO();
        ovComponentPart3.setId(3l);
        ovComponentPart3.setIntSeq("1.1");
        ovComponentPart3.setOvCompId(1l);
        ovComponentPart3.setStandard(22l);
        ovComponentPart3.setValue(28l);
        componentParts.add(ovComponentPart3);
        oVComponent.setOvComponentPartDTOs(componentParts);
        ovset.add(oVComponent);
        outputFlowDetailsDTO.setOvComponentDTOs(ovset);
        Assertions.assertThat(formatManagementService.outputFlowDetailsValidator(outputFlowDetailsDTO)).isFalse();

    }

    @Test
    public void fetchFilteredDataTest() {

        vehicleRepository.add(vehicle);

        this.setData();

        Assertions.assertThat(formatManagementService.fetchFilteredData(opflow)).isNotNull();

        Date now = new Date();
        Instant current = now.toInstant();
        LocalDateTime lastRun = LocalDateTime.ofInstant(current, ZoneId.systemDefault());

        opflow.setLastRun(lastRun);
        opflow.setAction(30L);
        Assertions.assertThat(formatManagementService.fetchFilteredData(opflow)).isNotNull();

        opflow.setAction(31L);
        Assertions.assertThat(formatManagementService.fetchFilteredData(opflow)).isNotNull();
        vehicles.add(vehicle);
        FormatManagementServiceImpl test = new FormatManagementServiceImpl();
        test.returnJsonFormat(vehicles, opflow);
        test.returnXmlFormat(vehicles, opflow);

        // vehicleRepository.remove(vehicle);

        List<OVComponentPart> std22 = new ArrayList<OVComponentPart>();

    }

    @Test(expected = Exception.class)
    public void emptyCheck() {
        Assertions.assertThat(formatManagementService.fetchFilteredData(null)).isNotNull();
    }

    @Test
    public void generateFileTest() {

        flowRepository.add(opflowft);
        String parentPath = new File(strFile).getParent();
        formatManagementService.generateFileFrFormat(parentPath, "TESTFITEST", ".dat", opflowft, true);
        opflowft.setFormat(1l);
        flowRepository.add(opflowft);
        formatManagementService.generateFileFrFormat(parentPath, "TESTFITEST", ".dat", opflowft, true);
        opflowft.setFormat(3l);
        flowRepository.add(opflowft);
        formatManagementService.generateFileFrFormat(parentPath, "TESTFITEST", ".dat", opflowft, true);
        Assertions.assertThat(opflowft).isNotNull();
    }

    @Test
    public void addUpdateGetTest() {
        flowManagementDetailsService.addOrUpdateflowDetails(outputFlowDetailsDTO);
        outputFlowDetailsDTO.setId(1l);
        formatManagementService.getflowDetailsById(1l);
        formatManagementService.addOrUpdateFormatDetails(outputFlowDetailsDTO);
        formatManagementService.getFlowStaticMetadata();
        Assertions.assertThat(outputFlowDetailsDTO).isNotNull();
    }

    @Test
    public void generateFileAtFolder() {
        String parentPath = new File(strFile).getParent();
        List<StringBuilder> buffers = new ArrayList<>();
        StringBuilder data = new StringBuilder("dsdfsfffsf");
        buffers.add(data);
        FormatManagementServiceImpl formatManagementServiceImpl = new FormatManagementServiceImpl();
        formatManagementServiceImpl.setAuditRepository(auditRepository);
        File file = formatManagementServiceImpl.generateFileAtFolder(parentPath, "TESTFITEST", buffers, false, buffers.size(), "test");
        Assertions.assertThat(file).isNotNull();
        file.delete();
    }

    @Test
    public void updateLastRun() {
        formatManagementService.updateLastRun(opflow);
        Assertions.assertThat(opflow).isNotNull();
    }

}
