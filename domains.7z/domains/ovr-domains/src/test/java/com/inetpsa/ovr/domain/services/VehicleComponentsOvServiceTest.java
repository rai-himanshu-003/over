/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.repository.VehicleComposantsOvRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleComponentsOvServiceTest {

    @Inject
    VehicleComponentsOvService vehicleComponentsOvService;

    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    private VehicleComposantsOvRepository vehicleComposantsOvRepository;

    @Test(expected = Exception.class)
    public void addOrUpdateOptionsTest() {

        ComposantsOv composantsOv = new ComposantsOv();
        composantsOv.setData("TEST");
        composantsOv.setEid("TEST");
        composantsOv.setLabel("TEST");
        composantsOv.setStandard("TEST");
        composantsOv.setVin("TESTVIN");
        composantsOv.setPart("TEST");
        composantsOv.setSupplier("TEST");

        // vehicleRepository.add(vehicle);

        Assertions.assertThat(vehicleComponentsOvService.addOrUpdateComposantsOv(composantsOv)).isNotNull();
        composantsOv.setId(1l);
        vehicleComposantsOvRepository.add(composantsOv);

        Assertions.assertThat(vehicleComponentsOvService.addOrUpdateComposantsOv(composantsOv)).isNotNull();

        Assertions.assertThat(vehicleComponentsOvService.deleteComposantsOvById(1l)).isTrue();

        Assertions.assertThat(vehicleComponentsOvService.deleteComposantsOvById(1L)).isFalse();
        List<ComposantsOv> composantsOvList = vehicleComponentsOvService.getvehicleComposantsOvByVin("TESTVIN");

        Assertions.assertThat(composantsOvList).isEmpty();

    }

    @Test
    public void addOrUpdateComposantsTest() {
        List<PsaKeyMapping> psaKeyMappings = new ArrayList<PsaKeyMapping>();
        PsaKeyMapping psaKeyMapping = new PsaKeyMapping();
        psaKeyMapping.setDescription("Test");
        psaKeyMapping.setOvKey("test");
        psaKeyMapping.setOvStandard("test");
        psaKeyMapping.setPsaDatatype("test");
        psaKeyMapping.setPsaKey("20");
        psaKeyMappings.add(psaKeyMapping);
        Assertions.assertThat(vehicleComposantsOvRepository.getComposants(psaKeyMappings, "TEST")).isNotNull();

    }

}
