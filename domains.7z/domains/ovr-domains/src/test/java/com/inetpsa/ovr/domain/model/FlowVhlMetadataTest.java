/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class FlowVhlMetadataTest {

    @Test
    public void OvComposantTest() {

        FlowVhlMetadata flMetadata = new FlowVhlMetadata();

        flMetadata.setFlowId(1l);
        flMetadata.setId(1l);
        flMetadata.setSeq(4l);
        flMetadata.setSeparator(",");
        flMetadata.setValue(5l);
        flMetadata.setFilter("test");

        FlowVhlMetadata flMetadata1 = new FlowVhlMetadata();

        flMetadata1.setFlowId(1l);
        flMetadata1.setId(1l);
        flMetadata1.setSeq(4l);
        flMetadata1.setSeparator(",");
        flMetadata1.setValue(51l);
        flMetadata1.setFilter("test");

        Assertions.assertThat(flMetadata).isNotNull();
        Assertions.assertThat(flMetadata.getId()).isNotNull();
        Assertions.assertThat(flMetadata.getFlowId()).isNotNull();
        Assertions.assertThat(flMetadata.getValue()).isNotNull();
        Assertions.assertThat(flMetadata.getSeq()).isNotNull();
        Assertions.assertThat(flMetadata.getSeparator()).isNotNull();
        Assertions.assertThat(flMetadata.hashCode()).isNotNull();
        Assertions.assertThat(flMetadata.toString()).isNotNull();

        Assertions.assertThat(flMetadata.equals(flMetadata1)).isNotNull();
        Assertions.assertThat(flMetadata.maptoDto()).isNotNull();

    }

}
