/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.interfaces.dto.OptionsDTO;

public class OptionDTOTest {

    @Test
    public void optionsTest() {

        Options options = new Options();
        options.setId(1L);
        options.setRpoData("Test");
        options.setVin("TestVin");

        Options options1 = new Options();
        options1.setId(1L);
        options1.setRpoData("Test");
        options1.setVin("TestVin");

        Assertions.assertThat(options).isNotNull();
        Assertions.assertThat(options.getId()).isNotNull();
        Assertions.assertThat(options.getRpoData()).isNotNull();
        Assertions.assertThat(options.getVin()).isNotNull();
        Assertions.assertThat(options.toString()).isNotNull();
        Assertions.assertThat(options.maptoDto()).isNotNull();
        Assertions.assertThat(options.hashCode()).isNotNull();
        Assertions.assertThat(options.equals(options1)).isNotNull();

    }

    @Test
    public void optionsDTOTest() {

        OptionsDTO optionsDTO = new OptionsDTO();
        optionsDTO.setId(1L);
        optionsDTO.setRpoData("Test");
        optionsDTO.setVin("TestVin");

        Assertions.assertThat(optionsDTO).isNotNull();
        Assertions.assertThat(optionsDTO.getId()).isNotNull();
        Assertions.assertThat(optionsDTO.getRpoData()).isNotNull();
        Assertions.assertThat(optionsDTO.getVin()).isNotNull();
        Assertions.assertThat(optionsDTO.toString()).isNotNull();
        Assertions.assertThat(optionsDTO.mapTomodel()).isNotNull();

    }

}
