/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.InterfaceAuditDto;
import com.inetpsa.ovr.interfaces.dto.InterfaceDto;

public class InterfaceAuditDtoTest {
    @Test
    public void ResponseDto() {
        InterfaceAuditDto interfaceAuditDto = new InterfaceAuditDto();
        Assertions.assertThat(interfaceAuditDto).isNotNull();
    }

    @Test
    public void testInterfaceRulesDtoSetGet() {

        InterfaceDto interfaceDto = new InterfaceDto();

        InterfaceAuditDto interfaceAuditDto = new InterfaceAuditDto();
        interfaceAuditDto.setDateCreation("01/01/2019");
        interfaceAuditDto.setDateCreationOrder("asc");
        interfaceAuditDto.setErrorCount(10);
        interfaceAuditDto.setErrorCountOrder("asc");
        interfaceAuditDto.setFileName("abc");
        interfaceAuditDto.setFileNameOrder("asc");
        interfaceAuditDto.setFromDateCreation("01/01/2019");
        interfaceAuditDto.setInterfaceName("Gepics");
        interfaceAuditDto.setInterfaceOrder("asc");
        interfaceAuditDto.setSuccessCount(10);
        interfaceAuditDto.setSuccessCountOrder("asc");
        interfaceAuditDto.setToDateCreation("05/05/2019");
        interfaceAuditDto.setUserCreation("Gepics");
        interfaceAuditDto.setUserCreationOrder("asc");

        Assertions.assertThat(interfaceAuditDto.getDateCreation()).isEqualTo("01/01/2019");
        Assertions.assertThat(interfaceAuditDto.getDateCreationOrder()).isEqualTo("asc");
        Assertions.assertThat(interfaceAuditDto.getErrorCount()).isEqualTo(10);
        Assertions.assertThat(interfaceAuditDto.getErrorCountOrder()).isEqualTo("asc");
        Assertions.assertThat(interfaceAuditDto.getFileName()).isEqualTo("abc");
        Assertions.assertThat(interfaceAuditDto.getFileNameOrder()).isEqualTo("asc");
        Assertions.assertThat(interfaceAuditDto.getFromDateCreation()).isEqualTo("01/01/2019");
        Assertions.assertThat(interfaceAuditDto.getInterfaceName()).isEqualTo("Gepics");
        Assertions.assertThat(interfaceAuditDto.getInterfaceOrder()).isEqualTo("asc");
        Assertions.assertThat(interfaceAuditDto.getSuccessCount()).isEqualTo(10);
        Assertions.assertThat(interfaceAuditDto.getSuccessCountOrder()).isEqualTo("asc");
        Assertions.assertThat(interfaceAuditDto.getUserCreation()).isEqualTo("Gepics");
        Assertions.assertThat(interfaceAuditDto.getToDateCreation()).isEqualTo("05/05/2019");
        Assertions.assertThat(interfaceAuditDto.getUserCreationOrder()).isEqualTo("asc");
        Assertions.assertThat(interfaceDto.getId()).isNull();
        Assertions.assertThat(interfaceDto.getInterfaceName()).isNull();

    }
}
