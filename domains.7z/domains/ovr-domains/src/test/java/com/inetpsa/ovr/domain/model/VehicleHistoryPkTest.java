/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

public class VehicleHistoryPkTest {

    VehicleHistoryPk vehicleHistoryPk;

    private String vinNo = "VINXXXXXXTEST0032";

    private String currentState = "TRDN";

    @Before
    public void setUpData() {

    }

    @Test
    public void constructorTesting() {
        vehicleHistoryPk = new VehicleHistoryPk(vinNo, currentState);
        Assertions.assertThat(vehicleHistoryPk).isNotNull();

    }

    @Test
    public void setterGetterTesting() {
        vehicleHistoryPk = new VehicleHistoryPk();
        vehicleHistoryPk.setVinNo(vinNo);
        vehicleHistoryPk.setStateId(currentState);
        vehicleHistoryPk.setDateCreation(LocalDateTime.now());

        Assertions.assertThat(vehicleHistoryPk.getVinNo()).isNotNull();
        Assertions.assertThat(vehicleHistoryPk.getStateId()).isNotNull();
        Assertions.assertThat(vehicleHistoryPk.getDateCreation()).isNotNull();

    }

    @Test
    public void hashcodeAndEqualsTesting() {
        vehicleHistoryPk = new VehicleHistoryPk();
        vehicleHistoryPk.setVinNo(vinNo);
        vehicleHistoryPk.setStateId(currentState);
        vehicleHistoryPk.setDateCreation(LocalDateTime.now());

        Assertions.assertThat(vehicleHistoryPk.equals(vehicleHistoryPk)).isNotNull();
        Assertions.assertThat(vehicleHistoryPk.equals(null)).isFalse();
        Assertions.assertThat(vehicleHistoryPk.hashCode()).isNotNull();

    }
}
