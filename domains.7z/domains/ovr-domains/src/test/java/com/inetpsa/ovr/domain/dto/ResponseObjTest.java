/*
 * Creation : 24 Jan 2020
 */
package com.inetpsa.ovr.domain.dto;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.ws.ComponentsOv;
import com.inetpsa.ovr.interfaces.dto.ws.Header;
import com.inetpsa.ovr.interfaces.dto.ws.ResponseObj;
import com.inetpsa.ovr.interfaces.dto.ws.VehiculeData;
import com.inetpsa.ovr.interfaces.dto.ws.Vehicules;

public class ResponseObjTest {
    Vehicules vehicule;

    ComponentsOv componentsOv;

    Header header;

    ResponseObj responseObj;

    @Before
    public void setup() {
        List<String> dummyList = new ArrayList<>();
        dummyList.add("abc");
        componentsOv = new ComponentsOv();
        componentsOv.setData("Data");
        componentsOv.setId("1");
        componentsOv.setLabel("label");
        componentsOv.setStandard("standard");
        componentsOv.setPart("part");
        componentsOv.setSupplier("supplier");
        List<ComponentsOv> ovs = new ArrayList<>();
        ovs.add(componentsOv);

        VehiculeData data = new VehiculeData();
        data = new VehiculeData();
        data.setApvpr("ab");
        data.setDateEcom("28041111");
        data.setDateEmon("212121");
        data.setDateExtension("12121212");
        data.setLcdv24("lcdv24");
        data.setModel("ab");
        data.setModelYear("2010");
        data.setNre("nre");
        data.setOa("oa");
        data.setTvv("of");
        data.setOf("of");
        data.setUp("up");
        List<VehiculeData> vhlList = new ArrayList<>();
        vhlList.add(data);

        vehicule = new Vehicules();
        vehicule.setExists("Y");
        vehicule.setVin("VINXXXXXX");
        vehicule.setArtificialLcdv(dummyList);
        vehicule.setRpoCodes(dummyList);
        vehicule.setComponentsOv(ovs);
        vehicule.setVehiculeData(vhlList);

        List<Vehicules> vehicules = new ArrayList<>();
        vehicules.add(vehicule);
        header = new Header();
        header.setClient("MZPXXXX");

        responseObj = new ResponseObj();
        responseObj.setHeader(header);
        responseObj.setVehicules(vehicules);

    }

    @Test
    public void getVehiclesTest() {

        Assertions.assertThat(componentsOv.getData()).isEqualTo("Data");
        Assertions.assertThat(componentsOv.getId()).isEqualTo("1");
        Assertions.assertThat(componentsOv.getLabel()).isEqualTo("label");
        Assertions.assertThat(componentsOv.getStandard()).isEqualTo("standard");
        Assertions.assertThat(componentsOv.getPart()).isEqualTo("part");
        Assertions.assertThat(componentsOv.getSupplier()).isEqualTo("supplier");
        Assertions.assertThat(vehicule.getVin()).isEqualTo("VINXXXXXX");
        Assertions.assertThat(vehicule.getExists()).isEqualTo("Y");
        Assertions.assertThat(vehicule.getComponentsOv()).isNotEmpty();
        Assertions.assertThat(vehicule.getArtificialLcdv()).isNotEmpty();
        Assertions.assertThat(vehicule.getRpoCodes()).isNotEmpty();
        Assertions.assertThat(vehicule.getVehiculeData()).isNotEmpty();
        Assertions.assertThat(vehicule.toString()).isNotNull();
        Assertions.assertThat(componentsOv.toString()).isNotNull();
        Assertions.assertThat(header.getClient()).isEqualTo("MZPXXXX");
        Assertions.assertThat(responseObj.getHeader()).isNotNull();
        Assertions.assertThat(responseObj.getVehicules()).isNotEmpty();
        Assertions.assertThat(header.toString()).isNotNull();
        Assertions.assertThat(responseObj.toString()).isNotNull();
    }

}
