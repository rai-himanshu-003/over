/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.io.File;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.inetpsa.ovr.domain.services.impl.SDIServiceImpl;

@RunWith(SeedITRunner.class)
public class SDIServiceTest {

    File testFile;
    SDIServiceImpl sdiSService;
    String filepath;

    @Before
    public void setupData() {
        sdiSService = new SDIServiceImpl();
        testFile = new File(this.getClass().getClassLoader().getResource("OVR_DAEMON_TEST").getFile());
        filepath = (testFile.getParent()).replace("test-classes", "");

    }

    @Test
    public void testSDI() {

        String fileName = "/TESTErr.err";

        sdiSService.setSdiFilePath(filepath);
        sdiSService.setSdiFileName(fileName);

        Assertions.assertThat(sdiSService.rasieSDIIncident("ERR", "Test2", "Test3")).isTrue();

        File deletefile = new File(filepath + "/TESTErr.err");
        deletefile.delete();
    }

    @Test
    public void testSDIPathDoesnotExist() {

        sdiSService.setSdiFilePath("http:");
        sdiSService.setSdiFileName("/TESTErr.err");

        Assertions.assertThat(sdiSService.rasieSDIIncident("ERR", "Test2", "Test3")).isFalse();
        Assertions.assertThat(sdiSService.getSDIErrorMessage("ERR", "Test2", "Test3")).isNotNull();

    }

    @Test
    public void testSDIFileName() {

        sdiSService.setSdiFilePath(filepath);
        sdiSService.setSdiFileName("http://??\\\\");

        Assertions.assertThat(sdiSService.rasieSDIIncident("ERR", "Test2", "Test3")).isFalse();
    }

}
