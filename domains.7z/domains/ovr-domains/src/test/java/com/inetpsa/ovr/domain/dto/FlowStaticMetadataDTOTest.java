/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.FlowStaticMetadataDTO;

public class FlowStaticMetadataDTOTest {

    @Test
    public void OvComposantTest() {

        FlowStaticMetadataDTO flowStaticMetadataDTO = new FlowStaticMetadataDTO();

        flowStaticMetadataDTO.setType("test");
        flowStaticMetadataDTO.setId(1l);
        flowStaticMetadataDTO.setValue("test");

        Assertions.assertThat(flowStaticMetadataDTO).isNotNull();
        Assertions.assertThat(flowStaticMetadataDTO.getId()).isNotNull();
        Assertions.assertThat(flowStaticMetadataDTO.getType()).isNotNull();
        Assertions.assertThat(flowStaticMetadataDTO.getValue()).isNotNull();

        Assertions.assertThat(flowStaticMetadataDTO.mapTomodel()).isNotNull();

    }

}
