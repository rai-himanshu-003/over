/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.repository.ArtLcdvOttRepository;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleArtLcdvOttServiceTest {

    @Inject
    VehicleArtLcdvOttService vehicleArtLcdvOttService;
    @Inject
    ArtLcdvOttRepository artLcdvOttRepository;

    @Test(expected = Exception.class)
    public void vehicleArtLcdvOttService() {

        ArtLcdvOtt artLcdvOtt = new ArtLcdvOtt();
        // artLcdvOtt.setId((long) 1);
        artLcdvOtt.setCode("A");
        artLcdvOtt.setFamily("10");
        artLcdvOtt.setVin("test");
        artLcdvOtt.setValue("11");

        Assertions.assertThat(vehicleArtLcdvOttService.addOrUpdateArtLcdvOtt(artLcdvOtt)).isNotNull();

        artLcdvOtt.setId(1l);
        artLcdvOttRepository.add(artLcdvOtt);
        Assertions.assertThat(vehicleArtLcdvOttService.addOrUpdateArtLcdvOtt(artLcdvOtt)).isNotNull();

        // Assertions.assertThat(vehicleArtLcdvOttService.addOrUpdateArtLcdvOtt(null)).isFalse();

        Assertions.assertThat(vehicleArtLcdvOttService.deleteArtLcdvOttById(1L)).isTrue();
        Assertions.assertThat(vehicleArtLcdvOttService.deleteArtLcdvOttById(1L)).isFalse();

        Assertions.assertThat(vehicleArtLcdvOttService.getArtLcdvOttByVin("test")).isEmpty();

    }

}
