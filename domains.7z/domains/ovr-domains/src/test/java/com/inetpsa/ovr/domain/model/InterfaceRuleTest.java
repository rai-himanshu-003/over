/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.domain.util.LoggedUser;

public class InterfaceRuleTest {
    private InterfaceRule interfaceRule;

    @Before
    public void setUpData() {
        LoggedUser.logIn("OVER");
    }

    @Test
    public void testSetterGetter() {
        interfaceRule = new InterfaceRule();
        interfaceRule.setIntId(1l);

        interfaceRule.setPriority(1);
        interfaceRule.setFilterType(1);
        interfaceRule.setCountry("FR");
        interfaceRule.setVehicleFamily("CK9");
        interfaceRule.setProductionCentre("CK9");
        interfaceRule.setId((long) 1);
        interfaceRule.setMaxEcom(new Date());
        interfaceRule.setMinEcom(new Date());
        interfaceRule.setVersion(1);
        interfaceRule.setVin("V111111111");
        Assertions.assertThat(interfaceRule).isNotNull();
        interfaceRule.prePersist();
        interfaceRule.preUpdate();

        interfaceRule.getId();
        interfaceRule.getIntId();
        interfaceRule.getPriority();
        interfaceRule.getCountry();
        interfaceRule.getVehicleFamily();
        interfaceRule.getFilterType();
        interfaceRule.getProductionCentre();
        interfaceRule.getMinEcom();
        interfaceRule.getMaxEcom();
        interfaceRule.getDateCreation();
        interfaceRule.getUserModif();
        interfaceRule.getUserCreation();
        interfaceRule.getDateModif();
        interfaceRule.getVersion();
        interfaceRule.getVin();
        interfaceRule.toString();
        Assertions.assertThat(interfaceRule).isNotNull();
    }

}
