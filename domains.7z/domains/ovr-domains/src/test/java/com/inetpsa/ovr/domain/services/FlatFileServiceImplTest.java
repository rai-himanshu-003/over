package com.inetpsa.ovr.domain.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.FlowVhlMetadata;
import com.inetpsa.ovr.domain.model.GenericCollection;
import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.domain.model.OVComponent;
import com.inetpsa.ovr.domain.model.OVComponentPart;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;

/*
 * Creation : 24 Jul 2019
 */
@RunWith(SeedITRunner.class)
public class FlatFileServiceImplTest {

    @Inject
    FlatFileService flatFileService;

    OutputFlowDetails flowDetails = new OutputFlowDetails();

    List<Vehicle> vehicles = new ArrayList<>();

    @Before
    public void setData() {

        flowDetails.setFlow("SAGAI");
        flowDetails.setFormat(1L);
        flowDetails.setAction(30L);
        flowDetails.setDescription("");

        Set<FlowVhlMetadata> flVhlSet = new HashSet<>();
        FlowVhlMetadata fl1 = new FlowVhlMetadata();
        fl1.setSeq(1L);
        fl1.setValue(7L);
        fl1.setSeparator(";");

        FlowVhlMetadata fl2 = new FlowVhlMetadata();
        fl2.setSeq(2L);
        fl2.setValue(8L);
        fl2.setSeparator(";");

        FlowVhlMetadata fl3 = new FlowVhlMetadata();
        fl3.setSeq(3L);
        fl3.setValue(9L);
        fl3.setSeparator(";");

        FlowVhlMetadata fl4 = new FlowVhlMetadata();
        fl4.setSeq(4L);
        fl4.setValue(10L);
        fl4.setSeparator(";");

        FlowVhlMetadata fl5 = new FlowVhlMetadata();
        fl5.setSeq(5L);
        fl5.setValue(11L);
        fl5.setSeparator(";");

        FlowVhlMetadata fl6 = new FlowVhlMetadata();
        fl6.setSeq(6L);
        fl6.setValue(12L);
        fl6.setSeparator(";");

        FlowVhlMetadata fl7 = new FlowVhlMetadata();
        fl7.setSeq(7L);
        fl7.setValue(13L);
        fl7.setSeparator(";");

        FlowVhlMetadata fl8 = new FlowVhlMetadata();
        fl8.setSeq(8L);
        fl8.setValue(14L);
        fl8.setSeparator(";");

        FlowVhlMetadata fl9 = new FlowVhlMetadata();
        fl9.setSeq(9L);
        fl9.setValue(15L);
        fl9.setSeparator(";");

        FlowVhlMetadata fl10 = new FlowVhlMetadata();
        fl10.setSeq(10L);
        fl10.setValue(16L);
        fl10.setSeparator(";");

        FlowVhlMetadata fl11 = new FlowVhlMetadata();
        fl11.setSeq(11L);
        fl11.setValue(17L);
        fl11.setSeparator(";");

        FlowVhlMetadata fl12 = new FlowVhlMetadata();
        fl12.setSeq(12L);
        fl12.setValue(18L);
        fl12.setSeparator(";");

        flVhlSet.add(fl1);
        flVhlSet.add(fl2);
        flVhlSet.add(fl3);
        flVhlSet.add(fl4);
        flVhlSet.add(fl5);
        flVhlSet.add(fl6);
        flVhlSet.add(fl7);
        flVhlSet.add(fl8);
        flVhlSet.add(fl9);
        flVhlSet.add(fl10);
        flVhlSet.add(fl11);
        flVhlSet.add(fl12);

        flowDetails.setFlowVhlMetadatas(flVhlSet);

        Set<GenericCollection> genericCollections = new HashSet<>();

        GenericCollection gencol = new GenericCollection();
        gencol.setSeq(13L);
        gencol.setIntSeparator("#");
        gencol.setValue(19L);
        gencol.setSeparator(";");
        gencol.setMaxOcc(8L);
        gencol.setAlignment(5L);
        gencol.setFilter("%test%");

        GenericCollection gencol_rpo = new GenericCollection();
        gencol_rpo.setSeq(14L);
        gencol_rpo.setIntSeparator("#");
        gencol_rpo.setValue(20L);
        gencol_rpo.setSeparator(";");
        gencol_rpo.setMaxOcc(8L);
        gencol_rpo.setAlignment(6L);
        gencol_rpo.setFilter("%test%");

        genericCollections.add(gencol);
        genericCollections.add(gencol_rpo);

        flowDetails.setGenericCollections(genericCollections);

        Set<OVComponentPart> partSet = new HashSet<>();

        OVComponentPart part1 = new OVComponentPart();
        part1.setStandard(22L);
        part1.setValue(25L);
        part1.setIntSeq("2.2");

        OVComponentPart part2 = new OVComponentPart();
        part2.setStandard(22L);
        part2.setValue(26L);
        part2.setIntSeq("2.1");

        OVComponentPart part8 = new OVComponentPart();
        part8.setStandard(22L);
        part8.setValue(27L);
        part8.setIntSeq("2.4");

        OVComponentPart part6 = new OVComponentPart();
        part6.setStandard(22L);
        part6.setValue(28L);
        part6.setIntSeq("2.4");

        OVComponentPart part7 = new OVComponentPart();
        part6.setStandard(22L);
        part6.setValue(29L);
        part6.setIntSeq("2.5");

        OVComponentPart part3 = new OVComponentPart();
        part3.setStandard(23L);
        part3.setValue(25L);
        part3.setIntSeq("3.2");

        OVComponentPart part4 = new OVComponentPart();
        part4.setStandard(23L);
        part4.setValue(26L);
        part4.setIntSeq("3.1");

        OVComponentPart part5 = new OVComponentPart();
        part5.setStandard(24L);
        part5.setValue(27L);
        part5.setIntSeq("1.3");

        partSet.add(part1);
        partSet.add(part2);
        partSet.add(part3);
        partSet.add(part4);
        partSet.add(part5);
        partSet.add(part6);
        partSet.add(part7);

        Set<OVComponent> compSet = new HashSet<>();
        OVComponent comp = new OVComponent();
        comp.setOvComponentParts(partSet);
        comp.setValue(21L);
        comp.setSeq(15L);
        comp.setIntSeparator("#");
        comp.setSeparator(";");
        comp.setAlignment(5L);
        comp.setMaxOcc(4L);

        compSet.add(comp);
        flowDetails.setOvComponents(compSet);

        for (int i = 0; i < 10; i++) {
            Vehicle vehicle = new Vehicle();
            vehicle.setVinNo("VIN1234567890111" + i);
            vehicle.setUp("UP");
            vehicle.setCcp("CP");
            vehicle.setVeh("VEVE");
            vehicle.setApvpr("AAPVPR");
            vehicle.setModel("model");
            vehicle.setModelYear("23");
            vehicle.setDateEcom(new Date());
            vehicle.setDateEmon(new Date());

            vehicle.setOa("OAOAOAOA");
            vehicle.setOf("OF");
            vehicle.setLcdv24("LCDV");

            Set<Options> options = new HashSet<>();
            Options options2 = new Options();
            options2.setId(1l);
            options2.setRpoData("abc");
            options2.setVin("VIN1234567890111" + i);
            options.add(options2);

            Options options3 = new Options();
            options3.setId(2l);
            options3.setRpoData("abw");
            options3.setVin("VIN1234567890111" + i);
            options.add(options3);

            Options options4 = new Options();
            options4.setId(3l);
            options4.setRpoData("abe");
            options4.setVin("VIN1234567890111" + i);
            options.add(options4);

            Options options5 = new Options();
            options5.setId(4l);
            options5.setRpoData("abr");
            options5.setVin("VIN1234567890111" + i);
            options.add(options5);

            Options options6 = new Options();
            options6.setId(5l);
            options6.setRpoData("abt");
            options6.setVin("VIN1234567890111" + i);
            options.add(options6);

            Set<LcdvOtt> lcdvOtts = new HashSet<>();
            LcdvOtt lcdvOtt = new LcdvOtt();
            lcdvOtt.setId(1l);
            lcdvOtt.setValue("LCDV1");
            lcdvOtt.setCharacteristic("char");
            lcdvOtt.setVin("VIN1234567890111" + i);
            lcdvOtts.add(lcdvOtt);

            LcdvOtt lcdvOtt1 = new LcdvOtt();
            lcdvOtt1.setId(1l);
            lcdvOtt1.setValue("LCDV2");
            lcdvOtt1.setCharacteristic("char");
            lcdvOtt1.setVin("VIN1234567890111" + i);
            lcdvOtts.add(lcdvOtt1);

            LcdvOtt lcdvOtt2 = new LcdvOtt();
            lcdvOtt2.setId(1l);
            lcdvOtt2.setValue("LCDV3");
            lcdvOtt2.setCharacteristic("char");
            lcdvOtt2.setVin("VIN1234567890111" + i);
            lcdvOtts.add(lcdvOtt2);

            LcdvOtt lcdvOtt3 = new LcdvOtt();
            lcdvOtt3.setId(1l);
            lcdvOtt3.setValue("LCDV4");
            lcdvOtt3.setCharacteristic("char");
            lcdvOtt3.setVin("VIN1234567890111" + i);
            lcdvOtts.add(lcdvOtt3);

            LcdvOtt lcdvOtt4 = new LcdvOtt();
            lcdvOtt4.setId(1l);
            lcdvOtt4.setValue("LCDV5");
            lcdvOtt4.setCharacteristic("char");
            lcdvOtt4.setVin("VIN1234567890111" + i);
            lcdvOtts.add(lcdvOtt4);

            Set<ComposantsOv> composantsOvs = new HashSet<>();
            ComposantsOv composantsOv = new ComposantsOv();
            composantsOv.setId(1l);
            composantsOv.setEid("eidtest");
            composantsOv.setStandard("GM1737");
            composantsOv.setPart("PART");
            composantsOv.setSupplier("S");
            composantsOv.setVin("VIN1234567890111" + i);
            composantsOv.setLabel("label");
            composantsOv.setData("testdata");
            composantsOvs.add(composantsOv);

            ComposantsOv composantsOv1 = new ComposantsOv();
            composantsOv1.setId(123l);
            composantsOv1.setEid("eidtest");
            composantsOv1.setStandard("GMW15862");
            composantsOv1.setPart("PART12345");
            composantsOv1.setSupplier("S12345678901");
            composantsOv1.setVin("VIN1234567890111" + i);
            composantsOv1.setLabel("label");
            composantsOv1.setData("testdata");
            composantsOvs.add(composantsOv1);

            ComposantsOv composantsOv3 = new ComposantsOv();
            composantsOv3.setId(123l);
            composantsOv3.setEid("eidtest");
            composantsOv3.setStandard("OTHER");
            composantsOv3.setPart("PART12345");
            composantsOv3.setSupplier("S12345678901");
            composantsOv3.setVin("VIN1234567890111" + i);
            composantsOv3.setLabel("label");
            composantsOv3.setData("testdata");
            composantsOvs.add(composantsOv3);

            vehicle.setLcdvOttOv(lcdvOtts);
            vehicle.setOptions(options);
            vehicle.setComposantsOv(composantsOvs);

            vehicles.add(vehicle);
        }

    }

    @Test
    public void outputFlowDetailsValidatorTestAllPositive() {
        Assertions.assertThat(flatFileService.returnFlatFormat(vehicles, flowDetails)).isNotNull();
    }

}
