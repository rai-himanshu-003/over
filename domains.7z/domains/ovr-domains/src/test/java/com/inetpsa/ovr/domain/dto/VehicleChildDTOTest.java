/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.VehicleChildDTO;

public class VehicleChildDTOTest {

    @Test
    public void vehicleChildDTOTest() {

        VehicleChildDTO vehicleChildDTO = new VehicleChildDTO();

        vehicleChildDTO.setComposants(true);
        vehicleChildDTO.setComposantsOv(true);
        vehicleChildDTO.setKeysOv(true);
        vehicleChildDTO.setLcdvOttOv(true);
        vehicleChildDTO.setOptions(true);
        vehicleChildDTO.setReferencesElectroniques(true);

        Assertions.assertThat(vehicleChildDTO.isComposants()).isTrue();
        Assertions.assertThat(vehicleChildDTO.isComposantsOv()).isTrue();
        Assertions.assertThat(vehicleChildDTO.isKeysOv()).isTrue();
        Assertions.assertThat(vehicleChildDTO.isLcdvOttOv()).isTrue();
        Assertions.assertThat(vehicleChildDTO.isOptions()).isTrue();
        Assertions.assertThat(vehicleChildDTO.isReferencesElectroniques()).isTrue();

    }

}
