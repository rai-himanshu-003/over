/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.constants;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.constant.BatchNameConstant;
import com.inetpsa.ovr.domain.constant.BatchStatusConstant;
import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.constant.ResponseConstant;
import com.inetpsa.ovr.domain.constant.TranslationState;

public class ConstantTest {

    @Test
    public void testAllConstants() {

        Assertions.assertThat(BatchNameConstant.BATCH_NAME_OVR_OTT_RESP.getConstValue()).isEqualToIgnoringCase("ottResponseJob");
        Assertions.assertThat(BatchStatusConstant.BATCH_ACTIVE_STATUS.getConstValue()).isEqualToIgnoringCase("ACTIVE");
        Assertions.assertThat(CommonConstant.INTERFACE_OTT.getConstValue()).isEqualToIgnoringCase("OTT_TO_OVER");
        Assertions.assertThat(CommonConstant.INTERFACE_OVER.getConstValue()).isEqualToIgnoringCase("OVER_TO_OTT");
        Assertions.assertThat(CommonConstant.USER_MOD_OVR_OTT_RESP.getConstValue()).isEqualToIgnoringCase("OTT");
        Assertions.assertThat(ResponseConstant.ERROR_CHECK.getConstValue()).isEqualToIgnoringCase("BERR");
        Assertions.assertThat(ResponseConstant.FOOTER_CHECK.getConstValue()).isEqualToIgnoringCase("F000");
        Assertions.assertThat(ResponseConstant.HEADER_CHECK.getConstValue()).isEqualToIgnoringCase("HRES");
        Assertions.assertThat(ResponseConstant.SUCCESS_CHECK.getConstValue()).isEqualToIgnoringCase("BPCD");
        Assertions.assertThat(TranslationState.KO_TRSNSLATION.getConstValue()).isEqualToIgnoringCase("KOTR");
        Assertions.assertThat(TranslationState.CANCELLED.getConstValue()).isEqualToIgnoringCase("CNLD");
        Assertions.assertThat(TranslationState.CREATED.getConstValue()).isEqualToIgnoringCase("CRTD");
        Assertions.assertThat(TranslationState.KO_TO_RETRANSLATE.getConstValue()).isEqualToIgnoringCase("RETR");
        Assertions.assertThat(TranslationState.SENT_TO_CORVET.getConstValue()).isEqualToIgnoringCase("STCR");
        Assertions.assertThat(TranslationState.TRANSLATED_DONE.getConstValue()).isEqualToIgnoringCase("TRDN");
        Assertions.assertThat(TranslationState.TRANSLATED_ON_PROGRESS.getConstValue()).isEqualToIgnoringCase("ONPR");
        Assertions.assertThat(CommonConstant.NEGATIVE_MAGIC_NUMBER.getConstValueInt()).isNegative();

    }

}
