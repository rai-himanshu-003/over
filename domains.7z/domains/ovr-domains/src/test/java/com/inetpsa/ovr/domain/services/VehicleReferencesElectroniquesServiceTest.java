/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.ReferencesElectroniques;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleReferencesElectroniquesRepository;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleReferencesElectroniquesServiceTest {

    @Inject
    VehicleReferencesElectroniquesService vehicleReferencesElectroniquesService;

    @Inject
    private VehicleReferencesElectroniquesRepository vehicleReferencesElectroniquesRepository;

    @Test(expected = Exception.class)
    public void vehicleReferencesElectroniquesServiceTest() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVinNo("TESTVIN");

        ReferencesElectroniques referencesElectroniques = new ReferencesElectroniques();
        referencesElectroniques.setData("TestData");
        referencesElectroniques.setVin("TESTVIN");

        Assertions.assertThat(vehicleReferencesElectroniquesService.addOrUpdateReferencesElectroniques(referencesElectroniques)).isNotNull();
        referencesElectroniques.setId(1l);
        vehicleReferencesElectroniquesRepository.add(referencesElectroniques);
        Assertions.assertThat(vehicleReferencesElectroniquesService.addOrUpdateReferencesElectroniques(referencesElectroniques)).isNotNull();

        Assertions.assertThat(vehicleReferencesElectroniquesService.deleteReferencesElectroniquesById(1l)).isTrue();

        Assertions.assertThat(vehicleReferencesElectroniquesService.deleteReferencesElectroniquesById(1L)).isFalse();

        List<ReferencesElectroniques> referencesElectroniquesList = vehicleReferencesElectroniquesService
                .getvehicleReferencesElectroniquesByVin(referencesElectroniques.getVin());

    }

}
