package com.inetpsa.ovr.domain.services;

import java.util.List;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.inetpsa.ovr.domain.model.TechnicalParameter;
import com.inetpsa.ovr.domain.repository.TechnicalParameterRepository;

/**
 * TODO : TechParamServiceTest
 */
@RunWith(SeedITRunner.class)
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class TechParamServiceTest {

    @Inject
    private TechnicalParameterService techParamService;
    TechnicalParameter technicalParameter;

    @Inject
    private TechnicalParameterRepository technicalParameterRepository;

    // @Inject
    // private TestRepository testRepository;

    @Before
    public void setUpData() {
        technicalParameter = new TechnicalParameter();
        technicalParameter.setCode("abc");
        technicalParameter.setValue("10");

    }

    @After
    public void cleanData() {
        technicalParameter = new TechnicalParameter();
        technicalParameter.setCode("abc");
        technicalParameter.setValue("10");
        technicalParameter.prePersist();
        technicalParameter.preUpdate();

    }

    @Test
    public void getTechParamList() {

        technicalParameterRepository.add(technicalParameter);
        List<TechnicalParameter> technicalParameterList = techParamService.getAllTechParam();
        techParamService.getTechParamByCode("abc");
        Assertions.assertThat(technicalParameterList).isNotEmpty();

    }

    @Test
    public void updateParamCase1() {
        boolean status = techParamService.updateParam(technicalParameter);
        Assertions.assertThat(status).isNotNull();
    }

    @Test
    public void updateParamCase2() {
        boolean status = techParamService.updateParam(null);
        Assertions.assertThat(status).isNotNull();
    }

    @Test
    public void deleteParamCase1() {
        boolean status = techParamService.deleteParam(technicalParameter);
        Assertions.assertThat(status).isTrue();
    }

    @Test
    public void deleteParamCase2() {
        technicalParameter.setCode("Test");
        boolean status = techParamService.deleteParam(technicalParameter);
        Assertions.assertThat(status).isFalse();
    }

    @Test
    public void deleteParamCase3() {
        boolean status = techParamService.deleteParam(null);
        Assertions.assertThat(status).isFalse();
    }

}