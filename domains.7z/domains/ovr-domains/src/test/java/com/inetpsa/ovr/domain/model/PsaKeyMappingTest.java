/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class PsaKeyMappingTest {

    @Test
    public void ResponseDto() {
        PsaKeyMapping psaKeyMapping = new PsaKeyMapping();
        Assertions.assertThat(psaKeyMapping).isNotNull();
    }

    @Test
    public void testOvPSaMappingDtoSetGet() {

        PsaKeyMapping psaKeyMapping = new PsaKeyMapping();
        psaKeyMapping.setId((long) 1);
        psaKeyMapping.setPsaDatatype("Test");
        psaKeyMapping.setPsaKey("10");
        psaKeyMapping.setOvStandard("test");
        psaKeyMapping.setOvKey("test");
        psaKeyMapping.setDescription("test");
        psaKeyMapping.setVersion(1);

        Assertions.assertThat(psaKeyMapping.getId()).isEqualTo(1);
        Assertions.assertThat(psaKeyMapping.getDescription()).isEqualTo("test");
        Assertions.assertThat(psaKeyMapping.getPsaDatatype()).isEqualTo("Test");
        Assertions.assertThat(psaKeyMapping.getPsaKey()).isEqualTo("10");
        Assertions.assertThat(psaKeyMapping.getOvStandard()).isEqualTo("test");
        Assertions.assertThat(psaKeyMapping.getOvKey()).isEqualTo("test");
        Assertions.assertThat(psaKeyMapping.getVersion()).isEqualTo(1);

    }

}
