/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.domain.util.LoggedUser;

public class VehicleErrorTest {

    VehicleError vehicleError;
    VehicleErrorPk vehicleErrorPk, vehicleErrorPk1;
    private String vinNo = "VINXXXXXXTEST0032";

    private String errCode = "TE-00001";

    private String errorComplement = "Transcodifiaction Error";
    private String errorDescription = "Transcodifiaction Error";
    private LocalDateTime dateCreation = LocalDateTime.now();;

    private String errMessage = "Transcodifiaction Error";

    @Before
    public void setUpData() {
        LoggedUser.logIn("OVER");
    }

    @After
    public void cleanUpData() {
        LoggedUser.logOut();
    }

    @Test
    public void constructorTesting() {
        vehicleErrorPk = new VehicleErrorPk(vinNo, errCode);
        vehicleError = new VehicleError(vehicleErrorPk, errCode, errorComplement, errorDescription, errMessage);
        Assertions.assertThat(vehicleError).isNotNull();
    }

    @Test
    public void setterGetterTesting() {
        vehicleError = new VehicleError();
        vehicleErrorPk = new VehicleErrorPk();
        vehicleErrorPk.setErrCode(errCode);
        vehicleErrorPk.setVinNo(vinNo);
        vehicleErrorPk.setDateCreation(LocalDateTime.now());
        vehicleError.setErrComplement(errorComplement);
        vehicleError.setErrDescription(errorDescription);
        vehicleError.setErrMessage(errMessage);
        vehicleError.setFlowname("OTT");
        vehicleError.setVehicleErrorPk(vehicleErrorPk);
        vehicleError.prePersist();

        Assertions.assertThat(vehicleErrorPk.getVinNo()).isNotNull();
        Assertions.assertThat(vehicleErrorPk.getErrCode()).isNotNull();
        Assertions.assertThat(vehicleError.getErrComplement()).isNotNull();
        Assertions.assertThat(vehicleError.getErrDescription()).isNotNull();
        Assertions.assertThat(vehicleError.getErrMessage()).isNotNull();
        Assertions.assertThat(vehicleErrorPk.getDateCreation()).isNotNull();
        Assertions.assertThat(vehicleError.getUserCreation()).isNotNull();
        Assertions.assertThat(vehicleError.getFlowname()).isNotNull();
        Assertions.assertThat(vehicleError.getVehicleErrorPk()).isNotNull();
        Assertions.assertThat(vehicleError.toString()).isNotNull();

    }

    @Test
    public void hashcodeAndEqualsTesting() {
        vehicleErrorPk = new VehicleErrorPk();
        vehicleErrorPk.setVinNo(vinNo);
        vehicleErrorPk.setErrCode(errCode);
        vehicleErrorPk.setDateCreation(LocalDateTime.now());

        vehicleErrorPk1 = new VehicleErrorPk();
        vehicleErrorPk1.setVinNo(vinNo);
        vehicleErrorPk1.setErrCode(errCode);
        vehicleErrorPk1.setDateCreation(LocalDateTime.now());

        Assertions.assertThat(vehicleErrorPk.equals(vehicleErrorPk)).isNotNull();
        Assertions.assertThat(vehicleErrorPk.equals(vehicleErrorPk1)).isNotNull();
        Assertions.assertThat(vehicleErrorPk.hashCode()).isNotNull();

    }

}
