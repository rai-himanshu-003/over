/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.google.gson.Gson;
import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.model.Cardinality;
import com.inetpsa.ovr.domain.model.CardinalityPk;
import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.CardinalityRepository;
import com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository;
import com.inetpsa.ovr.domain.repository.VehicleErrorRepository;
import com.inetpsa.ovr.domain.repository.VehicleOptionsRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.interfaces.dto.ws.RequestObj;
import com.inetpsa.ovr.interfaces.dto.ws.ResponseObj;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleOptionsServiceTest {

    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    private VehicleErrorRepository vehicleErrorRepository;

    @Inject
    private PsaKeyMappingRepository keyMappingRepository;

    @Inject
    private CardinalityRepository cardinalityRepository;
    @Inject
    private VehicleOptionsRepository vehicleOptionsRepository;

    @Inject
    private VehicleArtLcdvOttService artLcdvOttService;

    List<Vehicle> vehicles;

    Options options;
    ComposantsOv composantsOv;
    ComposantsOv composantsOv2;
    LcdvOtt lcdvOtt2;
    ArtLcdvOtt artLcdvOtt;

    RequestObj requestObj;

    PsaKeyMapping keyMapping;

    CardinalityPk cardinalityPk;
    Cardinality cardinality;

    Vehicle vehicle;

    @Inject
    VehicleService vehicleService;

    String jsonRequest = "{\r\n" + "    \"HEADER\": {\r\n" + "        \"CLIENT\": \"MZPXXXXXX\"\r\n" + "    },  \r\n" + "    \"CRITERIA\": [\r\n"
            + "        {\r\n" + "            \"VIN\": \"VR7XXXXX1\"\r\n" + "        },\r\n" + "            {\r\n"
            + "            \"VIN\": \"VR7XXXXX1NOVIN\"\r\n" + "        }\r\n" + "        \r\n" + "    ],\r\n" + "    \"RESPONSE\": {\r\n"
            + "        \"VEHICULE_DATA\": [\r\n" + "            \"UP\",\r\n" + "            \"LCDV24\",\r\n" + "            \"OA\",\r\n"
            + "            \"NRE\",\r\n" + "            \"TVV\",\r\n" + "            \"MODEL\",\r\n" + "            \"MODELYEAR\",\r\n"
            + "            \"DATE_EXTENSION\"\r\n" + "        ],\r\n" + "        \"RPO_CODES\": [\r\n" + "            \"%\"\r\n" + "        ],\r\n"
            + "        \"COMPONENTS_OV\": [\r\n" + "            {\"STANDARD\": \"PSA_ORGAN\", \"ID\":\"%\"},\r\n"
            + "            {\"STANDARD\": \"PSA_ORGAN\", \"ID\":\"2%|WT\"},\r\n" + "                {\"STANDARD\": \"GMW15862\", \"ID\":\"%\"},\r\n"
            + "                {\"STANDARD\": \"GMW15862\", \"ID\":\"A%|WT\"}\r\n" + "                \r\n" + "        ],\r\n"
            + "        \"ARTIFICIAL_LCDV\": [\r\n" + "            \"%\"\r\n" + "        ]\r\n" + "    }\r\n" + "}\r\n" + "";

    @Inject
    VehicleOptionsService vehicleOptionsService;

    @Test(expected = Exception.class)
    public void addOrUpdateOptionsTest() {

        // vehicleRepository.add(vehicle);

        Options options = new Options();

        options.setRpoData("TEST");
        options.setVin("test");

        Assertions.assertThat(vehicleOptionsService.addOrUpdateOptions(options)).isNotNull();

        options.setId(1l);
        vehicleOptionsRepository.add(options);
        Assertions.assertThat(vehicleOptionsService.checkOptionsExist("test", "TEST")).isNotNull();

        Assertions.assertThat(vehicleOptionsService.addOrUpdateOptions(options)).isNotNull();
        Assertions.assertThat(vehicleOptionsService.deleteOptionsById(1l)).isTrue();

        Assertions.assertThat(vehicleOptionsService.deleteOptionsById(1L)).isFalse();

        List<Options> optionsList = vehicleOptionsService.getOptionsByVin("test");

        Assertions.assertThat(optionsList).isEmpty();

    }

    @Test
    public void testGetVehicleInformationWs() {
        vehicle = new Vehicle();
        vehicle.setVinNo("VR7XXXXX1");
        vehicle.setCcp("AB");
        vehicle.setVeh("AB");
        vehicle.setUp("AB");
        vehicle.setCcp("AB");
        vehicle.setApvpr("AB");
        vehicle.setOa("AB");
        vehicle.setOf("AB");
        vehicle.setNre("AB");
        vehicle.setTvv("AB");
        vehicle.setLcdv24("AB");
        vehicle.setModel("AB");
        vehicle.setModelYear("AB");
        vehicle.setDateExtension(new Date());
        vehicle.setDateEcom(new Date());
        vehicle.setDateEmon(new Date());

        options = new Options();
        options.setRpoData("abc");
        options.setId(1l);
        options.setVin("VR7XXXXX1");
        Set<Options> optSet = new HashSet<>();
        optSet.add(options);

        vehicle.setOptions(optSet);

        composantsOv = new ComposantsOv();
        composantsOv.setData("TN2192190L9GX0433");
        composantsOv.setEid("Y1210000000000X");
        composantsOv.setLabel("ENGINE_NUMBER");
        composantsOv.setPart("abc");
        composantsOv.setStandard("GMW15862");
        composantsOv.setSupplier("abc");
        composantsOv.setVin("VR7XXXXX1");
        composantsOv.setId(1l);

        composantsOv2 = new ComposantsOv();
        composantsOv2.setData("TN2192190L9GX0400");
        composantsOv2.setEid("Y1210000000000X");
        composantsOv2.setLabel("ENGINE_NUMBER");
        composantsOv2.setPart("abc");
        composantsOv2.setStandard("GMW15862");
        composantsOv2.setSupplier("abcd");
        composantsOv2.setVin("VR7XXXXX1");
        composantsOv2.setId(2l);

        Set<ComposantsOv> comSet = new HashSet<>();
        comSet.add(composantsOv);
        comSet.add(composantsOv2);
        vehicle.setComposantsOv(comSet);

        lcdvOtt2 = new LcdvOtt();
        lcdvOtt2.setId(1l);
        lcdvOtt2.setCharacteristic("abc");
        lcdvOtt2.setIndicator("bb");
        lcdvOtt2.setNature("c");
        lcdvOtt2.setValue("d");
        lcdvOtt2.setVin("VR7XXXXX1");

        artLcdvOtt = new ArtLcdvOtt();
        artLcdvOtt.setCode("A");
        artLcdvOtt.setId(1l);
        artLcdvOtt.setFamily("AA");
        artLcdvOtt.setValue("AA");
        artLcdvOtt.setVin("VR7XXXXX1");

        Set<LcdvOtt> lcdvSet = new HashSet<>();
        lcdvSet.add(lcdvOtt2);

        Set<ArtLcdvOtt> artlcdvSet = new HashSet<>();
        artlcdvSet.add(artLcdvOtt);

        vehicle.setLcdvOttOv(lcdvSet);
        vehicle.setArtLcdvOtt(artlcdvSet);

        vehicleRepository.add(vehicle);
        Gson gson = new Gson();
        requestObj = gson.fromJson(jsonRequest, RequestObj.class);

        keyMapping = new PsaKeyMapping();
        keyMapping.setOvKey("Y1210000000000X");
        keyMapping.setOvStandard("GMW15862");
        keyMapping.setPsaDatatype("PSA_ORGAN");
        keyMapping.setPsaKey("20");
        keyMapping.setDescription("Engine");
        keyMappingRepository.add(keyMapping);

        cardinalityPk = new CardinalityPk();
        cardinalityPk.setPsaDataType("PSA_ORGAN");
        cardinalityPk.setPsaKey("20");

        cardinality = new Cardinality();
        cardinality.setCardinalityPk(cardinalityPk);
        cardinality.setCardinalityValue(3);

        cardinalityRepository.add(cardinality);

        vehicleService.fetchCardinalityByOvStd("GMW15862", "Y1210000000000X");
        ResponseObj responseObj = vehicleService.getVehicleInformationWs(requestObj);

        Assertions.assertThat(responseObj).isNotNull();

        Assertions.assertThat(vehicleOptionsService.checkOptionsExist("VR7XXXXX1", "abc")).isNotNull();
        Assertions.assertThat(vehicleOptionsService.getOptionsExist("VR7XXXXX1", "abc")).isNotNull();

        Assertions.assertThat(artLcdvOttService.checkLcdvExist("VR7XXXXX1", "AAAAA")).isNotNull();
        Assertions.assertThat(artLcdvOttService.getLcdvExist("VR7XXXXX1", "AAAAA")).isNotNull();

    }

}
