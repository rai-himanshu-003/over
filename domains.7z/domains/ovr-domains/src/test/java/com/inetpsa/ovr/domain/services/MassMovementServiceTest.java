package com.inetpsa.ovr.domain.services;

import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.MMVehicleHistory;
import com.inetpsa.ovr.domain.model.TrackChanges;
import com.inetpsa.ovr.domain.repository.TrackChangesRepository;
import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.TrackChangesDto;

/*
 * Creation : 24 Jul 2019
 */
@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class MassMovementServiceTest {

    @Inject
    MassMovementService mms;

    @Inject
    TrackChangesRepository trackChangesRepository;

    TrackChanges trackChanges;

    MMVehicleHistory mmHist;

    @After
    public void cleanUpData() {
        LoggedUser.logOut();
    }

    @Before
    public void setData() {
        trackChanges = new TrackChanges();
        trackChanges.setId(1l);
        trackChanges.setFileName("aaa.xlsx");
        trackChanges.setSuccessCount(1);
        trackChanges.setStatus("IN_PROGRESS");
        mmHist = new MMVehicleHistory();
        mmHist.setId(1l);
        mmHist.setVin("TESTVIN111");

    }

    @Test(expected = Exception.class)
    public void testaddTrackChanges() throws Exception {
        Long id = mms.addTrackChanges("IN_PROGRESS");

        Assertions.assertThat(id).isNotNull();
    }

    @Test(expected = Exception.class)
    public void testupdateTrackChanges() throws Exception {
        trackChangesRepository.add(trackChanges);
        trackChanges.setStatus("COMPLETED");
        mms.updateTrackChanges(trackChanges);
        mms.getById(1l);
        mms.findMaxSize("OVRQTVHL");
        Assertions.assertThat(trackChanges).isNotNull();
    }

    @Test(expected = Exception.class)
    public void addMMHistory() throws Exception {
        mms.addMMHistory(mmHist);
        Assertions.assertThat(trackChanges).isNotNull();
    }

    @Test(expected = Exception.class)
    public void testgetTrackChanges() throws Exception {
        mms.addTrackChanges("IN_PROGRESS");
        List<TrackChangesDto> list = mms.getAllTrackChanges();
        Assertions.assertThat(list).isNotNull();
    }
}
