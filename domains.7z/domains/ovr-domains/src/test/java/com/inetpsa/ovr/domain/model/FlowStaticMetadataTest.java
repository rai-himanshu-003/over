/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class FlowStaticMetadataTest {

    @Test
    public void OvComposantTest() {

        FlowStaticMetadata flowStaticMetadata = new FlowStaticMetadata();

        flowStaticMetadata.setType("test");
        flowStaticMetadata.setId(1l);
        flowStaticMetadata.setValue("test");

        FlowStaticMetadata flowStaticMetadata1 = new FlowStaticMetadata();

        flowStaticMetadata1.setType("test");
        flowStaticMetadata1.setId(1l);
        flowStaticMetadata1.setValue("test1");

        Assertions.assertThat(flowStaticMetadata).isNotNull();
        Assertions.assertThat(flowStaticMetadata.getId()).isNotNull();
        Assertions.assertThat(flowStaticMetadata.getType()).isNotNull();
        Assertions.assertThat(flowStaticMetadata.getValue()).isNotNull();
        Assertions.assertThat(flowStaticMetadata.hashCode()).isNotNull();
        Assertions.assertThat(flowStaticMetadata.toString()).isNotNull();
        Assertions.assertThat(flowStaticMetadata.equals(flowStaticMetadata1)).isNotNull();
        Assertions.assertThat(flowStaticMetadata.maptoDto()).isNotNull();

    }

}
