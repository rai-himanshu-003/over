/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.UserInfo;
import com.inetpsa.ovr.domain.repository.UserInfoRepository;
import com.inetpsa.ovr.interfaces.dto.UserInformationDTO;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class UserInfoServiceTest {

    @Inject
    UserInfoService userInfoService;
    @Inject
    UserInfoRepository userInfoRepository;

    @Test
    public void UserInfoService() {

        UserInfo userInfo = new UserInfo();
        // userInfo.setId((long) 1);
        userInfo.setUserId("E123");
        userInfo.setType("LAN");
        userInfo.setValue("EN");

        UserInformationDTO userInformationDTO = new UserInformationDTO();
        // userInfo.setId((long) 1);
        userInformationDTO.setUserId("E123");
        userInformationDTO.setType("LAN");
        userInformationDTO.setValue("EN");
        Assertions.assertThat(userInfoService.getUserDataByType("E123", "LAN", "EN")).isNull();
        Assertions.assertThat(userInfoService.updateUserInfo(userInformationDTO)).isNotNull();

        userInformationDTO.setId(1l);
        Assertions.assertThat(userInfoService.updateUserInfo(userInformationDTO)).isNotNull();

        // Assertions.assertThat(vehicleuserInfoService.addOrUpdateuserInfo(null)).isFalse();

        Assertions.assertThat(userInfoService.getUserDataByType("E123", "LAN", "EN")).isNotNull();

    }

}
