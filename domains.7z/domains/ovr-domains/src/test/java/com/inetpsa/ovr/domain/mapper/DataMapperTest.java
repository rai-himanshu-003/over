package com.inetpsa.ovr.domain.mapper;

import java.util.HashSet;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;
import com.inetpsa.ovr.interfaces.dto.OvPsaMappingDTO;
import com.inetpsa.ovr.interfaces.dto.VehicleChildDTO;
import com.inetpsa.ovr.interfaces.dto.VehicleDTO;
import com.inetpsa.ovr.interfaces.mapper.DataMapper;

public class DataMapperTest {

    DataMapper dataMapper = null;
    InterfaceRule interfaceRule = null;
    InterfaceRulesDto interfaceRulesDto = null;

    VehicleChildDTO vehicleChildDTO = null;
    VehicleDTO vehicleDTO = null;
    Vehicle vehicle = null;

    PsaKeyMapping psaKeyMapping = null;
    OvPsaMappingDTO ovPsaMappingDTO = null;

    @Before
    public void setUpData() {

        interfaceRule = new InterfaceRule();
        interfaceRule.setIntId(1l);

        interfaceRulesDto = new InterfaceRulesDto();
        interfaceRulesDto.setInterfaceId(1l);

        vehicleChildDTO = new VehicleChildDTO();
        vehicleChildDTO.setOptions(true);
        vehicle = new Vehicle();
        Options options = new Options();
        Set<Options> options2 = new HashSet<>();
        options2.add(options);
        vehicle.setOptions(options2);

        psaKeyMapping = new PsaKeyMapping();
        ovPsaMappingDTO = new OvPsaMappingDTO();

    }

    @Test
    public void mapToDto() {
        interfaceRulesDto = DataMapper.interfaceRulemapToDto(interfaceRule);
        Assertions.assertThat(interfaceRulesDto.toString()).isNotNull();
    }

    @Test
    public void mapTomodel() {
        interfaceRule = DataMapper.mapTomodel(interfaceRulesDto, interfaceRule);
        Assertions.assertThat(interfaceRule.toString()).isNotNull();
    }

    @Test
    public void vehiclemapToDto() {
        vehicleDTO = DataMapper.vehiclemapToDto(vehicle, vehicleChildDTO);
        Assertions.assertThat(interfaceRulesDto.toString()).isNotNull();
    }

    @Test
    public void mapToDtoMapping() {
        ovPsaMappingDTO = DataMapper.psaKeyMappingMapToDto(psaKeyMapping);
        Assertions.assertThat(ovPsaMappingDTO.toString()).isNotNull();
    }

    @Test
    public void mapTomodelMapping() {
        psaKeyMapping = DataMapper.ovPsaMappingDTOMapTomodel(ovPsaMappingDTO, psaKeyMapping);
        Assertions.assertThat(psaKeyMapping.toString()).isNotNull();
    }

}
