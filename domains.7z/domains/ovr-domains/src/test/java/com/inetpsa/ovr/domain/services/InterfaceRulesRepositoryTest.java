/*
 * Creation : 2 Mar 2020
 */
package com.inetpsa.ovr.domain.services;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.domain.repository.InterfaceRepository;
import com.inetpsa.ovr.domain.repository.InterfaceRulesRepository;
import com.inetpsa.ovr.interfaces.dto.CorvetRulesDto;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class InterfaceRulesRepositoryTest {

    InterfaceRule interfaceRule = null;

    @Inject
    private InterfaceRulesRepository interfaceRulesRepository;

    @Inject
    private InterfaceRepository interfaceRepository;

    Interface interfaceObj;

    @Before

    public void setUpData() {
        interfaceRule = new InterfaceRule();
        // interfaceRule.setIntId(1l);
        interfaceRule.setPriority(1);
        interfaceRule.setFilterType(1);
        interfaceRule.setCountry("FR");
        interfaceRule.setVehicleFamily("CK9");
        interfaceRule.setProductionCentre("CK9"); // interfaceRule.setId((long) 1); interfaceRule.setMaxEcom(LocalDateTime.MAX);
        interfaceRule.setMinEcom(new Date());
        interfaceRule.setVersion(0);

        interfaceObj = new Interface();
        interfaceObj.setId(1l);
        interfaceObj.setInterfaceName("GEPICS_TO_OVER");

    }

    @Test
    public void getAllInterfaceRules() {
        interfaceRepository.add(interfaceObj);
        interfaceRulesRepository.add(interfaceRule);
        List<CorvetRulesDto> corvetRulesDto = interfaceRulesRepository.getAllInterfaceRules();
        Assertions.assertThat(corvetRulesDto).isNotNull();
    }

}
