/*
 * Creation : 28 Apr 2020
 */
package com.inetpsa.ovr.domain.dto;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.json.OpFlJson;
import com.inetpsa.ovr.interfaces.dto.json.OpFooter;
import com.inetpsa.ovr.interfaces.dto.json.OpHeader;
import com.inetpsa.ovr.interfaces.dto.json.OpVehicule;
import com.inetpsa.ovr.interfaces.dto.json.OpVehiculeData;
import com.inetpsa.ovr.interfaces.dto.ws.ComponentsOv;

public class OpFlJsonTest {
    OpVehicule opVehicule;
    OpVehiculeData data;
    ComponentsOv componentsOv;
    OpFooter opFooter;
    OpHeader opHeader;
    OpFlJson opFlJson;

    @Before
    public void setup() {
        data = new OpVehiculeData();
        data.setApvpr("ab");
        data.setDateEcom("28041111");
        data.setDateEmon("212121");
        data.setLcdv24("lcdv24");
        data.setModel("ab");
        data.setModelYear("2010");
        data.setCcp("ccp");
        data.setOa("oa");
        data.setOf("of");
        data.setUp("up");
        data.setVeh("veh");
        data.setVin("VINTEST123");

        componentsOv = new ComponentsOv();
        componentsOv.setData("Data");
        componentsOv.setId("1");
        componentsOv.setLabel("label");
        componentsOv.setStandard("standard");
        componentsOv.setSupplier("abc");
        List<ComponentsOv> ovs = new ArrayList<>();
        ovs.add(componentsOv);

        opVehicule = new OpVehicule();
        List<String> artLcdv = new ArrayList<>();
        artLcdv.add("lcdv");

        opVehicule.setArtLcdv(artLcdv);
        opVehicule.setRpo(artLcdv);
        opVehicule.setComponentsOv(ovs);
        opVehicule.setVehiculeData(data);

        List<OpVehicule> vehiculeDatas = new ArrayList<>();
        vehiculeDatas.add(opVehicule);
        opFooter = new OpFooter();
        opFooter.setClient("SAGAI");
        opFooter.setNumberOfRecords("10");
        opFooter.setSender("OVER");

        opHeader = new OpHeader();
        opHeader.setClient("SAGAI");
        opHeader.setSender("OVER");
        opHeader.setSendingDate("01012020");

        opFlJson = new OpFlJson();
        opFlJson.setFooter(opFooter);
        opFlJson.setHeader(opHeader);
        opFlJson.setVehicules(vehiculeDatas);
    }

    @Test
    public void getVehiclesTest() {
        Assertions.assertThat(opFooter.getClient()).isEqualTo("SAGAI");
        Assertions.assertThat(opFooter.getNumberOfRecords()).isEqualTo("10");
        Assertions.assertThat(opFooter.getSender()).isEqualTo("OVER");
        Assertions.assertThat(opHeader.getClient()).isEqualTo("SAGAI");
        Assertions.assertThat(opHeader.getSendingDate()).isEqualTo("01012020");
        Assertions.assertThat(opHeader.getSender()).isEqualTo("OVER");
        Assertions.assertThat(data.getApvpr()).isEqualTo("ab");
        Assertions.assertThat(data.getDateEcom()).isEqualTo("28041111");
        Assertions.assertThat(data.getDateEmon()).isEqualTo("212121");
        Assertions.assertThat(data.getLcdv24()).isEqualTo("lcdv24");
        Assertions.assertThat(data.getModel()).isEqualTo("ab");
        Assertions.assertThat(data.getModelYear()).isEqualTo("2010");
        Assertions.assertThat(data.getCcp()).isEqualTo("ccp");
        Assertions.assertThat(data.getOa()).isEqualTo("oa");
        Assertions.assertThat(data.getVeh()).isEqualTo("veh");
        Assertions.assertThat(data.getOf()).isEqualTo("of");
        Assertions.assertThat(data.getUp()).isEqualTo("up");
        Assertions.assertThat(data.getVin()).isEqualTo("VINTEST123");
        Assertions.assertThat(opVehicule.getArtLcdv()).isNotEmpty();
        Assertions.assertThat(opVehicule.getRpo()).isNotEmpty();
        Assertions.assertThat(opVehicule.getComponentsOv()).isNotEmpty();
        Assertions.assertThat(opVehicule.getVehiculeData()).isNotNull();
        Assertions.assertThat(data.getVin()).isEqualTo("VINTEST123");
        Assertions.assertThat(opFlJson.getFooter()).isNotNull();
        Assertions.assertThat(opFlJson.getHeader()).isNotNull();
        Assertions.assertThat(opFlJson.getVehicules()).isNotEmpty();

    }

}
