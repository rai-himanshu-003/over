/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.util.ArrayList;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.PaginationDto;

public class TestPaginationDto {

    @Test
    public void ResponseDto() {
        PaginationDto<String> paginationDto = new PaginationDto<>();
        Assertions.assertThat(paginationDto).isNotNull();
    }

    @Test
    public void testResponseDtoSetGet() {

        PaginationDto<String> paginationDto = new PaginationDto<>();
        paginationDto.setTotalRecords(100);

        paginationDto.setResponseList(new ArrayList<String>());
        paginationDto.setPageNumber(10);
        paginationDto.setPageSize(5);
        Assertions.assertThat(paginationDto.getTotalRecords()).isEqualTo(100);
        Assertions.assertThat(paginationDto.getPageNumber()).isEqualTo(10);
        Assertions.assertThat(paginationDto.getResponseList()).isNotNull();
        Assertions.assertThat(paginationDto.getPageSize()).isEqualTo(5);

        Assertions.assertThat(paginationDto.toString()).isNotNull();
    }

}
