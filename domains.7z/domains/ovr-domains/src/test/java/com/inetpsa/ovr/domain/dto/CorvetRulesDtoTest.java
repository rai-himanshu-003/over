/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.CorvetRulesDto;

public class CorvetRulesDtoTest {

    @Test
    public void optionsTest() {

        CorvetRulesDto corvetRulesDto = new CorvetRulesDto(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        corvetRulesDto.setCountry("FR");
        corvetRulesDto.setFilterType(1);
        corvetRulesDto.setId(1l);
        corvetRulesDto.setInterfaceName("OTT");
        corvetRulesDto.setPriority(1);
        corvetRulesDto.setProductionCentre("CCP");
        corvetRulesDto.setUserCreation("OVER");
        corvetRulesDto.setDateCreation(new Date());
        corvetRulesDto.setVin("VTEST");
        corvetRulesDto.setDateModif(null);
        corvetRulesDto.setUserModif("OVER");
        corvetRulesDto.setMaxEcom(new Date());
        corvetRulesDto.setMinEcom(new Date());
        corvetRulesDto.toString();
        corvetRulesDto.setVersion(1);
        corvetRulesDto.setVehicleFamily("VEH");

        Assertions.assertThat(corvetRulesDto).isNotNull();
        Assertions.assertThat(corvetRulesDto.getId()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getProductionCentre()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getVin()).isNotNull();
        Assertions.assertThat(corvetRulesDto.toString()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getPriority()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getCountry()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getInterfaceName()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getUserCreation()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getUserModif()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getDateCreation()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getDateModif()).isNull();
        Assertions.assertThat(corvetRulesDto.getMaxEcom()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getMinEcom()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getVersion()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getVehicleFamily()).isNotNull();
        Assertions.assertThat(corvetRulesDto.getFilterType()).isNotNull();

    }

}
