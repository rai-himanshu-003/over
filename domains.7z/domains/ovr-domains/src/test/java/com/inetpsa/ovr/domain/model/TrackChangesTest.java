/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.TrackChangesDto;

public class TrackChangesTest {

    @Test
    public void ResponseDto() {
        TrackChanges trackChanges = new TrackChanges();
        Assertions.assertThat(trackChanges).isNotNull();
    }

    @Test
    public void testSetGet() {

        TrackChanges trackChanges = new TrackChanges();
        TrackChangesDto trackChangesDto = new TrackChangesDto();
        trackChanges.setId((long) 1);
        trackChanges.setFileName("mm.xlsx");
        trackChanges.setDateCreation(new Date());
        trackChanges.setEndDate(new Date());
        trackChanges.setErrorCount(1);
        trackChanges.setStartDate(new Date());
        trackChanges.setStatus("COMPLETED");
        trackChanges.setSuccessCount(1);
        trackChanges.setTotalCount(2);
        trackChanges.setUserCreation("E566559");
        trackChanges.prePersist();
        trackChanges.toString();

        trackChangesDto.setFileName("mm.xlsx");
        trackChangesDto.setDateCreation(new Date());
        trackChangesDto.setEndDate(new Date());
        trackChangesDto.setErrorCount(1);
        trackChangesDto.setStartDate(new Date());
        trackChangesDto.setStatus("COMPLETED");
        trackChangesDto.setSuccessCount(1);
        trackChangesDto.setTotalCount(2);
        trackChangesDto.setUserCreation("E566559");
        trackChangesDto.setDuration("1");
        trackChangesDto.setId(1l);

        Assertions.assertThat(trackChangesDto.getId()).isNotNull();
        Assertions.assertThat(trackChangesDto.getDateCreation()).isNotNull();
        Assertions.assertThat(trackChangesDto.getEndDate()).isNotNull();
        Assertions.assertThat(trackChangesDto.getErrorCount()).isNotNull();
        Assertions.assertThat(trackChangesDto.getFileName()).isNotNull();
        Assertions.assertThat(trackChangesDto.getStartDate()).isNotNull();
        Assertions.assertThat(trackChangesDto.getStatus()).isNotNull();
        Assertions.assertThat(trackChangesDto.getSuccessCount()).isNotNull();
        Assertions.assertThat(trackChangesDto.getTotalCount()).isNotNull();
        Assertions.assertThat(trackChangesDto.getUserCreation()).isNotNull();
        Assertions.assertThat(trackChangesDto.getDuration()).isNotNull();

        Assertions.assertThat(trackChanges.getId()).isNotNull();
        Assertions.assertThat(trackChanges.getDateCreation()).isNotNull();
        Assertions.assertThat(trackChanges.getEndDate()).isNotNull();
        Assertions.assertThat(trackChanges.getErrorCount()).isNotNull();
        Assertions.assertThat(trackChanges.getFileName()).isNotNull();
        Assertions.assertThat(trackChanges.getStartDate()).isNotNull();
        Assertions.assertThat(trackChanges.getStatus()).isNotNull();
        Assertions.assertThat(trackChanges.getSuccessCount()).isNotNull();
        Assertions.assertThat(trackChanges.getTotalCount()).isNotNull();

    }

}
