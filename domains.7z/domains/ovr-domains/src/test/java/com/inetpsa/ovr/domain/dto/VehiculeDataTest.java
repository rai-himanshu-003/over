/*
 * Creation : 24 Jan 2020
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.ws.VehiculeData;

public class VehiculeDataTest {
    VehiculeData data;

    @Before
    public void setup() {
        data = new VehiculeData();
        data.setApvpr("ab");
        data.setDateEcom("28041111");
        data.setDateEmon("212121");
        data.setDateExtension("12121212");
        data.setLcdv24("lcdv24");
        data.setModel("ab");
        data.setModelYear("2010");
        data.setNre("nre");
        data.setOa("oa");
        data.setTvv("of");
        data.setOf("of");
        data.setUp("up");
    }

    @Test
    public void getVehiclesTest() {
        Assertions.assertThat(data.getApvpr()).isEqualTo("ab");
        Assertions.assertThat(data.getDateEcom()).isEqualTo("28041111");
        Assertions.assertThat(data.getDateEmon()).isEqualTo("212121");
        Assertions.assertThat(data.getDateExtension()).isEqualTo("12121212");
        Assertions.assertThat(data.getLcdv24()).isEqualTo("lcdv24");
        Assertions.assertThat(data.getModel()).isEqualTo("ab");
        Assertions.assertThat(data.getModelYear()).isEqualTo("2010");
        Assertions.assertThat(data.getNre()).isEqualTo("nre");
        Assertions.assertThat(data.getOa()).isEqualTo("oa");
        Assertions.assertThat(data.getTvv()).isEqualTo("of");
        Assertions.assertThat(data.getOf()).isEqualTo("of");
        Assertions.assertThat(data.getUp()).isEqualTo("up");

    }

}
