/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

@RunWith(SeedITRunner.class)
public class InterfaceStatusTest {

    InterfaceStatus interfaceStatus;

    @Test
    public void constructorTesting() {
        interfaceStatus = new InterfaceStatus("TestInterface", "TestStatus");
        Assertions.assertThat(interfaceStatus).isNotNull();
    }

    @Test
    public void setterGetterTesting() {
        interfaceStatus = new InterfaceStatus();

        interfaceStatus.setInterfaceName("TestInterface");
        interfaceStatus.setStatus("TestStatus");

        Assertions.assertThat(interfaceStatus.getInterfaceName()).isEqualToIgnoringCase("TestInterface");
        Assertions.assertThat(interfaceStatus.getStatus()).isEqualToIgnoringCase("TestStatus");
        Assertions.assertThat(interfaceStatus.getUserModif()).isNull();
        Assertions.assertThat(interfaceStatus.getDateModif()).isNull();

    }

}
