/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;

public class InterfaceRuleDtoTest {

    @Test
    public void ResponseDto() {
        InterfaceRulesDto interfaceRulesDto = new InterfaceRulesDto();
        Assertions.assertThat(interfaceRulesDto).isNotNull();
    }

    @Test
    public void testInterfaceRulesDtoSetGet() {

        InterfaceRulesDto interfaceRulesDto = new InterfaceRulesDto();
        interfaceRulesDto.setId((long) 1);
        interfaceRulesDto.setInterfaceId((long) 1);
        interfaceRulesDto.setPriority(1);
        interfaceRulesDto.setTypeOfFilter(1);
        interfaceRulesDto.setFamilyOfVehicle("CK9");
        interfaceRulesDto.setCountry("FR");
        interfaceRulesDto.setVin("VINTest");
        interfaceRulesDto.setProductionCentre("FV");
        interfaceRulesDto.setMinEcomDate(new Date());
        interfaceRulesDto.setMaxEcomDate(new Date());
        interfaceRulesDto.setDateCreation(new Date());
        interfaceRulesDto.setVersion(1);

        Assertions.assertThat(interfaceRulesDto.getInterfaceId()).isEqualTo(1);
        Assertions.assertThat(interfaceRulesDto.getId()).isEqualTo(1);
        Assertions.assertThat(interfaceRulesDto.getPriority()).isEqualTo(1);
        Assertions.assertThat(interfaceRulesDto.getTypeOfFilter()).isEqualTo(1);
        Assertions.assertThat(interfaceRulesDto.getFamilyOfVehicle()).isEqualTo("CK9");
        Assertions.assertThat(interfaceRulesDto.getProductionCentre()).isEqualTo("FV");
        Assertions.assertThat(interfaceRulesDto.getCountry()).isEqualTo("FR");
        Assertions.assertThat(interfaceRulesDto.getVersion()).isEqualTo(1);
        Assertions.assertThat(interfaceRulesDto.getVin()).isEqualTo("VINTest");
        Assertions.assertThat(interfaceRulesDto.getMaxEcomDate()).isNotNull();
        Assertions.assertThat(interfaceRulesDto.getMinEcomDate()).isNotNull();
        Assertions.assertThat(InterfaceRulesDto.getSerialversionuid()).isNotNull();
        Assertions.assertThat(interfaceRulesDto.getDateCreation()).isNotNull();

    }

}
