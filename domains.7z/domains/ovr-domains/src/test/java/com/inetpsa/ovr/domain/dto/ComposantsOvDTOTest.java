/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.interfaces.dto.ComposantsOvDTO;

public class ComposantsOvDTOTest {

    @Test
    public void composantsOvTest() {

        ComposantsOv composantsOv = new ComposantsOv();
        composantsOv.setId(1L);
        composantsOv.setData("TEST");
        composantsOv.setEid("TEST");
        composantsOv.setLabel("TEST");
        composantsOv.setStandard("TEST");
        composantsOv.setVin("TESTVIN");
        composantsOv.setPart("TEST");
        composantsOv.setSupplier("TEST");

        ComposantsOv composantsOv1 = new ComposantsOv();
        composantsOv1.setId(1L);
        composantsOv1.setData("TEST");
        composantsOv1.setEid("TEST");
        composantsOv1.setLabel("TEST");
        composantsOv1.setStandard("TEST");
        composantsOv1.setVin("TESTVIN");
        composantsOv1.setPart("TEST");
        composantsOv1.setSupplier("TEST");

        Assertions.assertThat(composantsOv).isNotNull();
        Assertions.assertThat(composantsOv.getId()).isNotNull();
        Assertions.assertThat(composantsOv.getEid()).isNotNull();
        Assertions.assertThat(composantsOv.getVin()).isNotNull();
        Assertions.assertThat(composantsOv.getStandard()).isNotNull();
        Assertions.assertThat(composantsOv.getLabel()).isNotNull();
        Assertions.assertThat(composantsOv.getData()).isNotNull();
        Assertions.assertThat(composantsOv.getSupplier()).isNotNull();
        Assertions.assertThat(composantsOv.getPart()).isNotNull();
        Assertions.assertThat(composantsOv.toString()).isNotNull();
        Assertions.assertThat(composantsOv.maptoDto()).isNotNull();
        Assertions.assertThat(composantsOv.hashCode()).isNotNull();
        Assertions.assertThat(composantsOv.equals(composantsOv1)).isNotNull();

    }

    @Test
    public void omposantsOvDTOTest() {

        ComposantsOvDTO composantsOv = new ComposantsOvDTO();
        composantsOv.setId(1L);
        composantsOv.setData("TEST");
        composantsOv.setEid("TEST");
        composantsOv.setLabel("TEST");
        composantsOv.setStandard("TEST");
        composantsOv.setVin("TESTVIN");
        composantsOv.setPart("TEST");
        composantsOv.setSupplier("TEST");

        Assertions.assertThat(composantsOv).isNotNull();
        Assertions.assertThat(composantsOv.getId()).isNotNull();
        Assertions.assertThat(composantsOv.getEid()).isNotNull();
        Assertions.assertThat(composantsOv.getVin()).isNotNull();
        Assertions.assertThat(composantsOv.getStandard()).isNotNull();
        Assertions.assertThat(composantsOv.getLabel()).isNotNull();
        Assertions.assertThat(composantsOv.getData()).isNotNull();
        Assertions.assertThat(composantsOv.getSupplier()).isNotNull();
        Assertions.assertThat(composantsOv.getPart()).isNotNull();
        Assertions.assertThat(composantsOv.toString()).isNotNull();
        Assertions.assertThat(composantsOv.mapTomodel()).isNotNull();

    }

}
