/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class ArtLcdvOttTest {

    @Test
    public void ResponseDto() {
        ArtLcdvOtt artLcdvOtt = new ArtLcdvOtt();
        Assertions.assertThat(artLcdvOtt).isNotNull();
    }

    @Test
    public void testOvPSaMappingDtoSetGet() {

        ArtLcdvOtt artLcdvOtt = new ArtLcdvOtt();
        artLcdvOtt.setId((long) 1);
        artLcdvOtt.setCode("Test");
        artLcdvOtt.setFamily("10");
        artLcdvOtt.setVin("test");
        artLcdvOtt.setValue("test");

        Assertions.assertThat(artLcdvOtt.getId()).isEqualTo(1);
        Assertions.assertThat(artLcdvOtt.getFamily()).isEqualTo("10");
        Assertions.assertThat(artLcdvOtt.getCode()).isEqualTo("Test");
        Assertions.assertThat(artLcdvOtt.getVin()).isEqualTo("test");
        Assertions.assertThat(artLcdvOtt.getValue()).isEqualTo("test");
        Assertions.assertThat(artLcdvOtt.maptoDto()).isNotNull();
        artLcdvOtt.toString();
        artLcdvOtt.equals(new ArtLcdvOtt());
        artLcdvOtt.hashCode();

    }

}
