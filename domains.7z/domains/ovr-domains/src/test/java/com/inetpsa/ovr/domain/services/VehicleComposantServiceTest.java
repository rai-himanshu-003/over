/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.Composants;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleComposantsRepository;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleComposantServiceTest {

    @Inject
    VehicleComposantService vehicleComposantService;

    @Inject
    private VehicleComposantsRepository vehicleComposantsRepository;

    @Test(expected = Exception.class)
    public void vehicleReferencesElectroniquesServiceTest() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVinNo("TESTVIN");

        Composants composants = new Composants();
        composants.setData("TestData");
        composants.setVin("TESTVIN");

        Assertions.assertThat(vehicleComposantService.addOrUpdateComposants(composants)).isNotNull();
        composants.setId(1l);
        vehicleComposantsRepository.add(composants);
        Assertions.assertThat(vehicleComposantService.addOrUpdateComposants(composants)).isNotNull();

        Assertions.assertThat(vehicleComposantService.deleteComposantsById(1l)).isTrue();

        Assertions.assertThat(vehicleComposantService.deleteComposantsById(1L)).isFalse();
        List<Composants> composantsList = vehicleComposantService.getComposantsByVin("TESTVIN");

    }

}
