/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.UserInfo;
import com.inetpsa.ovr.interfaces.dto.UserInformationDTO;

public class UserInfoDTOTest {

    @Test
    public void UserInfoTest() {

        UserInformationDTO userInformationDTO = new UserInformationDTO();

        userInformationDTO.setId(1L);
        userInformationDTO.setUserId("VE");
        userInformationDTO.setType("A");
        userInformationDTO.setValue("VIN");

        Assertions.assertThat(userInformationDTO).isNotNull();
        Assertions.assertThat(userInformationDTO.getId()).isNotNull();
        Assertions.assertThat(userInformationDTO.getUserId()).isNotNull();
        Assertions.assertThat(userInformationDTO.getType()).isNotNull();
        Assertions.assertThat(userInformationDTO.getValue()).isNotNull();
        Assertions.assertThat(userInformationDTO.mapTomodel(new UserInfo())).isNotNull();
        userInformationDTO.toString();

    }

}
