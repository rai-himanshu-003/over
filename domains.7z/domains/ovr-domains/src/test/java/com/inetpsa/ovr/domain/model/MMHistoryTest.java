/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class MMHistoryTest {

    @Test
    public void ResponseDto() {
        MMVehicleHistory mmVehicleHistory = new MMVehicleHistory();
        Assertions.assertThat(mmVehicleHistory).isNotNull();
    }

    @Test
    public void testOvPSaMappingDtoSetGet() {

        MMVehicleHistory mmVehicleHistory = new MMVehicleHistory();
        mmVehicleHistory.setId((long) 1);
        mmVehicleHistory.setActionType("C");
        mmVehicleHistory.setData("x");
        mmVehicleHistory.setId1("1");
        mmVehicleHistory.setIdTech("1");
        mmVehicleHistory.setLabel("XZ");
        mmVehicleHistory.setOldValue("AA");
        mmVehicleHistory.setOperationDate(new Date());
        mmVehicleHistory.setPart("Sensor");
        mmVehicleHistory.setStandard("GM1737");
        mmVehicleHistory.setSupplier("GM");
        mmVehicleHistory.setTypeData("RPO");
        mmVehicleHistory.setUserId("E566559");
        mmVehicleHistory.setValue("a1");
        mmVehicleHistory.setVin("VIN11111111");
        mmVehicleHistory.prePersist();

        Assertions.assertThat(mmVehicleHistory.getActionType()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getData()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getId()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getId1()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getIdTech()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getLabel()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getOldValue()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getOperationDate()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getPart()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getStandard()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getSupplier()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getTypeData()).isNotNull();

        Assertions.assertThat(mmVehicleHistory.getValue()).isNotNull();
        Assertions.assertThat(mmVehicleHistory.getVin()).isNotNull();
    }

}
