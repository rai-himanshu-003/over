package com.inetpsa.ovr.domain.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.model.Cardinality;
import com.inetpsa.ovr.domain.model.CardinalityPk;
import com.inetpsa.ovr.domain.model.Composants;
import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.KeysOv;
import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.domain.model.MMVehicleHistory;
import com.inetpsa.ovr.domain.model.MultipleFlowStatus;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.model.ReferencesElectroniques;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.model.VehicleError;
import com.inetpsa.ovr.domain.model.VehicleErrorPk;
import com.inetpsa.ovr.domain.model.VehicleHistory;
import com.inetpsa.ovr.domain.model.VehicleHistoryPk;
import com.inetpsa.ovr.domain.repository.LcdvOttRepository;
import com.inetpsa.ovr.domain.repository.MMVehicleHistoryRepository;
import com.inetpsa.ovr.domain.repository.VehicleErrorRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;
import com.inetpsa.ovr.interfaces.dto.ws.RequestObj;

/*
 * Creation : 24 Jul 2019
 */
@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleServiceTest {
    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    private VehicleErrorRepository vehicleErrorRepository;

    @Inject
    MultipleFlowStatusService multipleFlowStatusService;
    @Inject
    private MMVehicleHistoryRepository mmVehicleHistoryRepository;

    Vehicle vehicle;

    private String vinNo = "VINXXXXXXTEST0000";

    private String currentState = "KOTR";

    private String ccp = "10";

    private String veh = "AA";

    private String xmlOv = "<?xml version='1.0' encoding='UTF-8'?><MESSAGE><ENTETE></ENTETE><CONTENU><VEHICULE><CAR_VEH><VIN>VINXXXXXXTEST0031</VIN><LCDV24>1CK9AFSLGKB0A010M0EUOGFR</LCDV24><DATE_EXTENSION>20190521</DATE_EXTENSION></CAR_VEH></VEHICULE></CONTENU></MESSAGE>";

    private Date dateExtension = new java.util.Date("01/01/2019");

    private String lcdvOtt = "BPCDVINXXXXXXTEST0032   U920190528SSSE2GK0F3TPG1C0A0D0M0F4OVFXOO   03GC930A GC19GA GG819A ";

    private LocalDate extFromDate = LocalDate.MAX;;
    private LocalDate extToDate = LocalDate.MAX;;
    private int offsetPositionToStartFrom = 0;
    private String codeErr;
    private String labelErr;
    private String errCmp;
    private LocalDate errFromDate;
    private LocalDate errToDate;
    private int rowsPerPage = 10;
    private Long countL = 0L;
    @Inject
    VehicleService vehicleService;
    ResendToOTTDto resendToOTTDtoTest, resendToOTTDtoTest1;
    List<ResendToOTTDto> dtos;
    MultipleFlowStatusDTO multipleFlowStatusDTO;
    VehicleError vehicleError;
    VehicleErrorPk vehicleErrorPk;
    private String userCreation = "OVER";
    private String flowname = "Test";

    List<Vehicle> vehicles;

    VehicleHistory vehicleHistory;

    VehicleHistoryPk vehicleHistoryPk;

    List<VehicleHistory> vehicleHistories;
    List<ResendToOTTDto> resendToOTTDtos;
    List<Object[]> arrayList;

    VehicleDetailsDto vehicleDetailsDto;

    Options options;
    ComposantsOv composantsOv;
    ComposantsOv composantsOv2;
    LcdvOtt lcdvOtt2;

    RequestObj requestObj;

    PsaKeyMapping keyMapping;

    CardinalityPk cardinalityPk;
    Cardinality cardinality;

    @Inject
    LcdvOttRepository lcdvOttrepo;

    List<MultipleFlowStatusDTO> multipleFlowStatusDTOs;
    MMVehicleHistory mmVehicleHistory;

    String jsonRequest = "{\r\n" + "    \"HEADER\": {\r\n" + "        \"CLIENT\": \"MZPXXXXXX\"\r\n" + "    },  \r\n" + "    \"CRITERIA\": [\r\n"
            + "        {\r\n" + "            \"VIN\": \"VR7XXXXX1TESTNEW7\"\r\n" + "        },\r\n" + "            {\r\n"
            + "            \"VIN\": \"VR7XXXXX1NOVIN\"\r\n" + "        }\r\n" + "        \r\n" + "    ],\r\n" + "    \"RESPONSE\": {\r\n"
            + "        \"VEHICULE_DATA\": [\r\n" + "            \"UP\",\r\n" + "            \"LCDV24\",\r\n" + "            \"OA\",\r\n"
            + "            \"NRE\",\r\n" + "            \"TVV\",\r\n" + "            \"MODEL\",\r\n" + "            \"MODELYEAR\",\r\n"
            + "            \"DATE_EXTENSION\"\r\n" + "        ],\r\n" + "        \"RPO_CODES\": [\r\n" + "            \"%\"\r\n" + "        ],\r\n"
            + "        \"COMPONENTS_OV\": [\r\n" + "            {\"STANDARD\": \"PSA_ORGAN\", \"ID\":\"%\"},\r\n"
            + "            {\"STANDARD\": \"PSA_ORGAN\", \"ID\":\"2%|WT\"},\r\n" + "                {\"STANDARD\": \"GMW15862\", \"ID\":\"%\"},\r\n"
            + "                {\"STANDARD\": \"GMW15862\", \"ID\":\"A%|WT\"}\r\n" + "                \r\n" + "        ],\r\n"
            + "        \"ARTIFICIAL_LCDV\": [\r\n" + "            \"%\"\r\n" + "        ]\r\n" + "    }\r\n" + "}\r\n" + "";

    @After
    public void cleanUpData() {
        LoggedUser.logOut();
    }

    @Before
    public void setData() {

        vehicleErrorPk = new VehicleErrorPk("VINXXXXXXTEST0000", "TE-10001");
        vehicleError = new VehicleError(vehicleErrorPk, "OVER", "abc", "label", "abc");

        resendToOTTDtoTest = new ResendToOTTDto();
        resendToOTTDtoTest1 = new ResendToOTTDto();

        resendToOTTDtoTest1.setVin("VINXXXXXXTEST0002");
        resendToOTTDtoTest.setVin("VINXXXXXXTEST0001");
        resendToOTTDtoTest.setCcp("1");
        resendToOTTDtoTest.setVeh("A");
        resendToOTTDtoTest.setCodeErr("TE-10001");
        resendToOTTDtoTest.setLabelErr("LABEL");
        resendToOTTDtoTest.setComplementErr("A");
        resendToOTTDtoTest.setExtFromDate("01/01/2019");
        resendToOTTDtoTest.setExtToDate("10/01/2019");
        // resendToOTTDtoTest.setErrFromDate("02/01/2019");
        // resendToOTTDtoTest.setErrToDate("02/01/2019");
        resendToOTTDtoTest.setComplementErr("A");
        resendToOTTDtoTest.setVinOrder("ASC");
        resendToOTTDtoTest.setCcpOrder("ASC");
        resendToOTTDtoTest.setVehOrder("ASC");
        resendToOTTDtoTest.setCodeErrOrder("ASC");
        resendToOTTDtoTest.setLabelErrOrder("ASC");
        resendToOTTDtoTest.setComplementErrOrder("ASC");
        resendToOTTDtoTest.setExtDateOrder("ASC");
        resendToOTTDtoTest.setErrDateOrder("ASC");
        resendToOTTDtoTest.setFlowName("OTT");

        LoggedUser.logIn("OVER");
        vehicle = new Vehicle(vinNo, currentState, ccp, veh, dateExtension, "OVER", LocalDateTime.now(), 1);

        vehicles = new ArrayList<>();
        vehicleHistories = new ArrayList<>();
        vehicleHistoryPk = new VehicleHistoryPk(vinNo, currentState);
        vehicleHistory = new VehicleHistory(vehicleHistoryPk, userCreation, "flowname");
        vehicles.add(vehicle);

        vehicleHistory.prePersist();
        vehicleHistories.add(vehicleHistory);
        resendToOTTDtos = new ArrayList<>();
        arrayList = new ArrayList<>();
        Object[] arr = { "vin", "ccp", "veh", "01/01/2019", "code", "label", "cmp", "01/01/2019" };
        arrayList.add(arr);

        vehicleDetailsDto = new VehicleDetailsDto();
        vehicleDetailsDto.setVin("V123");
        vehicleDetailsDto.setCcp("XY");
        vehicleDetailsDto.setVeh("V123");
        vehicleDetailsDto.setApvpr("XY");
        vehicleDetailsDto.setOa("V123");
        vehicleDetailsDto.setOf("XY");
        vehicleDetailsDto.setNre("V123");
        vehicleDetailsDto.setTvv("XY");
        vehicleDetailsDto.setModel("V123");
        vehicleDetailsDto.setModelYear("XY");
        vehicleDetailsDto.setUp("V123");
        vehicleDetailsDto.setLcdv24("XY");
        vehicleDetailsDto.setVersion(1);
        vehicleDetailsDto.setDateExtension(new Date());
        vehicleDetailsDto.setDateEcom(new Date());
        vehicleDetailsDto.setDateEmon(new Date());

        multipleFlowStatusDTO = new MultipleFlowStatusDTO();
        multipleFlowStatusDTO.setFlow("OTT");
        multipleFlowStatusDTO.setStatus("CRTD");
        multipleFlowStatusDTO.setVin("VINXXXXXXTEST0002");
        multipleFlowStatusDTO.setVersion(1);
        multipleFlowStatusDTO.setId(3l);
        multipleFlowStatusDTOs = new ArrayList<>();
        multipleFlowStatusDTOs.add(multipleFlowStatusDTO);
        vehicleDetailsDto.setMultipleFlowStatusDTO(multipleFlowStatusDTOs);
        // vehicleRepository.add(vehicle);
    }

    @Test
    public void testGetVehicleDetails() throws Exception {
        vehicleRepository.add(vehicle);
        Vehicle vehicle = vehicleService.getVehicleDetails(vinNo);

        Assertions.assertThat(vehicle).isNotNull();
        vehicleService.getOvVehicleDetails(vinNo);

    }

    @Test
    public void getErrList() {
        // vehicle.setVinNo("VINXXXXXXTEST0001");
        //
        // vehicleRepository.add(vehicle);
        // vehicleErrorRepository.add(vehicleError);
        List<ResendToOTTDto> resendToOTTDtos = vehicleService.getErrList(resendToOTTDtoTest, offsetPositionToStartFrom, rowsPerPage, false);
        Assertions.assertThat(resendToOTTDtos).isNotNull();

    }

    @Test
    public void getErrListtrue() {
        // vehicle.setVinNo("VINXXXXXXTEST0002");
        //
        // vehicleRepository.add(vehicle);
        // vehicleErrorRepository.add(vehicleError);
        List<ResendToOTTDto> resendToOTTDtos = vehicleService.getErrList(resendToOTTDtoTest, offsetPositionToStartFrom, rowsPerPage, true);
        Assertions.assertThat(resendToOTTDtos).isNotNull();

    }

    @Test
    public void testgetTotalRecords() {

        vehicleErrorRepository.add(vehicleError);
        long res = vehicleService.getTotalErrRecords(resendToOTTDtoTest, false);
        Assertions.assertThat(res).isNotNull();
    }

    @Test
    public void testgetTotalRecordstrue() {

        vehicleErrorRepository.add(vehicleError);
        long res = vehicleService.getTotalErrRecords(resendToOTTDtoTest, true);
        Assertions.assertThat(res).isNotNull();
    }

    @Test
    public void testgetTotalRecordsfalse() {

        vehicleErrorRepository.add(vehicleError);
        long res = vehicleService.getTotalErrRecords(resendToOTTDtoTest, false);
        Assertions.assertThat(res).isNotNull();
    }

    @Test(expected = Exception.class)
    public void testUpdateVehicles() {

        vehicleService.addVehicles(vehicles, flowname);
        vehicleService.updateVehicles(vehicles, flowname, null, null);
        Assertions.assertThat(vehicles).isNotNull();
    }

    @Test(expected = Exception.class)
    public void testaddVehicles() {

        vehicleService.addVehicles(vehicles, flowname);
        // vehicleService.updateVehicles(vehicles, flowname, multipleFlowStatusDTOs);
        Assertions.assertThat(vehicles).isNotNull();
    }

    @Test
    public void testUpdateVehicle() throws Exception {
        vehicle.setVinNo("VINXXXXXXTEST0001");

        vehicleRepository.add(vehicle);
        Set<ComposantsOv> composantsOv = new HashSet<>();

        ComposantsOv composantsOvObj = new ComposantsOv();
        composantsOvObj.setVin("VINXXXXXXTEST0001");
        composantsOvObj.setData("Test");
        composantsOvObj.setEid("1");
        composantsOvObj.setLabel("Test");
        composantsOvObj.setPart("Test");
        composantsOvObj.setStandard("Test");
        composantsOvObj.setSupplier("Test");
        composantsOvObj.setId(1l);

        composantsOv.add(composantsOvObj);

        Set<KeysOv> keysOvSet = new HashSet<>();

        KeysOv keysOv = new KeysOv();
        keysOv.setVin("VINXXXXXXTEST0001");
        keysOv.setData("Test");
        keysOv.setEid("1");
        // keysOv.setId(1l);
        keysOv.setLabel("Test");
        keysOv.setStandard("Test");
        keysOvSet.add(keysOv);

        Set<LcdvOtt> lcdvOttSet = new HashSet<>();

        LcdvOtt lcdvOtt = new LcdvOtt();
        lcdvOtt.setVin("VINXXXXXXTEST0001");
        lcdvOtt.setId(1L);
        lcdvOtt.setCharacteristic("tes");
        lcdvOtt.setIndicator("11");
        lcdvOtt.setNature("1");
        lcdvOtt.setValue("1");
        lcdvOttSet.add(lcdvOtt);

        Set<Composants> composantsSet = new HashSet<>();

        Composants composants = new Composants();
        composants.setData("Test");
        composants.setVin("VINXXXXXXTEST0001");
        composants.setId(1l);
        composantsSet.add(composants);

        Set<Options> optionsSet = new HashSet<>();

        Options options = new Options();
        options.setRpoData("ABC");
        options.setId(1l);
        options.setVin("VINXXXXXXTEST0001");

        List<MultipleFlowStatus> multipleFlowStatusList = new ArrayList<>();
        MultipleFlowStatus multipleFlowStatus = new MultipleFlowStatus();
        multipleFlowStatus.setFlow("GEPICS");
        multipleFlowStatus.setStatus("CRTD");
        multipleFlowStatus.setVin("VINXXXXXXTEST0001");
        multipleFlowStatusList.add(multipleFlowStatus);

        Set<ReferencesElectroniques> referencesElectroniques = new HashSet<>();
        ReferencesElectroniques electroniques = new ReferencesElectroniques();
        electroniques.setVin("VINXXXXXXTEST0001");
        electroniques.setData("abc");
        electroniques.setId(1l);
        referencesElectroniques.add(electroniques);

        ArtLcdvOtt artLcdvOtt = new ArtLcdvOtt();
        artLcdvOtt.setVin("VINXXXXXXTEST0001");
        artLcdvOtt.setId(1L);
        artLcdvOtt.setCode("ab");
        artLcdvOtt.setFamily("11");
        artLcdvOtt.setValue("1");
        Set<ArtLcdvOtt> artLcdvOtts = new HashSet<>();
        artLcdvOtts.add(artLcdvOtt);

        vehicle.setMultipleFlowStatus(multipleFlowStatusList);
        vehicle.setReferencesElectroniques(referencesElectroniques);
        vehicle.setOptions(optionsSet);
        vehicle.setComposants(composantsSet);
        vehicle.setLcdvOttOv(lcdvOttSet);
        vehicle.setComposantsOv(composantsOv);
        vehicle.setKeysOv(keysOvSet);
        vehicle.setArtLcdvOtt(artLcdvOtts);

        vehicleService.updateVehicle(vehicle, flowname);
        Assertions.assertThat(vehicle).isNotNull();

    }

    @Test
    public void updateParam() {
        vehicle.setVinNo("VINXXXXXXTEST0002");

        resendToOTTDtoTest.setVin("VINXXXXXXTEST0002");
        resendToOTTDtoTest.setVersion(0);
        vehicleRepository.add(vehicle);
        multipleFlowStatusService.saveflowstate(multipleFlowStatusDTO);
        boolean status = vehicleService.updateStatus(resendToOTTDtoTest, "RETR");
        Assertions.assertThat(status).isNotNull();
    }

    @Test
    public void updateStatus() {

        boolean status = vehicleService.updateStatus(null, "RETR");
        Assertions.assertThat(status).isNotNull();
    }

    @Test
    public void updateVehicleDetails() {

        boolean status = vehicleService.updateVehicleDetails(null, "RETR");
        Assertions.assertThat(status).isNotNull();
    }

    @Test
    public void getVehiclesDetailsTest() {

        vehicle.setVinNo("TEST");
        vehicle.setCcp("CK9");
        vehicle.setVeh("CK0");
        vehicle.setCurrentState("CRTD");
        vehicle.setDateExtension(new Date("10/04/2019"));
        vehicle.setVersion(1);
        vehicle.getVersion();
        vehicleRepository.add(vehicle);

        ResendToOTTDto dto = new ResendToOTTDto();
        dto.setVin("V");
        dto.setVinOrder("asc");

        dto.setCcp("V");
        dto.setCcpOrder("asc");

        dto.setVeh("c");
        dto.setVehOrder("asc");

        dto.setExtFromDate("09/04/2019");
        dto.setExtToDate("09/04/2019");
        dto.setExtDateOrder("asc");

        dto.setDateCreationOrder(null);

        dto.setExtFromDate(null);
        dto.getExtFromDate();

        dto.setFlowName("c");

        dto.setOttFlow("OTT");
        dto.setRevottFlow("REVOTT");
        dto.setCorvetFlow("CORVET");
        dto.setThubFlow("THUB");
        dto.setOttFlowOrder("ASC");
        dto.setRevottFlowOrder("ASC");
        dto.setThubFlowOrder("ASC");
        dto.setCorvetFlowOrder("ASC");
        dto.setFlowName("OTT");
        dto.setVersion(1);
        dto.setUserCreation("USER");
        dto.setDateCreationOrder("ASC");
        dto.setUserCreationOrder("ASC");

        // Assertions.assertThat(vehicleService.getVehiclesDetails(dto, 0, 10)).isNotNull();
        Assertions.assertThat(dto.getVin()).isNotNull();
        Assertions.assertThat(dto.getCcp()).isNotNull();
        Assertions.assertThat(dto.getVeh()).isNotNull();
        Assertions.assertThat(dto.getExtToDate()).isNotNull();
        Assertions.assertThat(dto.getDateCreationOrder()).isNotNull();

        Assertions.assertThat(dto.getVinOrder()).isNotNull();
        Assertions.assertThat(dto.getCcpOrder()).isNotNull();
        Assertions.assertThat(dto.getVehOrder()).isNotNull();
        Assertions.assertThat(dto.getDateCreationOrder()).isNotNull();
        Assertions.assertThat(dto.getExtDateOrder()).isNotNull();
        Assertions.assertThat(dto.toString()).isNotNull();

        dto.setVinOrder("desc");
        dto.setCcpOrder("desc");
        dto.setVehOrder("desc");
        dto.setExtDateOrder("desc");

        Assertions.assertThat(vehicleService.getVehiclesDetails(dto, 0, 10)).isNotNull();

        dto.setVinOrder(null);
        dto.setCcpOrder(null);
        dto.setVehOrder(null);
        dto.setExtDateOrder(null);

        Assertions.assertThat(vehicleService.getVehiclesDetails(dto, 0, 10)).isNotNull();
        Assertions.assertThat(vehicleService.getTotalVehicleCount(dto)).isNotNull();

        Assertions.assertThat(vehicleService.getVehiclesDetails(null, 0, 0)).isNotNull();

    }

    @Test
    public void testGetVehErrHistList() throws Exception {
        vehicleErrorRepository.add(vehicleError);
        List<VehicleDetailsDto> list = vehicleService.getVehErrHistList(vinNo);
        long count = vehicleService.getVehErrHistListCount(vinNo);
        Assertions.assertThat(list).isNotNull();

    }

    @Test
    public void testGetVehHistList() throws Exception {
        vehicleService.addVehicleError(vehicleError);
        vehicleErrorRepository.add(vehicleError);
        List<VehicleDetailsDto> list = vehicleService.getVehHistList(vinNo);
        long count = vehicleService.getVehHistListCount(vinNo);
        Assertions.assertThat(list).isNotNull();

    }

    @Test
    public void testUpdateVehicleDetails() {
        vehicle.setVinNo("V123");
        vehicle.setCcp("AB");
        vehicle.setVeh("AB");
        vehicle.setUp("AB");
        vehicle.setCcp("AB");
        vehicle.setApvpr("AB");
        vehicle.setOa("AB");
        vehicle.setOf("AB");
        vehicle.setNre("AB");
        vehicle.setTvv("AB");
        vehicle.setLcdv24("AB");
        vehicle.setModel("AB");
        vehicle.setModelYear("AB");
        vehicle.setDateExtension(new Date());
        vehicle.setDateEcom(new Date());
        vehicle.setDateEmon(new Date());

        MultipleFlowStatus multipleFlowStatus = new MultipleFlowStatus();
        multipleFlowStatus.setVin("V123");
        multipleFlowStatus.setFlow("OTT");
        multipleFlowStatus.setStatus("TRDN");
        List<MultipleFlowStatus> multipleFlowStatus2 = new ArrayList<>();
        multipleFlowStatus2.add(multipleFlowStatus);
        vehicle.setMultipleFlowStatus(multipleFlowStatus2);
        vehicleRepository.add(vehicle);

        boolean status = vehicleService.updateVehicleDetails(vehicleDetailsDto, flowname);
        Assertions.assertThat(status).isNotNull();
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testUpdateVehiclesAndLcdv() {
        vehicle.setVinNo("VINXXXXXXTEST0002");
        String lcdv = "abcdefghijklmnopqrstuvwxyz";
        String[] tokens = lcdv.split("(?<=\\G.{" + 7 + "})");
        List<String[]> lcdvTokenList = new ArrayList<>();

        List<MultipleFlowStatus> multipleFlowStatusList = new ArrayList<>();
        MultipleFlowStatus multipleFlowStatus = new MultipleFlowStatus();
        multipleFlowStatus.setFlow("OVER");
        multipleFlowStatus.setStatus("ONPR");
        multipleFlowStatus.setVin("VINXXXXXXTEST0002");
        multipleFlowStatusList.add(multipleFlowStatus);
        vehicle.setMultipleFlowStatus(multipleFlowStatusList);
        vehicleRepository.add(vehicle);
        lcdvTokenList.add(tokens);
        List<String> multipleFlowStatusOp = new ArrayList<>();
        multipleFlowStatusOp.add(1l + "");
        vehicleService.updateVehiclesAndLcdv(vehicles, lcdvTokenList, "OTT", multipleFlowStatusOp, "TRDN", tokens.length);
        Assertions.assertThat(tokens).isNotNull();
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testAddVehiclesAndLcdv() {

        LcdvOtt lcdvOtt = new LcdvOtt();
        lcdvOtt.setVin("VINXXXXXXTEST0003");
        lcdvOtt.setId(1L);
        lcdvOtt.setCharacteristic("tes");
        lcdvOtt.setIndicator("11");
        lcdvOtt.setNature("1");
        lcdvOtt.setValue("1");

        lcdvOttrepo.add(lcdvOtt);
        vehicle.setVinNo("VINXXXXXXTEST0003");
        String lcdv = "abcdefghijklmnopqrstuvwxyz";
        String[] tokens = lcdv.split("(?<=\\G.{" + 7 + "})");
        List<String[]> lcdvTokenList = new ArrayList<>();
        vehicles = new ArrayList<>();
        vehicles.add(vehicle);
        lcdvTokenList.add(tokens);
        List<String> multipleFlowStatusOp = new ArrayList<>();
        multipleFlowStatusOp.add(1l + "");
        vehicleService.addVehiclesAndLcdv(vehicles, lcdvTokenList, lcdv, tokens.length);
        Assertions.assertThat(tokens).isNotNull();
    }

    /*
     * @Test(expected = NullPointerException.class) public void testUpdateVehiclesAndArtLcdv() { vehicle.setVinNo("VINXXXXXXTEST0004"); String lcdv =
     * "abcdefghijklmnopqrstuvwxyz"; String[] tokens = lcdv.split("(?<=\\G.{" + 7 + "})"); List<String[]> lcdvTokenList = new ArrayList<>();
     * 
     * List<MultipleFlowStatus> multipleFlowStatusList = new ArrayList<>(); MultipleFlowStatus multipleFlowStatus = new MultipleFlowStatus();
     * multipleFlowStatus.setFlow("OVER"); multipleFlowStatus.setStatus("ONPR"); multipleFlowStatus.setVin("VINXXXXXXTEST0004");
     * multipleFlowStatusList.add(multipleFlowStatus); vehicle.setMultipleFlowStatus(multipleFlowStatusList); vehicleRepository.add(vehicle);
     * lcdvTokenList.add(tokens); List<String> multipleFlowStatusOp = new ArrayList<>(); multipleFlowStatusOp.add(1l + "");
     * vehicleService.updateVehiclesAndArtLcdv(vehicles, Collections.EMPTY_MAP, "THUB", multipleFlowStatusOp, "TRDN", tokens.length);
     * Assertions.assertThat(tokens).isNotNull(); }
     */

    @Test(expected = IndexOutOfBoundsException.class)
    public void testUpdateVehiclesAndRpo() {
        vehicle.setVinNo("VINXXXXXXTEST0005");
        String lcdv = "abcdefghijklmnopqrstuvwxyz";
        String[] tokens = lcdv.split("(?<=\\G.{" + 7 + "})");
        List<String[]> lcdvTokenList = new ArrayList<>();

        List<MultipleFlowStatus> multipleFlowStatusList = new ArrayList<>();
        MultipleFlowStatus multipleFlowStatus = new MultipleFlowStatus();
        multipleFlowStatus.setFlow("OVER");
        multipleFlowStatus.setStatus("ONPR");
        multipleFlowStatus.setVin("VINXXXXXXTEST0005");
        multipleFlowStatusList.add(multipleFlowStatus);
        vehicle.setMultipleFlowStatus(multipleFlowStatusList);
        vehicleRepository.add(vehicle);
        lcdvTokenList.add(tokens);
        List<String> multipleFlowStatusOp = new ArrayList<>();
        multipleFlowStatusOp.add(1l + "");
        vehicleService.addVehiclesandRpo(vehicles, lcdvTokenList, "REVOTT", multipleFlowStatusOp, "TRDN", tokens.length);
        Assertions.assertThat(tokens).isNotNull();
    }

    @Test
    public void testMMVehicleHistory() {
        mmVehicleHistory = new MMVehicleHistory();
        mmVehicleHistory.setVin("VINABC");
        mmVehicleHistory.setActionType("C");
        mmVehicleHistory.setTypeData("RPO");
        mmVehicleHistory.setOldValue("ABC");
        mmVehicleHistory.setValue("RLJ");
        mmVehicleHistory.setStandard("OTHER");
        mmVehicleHistory.setId1("1");
        mmVehicleHistory.setPart("abc");
        mmVehicleHistory.setData("abc");
        mmVehicleHistory.setSupplier("ds");
        mmVehicleHistory.setLabel("d");
        mmVehicleHistory.setUserId("E566869");
        mmVehicleHistory.setOperationDate(new Date());
        mmVehicleHistoryRepository.add(mmVehicleHistory);
        List<VehicleDetailsDto> vehicleDetailsDtos = vehicleService.getMMVehicleHistoryList("VINABC");
        Assertions.assertThat(vehicleDetailsDtos).isNotNull();
    }

}
