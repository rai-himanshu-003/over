/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.OvPsaMappingDTO;

public class OvPSaMappingDtoTest {

    @Test
    public void ResponseDto() {
        OvPsaMappingDTO ovPsaMappingDTO = new OvPsaMappingDTO();
        Assertions.assertThat(ovPsaMappingDTO).isNotNull();
    }

    @Test
    public void testOvPSaMappingDtoSetGet() {

        OvPsaMappingDTO ovPsaMappingDTO = new OvPsaMappingDTO();
        ovPsaMappingDTO.setId((long) 1);
        ovPsaMappingDTO.setPsaType("Test");
        ovPsaMappingDTO.setPsaKey("10");
        ovPsaMappingDTO.setOvStandard("test");
        ovPsaMappingDTO.setOvKey("test");
        ovPsaMappingDTO.setDescription("test");
        ovPsaMappingDTO.setVersion(1);

        Assertions.assertThat(ovPsaMappingDTO.getId()).isEqualTo(1);
        Assertions.assertThat(ovPsaMappingDTO.getDescription()).isEqualTo("test");
        Assertions.assertThat(ovPsaMappingDTO.getPsaType()).isEqualTo("Test");
        Assertions.assertThat(ovPsaMappingDTO.getPsaKey()).isEqualTo("10");
        Assertions.assertThat(ovPsaMappingDTO.getOvStandard()).isEqualTo("test");
        Assertions.assertThat(ovPsaMappingDTO.getOvKey()).isEqualTo("test");
        Assertions.assertThat(ovPsaMappingDTO.getVersion()).isEqualTo(1);

    }

}
