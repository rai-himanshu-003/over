/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

@RunWith(SeedITRunner.class)
public class OTTFileSequenceServiceTest {
    @Inject
    OTTFileSequenceService fileSequenceService;

    @Test
    public void testGetVehicleDetails() {
        Long number = fileSequenceService.getOTTFIleSequenceNumber().longValue();
        Assertions.assertThat(number).isNotNull();

    }

}
