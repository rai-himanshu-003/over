/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;

public class GenericCollectionDTOTest {

    @Test
    public void OvComposantTest() {

        GenericCollectionDTO genericCollectionDTO = new GenericCollectionDTO();

        genericCollectionDTO.setId(1L);
        genericCollectionDTO.setFlowId(1l);
        genericCollectionDTO.setSeq(1l);
        genericCollectionDTO.setSeparator(",");
        genericCollectionDTO.setIntSeparator(";");
        genericCollectionDTO.setMaxOcc(1l);
        genericCollectionDTO.setAlignment(5l);
        genericCollectionDTO.setValue(4l);
        genericCollectionDTO.setFilter("test");

        Assertions.assertThat(genericCollectionDTO).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getId()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getFlowId()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getValue()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getAlignment()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getSeq()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getSeparator()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getIntSeparator()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getFilter()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.getMaxOcc()).isNotNull();
        Assertions.assertThat(genericCollectionDTO.mapTomodel()).isNotNull();

    }

}
