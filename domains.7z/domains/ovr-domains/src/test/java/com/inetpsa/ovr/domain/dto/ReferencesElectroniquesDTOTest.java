/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.ReferencesElectroniques;
import com.inetpsa.ovr.interfaces.dto.ReferencesElectroniquesDTO;

public class ReferencesElectroniquesDTOTest {

    @Test
    public void referencesElectroniquesTest() {

        ReferencesElectroniques referencesElectroniques = new ReferencesElectroniques();
        referencesElectroniques.setId(1L);
        referencesElectroniques.setData("TEST");
        referencesElectroniques.setVin("VIN");

        ReferencesElectroniques referencesElectroniques1 = new ReferencesElectroniques();
        referencesElectroniques1.setId(1L);
        referencesElectroniques1.setData("TEST");
        referencesElectroniques1.setVin("VIN");

        Assertions.assertThat(referencesElectroniques).isNotNull();
        Assertions.assertThat(referencesElectroniques.getId()).isNotNull();
        Assertions.assertThat(referencesElectroniques.getData()).isNotNull();
        Assertions.assertThat(referencesElectroniques.getVin()).isNotNull();
        Assertions.assertThat(referencesElectroniques.toString()).isNotNull();
        Assertions.assertThat(referencesElectroniques.maptoDto()).isNotNull();
        Assertions.assertThat(referencesElectroniques.hashCode()).isNotNull();
        Assertions.assertThat(referencesElectroniques.equals(referencesElectroniques1)).isNotNull();

    }

    @Test
    public void referencesElectroniquesDTOTest() {

        ReferencesElectroniquesDTO referencesElectroniquesDTO = new ReferencesElectroniquesDTO();
        referencesElectroniquesDTO.setId(1L);
        referencesElectroniquesDTO.setData("TEST");
        referencesElectroniquesDTO.setVin("VIN");

        Assertions.assertThat(referencesElectroniquesDTO).isNotNull();
        Assertions.assertThat(referencesElectroniquesDTO.getId()).isNotNull();
        Assertions.assertThat(referencesElectroniquesDTO.getData()).isNotNull();
        Assertions.assertThat(referencesElectroniquesDTO.getVin()).isNotNull();
        Assertions.assertThat(referencesElectroniquesDTO.toString()).isNotNull();
        Assertions.assertThat(referencesElectroniquesDTO.mapTomodel()).isNotNull();

    }

}
