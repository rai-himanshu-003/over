/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.Composants;
import com.inetpsa.ovr.interfaces.dto.ComposantsDTO;

public class ComposantsDTOTest {

    @Test
    public void ComposantTest() {

        Composants composants = new Composants();
        composants.setId(1L);
        composants.setData("TEST");
        composants.setVin("VIN");

        Composants composants1 = new Composants();
        composants1.setId(1L);
        composants1.setData("TEST");
        composants1.setVin("VIN");

        Assertions.assertThat(composants).isNotNull();
        Assertions.assertThat(composants.getId()).isNotNull();
        Assertions.assertThat(composants.getData()).isNotNull();
        Assertions.assertThat(composants.getVin()).isNotNull();
        Assertions.assertThat(composants.toString()).isNotNull();
        Assertions.assertThat(composants.maptoDto()).isNotNull();
        Assertions.assertThat(composants.hashCode()).isNotNull();
        Assertions.assertThat(composants.equals(composants1)).isNotNull();

    }

    @Test
    public void referencesElectroniquesDTOTest() {

        ComposantsDTO composantsDTO = new ComposantsDTO();
        composantsDTO.setId(1L);
        composantsDTO.setData("TEST");
        composantsDTO.setVin("VIN");

        Assertions.assertThat(composantsDTO).isNotNull();
        Assertions.assertThat(composantsDTO.getId()).isNotNull();
        Assertions.assertThat(composantsDTO.getData()).isNotNull();
        Assertions.assertThat(composantsDTO.getVin()).isNotNull();
        Assertions.assertThat(composantsDTO.toString()).isNotNull();
        Assertions.assertThat(composantsDTO.mapTomodel()).isNotNull();
        Assertions.assertThat(composantsDTO.hashCode()).isNotNull();

    }

}
