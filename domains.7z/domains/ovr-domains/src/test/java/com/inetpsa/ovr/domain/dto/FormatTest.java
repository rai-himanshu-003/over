/*
 * Creation : 14 May 2020
 */
package com.inetpsa.ovr.domain.dto;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.xml.FORMAT;
import com.inetpsa.ovr.interfaces.dto.xml.ObjectFactory;

public class FormatTest {
    ObjectFactory factory;
    FORMAT format;
    FORMAT.HEADER header;
    FORMAT.FOOTER footer;
    FORMAT.VEHICULES vehicules;
    FORMAT.VEHICULES.LISTARTLCDV lcdvList;
    FORMAT.VEHICULES.LISTRPO rpoList;
    FORMAT.VEHICULES.VEHICLEDATAS vdatas;
    FORMAT.VEHICULES.LISTCOMPONENTSOV compList;
    FORMAT.VEHICULES.LISTCOMPONENTSOV.COMPONENTSOV comp;
    List<String> tempList;

    @Before
    public void setup() {
        factory = new ObjectFactory();
        format = factory.createFORMAT();
        header = factory.createFORMATHEADER();
        footer = factory.createFORMATFOOTER();
        vehicules = factory.createFORMATVEHICULES();
        lcdvList = factory.createFORMATVEHICULESLISTARTLCDV();
        rpoList = factory.createFORMATVEHICULESLISTRPO();
        vdatas = factory.createFORMATVEHICULESVEHICLEDATAS();
        compList = factory.createFORMATVEHICULESLISTCOMPONENTSOV();
        comp = factory.createFORMATVEHICULESLISTCOMPONENTSOVCOMPONENTSOV();

        tempList = new ArrayList<>();
        tempList.add("data");
    }

    @Test
    public void testFormat() {
        header.setCLIENT("SAGAI");
        header.setSENDER("OVER");
        header.setSENDINGDATE("01010110101");
        Assertions.assertThat(header.getCLIENT()).isEqualTo("SAGAI");
        Assertions.assertThat(header.getSENDER()).isEqualTo("OVER");
        Assertions.assertThat(header.getSENDINGDATE()).isEqualTo("01010110101");
        format.setHEADER(header);
        Assertions.assertThat(header).isNotNull();
        footer.setCLIENT("SAGAI");
        footer.setSENDER("OVER");
        footer.setNUMBEROFRECORDS("10");
        Assertions.assertThat(footer.getCLIENT()).isEqualTo("SAGAI");
        Assertions.assertThat(footer.getSENDER()).isEqualTo("OVER");
        Assertions.assertThat(footer.getNUMBEROFRECORDS()).isEqualTo("10");
        format.setFOOTER(footer);
        Assertions.assertThat(format.getFOOTER()).isNotNull();
        Assertions.assertThat(format.getHEADER()).isNotNull();
        lcdvList.getARTLCDV().addAll(tempList);
        rpoList.getRPO().addAll(tempList);
        Assertions.assertThat(lcdvList).isNotNull();
        Assertions.assertThat(rpoList).isNotNull();
        vdatas.setVIN("VINTEST001");
        vdatas.setVEH("VEH");
        vdatas.setUP("UP");
        vdatas.setOF("OF");
        vdatas.setOA("OA");
        vdatas.setMODELYEAR("2020");
        vdatas.setMODEL("PSA");
        vdatas.setLCDV24("lcdv24");
        vdatas.setDATEEMON("201010101");
        vdatas.setDATEECOM("201010101");
        vdatas.setCCP("CCP");
        vdatas.setAPVPR("APVPR");
        Assertions.assertThat(vdatas.getVIN()).isEqualTo("VINTEST001");
        Assertions.assertThat(vdatas.getVEH()).isEqualTo("VEH");
        Assertions.assertThat(vdatas.getUP()).isEqualTo("UP");
        Assertions.assertThat(vdatas.getOF()).isEqualTo("OF");
        Assertions.assertThat(vdatas.getOA()).isEqualTo("OA");
        Assertions.assertThat(vdatas.getMODELYEAR()).isEqualTo("2020");
        Assertions.assertThat(vdatas.getMODEL()).isEqualTo("PSA");
        Assertions.assertThat(vdatas.getLCDV24()).isEqualTo("lcdv24");
        Assertions.assertThat(vdatas.getDATEECOM()).isEqualTo("201010101");
        Assertions.assertThat(vdatas.getDATEEMON()).isEqualTo("201010101");
        Assertions.assertThat(vdatas.getCCP()).isEqualTo("CCP");
        Assertions.assertThat(vdatas.getAPVPR()).isEqualTo("APVPR");

        comp.setDATA("Data");
        comp.setID("1");
        comp.setLABEL("LABEL");
        comp.setPART("PART");
        comp.setSTANDARD("STANDARD");
        comp.setSUPPLIER("SUPPLIER");
        Assertions.assertThat(comp.getDATA()).isEqualTo("Data");
        Assertions.assertThat(comp.getID()).isEqualTo("1");
        Assertions.assertThat(comp.getLABEL()).isEqualTo("LABEL");
        Assertions.assertThat(comp.getPART()).isEqualTo("PART");
        Assertions.assertThat(comp.getSTANDARD()).isEqualTo("STANDARD");
        Assertions.assertThat(comp.getSUPPLIER()).isEqualTo("SUPPLIER");

        compList.getCOMPONENTSOV().add(comp);

        vehicules.setVEHICLEDATAS(vdatas);
        vehicules.setLISTARTLCDV(lcdvList);
        vehicules.setLISTRPO(rpoList);
        vehicules.setLISTCOMPONENTSOV(compList);

        Assertions.assertThat(vehicules.getLISTARTLCDV()).isNotNull();
        Assertions.assertThat(vehicules.getLISTCOMPONENTSOV()).isNotNull();
        Assertions.assertThat(vehicules.getLISTRPO()).isNotNull();
        Assertions.assertThat(vehicules.getVEHICLEDATAS()).isNotNull();
        Assertions.assertThat(vehicules.getLISTCOMPONENTSOV()).isNotNull();

        format.getVEHICULES().add(vehicules);

    }
}
