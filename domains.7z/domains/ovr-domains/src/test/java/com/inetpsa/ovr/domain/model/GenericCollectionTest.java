/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class GenericCollectionTest {

    @Test
    public void OvComposantTest() {

        GenericCollection genericCollection = new GenericCollection();

        genericCollection.setId(1L);
        genericCollection.setFlowId(1l);
        genericCollection.setSeq(1l);
        genericCollection.setSeparator(",");
        genericCollection.setIntSeparator(";");
        genericCollection.setMaxOcc(1l);
        genericCollection.setAlignment(5l);
        genericCollection.setValue(4l);
        genericCollection.setFilter("test");

        GenericCollection genericCollection1 = new GenericCollection();

        genericCollection1.setId(1L);
        genericCollection1.setFlowId(1l);
        genericCollection1.setSeq(1l);
        genericCollection1.setSeparator(",");
        genericCollection1.setIntSeparator(";");
        genericCollection1.setMaxOcc(1l);
        genericCollection1.setAlignment(5l);
        genericCollection1.setValue(4l);
        genericCollection1.setFilter("test");

        Assertions.assertThat(genericCollection).isNotNull();
        Assertions.assertThat(genericCollection.getId()).isNotNull();
        Assertions.assertThat(genericCollection.getFlowId()).isNotNull();
        Assertions.assertThat(genericCollection.getValue()).isNotNull();
        Assertions.assertThat(genericCollection.getAlignment()).isNotNull();
        Assertions.assertThat(genericCollection.getSeq()).isNotNull();
        Assertions.assertThat(genericCollection.getSeparator()).isNotNull();
        Assertions.assertThat(genericCollection.getIntSeparator()).isNotNull();
        Assertions.assertThat(genericCollection.getFilter()).isNotNull();
        Assertions.assertThat(genericCollection.getMaxOcc()).isNotNull();
        Assertions.assertThat(genericCollection.maptoDto()).isNotNull();
        Assertions.assertThat(genericCollection.hashCode()).isNotNull();
        Assertions.assertThat(genericCollection.toString()).isNotNull();

        Assertions.assertThat(genericCollection.equals(genericCollection1)).isNotNull();

    }

}
