/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.Date;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.Flow;
import com.inetpsa.ovr.domain.model.MultipleFlowStatus;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.FlowNameRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.interfaces.dto.FlowDto;
import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class MultipleFlowStatusServiceTest {

    @Inject
    MultipleFlowStatusService multipleFlowStatusService;

    @Inject
    FlowNameRepository flowNameRepository;

    @Inject
    VehicleRepository vehicleRepository;

    MultipleFlowStatusDTO multipleFlowStatusDTO = new MultipleFlowStatusDTO();
    Flow flow;
    FlowDto flowDto;
    Vehicle vehicle = null;

    @Before
    public void setUpData() {
        multipleFlowStatusDTO.setFlow("Test");
        multipleFlowStatusDTO.setStatus("INIT");
        multipleFlowStatusDTO.setVin("V123");
        vehicle = new Vehicle();
        vehicle.setVinNo("V123");
        vehicle.setCcp("AB");
        vehicle.setVeh("AB");
        vehicle.setUp("AB");
        vehicle.setApvpr("AB");
        vehicle.setOa("AB");
        vehicle.setOf("AB");
        vehicle.setNre("AB");
        vehicle.setTvv("AB");
        vehicle.setLcdv24("AB");
        vehicle.setModel("AB");
        vehicle.setModelYear("AB");
        vehicle.setDateExtension(new Date());
        vehicle.setDateEcom(new Date());
        vehicle.setDateEmon(new Date());

        flow = new Flow();
        flow.setId(1l);
        flow.setFlowName("OTT");
        flow.toString();

        flowDto = new FlowDto();
        flowDto.setId("1");
        flowDto.setFlowName("OTT");

    }

    @Test
    public void saveorupdate() {

        Assertions.assertThat(multipleFlowStatusService.getByVinFlowState(multipleFlowStatusDTO)).isNull();
        Assertions.assertThat(multipleFlowStatusService.getByVinFlowState(null)).isNull();
        vehicleRepository.add(vehicle);
        Assertions.assertThat(multipleFlowStatusService.saveflowstate(multipleFlowStatusDTO)).isTrue();
        Assertions.assertThat(multipleFlowStatusService.saveflowstate(null)).isFalse();

        MultipleFlowStatus multipleFlowStatusDTOSaved = multipleFlowStatusService.getByVinFlowState(multipleFlowStatusDTO);
        Assertions.assertThat(multipleFlowStatusService.updateflowstate(multipleFlowStatusDTOSaved.maptoDto())).isTrue();
        Assertions.assertThat(multipleFlowStatusService.updateflowstate(null)).isFalse();

        Assertions.assertThat(multipleFlowStatusService.saveorupdateflowstate(multipleFlowStatusDTO)).isTrue();
        Assertions.assertThat(multipleFlowStatusService.getByVin("V123")).isNotNull();
        Assertions.assertThat(multipleFlowStatusService.getByID(multipleFlowStatusDTOSaved.getId())).isNotNull();
        Assertions.assertThat(flow.getFlowName()).isNotNull();
        Assertions.assertThat(flow.getId()).isNotNull();

        Assertions.assertThat(flowDto.getFlowName()).isNotNull();
        Assertions.assertThat(flowDto.getId()).isNotNull();
    }

    @Test
    public void getFlowList() {
        flowNameRepository.add(flow);
        Assertions.assertThat(multipleFlowStatusService.getFlowList()).isNotNull();

    }

}
