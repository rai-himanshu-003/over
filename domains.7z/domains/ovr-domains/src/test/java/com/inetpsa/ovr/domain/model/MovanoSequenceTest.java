/*
 * Creation : 22 Aug 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

@RunWith(SeedITRunner.class)
public class MovanoSequenceTest {

    MovanoSequence movanoSequence = new MovanoSequence();

    @Test
    public void testCovertSequence() {

        movanoSequence.setId(1L);
        Assertions.assertThat(movanoSequence.getId()).isNotNull();

    }

}
