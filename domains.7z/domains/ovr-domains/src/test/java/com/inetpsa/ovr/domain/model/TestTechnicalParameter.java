/*
 * Creation : 26 Apr 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Test;

public class TestTechnicalParameter {

    private TechnicalParameter technicalParameter;

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testDefault() {
        technicalParameter = new TechnicalParameter("abc", "abc", "test", LocalDateTime.MAX, LocalDateTime.MAX, "test", "test", "type");
        Assertions.assertThat(technicalParameter.getCode()).isNotNull();
        Assertions.assertThat(technicalParameter.toString()).isNotNull();
    }

    @Test
    public void testSetterGetter() {
        technicalParameter = new TechnicalParameter();
        technicalParameter.setCode("OTT_FREQUENCY");
        technicalParameter.setLable("description");
        technicalParameter.setValue("10");
        technicalParameter.setUserCreation("test");
        technicalParameter.setDateCreation(LocalDateTime.MAX);
        technicalParameter.setUserModif("test");
        technicalParameter.setDateModif(LocalDateTime.MAX);
        Assertions.assertThat(technicalParameter).isNotNull();

        technicalParameter.getCode();
        technicalParameter.getLable();
        technicalParameter.getValue();
        technicalParameter.getUserCreation();
        technicalParameter.getDateCreation();
        technicalParameter.getUserModif();
        technicalParameter.getDateModif();
        Assertions.assertThat(technicalParameter).isNotNull();
    }

}
