/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.util.HashSet;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.OVComponentDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;

public class OVComponentDTOTest {

    @Test
    public void OvComposantTest() {

        OVComponentDTO ovComponentDTO = new OVComponentDTO();

        Set<OVComponentPartDTO> componentPartDTOs = new HashSet<>();
        ovComponentDTO.setId(1L);
        ovComponentDTO.setFlowId(1l);
        ovComponentDTO.setSeq(1l);
        ovComponentDTO.setSeparator(",");
        ovComponentDTO.setIntSeparator(";");
        ovComponentDTO.setMaxOcc(1l);
        ovComponentDTO.setAlignment(5l);
        ovComponentDTO.setValue(4l);
        ovComponentDTO.setFilter("test");

        Assertions.assertThat(ovComponentDTO).isNotNull();
        Assertions.assertThat(ovComponentDTO.getId()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getFlowId()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getValue()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getAlignment()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getSeq()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getSeparator()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getIntSeparator()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getFilter()).isNotNull();
        Assertions.assertThat(ovComponentDTO.getMaxOcc()).isNotNull();
        componentPartDTOs.add(new OVComponentPartDTO());
        Assertions.assertThat(ovComponentDTO.mapTomodel()).isNotNull();

    }

}
