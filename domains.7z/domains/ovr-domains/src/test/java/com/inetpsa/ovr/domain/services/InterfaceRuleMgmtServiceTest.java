package com.inetpsa.ovr.domain.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.InterfaceRepository;
import com.inetpsa.ovr.domain.repository.InterfaceRulesRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.IRMRequestDTO;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;
import com.inetpsa.ovr.interfaces.dto.PreviousFlowDetailsDTO;

/*
 * Creation : 24 Jul 2019
 */
@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class InterfaceRuleMgmtServiceTest {
    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    private InterfaceRulesRepository interfaceRulesRepository;

    @Inject
    private InterfaceRepository interfaceRepository;

    // @Inject
    // private InterfaceRuleMgmtService interfaceRuleMgmtService;

    @Inject
    private InterfaceRulesService interfaceRuleService;

    @Inject
    InterfaceRuleMgmtService interfaceRuleMgmtService;

    Vehicle vehicle;

    IRMRequestDTO irmRequestDTO;
    boolean irmResponseDTO;
    InterfaceRulesDto interfaceRulesDto;
    List<InterfaceRulesDto> dtos;
    List<String> status;
    InterfaceRule interfaceRule, interfaceRule1;
    Interface interface1;

    @After
    public void cleanUpData() {
        LoggedUser.logOut();
    }

    @Before
    public void setData() {
        status = new ArrayList<String>();
        status.add("CRTD");
        irmRequestDTO = new IRMRequestDTO();
        PreviousFlowDetailsDTO previousFlowDetailsDTO = new PreviousFlowDetailsDTO();
        List<PreviousFlowDetailsDTO> previousFlowDetailsDTOs = new ArrayList<>();
        List<String> statusList = new ArrayList();
        statusList.add("CRTD");
        statusList.add("KOTR");
        previousFlowDetailsDTO.setPreviousFlow("TH");
        previousFlowDetailsDTO.setStatus(statusList);
        previousFlowDetailsDTOs.add(previousFlowDetailsDTO);
        previousFlowDetailsDTO.setPreviousFlow("OTT");
        previousFlowDetailsDTO.setStatus(statusList);
        previousFlowDetailsDTOs.add(previousFlowDetailsDTO);

        irmRequestDTO.setCurrentFlow("OTT");
        irmRequestDTO.setPreviousFlowDetailsDTOs(previousFlowDetailsDTOs);
        irmRequestDTO.setIntId(1l);
        interfaceRulesDto = new InterfaceRulesDto();
        interfaceRulesDto.setInterfaceId(1l);
        interfaceRulesDto.setTypeOfFilter(2);
        interfaceRulesDto.setFamilyOfVehicle("CK9");
        interfaceRulesDto.setCountry("FR");
        interfaceRulesDto.setMinEcomDate(new Date());
        interfaceRulesDto.setMaxEcomDate(new Date());
        interfaceRulesDto.setVin("V123");
        interface1 = new Interface();
        interface1.setInterfaceName("GEPICS");
        interface1.setId(1l);
        interfaceRule = new InterfaceRule();
        interfaceRule.setIntId(1l);
        interfaceRule.setPriority(1);
        interfaceRule.setFilterType(2);
        interfaceRule.setCountry("FR");
        interfaceRule.setVehicleFamily("CK9");
        interfaceRule.setProductionCentre("CK9"); // interfaceRule.setId((long) 1); interfaceRule.setMaxEcom(LocalDateTime.MAX);
        interfaceRule.setMinEcom(new Date());
        interfaceRule.setMaxEcom(new Date());
        interfaceRule.setVersion(0);
        interfaceRule.setVin("V123");

        interfaceRule1 = new InterfaceRule();
        interfaceRule1.setFilterType(1);
        interfaceRule1.setIntId(1l);

    }

    @Test // (expected = Exception.class)
    public void updateIgnoredRecs() {

        irmResponseDTO = interfaceRuleMgmtService.applyAndGetInterfaceRulesFor(irmRequestDTO);

        interfaceRepository.add(interface1);
        interfaceRulesRepository.add(interfaceRule);
        interfaceRulesRepository.add(interfaceRule1);

        irmResponseDTO = interfaceRuleMgmtService.applyAndGetInterfaceRulesFor(irmRequestDTO);

        irmRequestDTO.setCurrentFlow("CORVET");
        irmResponseDTO = interfaceRuleMgmtService.applyAndGetInterfaceRulesFor(irmRequestDTO);
        Assertions.assertThat(irmResponseDTO).isNotNull();
    }

}
