/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.domain.util.LoggedUser;

public class VehicleHistoryTest {

    VehicleHistory vehicleHistory;
    VehicleHistoryPk historyPk;

    private String vinNo = "VINXXXXXXTEST0032";

    private String currentState = "TRDN";

    private String userCreation = "OVER";

    @Before
    public void setUpData() {
        LoggedUser.logIn("OVER");
    }

    @After
    public void cleanUpData() {
        LoggedUser.logOut();
    }

    @Test
    public void constructorTesting() {
        historyPk = new VehicleHistoryPk(vinNo, currentState);
        vehicleHistory = new VehicleHistory(historyPk, userCreation, "flowname");
        Assertions.assertThat(vehicleHistory).isNotNull();
    }

    @Test
    public void setterGetterTesting() {
        historyPk = new VehicleHistoryPk();
        historyPk.setVinNo(vinNo);
        historyPk.setStateId(currentState);

        vehicleHistory = new VehicleHistory();
        vehicleHistory.setHistoryModelPk(historyPk);
        vehicleHistory.setFlowname("OTT");
        vehicleHistory.prePersist();

        Assertions.assertThat(vehicleHistory.getUserCreation()).isNotNull();
        Assertions.assertThat(vehicleHistory.getHistoryModelPk()).isNotNull();
        Assertions.assertThat(vehicleHistory.toString()).isNotNull();
        Assertions.assertThat(vehicleHistory.getFlowname()).isNotNull();

    }

}
