/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.FlowVhlMetadata;
import com.inetpsa.ovr.domain.model.GenericCollection;
import com.inetpsa.ovr.domain.model.OVComponent;
import com.inetpsa.ovr.domain.model.OVComponentPart;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.FlowVhlMetadataDTO;
import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;

public class OutputFlowDetailsDTOTest {

    @Test
    public void ResponseDto() {
        OutputFlowDetailsDTO outputFlowDetailsDTO = new OutputFlowDetailsDTO();
        Assertions.assertThat(outputFlowDetailsDTO).isNotNull();
    }

    /**
     * Test interface rules dto set get.
     */
    @Test
    public void testOutputFlowDetailsDtoSetGet() {
        OutputFlowDetails outputFlowDetails = new OutputFlowDetails();
        Set<FlowVhlMetadata> flowVhlMetadatas = new HashSet<>();
        Set<GenericCollection> collections = new HashSet<>();
        Set<OVComponent> ovComponents = new HashSet<>();
        Set<OVComponentPart> ovComponentParts = new HashSet<>();

        OutputFlowDetailsDTO outputFlowDetailsDTO = new OutputFlowDetailsDTO();
        Set<FlowVhlMetadataDTO> flowVhlMetadataDTOs = new HashSet<>();
        Set<GenericCollectionDTO> collectionDTOs = new HashSet<>();
        Set<OVComponentDTO> componentDTOs = new HashSet<>();
        Set<OVComponentPartDTO> ovComponentPartDTOs = new HashSet<>();

        OVComponentDTO ovComponent = new OVComponentDTO();
        ovComponentPartDTOs.add(new OVComponentPartDTO());
        ovComponent.setOvComponentPartDTOs(ovComponentPartDTOs);
        FlowVhlMetadataDTO flowVhlMetadataDTO = new FlowVhlMetadataDTO();
        flowVhlMetadataDTO.setValue(13l);
        flowVhlMetadataDTO.setFilter("DD/mm/YYYY");
        flowVhlMetadataDTOs.add(flowVhlMetadataDTO);
        collectionDTOs.add(new GenericCollectionDTO());
        componentDTOs.add(ovComponent);

        outputFlowDetails.setFlowVhlMetadatas(flowVhlMetadatas);
        outputFlowDetails.setGenericCollections(collections);
        outputFlowDetails.setOvComponents(ovComponents);

        outputFlowDetailsDTO.setId((long) 1);
        outputFlowDetailsDTO.setAction((long) 1);
        outputFlowDetailsDTO.setDescription("test");
        outputFlowDetailsDTO.setFrequency("test");
        outputFlowDetailsDTO.setFolderLocation("test");
        outputFlowDetailsDTO.setFlow("test");
        outputFlowDetailsDTO.setFileFormatId(1l);
        outputFlowDetailsDTO.setFileName("test");
        outputFlowDetailsDTO.setLastRun(LocalDateTime.MAX);
        outputFlowDetailsDTO.setVersion(1);
        outputFlowDetailsDTO.setFlowVhlMetadataDTOs(flowVhlMetadataDTOs);
        outputFlowDetailsDTO.setCollectionDTOs(collectionDTOs);
        outputFlowDetailsDTO.setOvComponentDTOs(componentDTOs);

        Assertions.assertThat(outputFlowDetailsDTO.getFileFormatId()).isEqualTo(1);
        Assertions.assertThat(outputFlowDetailsDTO.getId()).isEqualTo(1);
        Assertions.assertThat(outputFlowDetailsDTO.getAction()).isEqualTo(1);
        Assertions.assertThat(outputFlowDetailsDTO.getFlow()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetailsDTO.getDescription()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetailsDTO.getFrequency()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetailsDTO.getFolderLocation()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetailsDTO.getVersion()).isEqualTo(1);
        Assertions.assertThat(outputFlowDetailsDTO.getFileName()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetailsDTO.getLastRun()).isNotNull();
        Assertions.assertThat(outputFlowDetailsDTO.mapTomodel(new OutputFlowDetails())).isNotNull();
        Assertions.assertThat(outputFlowDetailsDTO.mapTomodelForFMGMT(outputFlowDetails)).isNotNull();

    }

    @Test
    public void testOutputFlowDetailsSetGet() {

        Set<FlowVhlMetadata> flowVhlMetadatas = new HashSet<>();
        Set<GenericCollection> collections = new HashSet<>();
        Set<OVComponent> ovComponents = new HashSet<>();
        Set<OVComponentPart> ovComponentParts = new HashSet<>();
        OVComponent ovComponent = new OVComponent();
        ovComponentParts.add(new OVComponentPart());
        ovComponent.setOvComponentParts(ovComponentParts);
        flowVhlMetadatas.add(new FlowVhlMetadata());
        collections.add(new GenericCollection());
        ovComponents.add(ovComponent);

        OutputFlowDetails outputFlowDetails = new OutputFlowDetails();
        outputFlowDetails.setId((long) 1);
        outputFlowDetails.setAction((long) 1);
        outputFlowDetails.setDescription("test");
        outputFlowDetails.setFrequency("test");
        outputFlowDetails.setFolder("test");
        outputFlowDetails.setFlow("test");
        outputFlowDetails.setFileName("test");
        outputFlowDetails.setLastRun(LocalDateTime.MAX);
        outputFlowDetails.setVersion(1);
        outputFlowDetails.setIsDeleted("Y");
        LoggedUser.logIn("OVER");
        outputFlowDetails.prePersist();
        outputFlowDetails.preUpdate();
        outputFlowDetails.setFlowVhlMetadatas(flowVhlMetadatas);
        outputFlowDetails.setGenericCollections(collections);
        outputFlowDetails.setOvComponents(ovComponents);

        Assertions.assertThat(outputFlowDetails.getId()).isEqualTo(1);
        Assertions.assertThat(outputFlowDetails.getAction()).isEqualTo(1);
        Assertions.assertThat(outputFlowDetails.getFlow()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetails.getDescription()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetails.getFrequency()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetails.getFolder()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetails.getVersion()).isEqualTo(1);
        Assertions.assertThat(outputFlowDetails.getFileName()).isEqualTo("test");
        Assertions.assertThat(outputFlowDetails.getLastRun()).isNotNull();
        Assertions.assertThat(outputFlowDetails.maptoDto()).isNotNull();
        Assertions.assertThat(outputFlowDetails.getIsDeleted()).isNotNull();
        Assertions.assertThat(outputFlowDetails.getDateCreation()).isNotNull();
        Assertions.assertThat(outputFlowDetails.getDateModif()).isNotNull();
        Assertions.assertThat(outputFlowDetails.getUserCreation()).isNotNull();
        Assertions.assertThat(outputFlowDetails.getUserModif()).isNotNull();
        Assertions.assertThat(outputFlowDetails.maptoDtoForFMGT()).isNotNull();

    }

}
