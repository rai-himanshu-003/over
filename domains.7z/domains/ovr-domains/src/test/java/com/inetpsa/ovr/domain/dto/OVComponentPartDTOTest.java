/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;

public class OVComponentPartDTOTest {

    @Test
    public void OvComposantTest() {

        OVComponentPartDTO ovComponentPartDTO = new OVComponentPartDTO();

        ovComponentPartDTO.setId(1l);
        ovComponentPartDTO.setStandard(5l);
        ovComponentPartDTO.setIntSeq("test");
        ovComponentPartDTO.setFilter("test");
        ovComponentPartDTO.setOvCompId(1l);
        ovComponentPartDTO.setValue(1l);

        Assertions.assertThat(ovComponentPartDTO).isNotNull();
        Assertions.assertThat(ovComponentPartDTO.getId()).isNotNull();
        Assertions.assertThat(ovComponentPartDTO.getOvCompId()).isNotNull();
        Assertions.assertThat(ovComponentPartDTO.getValue()).isNotNull();
        Assertions.assertThat(ovComponentPartDTO.getStandard()).isNotNull();
        Assertions.assertThat(ovComponentPartDTO.getIntSeq()).isNotNull();
        Assertions.assertThat(ovComponentPartDTO.getFilter()).isNotNull();
        Assertions.assertThat(ovComponentPartDTO.mapTomodel()).isNotNull();

    }

}
