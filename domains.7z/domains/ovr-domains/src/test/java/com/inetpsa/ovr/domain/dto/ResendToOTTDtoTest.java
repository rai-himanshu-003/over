/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.time.LocalDateTime;
import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;

public class ResendToOTTDtoTest {

    @Test
    public void ResponseDto() {
        ResendToOTTDto resendToOTTDtoTest = new ResendToOTTDto();
        Assertions.assertThat(resendToOTTDtoTest).isNotNull();
    }

    @Test
    public void testResendToOTTDtoSetGet() {

        ResendToOTTDto resendToOTTDtoTest = new ResendToOTTDto();
        ResendToOTTDto resendToOTTDtoTest1 = new ResendToOTTDto("vdv", "vdv", "fdf", "dsd", "vdv", new Date(), "dvv", "vdv");
        resendToOTTDtoTest.setVin("VIN");
        resendToOTTDtoTest.setCcp("1");
        resendToOTTDtoTest.setVeh("A");
        resendToOTTDtoTest.setCodeErr("ERROR");
        resendToOTTDtoTest.setLabelErr("LABEL");
        resendToOTTDtoTest.setComplementErr("A");
        resendToOTTDtoTest.setExtFromDate(LocalDateTime.MAX.toString());
        resendToOTTDtoTest.setExtToDate(LocalDateTime.MIN.toString());
        resendToOTTDtoTest.setErrFromDate(LocalDateTime.MAX.toString());
        resendToOTTDtoTest.setErrToDate(LocalDateTime.MIN.toString());
        resendToOTTDtoTest.setComplementErr("A");
        resendToOTTDtoTest.setVinOrder("ASC");
        resendToOTTDtoTest.setCcpOrder("ASC");
        resendToOTTDtoTest.setVehOrder("ASC");
        resendToOTTDtoTest.setCodeErrOrder("ASC");
        resendToOTTDtoTest.setLabelErrOrder("ASC");
        resendToOTTDtoTest.setComplementErrOrder("ASC");
        resendToOTTDtoTest.setExtDateOrder("ASC");
        resendToOTTDtoTest.setErrDateOrder("ASC");
        resendToOTTDtoTest.setOttFlow("OTT");
        resendToOTTDtoTest.setRevottFlow("REVOTT");
        resendToOTTDtoTest.setCorvetFlow("CORVET");
        resendToOTTDtoTest.setThubFlow("THUB");
        resendToOTTDtoTest.setOttFlowOrder("ASC");
        resendToOTTDtoTest.setRevottFlowOrder("ASC");
        resendToOTTDtoTest.setThubFlowOrder("ASC");
        resendToOTTDtoTest.setCorvetFlowOrder("ASC");
        resendToOTTDtoTest.setFlowName("OTT");
        resendToOTTDtoTest.setVersion(1);
        resendToOTTDtoTest.setUserCreation("USER");
        resendToOTTDtoTest.setDateCreationOrder("ASC");
        resendToOTTDtoTest.setUserCreationOrder("ASC");
        resendToOTTDtoTest.setCurrentState("CRTD");
        Assertions.assertThat(resendToOTTDtoTest.getVin()).isEqualTo("VIN");
        Assertions.assertThat(resendToOTTDtoTest.getCcp()).isEqualTo("1");
        Assertions.assertThat(resendToOTTDtoTest.getVeh()).isEqualTo("A");
        Assertions.assertThat(resendToOTTDtoTest.getCodeErr()).isEqualTo("ERROR");
        Assertions.assertThat(resendToOTTDtoTest.getLabelErr()).isEqualTo("LABEL");
        Assertions.assertThat(resendToOTTDtoTest.getComplementErr()).isEqualTo("A");
        Assertions.assertThat(resendToOTTDtoTest.getLabelErr()).isEqualTo("LABEL");
        Assertions.assertThat(resendToOTTDtoTest.getExtFromDate()).isEqualTo(LocalDateTime.MAX.toString());
        Assertions.assertThat(resendToOTTDtoTest.getExtToDate()).isEqualTo(LocalDateTime.MIN.toString());
        Assertions.assertThat(resendToOTTDtoTest.getErrFromDate()).isEqualTo(LocalDateTime.MAX.toString());
        Assertions.assertThat(resendToOTTDtoTest.getErrToDate()).isEqualTo(LocalDateTime.MIN.toString());
        Assertions.assertThat(resendToOTTDtoTest.getVinOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getCcpOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getVehOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getCodeErrOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getLabelErrOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getComplementErrOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getExtDateOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getErrDateOrder()).isEqualTo("ASC");

        Assertions.assertThat(resendToOTTDtoTest.getSerialversionuid()).isEqualTo(-4527943607165453814L);
        Assertions.assertThat(resendToOTTDtoTest.toString()).isNotNull();
        Assertions.assertThat(resendToOTTDtoTest.getOttFlowOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getRevottFlowOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getThubFlowOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getCorvetFlowOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getOttFlow()).isEqualTo("OTT");
        Assertions.assertThat(resendToOTTDtoTest.getRevottFlow()).isEqualTo("REVOTT");
        Assertions.assertThat(resendToOTTDtoTest.getThubFlow()).isEqualTo("THUB");
        Assertions.assertThat(resendToOTTDtoTest.getCorvetFlow()).isEqualTo("CORVET");
        Assertions.assertThat(resendToOTTDtoTest.getFlowName()).isEqualTo("OTT");
        Assertions.assertThat(resendToOTTDtoTest.getVersion()).isEqualTo(1);
        Assertions.assertThat(resendToOTTDtoTest.getFlowName()).isEqualTo("OTT");
        Assertions.assertThat(resendToOTTDtoTest.getUserCreationOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getDateCreationOrder()).isEqualTo("ASC");
        Assertions.assertThat(resendToOTTDtoTest.getCurrentState()).isEqualTo("CRTD");
    }

}
