/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;

public class MultipleFlowStatusDTOTest {

    @Test
    public void multipleFlowStatusDTOTestFun() {

        MultipleFlowStatusDTO multipleFlowStatusDTO = new MultipleFlowStatusDTO();
        multipleFlowStatusDTO.setFlow("flow");
        multipleFlowStatusDTO.setId(1L);
        multipleFlowStatusDTO.setStatus("true");
        multipleFlowStatusDTO.setVin("test");
        multipleFlowStatusDTO.setVersion(1);

        Assertions.assertThat(multipleFlowStatusDTO.getFlow()).isNotNull();
        Assertions.assertThat(multipleFlowStatusDTO.getId()).isNotNull();
        Assertions.assertThat(multipleFlowStatusDTO.getStatus()).isNotNull();
        Assertions.assertThat(multipleFlowStatusDTO.getVersion()).isNotNull();
        Assertions.assertThat(multipleFlowStatusDTO.getVin()).isNotNull();
        Assertions.assertThat(multipleFlowStatusDTO.toString()).isNotNull();
        Assertions.assertThat(multipleFlowStatusDTO.mapToModel()).isNotNull();

    }

}
