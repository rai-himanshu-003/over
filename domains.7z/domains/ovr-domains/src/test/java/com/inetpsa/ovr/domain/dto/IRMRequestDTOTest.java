/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.IRMRequestDTO;
import com.inetpsa.ovr.interfaces.dto.PreviousFlowDetailsDTO;

public class IRMRequestDTOTest {

    @Test
    public void ResponseDto() {
        IRMRequestDTO irmRequestDTO = new IRMRequestDTO();
        Assertions.assertThat(irmRequestDTO).isNotNull();
    }

    @Test
    public void testIRMRequestDtoSetGet() {

        IRMRequestDTO irmRequestDTO = new IRMRequestDTO();
        PreviousFlowDetailsDTO previousFlowDetailsDTO = new PreviousFlowDetailsDTO();
        List<PreviousFlowDetailsDTO> previousFlowDetailsDTOs = new ArrayList<>();
        List<String> statusList = new ArrayList();
        statusList.add("CRTD");
        statusList.add("KOTR");
        previousFlowDetailsDTO.setPreviousFlow("GEPICS");
        previousFlowDetailsDTO.setStatus(statusList);
        previousFlowDetailsDTOs.add(previousFlowDetailsDTO);

        irmRequestDTO.setCurrentFlow("OTT");
        irmRequestDTO.setIntId(1l);
        irmRequestDTO.setPreviousFlowDetailsDTOs(previousFlowDetailsDTOs);

        Assertions.assertThat(irmRequestDTO.getCurrentFlow()).isEqualTo("OTT");
        Assertions.assertThat(irmRequestDTO.getIntId()).isEqualTo(1l);
        Assertions.assertThat(irmRequestDTO.getPreviousFlowDetailsDTOs()).isNotNull();

        Assertions.assertThat(previousFlowDetailsDTO.getPreviousFlow()).isEqualTo("GEPICS");
        Assertions.assertThat(previousFlowDetailsDTO.getStatus()).isNotNull();

    }

}
