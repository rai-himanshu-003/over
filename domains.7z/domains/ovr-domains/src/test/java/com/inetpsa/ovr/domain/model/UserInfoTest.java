/*
 * Creation : 21 Feb 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.util.LoggedUser;

public class UserInfoTest {

    @Test
    public void ResponseDto() {
        UserInfo userInfo = new UserInfo();
        Assertions.assertThat(userInfo).isNotNull();
    }

    @Test
    public void testUserInfoSetGet() {

        UserInfo userInfo = new UserInfo();
        userInfo.setId((long) 1);
        userInfo.setUserId("E123");
        userInfo.setType("lang");
        userInfo.setValue("test");
        userInfo.setVersion(1);
        LoggedUser.logIn("E123");
        userInfo.prePersist();
        userInfo.preUpdate();

        Assertions.assertThat(userInfo.getId()).isEqualTo(1);
        Assertions.assertThat(userInfo.getUserId()).isEqualTo("E123");
        Assertions.assertThat(userInfo.getType()).isEqualTo("lang");
        Assertions.assertThat(userInfo.getValue()).isEqualTo("test");
        Assertions.assertThat(userInfo.maptoDto()).isNotNull();
        Assertions.assertThat(userInfo.getUserCreation()).isNotNull();
        Assertions.assertThat(userInfo.getDateCreation()).isNotNull();
        Assertions.assertThat(userInfo.getUserModif()).isNotNull();
        Assertions.assertThat(userInfo.getDateModif()).isNotNull();
        Assertions.assertThat(userInfo.getVersion()).isNotNull();
        userInfo.toString();
        userInfo.equals(new UserInfo());
        userInfo.hashCode();

    }

}
