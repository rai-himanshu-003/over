/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import java.util.ArrayList;
import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;

public class VehicleDetailsDtoTest {

    @Test
    public void ResponseDto() {
        VehicleDetailsDto vehicleDetailsDto = new VehicleDetailsDto();
        Assertions.assertThat(vehicleDetailsDto).isNotNull();
    }

    @Test
    public void testInterfaceRulesDtoSetGet() {

        VehicleDetailsDto vehicleDetailsDto = new VehicleDetailsDto();
        vehicleDetailsDto.setCcp("cc");
        vehicleDetailsDto.setDateCreation(new Date(2019, 01, 01));
        vehicleDetailsDto.setErrCode("00");
        vehicleDetailsDto.setErrComplement("abc");
        vehicleDetailsDto.setErrDesc("abc");
        vehicleDetailsDto.setErrMessage("abc");
        vehicleDetailsDto.setLcdvOtt("abc");
        vehicleDetailsDto.setStateId("abc");
        vehicleDetailsDto.setUserCreation("abc");
        vehicleDetailsDto.setVeh("abc");
        vehicleDetailsDto.setVersion(0);
        vehicleDetailsDto.setVin("abc");
        vehicleDetailsDto.setXmlOv("abc");
        vehicleDetailsDto.setApvpr("TEST");
        vehicleDetailsDto.setOa("OA");
        vehicleDetailsDto.setOf("OF");
        vehicleDetailsDto.setNre("NRE");

        vehicleDetailsDto.setTvv("tvv");
        vehicleDetailsDto.setUp("up");
        vehicleDetailsDto.setLcdv24("lcdv24");
        vehicleDetailsDto.setModel("model");
        vehicleDetailsDto.setModelYear("2020");
        vehicleDetailsDto.setFlowName("OTT");
        vehicleDetailsDto.setDateEcom(new Date());
        vehicleDetailsDto.setDateEmon(new Date());
        vehicleDetailsDto.setDateExtension(new Date());
        vehicleDetailsDto.setTransmission("tvv");
        vehicleDetailsDto.setEngine("up");
        vehicleDetailsDto.setCountry("lcdv24");
        vehicleDetailsDto.setModelName("model");
        vehicleDetailsDto.setDateModif(new Date());
        vehicleDetailsDto.setDateOperation(new Date());
        vehicleDetailsDto.setOldValue("tvv");
        vehicleDetailsDto.setValue("up");
        vehicleDetailsDto.setActionType("lcdv24");
        vehicleDetailsDto.setTypeData("model");
        vehicleDetailsDto.setStandard("tvv");
        vehicleDetailsDto.setId("up");
        vehicleDetailsDto.setData("lcdv24");
        vehicleDetailsDto.setSupplier("model");
        vehicleDetailsDto.setLabel("model");
        vehicleDetailsDto.setPart("model");
        vehicleDetailsDto.setUserId("model");
        vehicleDetailsDto.setUserModif("model");

        vehicleDetailsDto.setMultipleFlowStatusDTO(new ArrayList<MultipleFlowStatusDTO>());
        Assertions.assertThat(vehicleDetailsDto.getDateEcom()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getDateEmon()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getDateExtension()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getTvv()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getUp()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getLcdv24()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getModel()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getModelYear()).isNotNull();

        Assertions.assertThat(vehicleDetailsDto.getOa()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getOf()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getNre()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getApvpr()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getCcp()).isEqualTo("cc");
        Assertions.assertThat(vehicleDetailsDto.getDateCreation()).isEqualTo(new Date(2019, 01, 01));
        Assertions.assertThat(vehicleDetailsDto.getErrCode()).isEqualTo("00");
        Assertions.assertThat(vehicleDetailsDto.getErrComplement()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getErrDesc()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getErrMessage()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getLcdvOtt()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getStateId()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getUserCreation()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getVeh()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getVersion()).isEqualTo(0);
        Assertions.assertThat(vehicleDetailsDto.getVin()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getXmlOv()).isEqualTo("abc");
        Assertions.assertThat(vehicleDetailsDto.getFlowName()).isEqualTo("OTT");
        Assertions.assertThat(vehicleDetailsDto.getMultipleFlowStatusDTO()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getCountry()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getEngine()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getTransmission()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getModelName()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getActionType()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getTypeData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getOldValue()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getValue()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getStandard()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getId()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getPart()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getData()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getSupplier()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getLabel()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getUserId()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getDateOperation()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getUserModif()).isNotNull();
        Assertions.assertThat(vehicleDetailsDto.getDateModif()).isNotNull();

    }

}
