/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

@RunWith(SeedITRunner.class)
public class AuditPkTest {

    AuditPk auditPk;

    @Test
    public void constructorTesting() {
        auditPk = new AuditPk("req_to_ott_20190723144520000000TEST.dat");
        Assertions.assertThat(auditPk).isNotNull();
    }

    @Test
    public void setterGetterTesting() {
        auditPk = new AuditPk();
        auditPk.setFileName("TestFileName");
        auditPk.setDateCreation(new Date());
        Assertions.assertThat(auditPk.getFileName()).isEqualToIgnoringCase("TestFileName");
        Assertions.assertThat(auditPk.getDateCreation()).isNotNull();
        Assertions.assertThat(auditPk.toString()).isNotNull();
        Assertions.assertThat(auditPk.getSerialversionuid()).isNotNull();
    }

    @Test
    public void hashcodeAndEqualsTesting() {
        auditPk = new AuditPk();
        auditPk.setFileName("TestFileName");
        auditPk.setDateCreation(new Date());

        Assertions.assertThat(auditPk.hashCode()).isNotNull();
        Assertions.assertThat(auditPk.equals(null)).isFalse();
    }

    @Test
    public void hashcodeAndEqualsTestingObject() {
        Object obj = new Audit();
        auditPk = new AuditPk();
        auditPk.setFileName("TestFileName");
        auditPk.setDateCreation(new Date());

        Assertions.assertThat(auditPk.hashCode()).isNotNull();
        Assertions.assertThat(auditPk.equals(obj)).isFalse();
    }

    @Test
    public void hashcodeAndEqualsTestingObject1() {
        Object obj = new AuditPk();
        auditPk = new AuditPk();

        Assertions.assertThat(auditPk.hashCode()).isNotNull();
        Assertions.assertThat(auditPk.equals(auditPk)).isTrue();
    }

    @Test
    public void hashcodeAndEqualsDteCreationNull() {
        AuditPk auditPk1 = new AuditPk();
        auditPk1.setDateCreation(null);
        auditPk = new AuditPk();
        auditPk.setFileName("TestFileName");
        auditPk.setDateCreation(new Date());

        Assertions.assertThat(auditPk.hashCode()).isNotNull();
        Assertions.assertThat(auditPk.equals(auditPk1)).isFalse();
    }

    @Test
    public void hashcodeAndEqualsDteCreationNull2() {
        AuditPk auditPk1 = new AuditPk();
        auditPk1.setDateCreation(new Date());
        auditPk = new AuditPk();

        auditPk.setFileName("TestFileName");
        auditPk.setDateCreation(null);

        Assertions.assertThat(auditPk.hashCode()).isNotNull();
        Assertions.assertThat(auditPk.equals(auditPk1)).isFalse();
    }

    @Test
    public void hashcodeAndEqualsfileName1() {
        AuditPk auditPk1 = new AuditPk();
        auditPk = new AuditPk();
        auditPk1.setDateCreation(new Date());
        auditPk.setDateCreation(new Date());

        auditPk1.setFileName("test.txt");
        auditPk.setFileName(null);

        Assertions.assertThat(auditPk.hashCode()).isNotNull();
        Assertions.assertThat(auditPk.equals(auditPk1)).isFalse();
    }

    @Test
    public void hashcodeAndEqualsfileName2() {
        AuditPk auditPk1 = new AuditPk();
        auditPk = new AuditPk();
        auditPk1.setDateCreation(new Date());
        auditPk.setDateCreation(new Date());

        auditPk1.setFileName("test.txt");
        auditPk.setFileName("Test.1txt");

        Assertions.assertThat(auditPk.hashCode()).isNotNull();
        Assertions.assertThat(auditPk.equals(auditPk1)).isFalse();
    }
}
