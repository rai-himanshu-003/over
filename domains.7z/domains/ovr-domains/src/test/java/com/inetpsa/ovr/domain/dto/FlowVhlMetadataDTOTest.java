/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.FlowVhlMetadataDTO;

public class FlowVhlMetadataDTOTest {

    @Test
    public void OvComposantTest() {

        FlowVhlMetadataDTO flMetadataDTO = new FlowVhlMetadataDTO();

        flMetadataDTO.setFlowId(1l);
        flMetadataDTO.setId(1l);
        flMetadataDTO.setSeq(4l);
        flMetadataDTO.setSeparator(",");
        flMetadataDTO.setValue(5l);
        flMetadataDTO.setFilter("test");

        Assertions.assertThat(flMetadataDTO).isNotNull();
        Assertions.assertThat(flMetadataDTO.getId()).isNotNull();
        Assertions.assertThat(flMetadataDTO.getFlowId()).isNotNull();
        Assertions.assertThat(flMetadataDTO.getValue()).isNotNull();
        Assertions.assertThat(flMetadataDTO.getSeq()).isNotNull();
        Assertions.assertThat(flMetadataDTO.getSeparator()).isNotNull();

        Assertions.assertThat(flMetadataDTO.mapTomodel()).isNotNull();

    }

}
