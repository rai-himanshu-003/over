/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.constants;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.constant.FormatManagementConstant;

public class FormatManagementConstantTest {

    @Test
    public void testAllConstants() {

        Assertions.assertThat(FormatManagementConstant.AND.getConstValue()).isNotNull();
        Assertions.assertThat(FormatManagementConstant.OR.getConstValue()).isNotNull();
        Assertions.assertThat(FormatManagementConstant.GM1737.getConstValue()).isNotNull();
        Assertions.assertThat(FormatManagementConstant.GMW15862.getConstValue()).isNotNull();
        Assertions.assertThat(FormatManagementConstant.OTHER.getConstValue()).isNotNull();
    }

}
