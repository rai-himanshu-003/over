/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.domain.util.LoggedUser;

public class MultipleFLowStatusTest {

    MultipleFlowStatus multipleFLowStatus = new MultipleFlowStatus();

    @Before
    public void setUpData() {

        multipleFLowStatus.setFlow("flow");
        multipleFLowStatus.setId(1L);
        multipleFLowStatus.setStatus("true");
        multipleFLowStatus.setVin("test");
        multipleFLowStatus.setVersion(1);

        LoggedUser.logIn("OVER");
        multipleFLowStatus.prePersist();
        multipleFLowStatus.preUpdate();

    }

    @Test
    public void constructorTesting() {
        Assertions.assertThat(multipleFLowStatus.getFlow()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getId()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getStatus()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getVin()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getVersion()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getUserCreation()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getDateCreation()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getDateModif()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.getUserModif()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.toString()).isNotNull();
        Assertions.assertThat(multipleFLowStatus.maptoDto()).isNotNull();

        MultipleFlowStatus multipleFLowStatus = new MultipleFlowStatus(1L, "Test", "Vin", "Status");
        Assertions.assertThat(multipleFLowStatus).isNotNull();
    }

}
