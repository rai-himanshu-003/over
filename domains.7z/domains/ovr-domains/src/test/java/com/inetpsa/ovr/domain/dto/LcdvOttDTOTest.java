/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.interfaces.dto.LcdvOttDTO;

public class LcdvOttDTOTest {

    @Test
    public void lcdvOttTest() {

        LcdvOtt lcdvOtt = new LcdvOtt();
        lcdvOtt.setId(1L);
        lcdvOtt.setCharacteristic("TES");
        lcdvOtt.setIndicator("TR");
        lcdvOtt.setNature("T");
        lcdvOtt.setValue("t");
        lcdvOtt.setVin("TESTVIN");

        LcdvOtt lcdvOtt1 = new LcdvOtt();
        lcdvOtt1.setId(1L);
        lcdvOtt1.setCharacteristic("TES");
        lcdvOtt1.setIndicator("TR");
        lcdvOtt1.setNature("T");
        lcdvOtt1.setValue("t");
        lcdvOtt1.setVin("TESTVIN");

        Assertions.assertThat(lcdvOtt).isNotNull();
        Assertions.assertThat(lcdvOtt.getId()).isNotNull();
        Assertions.assertThat(lcdvOtt.getCharacteristic()).isNotNull();
        Assertions.assertThat(lcdvOtt.getIndicator()).isNotNull();
        Assertions.assertThat(lcdvOtt.getNature()).isNotNull();
        Assertions.assertThat(lcdvOtt.getValue()).isNotNull();
        Assertions.assertThat(lcdvOtt.hashCode()).isNotNull();
        Assertions.assertThat(lcdvOtt.toString()).isNotNull();
        Assertions.assertThat(lcdvOtt.maptoDto()).isNotNull();
        Assertions.assertThat(lcdvOtt.equals(lcdvOtt1)).isNotNull();

    }

    @Test
    public void lcdvOttDTOTest() {

        LcdvOttDTO lcdvOtt = new LcdvOttDTO();
        lcdvOtt.setId(1L);
        lcdvOtt.setCharacteristic("TES");
        lcdvOtt.setIndicator("TR");
        lcdvOtt.setNature("T");
        lcdvOtt.setValue("t");
        lcdvOtt.setVin("TESTVIN");

        Assertions.assertThat(lcdvOtt).isNotNull();
        Assertions.assertThat(lcdvOtt.getId()).isNotNull();
        Assertions.assertThat(lcdvOtt.getCharacteristic()).isNotNull();
        Assertions.assertThat(lcdvOtt.getIndicator()).isNotNull();
        Assertions.assertThat(lcdvOtt.getNature()).isNotNull();
        Assertions.assertThat(lcdvOtt.getValue()).isNotNull();
        Assertions.assertThat(lcdvOtt.toString()).isNotNull();
        Assertions.assertThat(lcdvOtt.mapTomodel()).isNotNull();

    }

}
