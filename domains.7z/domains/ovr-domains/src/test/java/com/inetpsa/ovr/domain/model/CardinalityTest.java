/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class CardinalityTest {

    @Test
    public void OvComposantTest() {

        Cardinality cardinality = new Cardinality();
        CardinalityPk cardinalityPk = new CardinalityPk();
        cardinalityPk.setPsaDataType("PSA");
        cardinalityPk.setPsaKey("10");
        cardinality.setCardinalityPk(cardinalityPk);
        cardinality.setCardinalityValue(1);

        Assertions.assertThat(cardinality).isNotNull();
        Assertions.assertThat(cardinalityPk).isNotNull();
        Assertions.assertThat(cardinalityPk.getPsaDataType()).isNotNull();
        Assertions.assertThat(cardinalityPk.getPsaKey()).isNotNull();
        Assertions.assertThat(cardinality.getId()).isNotNull();
        Assertions.assertThat(cardinality.getCardinalityValue()).isNotNull();
        Assertions.assertThat(cardinality.getCardinalityPk()).isNotNull();
        Assertions.assertThat(cardinality.toString()).isNotNull();

    }

}
