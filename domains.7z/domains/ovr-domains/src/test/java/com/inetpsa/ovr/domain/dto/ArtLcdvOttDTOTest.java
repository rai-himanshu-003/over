/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.ArtLcdvOttDTO;

public class ArtLcdvOttDTOTest {

    @Test
    public void ArtLcdvTest() {

        ArtLcdvOttDTO artLcdvOttDTO = new ArtLcdvOttDTO();

        artLcdvOttDTO.setIdArtLcdvDto(1L);
        artLcdvOttDTO.setFamilyArtLcdvDto("VE");
        artLcdvOttDTO.setCodeArtLcdvDto("A");
        artLcdvOttDTO.setVinArtLcdvDto("VIN");
        artLcdvOttDTO.setValueArtLcdvDto("ab");

        Assertions.assertThat(artLcdvOttDTO).isNotNull();
        Assertions.assertThat(artLcdvOttDTO.getIdArtLcdvDto()).isNotNull();
        Assertions.assertThat(artLcdvOttDTO.getValueArtLcdvDto()).isNotNull();
        Assertions.assertThat(artLcdvOttDTO.getVinArtLcdvDto()).isNotNull();
        Assertions.assertThat(artLcdvOttDTO.getCodeArtLcdvDto()).isNotNull();
        Assertions.assertThat(artLcdvOttDTO.getFamilyArtLcdvDto()).isNotNull();
        Assertions.assertThat(artLcdvOttDTO.mapTomodel()).isNotNull();
        artLcdvOttDTO.toString();

    }

}
