/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.KeysOv;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleRepository;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleKeysOvServiceTest {

    @Inject
    VehicleKeysOvService vehicleKeysOvService;

    @Inject
    private VehicleRepository vehicleRepository;

    @Test
    public void addOrUpdateOptionsTest() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVinNo("TESTVIN");

        vehicleRepository.add(vehicle);

        KeysOv keysOv = new KeysOv();
        keysOv.setData("TEST");
        keysOv.setEid("TEST");
        keysOv.setLabel("TEST");
        keysOv.setStandard("TEST");
        keysOv.setVin("TESTVIN");

        Assertions.assertThat(vehicleKeysOvService.addOrUpdateKeysOv(keysOv)).isTrue();

        List<KeysOv> keysOvList = vehicleKeysOvService.getvehicleKeysOvByVin(keysOv.getVin());

        Assertions.assertThat(keysOvList).isNotNull();

        Assertions.assertThat(vehicleKeysOvService.addOrUpdateKeysOv(keysOvList.get(0))).isTrue();

        Assertions.assertThat(vehicleKeysOvService.addOrUpdateKeysOv(null)).isFalse();

        Assertions.assertThat(vehicleKeysOvService.deleteKeysOvById(keysOvList.get(0).getId())).isTrue();

        Assertions.assertThat(vehicleKeysOvService.deleteKeysOvById(1L)).isFalse();

    }

}
