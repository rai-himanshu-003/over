/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.domain.util.LoggedUser;

public class VehicleTest {

    Vehicle vehicle;

    private String vinNo = "VINXXXXXXTEST0032";

    private String currentState = "TRDN";

    private String ccp = "AA";

    private String veh = "AA";

    private String xmlOv = "<?xml version='1.0' encoding='UTF-8'?><MESSAGE><ENTETE><NUM>62672795</NUM><TYP>ECOM</TYP><GRP>CORVETA</GRP><EME>GEPICSFV</EME><DST>CORVETA</DST><HDA>20190410000002</HDA></ENTETE><CONTENU><VEHICULE><CAR_VEH><UP>LT</UP><OF>9D24AAVH</OF><VIN>VINXXXXXXTEST0031</VIN><LCDV24>1CK9AFSLGKB0A010M0EUOGFR</LCDV24><DATE_EMON>20190409174117</DATE_EMON><DATE_ECOM>20190410000002</DATE_ECOM><DATE_EXTENSION>20190521</DATE_EXTENSION><OA>9D24AAVH</OA><APVPR>15492FV20618</APVPR><NRE>e2*2007/46*0624*03</NRE><TVV>ERHNPJ-A1B000</TVV><OPTIONS>0L2 5LS 80I 8P9 8Y5 A2V A63 A6M A7E AA0 AEF AKK AKO AKX AOL AQR AWM AWW AXG AXJ AY0 B26 B48 C7C C95 CE1 CHO CJ2 CS0 D26 D6I D6K DD8 DE8 DFA DFM FX3 G02 G4O IO5 J1U J69 K34 K80 KL5 KTM LHD MBM MM1 MRE N34 NCH NCV O4H OAT PGK Q24 QQ5 R1C RQ6 RVF T2C T3U T4A T7E T83 T87 TR0 TTB U91 UC3 UD5 UDD UDQ UJO UL3 UX8 VQ9 W9T WHE WZI Y74 YA2 Z86</OPTIONS><MODEL>0CD06</MODEL><MODELYEAR>2020</MODELYEAR></CAR_VEH><COMPOSANTS><E>5XHEAM0101205</E></COMPOSANTS><REFERENCESELECTRONIQUES><E>32Y9693240280</E></REFERENCESELECTRONIQUES></VEHICULE></CONTENU></MESSAGE>";

    private Date dateExtension = new java.util.Date();

    private String lcdvOtt = "BPCDVINXXXXXXTEST0032   U920190528SSSE2GK0F3TPG1C0A0D0M0F4OVFXOO   03GC930A GC19GA GG819A                                                                                                                                                                                                                                                                                                                                          012DUB07CPDZHOJCPDPD22CPDLA04CPDPX37CPDAQ03CPDGB38CPDWZ07CPDRG04CPDWO07CPDDK12CPDRS03CP                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ";

    private LocalDateTime dateCreation = LocalDateTime.now();;

    private String userCreation = "OVER";

    @Before
    public void setUpData() {
        LoggedUser.logIn("OVER");
    }

    @After
    public void cleanUpData() {
        LoggedUser.logOut();
    }

    @Test
    public void constructorTesting() {
        vehicle = new Vehicle(vinNo, currentState, ccp, veh, dateExtension, userCreation, dateCreation, 1);
        Assertions.assertThat(vehicle).isNotNull();
    }

    @Test
    public void setterGetterTesting() {
        vehicle = new Vehicle();

        vehicle.setCcp(ccp);
        vehicle.setCurrentState(currentState);
        vehicle.setDateExtension(dateExtension);
        vehicle.setVinNo(vinNo);
        vehicle.setVeh(veh);

        vehicle.setApvpr("test");
        vehicle.setComposants(null);
        vehicle.setComposantsOv(null);
        vehicle.setDateEcom(new Date());
        vehicle.setDateEmon(new Date());
        vehicle.setKeysOv(null);
        vehicle.setLcdv24("test");
        vehicle.setLcdvOttOv(null);
        vehicle.setModel("model");
        vehicle.setModelYear("2020");
        vehicle.setNre("nre");
        vehicle.setOa("oa");
        vehicle.setOf("of");
        vehicle.setOptions(null);
        vehicle.setReferencesElectroniques(null);
        vehicle.setTvv("tvv");
        vehicle.setUp("up");
        vehicle.setVersion(1);
        vehicle.setModelYearSuffix("A");
        vehicle.setMultipleFlowStatus(new ArrayList<MultipleFlowStatus>());
        Assertions.assertThat(vehicle.getApvpr()).isNotNull();
        Assertions.assertThat(vehicle.getComposants()).isNull();
        Assertions.assertThat(vehicle.getComposantsOv()).isNull();
        Assertions.assertThat(vehicle.getDateEcom()).isNotNull();
        Assertions.assertThat(vehicle.getDateEmon()).isNotNull();
        Assertions.assertThat(vehicle.getKeysOv()).isNull();
        Assertions.assertThat(vehicle.getLcdv24()).isNotNull();
        Assertions.assertThat(vehicle.getLcdvOttOv()).isNull();
        Assertions.assertThat(vehicle.getModel()).isNotNull();
        Assertions.assertThat(vehicle.getModelYear()).isNotNull();
        Assertions.assertThat(vehicle.getNre()).isNotNull();
        Assertions.assertThat(vehicle.getOa()).isNotNull();
        Assertions.assertThat(vehicle.getOf()).isNotNull();
        Assertions.assertThat(vehicle.getOptions()).isNull();
        Assertions.assertThat(vehicle.getReferencesElectroniques()).isNull();
        Assertions.assertThat(vehicle.getTvv()).isNotNull();
        Assertions.assertThat(vehicle.getUp()).isNotNull();
        Assertions.assertThat(vehicle.getVersion()).isNotNull();
        Assertions.assertThat(vehicle.getMultipleFlowStatus()).isNotNull();
        vehicle.prePersist();
        vehicle.preUpdate();
        Assertions.assertThat(vehicle.getCcp()).isNotNull();
        Assertions.assertThat(vehicle.getCurrentState()).isNotNull();
        Assertions.assertThat(vehicle.getDateExtension()).isNotNull();
        Assertions.assertThat(vehicle.getVinNo()).isNotNull();
        Assertions.assertThat(vehicle.getVeh()).isNotNull();
        Assertions.assertThat(vehicle.toString()).isNotNull();
        Assertions.assertThat(vehicle.getDateModif()).isNotNull();
        Assertions.assertThat(vehicle.getDateCreation()).isNotNull();
        Assertions.assertThat(vehicle.getUserModif()).isNotNull();
        Assertions.assertThat(vehicle.getUserCreation()).isNotNull();
        Assertions.assertThat(vehicle.getModelYearSuffix()).isNotNull();

    }
}
