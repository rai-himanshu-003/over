/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.domain.model.TechnicalParameter;
import com.inetpsa.ovr.domain.repository.InterfaceRepository;
import com.inetpsa.ovr.domain.repository.InterfaceRulesRepository;
import com.inetpsa.ovr.domain.repository.TechnicalParameterRepository;
import com.inetpsa.ovr.interfaces.dto.InterfaceDto;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class InterfaceRulesServiceTest {

    @Inject
    InterfaceRulesService interfaceRulesService;

    InterfaceRule interfaceRule = null;
    InterfaceRulesDto interfaceRulesDto = null;
    Interface interfaceObj;
    TechnicalParameter techParameter;

    @Inject
    TechnicalParameterRepository parameterRepository;

    @Inject
    private InterfaceRulesRepository interfaceRulesRepository;

    @Inject
    private InterfaceRepository interfaceRepository;

    @Before
    public void setUpData() {
        interfaceRule = new InterfaceRule();
        // interfaceRule.setIntId(1l);
        interfaceRule.setPriority(1);
        interfaceRule.setFilterType(1);
        interfaceRule.setCountry("FR");
        interfaceRule.setVehicleFamily("CK9");
        interfaceRule.setProductionCentre("CK9"); // interfaceRule.setId((long) 1); interfaceRule.setMaxEcom(LocalDateTime.MAX);
        interfaceRule.setMinEcom(new Date());
        interfaceRule.setVersion(0);

        interfaceRulesDto = new InterfaceRulesDto();
        interfaceRulesDto.setVersion(0);
        interfaceRulesDto.setId(1l);
        interfaceRulesDto.setInterfaceId((long) 1);
        interfaceRulesDto.setPriority(1);

        interfaceObj = new Interface();
        interfaceObj.setId(1l);
        interfaceObj.setInterfaceName("GEPICS_TO_OVER");

        techParameter = new TechnicalParameter();
        techParameter.setCode(CommonConstant.SEND_RULES_CONSTANT.getConstValue());
        techParameter.setLable("corvet interface rules export flag");
        techParameter.setValue(CommonConstant.PARAMETER_OK.getConstValue());

        Assertions.assertThat(interfaceRulesService).isNotNull();

    }

    @Test
    public void addInterfaceRules() {
        interfaceRulesRepository.add(interfaceRule);
        Assertions.assertThat(interfaceRule).isNotNull();
    }

    @Test
    public void getInterfaceRules() {
        interfaceRulesRepository.add(interfaceRule);
        List<InterfaceRulesDto> interfaceRulesDtos = interfaceRulesService.getInterfaceRules(1l);
        Assertions.assertThat(interfaceRulesDtos).isNotNull();
    }

    @Test
    public void addOrUpdateInterfaceRule() {
        parameterRepository.add(techParameter);
        Boolean msg = interfaceRulesService.addOrUpdateInterfaceRule(interfaceRulesDto);
        Assertions.assertThat(msg).isTrue();
        parameterRepository.remove(techParameter);
    }

    @Test
    public void addOrUpdateInterfaceRuleException() {
        Boolean msg = interfaceRulesService.addOrUpdateInterfaceRule(null);
        Assertions.assertThat(msg).isFalse();
    }

    @Test
    public void addOrUpdateInterfaceRule1() {
        parameterRepository.add(techParameter);
        interfaceRule.setPriority(2);
        interfaceRulesRepository.add(interfaceRule);
        interfaceRulesDto.setPriority(2);
        Boolean msg = interfaceRulesService.addOrUpdateInterfaceRule(interfaceRulesDto);
        Assertions.assertThat(msg).isTrue();
        parameterRepository.remove(techParameter);
    }

    @Test
    public void deleteInterfaceRule() {
        parameterRepository.add(techParameter);
        interfaceRulesRepository.add(interfaceRule);
        interfaceRulesService.deleteInterfaceRule(new Long(1));
        Assertions.assertThat(interfaceRule).isNotNull();
        parameterRepository.remove(techParameter);
    }

    @Test
    public void getInterfaceList() {
        interfaceRepository.add(interfaceObj);
        List<InterfaceDto> intList = interfaceRulesService.getInterfaceList();
        Assertions.assertThat(intList).isNotNull();
    }

}
