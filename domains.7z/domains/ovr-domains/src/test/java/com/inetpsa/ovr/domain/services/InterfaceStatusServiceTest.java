/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.Date;
import java.util.Optional;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.InterfaceStatus;
import com.inetpsa.ovr.domain.repository.InterfaceStatusRepository;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class InterfaceStatusServiceTest {

    @Inject
    InterfaceStatusService interfaceStatusService;

    Optional<InterfaceStatus> interfaceStatusOptional;
    InterfaceStatus interfaceStatus, interfaceStatus1;

    @Inject
    private InterfaceStatusRepository interfaceStatusRepository;

    @Test
    public void getandUpdateInterfaceStatus() {
        InterfaceStatus interfaceStatus = new InterfaceStatus("OVER_TO_OTT", "ACTIVE");
        interfaceStatusRepository.add(interfaceStatus);

        interfaceStatusOptional = interfaceStatusService.getInterfaceStatus("OVER_TO_OTT");
        Assertions.assertThat(interfaceStatusOptional).isNotNull();

        interfaceStatus = interfaceStatusOptional.get();
        interfaceStatusService.updateInterfaceStatus(interfaceStatus);
        interfaceStatusService.updateInterfaceStatus(null);
        Assertions.assertThat(interfaceStatus).isNotNull();
        interfaceStatusRepository.remove(interfaceStatus);

    }

    @Test
    public void isOVERTimedOutFalse() {
        Assertions.assertThat(interfaceStatusService.isOVERTimedOut(new Date(), 1 + "")).isFalse();
    }

    @Test
    public void isOVERTimedOutFalse1() {
        Assertions.assertThat(interfaceStatusService.isOVERTimedOut(null, "1")).isFalse();
    }

    @Test
    public void isOVERTimedOutTrue() {
        Assertions.assertThat(interfaceStatusService.isOVERTimedOut(new Date(System.currentTimeMillis() - 3600 * 1000), 1 + "")).isTrue();
    }

    @Test
    public void updateInterfaceStatusTest() {

        interfaceStatus = new InterfaceStatus();
        interfaceStatus.setInterfaceName("OVER_TO_OTT");
        interfaceStatus.setStatus("ACTIVE");
        interfaceStatus.setRemark("JUNIT TESTING");
        interfaceStatus.setStatusList("ACTIVE,STOPPED");
        interfaceStatus.setVersion(1);

        Assertions.assertThat(interfaceStatus.getRemark()).isNotNull();
        Assertions.assertThat(interfaceStatus.toString()).isNotNull();
        Assertions.assertThat(interfaceStatusService.updateInterfaceStatus(interfaceStatus)).isFalse();

        interfaceStatusRepository.add(interfaceStatus);

        interfaceStatus1 = new InterfaceStatus();
        interfaceStatus1.setInterfaceName("OVER_TO_OTT");
        interfaceStatus1.setStatus("ACTIVE");
        interfaceStatus1.setRemark("JUNIT TESTING");
        interfaceStatus1.setStatus("WAITING");
        interfaceStatus1.setVersion(100);

        Assertions.assertThat(interfaceStatusService.updateInterfaceStatus(interfaceStatus1)).isFalse();
        interfaceStatus.setVersion(2);
        Assertions.assertThat(interfaceStatusService.updateInterfaceStatus(interfaceStatus)).isTrue();

        Assertions.assertThat(interfaceStatusService.getAllInterfaces()).isNotNull();

    }
}
