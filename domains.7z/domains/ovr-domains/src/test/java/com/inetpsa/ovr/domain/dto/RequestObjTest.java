/*
 * Creation : 24 Jan 2020
 */
package com.inetpsa.ovr.domain.dto;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import com.inetpsa.ovr.interfaces.dto.ws.ComponentsOv;
import com.inetpsa.ovr.interfaces.dto.ws.Criteria;
import com.inetpsa.ovr.interfaces.dto.ws.Header;
import com.inetpsa.ovr.interfaces.dto.ws.RequestObj;
import com.inetpsa.ovr.interfaces.dto.ws.Response;

public class RequestObjTest {

    Header header;
    Criteria criteria;

    ComponentsOv componentsOv;

    Response response;

    RequestObj requestObj;

    @Before
    public void setup() {

        header = new Header();
        header.setClient("MZPXXXX");

        criteria = new Criteria();
        criteria.setVin("VINTEST01");
        List<Criteria> cl = new ArrayList<>();
        cl.add(criteria);

        componentsOv = new ComponentsOv();
        componentsOv.setData("Data");
        componentsOv.setId("1");
        componentsOv.setLabel("label");
        componentsOv.setStandard("standard");

        List<ComponentsOv> ovs = new ArrayList<>();
        ovs.add(componentsOv);

        List<String> dummyList = new ArrayList<>();
        dummyList.add("abc");

        response = new Response();
        response.setArtificialLcdv(dummyList);
        response.setComponentsOv(ovs);
        response.setRpoCodes(dummyList);
        response.setVehiculeData(dummyList);

        requestObj = new RequestObj();
        requestObj.setCriteria(cl);
        requestObj.setResponse(response);
        requestObj.setHeader(header);

    }

    @Test
    public void getVehiclesTest() {

        Assertions.assertThat(header.getClient()).isEqualTo("MZPXXXX");
        Assertions.assertThat(criteria.getVin()).isEqualTo("VINTEST01");
        Assertions.assertThat(response.getArtificialLcdv()).isNotEmpty();
        Assertions.assertThat(response.getComponentsOv()).isNotEmpty();
        Assertions.assertThat(response.getRpoCodes()).isNotEmpty();
        Assertions.assertThat(response.getVehiculeData()).isNotEmpty();
        Assertions.assertThat(requestObj.getCriteria()).isNotEmpty();
        Assertions.assertThat(requestObj.getHeader()).isNotNull();
        Assertions.assertThat(requestObj.getResponse()).isNotNull();

        Assertions.assertThat(criteria.toString()).isNotNull();
        Assertions.assertThat(response.toString()).isNotNull();
        Assertions.assertThat(requestObj.toString()).isNotNull();
    }

}
