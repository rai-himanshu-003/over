/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.inetpsa.ovr.domain.model.Audit;
import com.inetpsa.ovr.domain.model.AuditPk;
import com.inetpsa.ovr.interfaces.dto.InterfaceAuditDto;

@RunWith(SeedITRunner.class)
public class AuditServiceTest {

    Audit audit;
    AuditPk auditPk;
    InterfaceAuditDto interfaceAuditDto;

    @Inject
    private AuditService auditService;

    List<InterfaceAuditDto> list;

    @Before
    public void setData() {
        auditPk = new AuditPk("req_to_ott_20190723144520000000TEST.dat");
        audit = new Audit(auditPk, 0, 0, "JunitTest");
        interfaceAuditDto = new InterfaceAuditDto();

        interfaceAuditDto.setInterfaceName("Junit");
        interfaceAuditDto.setFileName("req_to");
        interfaceAuditDto.setErrorCount(0);
        interfaceAuditDto.setSuccessCount(0);
        interfaceAuditDto.setUserCreation("GEPICS");
        interfaceAuditDto.setDateCreation("10/10/2019");
        interfaceAuditDto.setDateCreationOrder("asc");
        interfaceAuditDto.setErrorCountOrder("asc");
        interfaceAuditDto.setFileNameOrder("asc");
        interfaceAuditDto.setFromDateCreation("01/09/2019");
        interfaceAuditDto.setToDateCreation("30/10/2019");
        interfaceAuditDto.setInterfaceOrder("asc");
        interfaceAuditDto.setSuccessCountOrder("asc");
        interfaceAuditDto.setUserCreationOrder("asc");
        Assertions.assertThat(auditService).isNotNull();
    }

    @Test
    public void addAudit() {
        auditService.addAudit(audit);
        Assertions.assertThat(audit).isNotNull();
    }

    @Test
    public void toStringTest() {
        Assertions.assertThat(auditPk.getSerialversionuid()).isNotNull();
        Assertions.assertThat(auditPk.toString()).isNotNull();
    }

    @Test
    public void getAuditListTest1() {
        auditService.addAudit(audit);
        list = auditService.getAuditList(interfaceAuditDto, 0, 10);
        Assertions.assertThat(list).isNotNull();
    }

    @Test
    public void getAuditListTest2() {
        interfaceAuditDto.setDateCreationOrder("desc");
        interfaceAuditDto.setErrorCountOrder("desc");
        interfaceAuditDto.setFileNameOrder("desc");
        interfaceAuditDto.setInterfaceOrder("desc");
        interfaceAuditDto.setSuccessCountOrder("desc");
        interfaceAuditDto.setUserCreationOrder("desc");
        interfaceAuditDto.setUserCreation(null);
        interfaceAuditDto.setDateCreation(null);
        interfaceAuditDto.setFromDateCreation(null);
        interfaceAuditDto.setToDateCreation(null);
        auditService.addAudit(audit);
        list = auditService.getAuditList(interfaceAuditDto, 0, 10);
        Assertions.assertThat(list).isNotEmpty();
    }

    @Test
    public void getAuditListTest13() {
        interfaceAuditDto.setDateCreationOrder(null);
        interfaceAuditDto.setErrorCountOrder(null);
        interfaceAuditDto.setFileNameOrder(null);
        interfaceAuditDto.setInterfaceOrder(null);
        interfaceAuditDto.setSuccessCountOrder(null);
        interfaceAuditDto.setUserCreationOrder(null);
        auditService.addAudit(audit);
        list = auditService.getAuditList(interfaceAuditDto, 0, 10);
        Assertions.assertThat(list).isNotNull();
    }

    @Test
    public void getAuditListCountTest() {
        long count = auditService.getAuditListCount();
        Assertions.assertThat(count).isNotNull();
    }

    @Test
    public void getLatestAuditTest() {
        audit.setFlowname("TEST");
        auditService.addAudit(audit);
        auditService.getLatestAuditByIntName("TEST");
        Assertions.assertThat(audit).isNotNull();
    }
}
