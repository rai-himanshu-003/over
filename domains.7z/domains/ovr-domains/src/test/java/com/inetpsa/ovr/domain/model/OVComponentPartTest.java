/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class OVComponentPartTest {

    @Test
    public void OvComposantTest() {

        OVComponentPart ovComponentPart = new OVComponentPart();

        ovComponentPart.setId(1l);
        ovComponentPart.setStandard(5l);
        ovComponentPart.setIntSeq("test");
        ovComponentPart.setFilter("test");
        ovComponentPart.setOvCompId(1l);
        ovComponentPart.setValue(1l);

        OVComponentPart ovComponentPart1 = new OVComponentPart();

        ovComponentPart1.setId(1l);
        ovComponentPart1.setStandard(5l);
        ovComponentPart1.setIntSeq("test");
        ovComponentPart1.setFilter("test");
        ovComponentPart1.setOvCompId(1l);
        ovComponentPart1.setValue(1l);

        Assertions.assertThat(ovComponentPart).isNotNull();
        Assertions.assertThat(ovComponentPart.getId()).isNotNull();
        Assertions.assertThat(ovComponentPart.getOvCompId()).isNotNull();
        Assertions.assertThat(ovComponentPart.getValue()).isNotNull();
        Assertions.assertThat(ovComponentPart.getStandard()).isNotNull();
        Assertions.assertThat(ovComponentPart.getIntSeq()).isNotNull();
        Assertions.assertThat(ovComponentPart.getFilter()).isNotNull();
        Assertions.assertThat(ovComponentPart.maptoDto()).isNotNull();
        Assertions.assertThat(ovComponentPart.hashCode()).isNotNull();
        Assertions.assertThat(ovComponentPart.toString()).isNotNull();

        Assertions.assertThat(ovComponentPart.equals(ovComponentPart1)).isNotNull();

    }

}
