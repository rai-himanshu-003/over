/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.ovr.domain.dto;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.inetpsa.ovr.domain.model.KeysOv;
import com.inetpsa.ovr.interfaces.dto.KeysOvDTO;

public class KeysOvDTOTest {

    @Test
    public void keysOvTest() {

        KeysOv keysOv = new KeysOv();
        keysOv.setId(1L);
        keysOv.setData("TEST");
        keysOv.setEid("TEST");
        keysOv.setLabel("TEST");
        keysOv.setStandard("TEST");
        keysOv.setVin("TESTVIN");

        KeysOv keysOv1 = new KeysOv();
        keysOv1.setId(1L);
        keysOv1.setData("TEST");
        keysOv1.setEid("TEST");
        keysOv1.setLabel("TEST");
        keysOv1.setStandard("TEST");
        keysOv1.setVin("TESTVIN");

        Assertions.assertThat(keysOv).isNotNull();
        Assertions.assertThat(keysOv.getId()).isNotNull();
        Assertions.assertThat(keysOv.getEid()).isNotNull();
        Assertions.assertThat(keysOv.getVin()).isNotNull();
        Assertions.assertThat(keysOv.getStandard()).isNotNull();
        Assertions.assertThat(keysOv.getLabel()).isNotNull();
        Assertions.assertThat(keysOv.getData()).isNotNull();
        Assertions.assertThat(keysOv.toString()).isNotNull();
        Assertions.assertThat(keysOv.maptoDto()).isNotNull();
        Assertions.assertThat(keysOv.hashCode()).isNotNull();
        Assertions.assertThat(keysOv.equals(keysOv1)).isNotNull();

    }

    @Test
    public void keysOvDTOTest() {

        KeysOvDTO keysOv = new KeysOvDTO();
        keysOv.setId(1L);
        keysOv.setData("TEST");
        keysOv.setEid("TEST");
        keysOv.setLabel("TEST");
        keysOv.setStandard("TEST");
        keysOv.setVin("TESTVIN");

        Assertions.assertThat(keysOv).isNotNull();
        Assertions.assertThat(keysOv.getId()).isNotNull();
        Assertions.assertThat(keysOv.getEid()).isNotNull();
        Assertions.assertThat(keysOv.getVin()).isNotNull();
        Assertions.assertThat(keysOv.getStandard()).isNotNull();
        Assertions.assertThat(keysOv.getLabel()).isNotNull();
        Assertions.assertThat(keysOv.getData()).isNotNull();
        Assertions.assertThat(keysOv.toString()).isNotNull();
        Assertions.assertThat(keysOv.mapTomodel()).isNotNull();

    }

}
