/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.domain.repository.LcdvOttRepository;
import com.inetpsa.ovr.interfaces.dto.ComposantsDTO;
import com.inetpsa.ovr.interfaces.dto.KeysOvDTO;
import com.inetpsa.ovr.interfaces.dto.LcdvOttDTO;
import com.inetpsa.ovr.interfaces.dto.ReferencesElectroniquesDTO;

@RunWith(SeedITRunner.class)
@JpaUnit("ovr-domain-jpa-unit")
@Transactional
public class VehicleLcdvOttServiceTest {

    @Inject
    VehicleLcdvOttService VehicleLcdvOttService;
    @Inject
    LcdvJdbcService lcdvJdbcService;

    @Inject
    LcdvOttRepository lcdvOttRepository;

    @Test(expected = Exception.class)
    public void vehicleLcdvOttService() {

        LcdvOtt lcdvOtt = new LcdvOtt();

        lcdvOtt.setCharacteristic("TES");
        lcdvOtt.setIndicator("TR");
        lcdvOtt.setNature("T");
        lcdvOtt.setValue("t");
        lcdvOtt.setVin("TESTVIN");

        Assertions.assertThat(VehicleLcdvOttService.addOrUpdateLcdvOtt(lcdvOtt)).isNotNull();

        lcdvOtt.setId(1l);
        lcdvOttRepository.add(lcdvOtt);
        Assertions.assertThat(VehicleLcdvOttService.addOrUpdateLcdvOtt(lcdvOtt)).isNotNull();
        Assertions.assertThat(VehicleLcdvOttService.deleteLcdvOttById(1L)).isTrue();
        Assertions.assertThat(VehicleLcdvOttService.deleteLcdvOttById(1L)).isFalse();

        Assertions.assertThat(VehicleLcdvOttService.getLcdvOttByVin("TESTVIN")).isEmpty();

    }

    @Test
    public void getCompoSantsForCorvet() {
        List<String> vinList = new ArrayList<>();
        vinList.add("VIN123");
        List<ComposantsDTO> composantsDTOs = lcdvJdbcService.getCompoSantsForCorvet(vinList);
        Assertions.assertThat(composantsDTOs).isNotNull();
    }

    @Test
    public void getLCDVForCorvet() {
        List<String> vinList = new ArrayList<>();
        vinList.add("VIN123");
        List<LcdvOttDTO> lcdvOttDTOs = lcdvJdbcService.getLCDVForCorvet(vinList);
        Assertions.assertThat(lcdvOttDTOs).isNotNull();
    }

    @Test
    public void getRefElectForCorvet() {
        List<String> vinList = new ArrayList<>();
        vinList.add("VIN123");
        List<ReferencesElectroniquesDTO> referencesElectroniquesDTOs = lcdvJdbcService.getRefElectForCorvet(vinList);
        Assertions.assertThat(referencesElectroniquesDTOs).isNotNull();
    }

    @Test
    public void getKeysOVForCorvet() {
        List<String> vinList = new ArrayList<>();
        vinList.add("VIN123");
        List<KeysOvDTO> keysOvDTOs = lcdvJdbcService.getKeysOVForCorvet(vinList);
        Assertions.assertThat(keysOvDTOs).isNotNull();
    }

}
