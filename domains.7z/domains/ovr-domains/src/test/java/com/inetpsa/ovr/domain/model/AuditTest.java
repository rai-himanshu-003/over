/*
 * Creation : 24 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

@RunWith(SeedITRunner.class)
public class AuditTest {

    AuditPk auditPk;
    Audit audit;

    @Test
    public void constructorTesting() {
        auditPk = new AuditPk("req_to_ott_20190723144520000000TEST.dat");
        audit = new Audit(auditPk, 0, 0, "Test");
        Assertions.assertThat(audit).isNotNull();
    }

    @Test
    public void setterGetterTesting() {
        auditPk = new AuditPk();
        auditPk.setFileName("TestFileName");

        audit = new Audit();
        audit.setAuditModelPk(auditPk);
        audit.setErrorCount(0);
        audit.setInterfaceName("Test");
        audit.setSuccessCount(0);

        Assertions.assertThat(audit.getAuditModelPk()).isEqualTo(auditPk);
        Assertions.assertThat(audit.getErrorCount()).isNotNegative();
        Assertions.assertThat(audit.getSuccessCount()).isNotNegative();
        Assertions.assertThat(audit.getInterfaceName()).isEqualToIgnoringCase("Test");
        Assertions.assertThat(audit.getUserCreation()).isNull();
    }
}
