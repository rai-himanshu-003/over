/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.TranslationState;
import com.inetpsa.ovr.domain.model.VehicleError;
import com.inetpsa.ovr.domain.repository.VehicleErrorRepository;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;

/**
 * The Class VehicleErrorRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleErrorRepositoryImpl extends BaseJpaRepository<VehicleError, String> implements VehicleErrorRepository {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleErrorRepositoryImpl.class);

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The Constant FLOWNAME. */
    private static final String FLOWNAME = "flowName";

    /** The date format. */
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * This method get details of vin with given filter criteria.
     *
     * @param resendToOTTDto of type {@link ResendToOTTDto} represents the code attribute
     * @param query of type {@literal StringBuilder} represents the query
     * @param callFrom of type {@literal Boolean} represents the calling method.
     * @return a {@link List} of {@link ResendToOTTDto}
     */

    // As per Jira 100 the DATE_EXTENSION has been change to DATE_EMON in below method
    public Query filterCriteria(ResendToOTTDto resendToOTTDto, StringBuilder query, Boolean callFrom) {
        LocalDate extFromDate = null;
        LocalDate extToDate = null;
        LocalDate errFromDate = null;
        LocalDate errToDate = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        StringBuilder orderBy = new StringBuilder();
        String finalQuery = null;
        StringBuilder subQuery = new StringBuilder(" AND oe.DATE_CREATION=(select MAX(DATE_CREATION) from OVRQTERR where vin=ov.vin AND flowname='"
                + resendToOTTDto.getFlowName() + "'");

        String cons = null;
        if (resendToOTTDto != null) {
            if (!(resendToOTTDto.getExtFromDate() == null || resendToOTTDto.getExtFromDate().equals("null"))) {
                extFromDate = LocalDate.parse(resendToOTTDto.getExtFromDate(), formatter);
            }

            if (!(resendToOTTDto.getExtToDate() == null || resendToOTTDto.getExtToDate().equals("null"))) {
                extToDate = LocalDate.parse(resendToOTTDto.getExtToDate(), formatter);
            }

            if (!(resendToOTTDto.getErrFromDate() == null || resendToOTTDto.getErrFromDate().equals("null"))) {
                errFromDate = LocalDate.parse(resendToOTTDto.getErrFromDate(), formatter);
            }

            if (!(resendToOTTDto.getErrToDate() == null || resendToOTTDto.getErrToDate().equals("null"))) {
                errToDate = LocalDate.parse(resendToOTTDto.getErrToDate(), formatter);
            }

            if (resendToOTTDto.getVin() != null) {
                query.append(" AND upper(ov.vin) like:vin ESCAPE '\\' ");
            }
            if (resendToOTTDto.getCcp() != null && resendToOTTDto.getCcp().trim().length() != 0) {
                query.append(" AND upper(ov.ccp) like:ccp ESCAPE '\\' ");

            }
            if (resendToOTTDto.getVeh() != null && resendToOTTDto.getVeh().trim().length() != 0) {
                query.append(" AND upper (ov.veh) like:veh ESCAPE '\\'");

            }
            if (errFromDate != null) {
                query.append(" AND trunc(oe.DATE_CREATION) >=:errFromDate ");
                // subQuery.append(" and trunc(date_creation) >= :errFromDate");
            }
            if (errToDate != null) {
                query.append(" AND trunc(oe.DATE_CREATION) <=:errToDate ");

                // subQuery.append(" and trunc(date_creation) <= :errToDate");
            }
            if (resendToOTTDto.getCodeErr() != null) {
                query.append(" AND upper(oe.ERR_CODE) like:errCode ESCAPE '\\' ");

            }
            if (resendToOTTDto.getLabelErr() != null && resendToOTTDto.getLabelErr().trim().length() != 0) {
                query.append(" AND upper(oe.ERR_DESCRIPTION) like:errLabel ESCAPE '\\' ");
            }
            if (resendToOTTDto.getComplementErr() != null && resendToOTTDto.getComplementErr().trim().length() != 0) {
                query.append(" AND upper(oe.ERR_COMPLEMENT) like:errCmp ");
            }
            if (extFromDate != null) {
                query.append(" AND trunc(ov.DATE_EMON) >=:extFromDate  ");
            }
            if (extToDate != null) {
                query.append(" AND trunc(ov.DATE_EMON) <=:extToDate ");
            }

            if (callFrom) {
                orderBy.append("Order").append(" by");
                cons = orderBy.toString();
                if (resendToOTTDto.getVinOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append("  ov.vin ").append(resendToOTTDto.getVinOrder());

                }
                if (resendToOTTDto.getCcpOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append("  ov.ccp ").append(resendToOTTDto.getCcpOrder());

                }
                if (resendToOTTDto.getVehOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append("  ov.veh ").append(resendToOTTDto.getVehOrder());
                }

                if (resendToOTTDto.getCodeErrOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append("  oe.ERR_CODE ").append(resendToOTTDto.getCodeErrOrder());
                }

                if (resendToOTTDto.getLabelErrOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append("  oe.ERR_DESCRIPTION ").append(resendToOTTDto.getLabelErrOrder());
                }

                if (resendToOTTDto.getComplementErrOrder() != null) {
                    if (!orderBy.toString().equals("Order by")) {
                        orderBy.append(",");
                    }
                    orderBy.append("  oe.ERR_COMPLEMENT ").append(resendToOTTDto.getComplementErrOrder());
                }
                if (resendToOTTDto.getExtDateOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" ov.DATE_EMON ").append(resendToOTTDto.getExtDateOrder());
                }
                if (resendToOTTDto.getErrDateOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append("  oe.date_creation ").append(resendToOTTDto.getErrDateOrder());
                }

            }
        }
        if (callFrom) {

            if (orderBy.toString().equals(cons)) {
                orderBy.append(" oe.date_creation desc,ov.vin asc ");
            } else {
                orderBy.append(" ,ov.vin asc ");
            }
            finalQuery = query.append(orderBy).toString();
        } else
            finalQuery = query.append(subQuery.toString()).append(")").append(orderBy).toString();
        // System.out.println("final query------------------->" + finalQuery);

        Query hql = super.getEntityManager().createNativeQuery(finalQuery);
        if (resendToOTTDto != null) {
            if (resendToOTTDto.getVin() != null)
                hql.setParameter("vin", "%" + resendToOTTDto.getVin().replace("_", "\\_").trim().toUpperCase() + "%");
            if (resendToOTTDto.getCcp() != null && resendToOTTDto.getCcp().trim().length() != 0)
                hql.setParameter("ccp", "%" + resendToOTTDto.getCcp().replace("_", "\\_").trim().toUpperCase() + "%");
            if (errFromDate != null) {
                hql.setParameter("errFromDate", errFromDate);
            }

            if (errToDate != null) {
                hql.setParameter("errToDate", errToDate);
            }
            if (extFromDate != null) {
                hql.setParameter("extFromDate", extFromDate);
            }

            if (extToDate != null) {
                hql.setParameter("extToDate", extToDate);
            }
            if (resendToOTTDto.getVeh() != null && resendToOTTDto.getVeh().trim().length() != 0)
                hql.setParameter("veh", "%" + resendToOTTDto.getVeh().trim().toUpperCase() + "%");
            if (resendToOTTDto.getCodeErr() != null)
                hql.setParameter("errCode", "%" + resendToOTTDto.getCodeErr().replace("_", "\\_").trim().toUpperCase() + "%");
            if (resendToOTTDto.getLabelErr() != null && resendToOTTDto.getLabelErr().trim().length() != 0)
                hql.setParameter("errLabel", "%" + resendToOTTDto.getLabelErr().trim().replace("_", "\\_").toUpperCase() + "%");
            if (resendToOTTDto.getComplementErr() != null && resendToOTTDto.getComplementErr().trim().length() != 0)
                hql.setParameter("errCmp", "%" + resendToOTTDto.getComplementErr().replace("_", "\\_").toUpperCase().trim() + "%");

        }

        return hql;

    }

    /**
     * Generate response.
     *
     * @param arrayList the array list
     * @param resendToOTTDtoList the resend to OTT dto list
     * @return the list
     */
    private List<ResendToOTTDto> generateResponse(List arrayList, List<ResendToOTTDto> resendToOTTDtoList) {
        Iterator itr = arrayList.iterator();
        while (itr.hasNext()) {
            Object[] obj = (Object[]) (itr.next());
            ResendToOTTDto resendToOTTDtoObj = new ResendToOTTDto();
            resendToOTTDtoObj.setVin(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER0]).orElse("").toString());
            resendToOTTDtoObj.setCcp(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER1]).orElse("").toString());
            resendToOTTDtoObj.setVeh(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER2]).orElse("").toString());
            if (obj[OVERConstants.MAGICNUMBER3] != null)
                resendToOTTDtoObj.setExtFromDate(obj[OVERConstants.MAGICNUMBER3].toString());
            resendToOTTDtoObj.setCodeErr(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER4]).orElse("").toString());
            resendToOTTDtoObj.setLabelErr(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER5]).orElse("").toString());
            resendToOTTDtoObj.setComplementErr(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER6]).orElse("").toString());
            if (obj[OVERConstants.MAGICNUMBER7] != null)
                resendToOTTDtoObj.setErrFromDate(obj[OVERConstants.MAGICNUMBER7].toString());
            resendToOTTDtoObj.setCurrentState(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER8]).orElse("").toString());
            resendToOTTDtoObj.setVersion(Integer.parseInt(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER9]).orElse("").toString()));
            resendToOTTDtoObj.setFlowName(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER10]).orElse("").toString());
            resendToOTTDtoList.add(resendToOTTDtoObj);
        }
        return resendToOTTDtoList;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleErrorRepository#getErrList(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto, int, int)
     */
    public List<ResendToOTTDto> getErrList(ResendToOTTDto resendToOTTDto, int offsetPositionToStartFrom, int rowsPerPage, boolean toIgnore) {

        logger.info("Entering getErrList of VehicleErrorRepositoryImpl");
        List<ResendToOTTDto> resendToOTTDtoList = null;
        try {
            resendToOTTDtoList = new ArrayList();
            StringBuilder query;
            List list = null;
            if (toIgnore) {
                query = new StringBuilder(
                        "select ov.VIN ,ov.ccp,ov.veh,to_char(ov.DATE_EMON,'dd/mm/yyyy'),oe.ERR_CODE,oe.ERR_DESCRIPTION,oe.ERR_COMPLEMENT,to_char(oe.DATE_CREATION,'dd/mm/yyyy hh24:mi:ss'),req_1.STATUS,req_1.version,req_1.FLOW FROM ( SELECT DISTINCT os.vin,os.status,os.version,os.flow, os.rowid rowid_os_last_error, FIRST_VALUE(oe.rowid) OVER(PARTITION BY oe.flowname, oe.vin ORDER BY oe.date_creation DESC) rowid_oe_last_error, FIRST_VALUE(oe.date_creation) OVER(PARTITION BY oe.flowname, oe.vin ORDER BY oe.date_creation DESC) date_creation_last_error"
                                + " FROM   ovrqterr oe, ovrqtvsts os where os.STATUS in (:status1,:status2,:status3) and os.vin=oe.vin and os.flow=oe.flowname and os.FLOW=:flowName ) req_1, ovrqterr oe, ovrqtvhl ov WHERE req_1.rowid_oe_last_error = oe.rowid  AND req_1.vin = ov.vin ");
                Query hql = filterCriteria(resendToOTTDto, query, true);
                hql.setFirstResult(offsetPositionToStartFrom);
                if (rowsPerPage != OVERConstants.MAGICNUMBER0)
                    hql.setMaxResults(rowsPerPage);
                hql.setParameter("status1", TranslationState.KO_TRSNSLATION.getConstValue());
                hql.setParameter("status2", TranslationState.CANCELLED.getConstValue());
                hql.setParameter("status3", TranslationState.IGNORE.getConstValue());
                hql.setParameter(FLOWNAME, resendToOTTDto.getFlowName());
                list = hql.getResultList();

            } else {
                query = new StringBuilder(
                        "select ov.VIN ,ov.ccp,ov.veh,to_char(ov.DATE_EMON,'dd/mm/yyyy'),oe.ERR_CODE,oe.ERR_DESCRIPTION,oe.ERR_COMPLEMENT,to_char(oe.DATE_CREATION,'dd/mm/yyyy hh24:mi:ss'),req_1.STATUS,req_1.version,req_1.FLOW FROM ( SELECT DISTINCT os.vin,os.status,os.version,os.flow, os.rowid rowid_os_last_error, FIRST_VALUE(oe.rowid) OVER(PARTITION BY oe.flowname, oe.vin ORDER BY oe.date_creation DESC) rowid_oe_last_error, FIRST_VALUE(oe.date_creation) OVER(PARTITION BY oe.flowname, oe.vin ORDER BY oe.date_creation DESC) date_creation_last_error"
                                + " FROM   ovrqterr oe, ovrqtvsts os where os.STATUS in (:status1) and os.vin=oe.vin and os.flow=oe.flowname and os.FLOW=:flowName ) req_1, ovrqterr oe, ovrqtvhl ov WHERE req_1.rowid_oe_last_error = oe.rowid  AND req_1.vin = ov.vin ");
                Query hql = filterCriteria(resendToOTTDto, query, true);
                hql.setFirstResult(offsetPositionToStartFrom);
                if (rowsPerPage != OVERConstants.MAGICNUMBER0)
                    hql.setMaxResults(rowsPerPage);
                hql.setParameter(FLOWNAME, resendToOTTDto.getFlowName());
                hql.setParameter("status1", TranslationState.KO_TRSNSLATION.getConstValue());
                list = hql.getResultList();
            }

            // this part needs to be moved from here

            resendToOTTDtoList = generateResponse(list, resendToOTTDtoList);

            logger.info("Exiting getErrList of VehicleErrorRepositoryImpl");
            return resendToOTTDtoList;
        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return resendToOTTDtoList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleErrorRepository#getTotalErrRecords(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto)
     */
    @Override
    public long getTotalErrRecords(ResendToOTTDto resendToOTTDto, boolean toIgnore) {
        logger.info("Entering getTotalErrRecords of VehicleErrorRepositoryImpl");
        try {
            Query hql = null;
            if (toIgnore) {
                StringBuilder query = new StringBuilder(
                        " select count(distinct(ov.vin)) from OVRQTVHL ov join OVRQTVSTS os on ov.vin=os.vin join OVRQTERR oe on os.VIN=oe.VIN  where os.STATUS in (:status1,:status2,:status3) and os.FLOW=:flowName");

                hql = filterCriteria(resendToOTTDto, query, false);
                hql.setParameter("status1", TranslationState.KO_TRSNSLATION.getConstValue());
                hql.setParameter("status2", TranslationState.CANCELLED.getConstValue());
                hql.setParameter("status3", TranslationState.IGNORE.getConstValue());
                hql.setParameter(FLOWNAME, resendToOTTDto.getFlowName());

                logger.info("Exiting getTotalErrRecords of VehicleErrorRepositoryImpl");
            } else {
                StringBuilder query = new StringBuilder(
                        " select count(distinct(ov.vin)) from OVRQTVHL ov join OVRQTVSTS os on ov.vin=os.vin join OVRQTERR oe on os.VIN=oe.VIN where os.STATUS in (:status )and os.FLOW=:flowName");

                hql = filterCriteria(resendToOTTDto, query, false);
                hql.setParameter(FLOWNAME, resendToOTTDto.getFlowName());
                hql.setParameter("status", TranslationState.KO_TRSNSLATION.getConstValue());

                logger.info("Exiting getTotalErrRecords of VehicleErrorRepositoryImpl");

            }

            return ((BigDecimal) hql.getSingleResult()).longValue();
        } catch (Exception e) {
            logger.error("Error occurred while updating {}", e.getMessage());
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleErrorRepository#getVehErrHistListCount(java.lang.String)
     */
    public long getVehErrHistListCount(String vin) {

        logger.info("Entering getErrList of VehicleErrorRepositoryImpl");

        try {

            Query hql = super.getEntityManager().createNativeQuery("select count(*)from ovrqterr ve where ve.vin =:vin");
            hql.setParameter("vin", vin);

            return ((BigDecimal) hql.getSingleResult()).longValue();

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return 0;
    }
}
