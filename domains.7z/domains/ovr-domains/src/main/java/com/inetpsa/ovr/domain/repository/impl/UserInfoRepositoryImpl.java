/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import javax.inject.Inject;

import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.UserInfo;
import com.inetpsa.ovr.domain.repository.UserInfoRepository;

/**
 * The Class UserInfoRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class UserInfoRepositoryImpl extends BaseJpaRepository<UserInfo, Long> implements UserInfoRepository {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(UserInfoRepositoryImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

}
