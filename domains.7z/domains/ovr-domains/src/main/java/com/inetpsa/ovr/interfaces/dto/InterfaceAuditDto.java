/*
 * Creation : 30 Oct 2019
 */
package com.inetpsa.ovr.interfaces.dto;

/**
 * The Class InterfaceAuditDto added.
 */
public class InterfaceAuditDto {

    /** The interface name. */
    private String interfaceName;

    /** The date creation. */
    private String dateCreation;

    /** The from date creation. */
    private String fromDateCreation;

    /** The to date creation. */
    private String toDateCreation;

    /** The file name. */
    private String fileName;

    /** The success count. */
    private Integer successCount;

    /** The error count. */
    private Integer errorCount;

    /** The user creation. */
    private String userCreation;

    /** The interface order. */
    private String interfaceOrder;

    /** The file name order. */
    private String fileNameOrder;

    /** The success count order. */
    private String successCountOrder;

    /** The date creation order. */
    private String dateCreationOrder;

    /** The error count order. */
    private String errorCountOrder;

    /** The user creation order. */
    private String userCreationOrder;

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public String getDateCreation() {
        return dateCreation;
    }

    /**
     * Sets the date creation.
     *
     * @param dateCreation the new date creation
     */
    public void setDateCreation(String dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Gets the success count.
     *
     * @return the success count
     */
    public Integer getSuccessCount() {
        return successCount;
    }

    /**
     * Sets the success count.
     *
     * @param successCount the new success count
     */
    public void setSuccessCount(Integer successCount) {
        this.successCount = successCount;
    }

    /**
     * Gets the error count.
     *
     * @return the error count
     */
    public Integer getErrorCount() {
        return errorCount;
    }

    /**
     * Sets the error count.
     *
     * @param errorCount the new error count
     */
    public void setErrorCount(Integer errorCount) {
        this.errorCount = errorCount;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Sets the user creation.
     *
     * @param userCreation the new user creation
     */
    public void setUserCreation(String userCreation) {
        this.userCreation = userCreation;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the new file name
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Gets the interface name.
     *
     * @return the interface name
     */
    public String getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the interface name.
     *
     * @param interfaceName the new interface name
     */
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    /**
     * Gets the interface order.
     *
     * @return the interface order
     */
    public String getInterfaceOrder() {
        return interfaceOrder;
    }

    /**
     * Sets the interface order.
     *
     * @param interfaceOrder the new interface order
     */
    public void setInterfaceOrder(String interfaceOrder) {
        this.interfaceOrder = interfaceOrder;
    }

    /**
     * Gets the file name order.
     *
     * @return the file name order
     */
    public String getFileNameOrder() {
        return fileNameOrder;
    }

    /**
     * Sets the file name order.
     *
     * @param fileNameOrder the new file name order
     */
    public void setFileNameOrder(String fileNameOrder) {
        this.fileNameOrder = fileNameOrder;
    }

    /**
     * Gets the success count order.
     *
     * @return the success count order
     */
    public String getSuccessCountOrder() {
        return successCountOrder;
    }

    /**
     * Sets the success count order.
     *
     * @param successCountOrder the new success count order
     */
    public void setSuccessCountOrder(String successCountOrder) {
        this.successCountOrder = successCountOrder;
    }

    /**
     * Gets the date creation order.
     *
     * @return the date creation order
     */
    public String getDateCreationOrder() {
        return dateCreationOrder;
    }

    /**
     * Sets the date creation order.
     *
     * @param dateCreationOrder the new date creation order
     */
    public void setDateCreationOrder(String dateCreationOrder) {
        this.dateCreationOrder = dateCreationOrder;
    }

    /**
     * Gets the error count order.
     *
     * @return the error count order
     */
    public String getErrorCountOrder() {
        return errorCountOrder;
    }

    /**
     * Sets the error count order.
     *
     * @param errorCountOrder the new error count order
     */
    public void setErrorCountOrder(String errorCountOrder) {
        this.errorCountOrder = errorCountOrder;
    }

    /**
     * Gets the user creation order.
     *
     * @return the user creation order
     */
    public String getUserCreationOrder() {
        return userCreationOrder;
    }

    /**
     * Sets the user creation order.
     *
     * @param userCreationOrder the new user creation order
     */
    public void setUserCreationOrder(String userCreationOrder) {
        this.userCreationOrder = userCreationOrder;
    }

    /**
     * Gets the from date creation.
     *
     * @return the from date creation
     */
    public String getFromDateCreation() {
        return fromDateCreation;
    }

    /**
     * Sets the from date creation.
     *
     * @param fromDateCreation the new from date creation
     */
    public void setFromDateCreation(String fromDateCreation) {
        this.fromDateCreation = fromDateCreation;
    }

    /**
     * Gets the to date creation.
     *
     * @return the to date creation
     */
    public String getToDateCreation() {
        return toDateCreation;
    }

    /**
     * Sets the to date creation.
     *
     * @param toDateCreation the new to date creation
     */
    public void setToDateCreation(String toDateCreation) {
        this.toDateCreation = toDateCreation;
    }

}
