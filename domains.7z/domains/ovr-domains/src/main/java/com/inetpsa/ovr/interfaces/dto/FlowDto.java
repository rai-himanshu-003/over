/*
 * Creation : 19 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

/**
 * the class InterfaceDto.
 *
 * @author E566559
 */
public class FlowDto {

    /** The id. */
    private String id;

    /** The flow name. */
    private String flowName;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the flow name.
     *
     * @return the flow name
     */
    public String getFlowName() {
        return flowName;
    }

    /**
     * Sets the flow name.
     *
     * @param flowName the new flow name
     */
    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

}
