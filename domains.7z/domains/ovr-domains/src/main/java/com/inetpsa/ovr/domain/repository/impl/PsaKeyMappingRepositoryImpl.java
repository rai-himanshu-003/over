/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.util.List;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository;

/**
 * The Class PsaKeyMappingRepositoryImpl.
 */
public class PsaKeyMappingRepositoryImpl extends BaseJpaRepository<PsaKeyMapping, Long> implements PsaKeyMappingRepository {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(PsaKeyMappingRepositoryImpl.class);

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository#findByIntNameAndPriority(java.lang.String, java.lang.String, java.lang.String,
     *      java.lang.String)
     */
    @Override
    public PsaKeyMapping findUniqueMapping(String psaType, String psaKey, String ovStd, String ovKey) {
        PsaKeyMapping psaKeyMapping = null;
        logger.info("Entering findUniqueMapping of PsaKeyMappingRepositoryImpl to fetch mappings  for psaType :{} , psaKey :{} ,ovkey :{} ,ovStd:{}",
                psaType, psaKey, ovKey, ovStd);
        try {

            Query query = super.getEntityManager().createQuery(
                    "From PsaKeyMapping where psaDatatype=:psaDatatype and psaKey=:psaKey and ovStandard=:ovStandard and ovKey=:ovKey",
                    PsaKeyMapping.class);

            query.setParameter("psaDatatype", psaType);
            query.setParameter("psaKey", psaKey);
            query.setParameter("ovStandard", ovStd);
            query.setParameter("ovKey", ovKey);
            logger.info("Exiting findUniqueMapping of PsaKeyMappingRepositoryImpl");
            return (PsaKeyMapping) query.getSingleResult();
        } catch (Exception e) {
            logger.error("Error occurred while fetching for PSA type :{} and PSA Key :{}", psaType, psaKey);
            logger.error("Error occurred while updating ", e.getMessage());
            return psaKeyMapping;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository#findPsaMapping(java.lang.String, java.lang.String)
     */
    @Override
    public PsaKeyMapping findPsaMapping(String ovStd, String ovKey) {
        PsaKeyMapping psaKeyMapping = null;
        logger.info("Entering findPsaMapping of PsaKeyMappingRepositoryImpl to fetch mappings  for ovkey :{} ,ovStd:{}", ovKey, ovStd);
        try {

            Query query = super.getEntityManager().createQuery("From PsaKeyMapping where ovStandard=:ovStandard and ovKey=:ovKey",
                    PsaKeyMapping.class);

            query.setParameter("ovStandard", ovStd);
            query.setParameter("ovKey", ovKey);
            logger.info("Exiting findPsaMapping of PsaKeyMappingRepositoryImpl");
            return (PsaKeyMapping) query.getSingleResult();
        } catch (Exception e) {
            logger.error("Error occurred while fetching for ovkey :{} ,ovStd:{}", ovKey, ovStd);
            return psaKeyMapping;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository#findOvMapping(java.lang.String, java.lang.String)
     */
    @Override
    public List<PsaKeyMapping> findOvMapping(String psaType, String psaKey) {

        List<PsaKeyMapping> psaKeyMappings = null;
        logger.info("Entering findPsaMapping of PsaKeyMappingRepositoryImpl to fetch mappings  for psaKey :{} ,psaType:{}", psaKey, psaType);
        try {

            Query query = super.getEntityManager().createQuery("From PsaKeyMapping where psaDatatype=:psaType and psaKey=:psaKey",
                    PsaKeyMapping.class);

            query.setParameter("psaType", psaType);
            query.setParameter("psaKey", psaKey);
            logger.info("Exiting findPsaMapping of PsaKeyMappingRepositoryImpl");
            return query.getResultList();
        } catch (Exception e) {
            logger.error("Error occurred while fetching for psaKey :{} ,psaType:{}", psaKey, psaType);
            logger.error(e.getMessage());
            return psaKeyMappings;
        }
    }

}