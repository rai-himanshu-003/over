/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.Audit;
import com.inetpsa.ovr.interfaces.dto.InterfaceAuditDto;

/**
 * The Interface AuditService.
 */
@Service
public interface AuditService {

    /**
     * Adds the audit.
     *
     * @param audit the audit
     */
    void addAudit(Audit audit);

    /**
     * Gets the audit list count.
     *
     * @return the count
     */
    long getAuditListCount();

    /**
     * Gets the audit list.
     *
     * @param interfaceAuditDto the dto
     * @param offsetPositionToStartFrom the offset
     * @param rowsPerPage the rows per page
     * @return the list of object
     */
    List<InterfaceAuditDto> getAuditList(InterfaceAuditDto interfaceAuditDto, int offsetPositionToStartFrom, int rowsPerPage);

    Optional<Audit> getLatestAuditByIntName(String interfaceName);
}
