/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

// TODO: Auto-generated Javadoc
/**
 * The Interface VehicleArtLcdvOttService.
 */
@Service
public interface VehicleArtLcdvOttService {

    /**
     * Gets the art lcdv ott by vin.
     *
     * @param vin the vin
     * @return the art lcdv ott by vin
     */
    List<ArtLcdvOtt> getArtLcdvOttByVin(String vin);

    /**
     * Delete art lcdv ott by id.
     *
     * @param artLcdvOtt the art lcdv ott
     * @return true, if successful
     */
    boolean deleteArtLcdvOttById(Long artLcdvOtt);

    /**
     * Adds the or update art lcdv ott.
     *
     * @param artLcdvOtt the art lcdv ott
     * @return the response dto
     */
    ResponseDto addOrUpdateArtLcdvOtt(ArtLcdvOtt artLcdvOtt);

    /**
     * Gets the sequence count.
     *
     * @param numberOfSeq the number of seq
     * @return the sequence count
     */
    List<BigDecimal> getSequenceCount(int numberOfSeq);

    /**
     * Check lcdv exist.
     *
     * @param vin the vin
     * @param lcdv the lcdv
     * @return true, if successful
     */
    boolean checkLcdvExist(String vin, String lcdv);

    /**
     * Gets the lcdv exist.
     *
     * @param vin the vin
     * @param lcdv the lcdv
     * @return the lcdv exist
     */
    Map<Long, ArtLcdvOtt> getLcdvExist(String vin, String lcdv);

}
