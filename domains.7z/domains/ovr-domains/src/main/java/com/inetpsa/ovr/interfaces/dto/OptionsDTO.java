/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.Options;

/**
 * The Class OptionsDTO.
 */

public class OptionsDTO {

    /** The id. */

    private Long idRpoDto;

    /** The data. */
    private String rpoDataRpoDto;

    /** The vin. */
    private String vinRpoDto;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return idRpoDto;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idRpoDto = id;
    }

    /**
     * Gets the rpo data.
     *
     * @return the rpo data
     */
    public String getRpoData() {
        return rpoDataRpoDto;
    }

    /**
     * Sets the rpo data.
     *
     * @param rpoData the new rpo data
     */
    public void setRpoData(String rpoData) {
        this.rpoDataRpoDto = rpoData;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vinRpoDto;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vinRpoDto = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Options [id=" + idRpoDto + ", rpoData=" + rpoDataRpoDto + ", vin=" + vinRpoDto + "]";
    }

    /**
     * Map tomodel.
     *
     * @return the options
     */
    public Options mapTomodel() {
        Options options = new Options();
        options.setId(this.getId());
        options.setRpoData(this.getRpoData());
        options.setVin(this.getVin());
        return options;
    }

}
