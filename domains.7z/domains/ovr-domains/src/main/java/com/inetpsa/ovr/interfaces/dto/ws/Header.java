/*
 * Creation : 17 Dec 2019
 */
package com.inetpsa.ovr.interfaces.dto.ws;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Header.
 */
public class Header {

    /** The client. */
    @JsonProperty("CLIENT")
    @SerializedName("CLIENT")
    private String client;

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Header [client=" + client + "]";
    }

}