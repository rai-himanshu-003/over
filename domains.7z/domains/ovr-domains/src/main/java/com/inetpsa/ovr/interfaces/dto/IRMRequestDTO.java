package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.util.List;

/**
 * The Class IRMRequestDTO.
 */
public class IRMRequestDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;
    /** The interface id. */
    private String currentFlow;

    /** The int id. */
    private long intId;

    /** The previous flow details DT os. */
    private List<PreviousFlowDetailsDTO> previousFlowDetailsDTOs;

    /**
     * Gets the current flow.
     *
     * @return the current flow
     */
    public String getCurrentFlow() {
        return currentFlow;
    }

    /**
     * Sets the current flow.
     *
     * @param currentFlow the new current flow
     */
    public void setCurrentFlow(String currentFlow) {
        this.currentFlow = currentFlow;
    }

    /**
     * Gets the int id.
     *
     * @return the int id
     */
    public long getIntId() {
        return intId;
    }

    /**
     * Sets the int id.
     *
     * @param intId the new int id
     */
    public void setIntId(long intId) {
        this.intId = intId;
    }

    /**
     * Gets the previous flow details DT os.
     *
     * @return the previous flow details DT os
     */
    public List<PreviousFlowDetailsDTO> getPreviousFlowDetailsDTOs() {
        return previousFlowDetailsDTOs;
    }

    /**
     * Sets the previous flow details DT os.
     *
     * @param previousFlowDetailsDTOs the new previous flow details DT os
     */
    public void setPreviousFlowDetailsDTOs(List<PreviousFlowDetailsDTO> previousFlowDetailsDTOs) {
        this.previousFlowDetailsDTOs = previousFlowDetailsDTOs;
    }

}
