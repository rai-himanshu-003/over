/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

/**
 * The Class PsaKeyMapping.
 * 
 * @author E566559
 */
@Entity
@Table(name = "OVRQTKEYMAP")
public class PsaKeyMapping extends BaseAggregateRoot<Long> implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 6793092847153490518L;

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTKEYMAP_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The psa datatype. */
    @Column(name = "PSA_DATA_TYPE")
    @NotNull
    private String psaDatatype;

    /** The psa key. */
    @Column(name = "PSA_KEY")
    @NotNull
    private String psaKey;

    /** The ov standard. */
    @Column(name = "OV_STANDARD")
    @NotNull
    private String ovStandard;

    /** The ov key. */
    @Column(name = "OV_KEY")
    @NotNull
    private String ovKey;

    /** The description. */
    @Column(name = "DESCRIPTION")
    @NotNull
    private String description;

    /** The version. */
    @Version
    @Column(name = "VERSION")
    private Integer version;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the psa datatype.
     *
     * @return the psa datatype
     */
    public String getPsaDatatype() {
        return psaDatatype;
    }

    /**
     * Sets the psa datatype.
     *
     * @param psaDatatype the new psa datatype
     */
    public void setPsaDatatype(String psaDatatype) {
        this.psaDatatype = psaDatatype;
    }

    /**
     * Gets the psa key.
     *
     * @return the psa key
     */
    public String getPsaKey() {
        return psaKey;
    }

    /**
     * Sets the psa key.
     *
     * @param psaKey the new psa key
     */
    public void setPsaKey(String psaKey) {
        this.psaKey = psaKey;
    }

    /**
     * Gets the ov standard.
     *
     * @return the ov standard
     */
    public String getOvStandard() {
        return ovStandard;
    }

    /**
     * Sets the ov standard.
     *
     * @param ovStandard the new ov standard
     */
    public void setOvStandard(String ovStandard) {
        this.ovStandard = ovStandard;
    }

    /**
     * Gets the ov key.
     *
     * @return the ov key
     */
    public String getOvKey() {
        return ovKey;
    }

    /**
     * Sets the ov key.
     *
     * @param ovKey the new ov key
     */
    public void setOvKey(String ovKey) {
        this.ovKey = ovKey;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "PsaKeyMapping [id=" + id + ", psaDatatype=" + psaDatatype + ", psaKey=" + psaKey + ", ovStandard=" + ovStandard + ", ovKey=" + ovKey
                + ", description=" + description + ", version=" + version + ", getId()=" + getId() + ", getPsaDatatype()=" + getPsaDatatype()
                + ", getPsaKey()=" + getPsaKey() + ", getOvStandard()=" + getOvStandard() + ", getOvKey()=" + getOvKey() + ", getDescription()="
                + getDescription() + ", getVersion()=" + getVersion() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
                + ", getClass()=" + getClass() + "]";
    }

}
