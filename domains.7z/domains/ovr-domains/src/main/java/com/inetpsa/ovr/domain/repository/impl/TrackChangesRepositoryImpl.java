/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.math.BigDecimal;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.TrackChanges;
import com.inetpsa.ovr.domain.repository.TrackChangesRepository;

/**
 * The Class VehicleKeysOvRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class TrackChangesRepositoryImpl extends BaseJpaRepository<TrackChanges, Long> implements TrackChangesRepository {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(TrackChangesRepositoryImpl.class);

    @Override
    public Long generateSequence() {
        logger.info("Entering getSequenceCount");
        BigDecimal id = null;
        try {

            Query query = super.getEntityManager().createNativeQuery("select OVRQTMMTC_SEQ.nextval from dual");

            id = (BigDecimal) query.getSingleResult();
            logger.info("Exiting getSequenceCount");
            return id.longValue();

        } catch (Exception e) {
            logger.error("Error while genereting MMTC number : {}", e.getMessage());
            return 0l;
        }

    }

}