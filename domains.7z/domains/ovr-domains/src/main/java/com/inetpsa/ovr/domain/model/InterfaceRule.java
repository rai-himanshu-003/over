/*
 * Creation : 2 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class Vehicle.
 */
@Entity
@DynamicUpdate(value = true)
@Table(name = "OVRQTINTRULE")
public class InterfaceRule extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTINTRULE_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The interface name. */
    @Column(name = "INT_ID")
    @NotNull
    private Long intId;

    /** The priority. */
    @Column(name = "PRIORITY")
    @NotNull
    private Integer priority;

    /** The filter type. */
    @Column(name = "FILTER_TYPE")
    @NotNull
    private Integer filterType;

    /** The vehicle family. */
    @Column(name = "VEHICLE_FAMILY")
    private String vehicleFamily;

    /** The production centre. */
    @Column(name = "PRODUCTION_CENTRE")
    private String productionCentre;

    /** The country. */
    @Column(name = "country")
    private String country;

    /** The min ecom. */
    @Column(name = "MIN_ECOM")
    private Date minEcom;

    /** The max ecom. */
    @Column(name = "MAX_ECOM")
    private Date maxEcom;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private Date dateCreation;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The date modif. */
    @Column(name = "DATE_MODIF")

    private LocalDateTime dateModif;

    /** The user modif. */
    @Column(name = "USER_MODIF")
    private String userModif;

    /** The version. */
    @Version
    @Column(name = "VERSION")
    private Integer version;

    /** The vin. */
    @Column(name = "VIN")
    private String vin;

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        dateCreation = new Date();
        userCreation = LoggedUser.get();
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();
    }

    /**
     * Pre update.
     */
    @PreUpdate
    public void preUpdate() {
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the int id.
     *
     * @return the int id
     */
    public Long getIntId() {
        return intId;
    }

    /**
     * Sets the int id.
     *
     * @param intId the new int id
     */
    public void setIntId(Long intId) {
        this.intId = intId;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the priority.
     *
     * @param priority the new priority
     */
    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    /**
     * Gets the vehicle family.
     *
     * @return the vehicle family
     */
    public String getVehicleFamily() {
        return vehicleFamily;
    }

    /**
     * Sets the vehicle family.
     *
     * @param vehicleFamily the new vehicle family
     */
    public void setVehicleFamily(String vehicleFamily) {
        this.vehicleFamily = vehicleFamily;
    }

    /**
     * Gets the production centre.
     *
     * @return the production centre
     */
    public String getProductionCentre() {
        return productionCentre;
    }

    /**
     * Sets the production centre.
     *
     * @param productionCentre the new production centre
     */
    public void setProductionCentre(String productionCentre) {
        this.productionCentre = productionCentre;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public LocalDateTime getDateModif() {
        return dateModif;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Gets the min ecom.
     *
     * @return the min ecom
     */
    public Date getMinEcom() {
        return minEcom;
    }

    /**
     * Sets the min ecom.
     *
     * @param minEcom the new min ecom
     */
    public void setMinEcom(Date minEcom) {
        this.minEcom = minEcom;
    }

    /**
     * Gets the max ecom.
     *
     * @return the max ecom
     */
    public Date getMaxEcom() {
        return maxEcom;
    }

    /**
     * Sets the max ecom.
     *
     * @param maxEcom the new max ecom
     */
    public void setMaxEcom(Date maxEcom) {
        this.maxEcom = maxEcom;
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public Date getDateCreation() {
        return dateCreation;
    }

    /**
     * Gets the filter type.
     *
     * @return the filter type
     */
    public Integer getFilterType() {
        return filterType;
    }

    /**
     * Sets the filter type.
     *
     * @param filterType the new filter type
     */
    public void setFilterType(Integer filterType) {
        this.filterType = filterType;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "InterfaceRule [id=" + id + ", intId=" + intId + ", priority=" + priority + ", filterType=" + filterType + ", vehicleFamily="
                + vehicleFamily + ", productionCentre=" + productionCentre + ", country=" + country + ", minEcom=" + minEcom + ", maxEcom=" + maxEcom
                + ", dateCreation=" + dateCreation + ", userCreation=" + userCreation + ", dateModif=" + dateModif + ", userModif=" + userModif
                + ", version=" + version + ", vin=" + vin + "]";
    }

}
