/*
 * Creation : 19 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

/**
 * the class InterfaceDto.
 *
 * @author E566559
 */
public class InterfaceDto {

    /** The id. */
    private String id;

    /** The interface name. */
    private String interfaceName;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the interface name.
     *
     * @return the interface name
     */
    public String getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the interface name.
     *
     * @param interfaceName the new interface name
     */
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

}
