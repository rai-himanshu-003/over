/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.InterfaceStatus;

/**
 * The Interface InterfaceStatusService.
 * 
 * @author E567673
 */
@Service
public interface InterfaceStatusService {

    /**
     * Gets the interface status.
     *
     * @param string the string
     * @return the interface status
     */
    Optional<InterfaceStatus> getInterfaceStatus(String string);

    /**
     * Checks if is OVER timed out.
     *
     * @param dateModif the date modif
     * @param ottMaxWaiting the ott max waiting
     * @return true, if is OVER timed out
     */
    boolean isOVERTimedOut(Date dateModif, String ottMaxWaiting);

    /**
     * Update interface status.
     *
     * @param updateStatus the update status
     * @return true, if successful
     */
    boolean updateInterfaceStatus(InterfaceStatus updateStatus);

    /**
     * Gets the all interfaces.
     *
     * @return the all interfaces
     */
    List<InterfaceStatus> getAllInterfaces();
}
