/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.ComposantsOvDTO;

/**
 * The Class ComposantsOv.
 */
@Entity
@Table(name = "OVRQTVCOMOV")
@DynamicUpdate(value = true)
public class ComposantsOv extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    private Long id;

    /** The data. */
    @Column(name = "DATA")
    private String data;

    /** The vin. */
    @Column(name = "VIN")
    private String vin;

    /** The eid. */
    @Column(name = "E_ID")
    private String eid;

    /** The label. */
    @Column(name = "LABEL")
    private String label;

    /** The part. */
    @Column(name = "PART")
    private String part;

    /** The standard. */
    @Column(name = "STANDARD")
    private String standard;

    /** The supplier. */
    @Column(name = "SUPPLIER")
    private String supplier;

    /**
     * Gets the eid.
     *
     * @return the eid
     */
    public String getEid() {
        return eid;
    }

    /**
     * Sets the eid.
     *
     * @param eid the new eid
     */
    public void setEid(String eid) {
        this.eid = eid;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the part.
     *
     * @return the part
     */
    public String getPart() {
        return part;
    }

    /**
     * Sets the part.
     *
     * @param part the new part
     */
    public void setPart(String part) {
        this.part = part;
    }

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public String getStandard() {
        return standard;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(String standard) {
        this.standard = standard;
    }

    /**
     * Gets the supplier.
     *
     * @return the supplier
     */
    public String getSupplier() {
        return supplier;
    }

    /**
     * Sets the supplier.
     *
     * @param supplier the new supplier
     */
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((data == null) ? 0 : data.hashCode());
        result = prime * result + ((eid == null) ? 0 : eid.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        result = prime * result + ((part == null) ? 0 : part.hashCode());
        result = prime * result + ((standard == null) ? 0 : standard.hashCode());
        result = prime * result + ((supplier == null) ? 0 : supplier.hashCode());
        result = prime * result + ((vin == null) ? 0 : vin.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        ComposantsOv other = (ComposantsOv) obj;
        if (data == null) {
            if (other.data != null)
                return false;
        } else if (!data.equals(other.data))
            return false;
        if (eid == null) {
            if (other.eid != null)
                return false;
        } else if (!eid.equals(other.eid))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (label == null) {
            if (other.label != null)
                return false;
        } else if (!label.equals(other.label))
            return false;
        if (part == null) {
            if (other.part != null)
                return false;
        } else if (!part.equals(other.part))
            return false;

        if (standard == null) {
            if (other.standard != null)
                return false;
        } else if (!standard.equals(other.standard))
            return false;
        if (supplier == null) {
            if (other.supplier != null)
                return false;
        } else if (!supplier.equals(other.supplier))
            return false;
        if (vin == null) {
            if (other.vin != null)
                return false;
        } else if (!vin.equals(other.vin))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "ComposantsOv [id=" + id + ", data=" + data + ", vin=" + vin + ", eid=" + eid + ", label=" + label + ", part=" + part + ", standard="
                + standard + ", supplier=" + supplier + "]";
    }

    public ComposantsOvDTO maptoDto() {
        ComposantsOvDTO composantsOvDTO = new ComposantsOvDTO();
        composantsOvDTO.setData(this.getData());
        composantsOvDTO.setEid(this.getEid());
        composantsOvDTO.setId(this.getId());
        composantsOvDTO.setLabel(this.getLabel());
        composantsOvDTO.setPart(this.getPart());
        composantsOvDTO.setStandard(this.getStandard());
        composantsOvDTO.setSupplier(this.getSupplier());
        composantsOvDTO.setVin(this.getVin());
        return composantsOvDTO;
    }

}
