/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.Column;

/**
 * The Class VehicleHistoryPk.
 */
public class VehicleHistoryPk implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The vin no. */
    @Column(name = "VIN")
    private String vinNo;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private LocalDateTime dateCreation;

    /** The state id. */
    @Column(name = "STATE_ID")
    private String stateId;

    /**
     * Instantiates a new vehicle history pk.
     */
    public VehicleHistoryPk() {
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    /**
     * Sets the date creation.
     *
     * @param dateCreation the new date creation
     */
    public void setDateCreation(LocalDateTime dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * Gets the vin no.
     *
     * @return the vin no
     */
    public String getVinNo() {
        return vinNo;
    }

    /**
     * Sets the vin no.
     *
     * @param vinNo the new vin no
     */
    public void setVinNo(String vinNo) {
        this.vinNo = vinNo;
    }

    /**
     * Gets the state id.
     *
     * @return the state id
     */
    public String getStateId() {
        return stateId;
    }

    /**
     * Sets the state id.
     *
     * @param stateId the new state id
     */
    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof VehicleHistoryPk))
            return false;
        VehicleHistoryPk that = (VehicleHistoryPk) o;
        return Objects.equals(getVinNo(), that.getVinNo()) && Objects.equals(getDateCreation(), that.getDateCreation())
                && Objects.equals(getStateId(), that.getStateId());
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(getVinNo(), getDateCreation(), getStateId());
    }

    /**
     * Instantiates a new vehicle history pk.
     *
     * @param vinNo the vin no
     * @param stateId the state id
     */
    public VehicleHistoryPk(String vinNo, String stateId) {
        super();
        this.vinNo = vinNo;
        this.stateId = stateId;
    }

}
