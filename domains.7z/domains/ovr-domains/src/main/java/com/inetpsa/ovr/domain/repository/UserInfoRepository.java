/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.Service;
import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.UserInfo;

/**
 * The Interface TechnicalParameterRepository.
 */
@Service
public interface UserInfoRepository extends Repository<UserInfo, Long> {

}
