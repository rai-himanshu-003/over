/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

// TODO: Auto-generated Javadoc
/**
 * The Interface VehicleOptionsService.
 */
@Service
public interface VehicleOptionsService {

    /**
     * Gets the options by vin.
     *
     * @param vin the vin
     * @return the options by vin
     */
    List<Options> getOptionsByVin(String vin);

    /**
     * Delete options by id.
     *
     * @param options the options
     * @return true, if successful
     */
    boolean deleteOptionsById(Long options);

    /**
     * Adds the or update options.
     *
     * @param options the options
     * @return true, if successful
     */
    ResponseDto addOrUpdateOptions(Options options);

    /**
     * Gets the sequence count.
     *
     * @param numberOfSeq the number of seq
     * @return the sequence count
     */
    List<BigDecimal> getSequenceCount(int numberOfSeq);

    /**
     * Check options exist.
     *
     * @param vin the vin
     * @param rpo the rpo
     * @return true, if successful
     */
    boolean checkOptionsExist(String vin, String rpo);

    /**
     * Gets the options exist.
     *
     * @param vin the vin
     * @param rpo the rpo
     * @return the options exist
     */
    Map<Long, Options> getOptionsExist(String vin, String rpo);

}
