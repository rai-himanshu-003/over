/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;

/**
 * The Class OVComponentPart.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTFLOVCMPT")
public class OVComponentPart extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTFLOVCMPT_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The flow id. */
    @Column(name = "OVCOMP_ID")
    private Long ovCompId;

    /** The seq. */
    @Column(name = "STANDARD")
    private Long standard;

    /** The value. */
    @Column(name = "VALUE")
    private Long value;

    /** The filter. */
    @Column(name = "FILTER")
    private String filter;

    /** The selected. */
    @Column(name = "INTSEQ")
    private String intSeq;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * Gets the ov comp id.
     *
     * @return the ov comp id
     */
    public Long getOvCompId() {
        return ovCompId;
    }

    /**
     * Sets the ov comp id.
     *
     * @param ovCompId the new ov comp id
     */
    public void setOvCompId(Long ovCompId) {
        this.ovCompId = ovCompId;
    }

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public Long getStandard() {
        return standard;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(Long standard) {
        this.standard = standard;
    }

    public String getIntSeq() {
        return intSeq;
    }

    public void setIntSeq(String intSeq) {
        this.intSeq = intSeq;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((filter == null) ? 0 : filter.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((intSeq == null) ? 0 : intSeq.hashCode());
        result = prime * result + ((ovCompId == null) ? 0 : ovCompId.hashCode());
        result = prime * result + ((standard == null) ? 0 : standard.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        OVComponentPart other = (OVComponentPart) obj;
        if (filter == null) {
            if (other.filter != null)
                return false;
        } else if (!filter.equals(other.filter))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (intSeq == null) {
            if (other.intSeq != null)
                return false;
        } else if (!intSeq.equals(other.intSeq))
            return false;
        if (ovCompId == null) {
            if (other.ovCompId != null)
                return false;
        } else if (!ovCompId.equals(other.ovCompId))
            return false;
        if (standard == null) {
            if (other.standard != null)
                return false;
        } else if (!standard.equals(other.standard))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        } else if (!value.equals(other.value))
            return false;
        return true;
    }

    /**
     * /** Mapto dto.
     *
     * @return the flow static metadata DTO
     */
    public OVComponentPartDTO maptoDto() {
        OVComponentPartDTO ovComponentPartDTO = new OVComponentPartDTO();
        ovComponentPartDTO.setId(this.getId());
        ovComponentPartDTO.setStandard(this.getStandard());
        ovComponentPartDTO.setIntSeq(this.getIntSeq());
        ovComponentPartDTO.setFilter(this.getFilter());
        ovComponentPartDTO.setOvCompId(this.getOvCompId());
        ovComponentPartDTO.setValue(this.getValue());
        return ovComponentPartDTO;

    }

}
