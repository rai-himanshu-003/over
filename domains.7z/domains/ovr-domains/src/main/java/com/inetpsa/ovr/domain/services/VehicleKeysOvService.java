/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.KeysOv;

/**
 * The Interface VehicleKeysOvService.
 */
@Service
public interface VehicleKeysOvService {

    /**
     * Gets the vehicle keys ov by vin.
     *
     * @param vin the vin
     * @return the vehicle keys ov by vin
     */
    List<KeysOv> getvehicleKeysOvByVin(String vin);

    /**
     * Delete keys ov by id.
     *
     * @param keysOv the keys ov
     * @return true, if successful
     */
    boolean deleteKeysOvById(Long keysOv);

    /**
     * Adds the or update keys ov.
     *
     * @param keysOv the keys ov
     * @return true, if successful
     */
    boolean addOrUpdateKeysOv(KeysOv keysOv);

}
