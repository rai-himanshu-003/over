/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.ComposantsDTO;

/**
 * The Class Composants.
 */
@Entity
@Table(name = "OVRQTVCOM")
@DynamicUpdate(value = true)
public class Composants extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    // @SequenceGenerator(name = "SEQ_GEN1", sequenceName = "OVRQTVCOM_SEQ", allocationSize = 1)
    // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN1")
    @Column(name = "ID")
    private Long id;

    /** The data. */
    @Column(name = "DATA")
    private String data;

    /** The vin. */
    @Column(name = "VIN")
    private String vin;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Composants [id=" + id + ", data=" + data + ", vin=" + vin + "]";
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((data == null) ? 0 : data.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((vin == null) ? 0 : vin.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Composants other = (Composants) obj;
        if (data == null) {
            if (other.data != null)
                return false;
        } else if (!data.equals(other.data))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (vin == null) {
            if (other.vin != null)
                return false;
        } else if (!vin.equals(other.vin))
            return false;
        return true;
    }

    /**
     * Mapto dto.
     *
     * @return the composants DTO
     */
    public ComposantsDTO maptoDto() {
        ComposantsDTO composantsDTO = new ComposantsDTO();
        composantsDTO.setData(this.getData());
        composantsDTO.setId(this.getId());
        composantsDTO.setVin(this.getVin());
        return composantsDTO;

    }

}
