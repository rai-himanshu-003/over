/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository;
import com.inetpsa.ovr.domain.services.PsaKeyMappingService;
import com.inetpsa.ovr.interfaces.dto.OvPsaMappingDTO;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;
import com.inetpsa.ovr.interfaces.mapper.DataMapper;

/**
 * The Class PsaKeyMappingServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class PsaKeyMappingServiceImpl implements PsaKeyMappingService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(PsaKeyMappingServiceImpl.class);

    /** The mapping repository. */
    @Inject
    private PsaKeyMappingRepository mappingRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.PsaKeyMappingService#getPsaKeyMapping(java.lang.Long)
     */
    @Override
    public Optional<PsaKeyMapping> getPsaKeyMapping(Long id) {

        return mappingRepository.get(id);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.PsaKeyMappingService#getPsaKeyByOvKey(java.lang.String)
     */
    @Override
    public List<PsaKeyMapping> getPsaKeyByOvKey(String eid) {

        Specification<PsaKeyMapping> spec = specificationBuilder.of(PsaKeyMapping.class).property("ovKey").equalTo(eid).build();
        return mappingRepository.get(spec).collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.PsaKeyMappingService#addOrUpdateMapping(com.inetpsa.ovr.interfaces.dto.OvPsaMappingDTO)
     */
    public ResponseDto addOrUpdateMapping(OvPsaMappingDTO ovPsaMappingDTO) {
        ResponseDto responseDto = new ResponseDto();
        boolean flag = false;
        try {
            logger.info("Entering addOrUpdateMapping of PsaKeyMappingServiceImpl");
            Optional<PsaKeyMapping> aggregate = null;
            PsaKeyMapping psaKeyMapping = null;

            if (ovPsaMappingDTO.getId() != null) {
                responseDto.setId(ovPsaMappingDTO.getId().toString());
                aggregate = mappingRepository.get(ovPsaMappingDTO.getId());
                if (aggregate.isPresent() && aggregate.get() != null) {

                    psaKeyMapping = mappingRepository.findPsaMapping(ovPsaMappingDTO.getOvStandard(), ovPsaMappingDTO.getOvKey());
                    if (psaKeyMapping != null && !(psaKeyMapping.getId().equals(ovPsaMappingDTO.getId()))) {
                        logger.error("Can not update since another record found with OV std :{} and OV Key :{}", ovPsaMappingDTO.getOvStandard(),
                                ovPsaMappingDTO.getOvKey());
                        responseDto.setMsg(flag);
                        return responseDto;

                    }
                    psaKeyMapping = aggregate.get();
                    logger.info("Mapping version from database {}", psaKeyMapping.getVersion());
                    logger.info("Mapping version from ui {}", ovPsaMappingDTO.getVersion());
                    if (psaKeyMapping.getVersion().equals(ovPsaMappingDTO.getVersion())) {
                        psaKeyMapping = DataMapper.ovPsaMappingDTOMapTomodel(ovPsaMappingDTO, psaKeyMapping);
                        mappingRepository.update(psaKeyMapping);
                    } else {

                        logger.error("Version did not match for PSA type :{} and PSA Key :{}", ovPsaMappingDTO.getPsaType(),
                                ovPsaMappingDTO.getPsaKey());
                        responseDto.setMsg(flag);
                        return responseDto;
                    }
                }

            } else {
                psaKeyMapping = mappingRepository.findPsaMapping(ovPsaMappingDTO.getOvStandard(), ovPsaMappingDTO.getOvKey());
                if (psaKeyMapping != null) {
                    logger.error("Can not insert since another record found with OV std :{} and OV Key :{}", ovPsaMappingDTO.getOvStandard(),
                            ovPsaMappingDTO.getOvKey());
                    responseDto.setMsg(flag);
                    return responseDto;

                }

                psaKeyMapping = new PsaKeyMapping();
                psaKeyMapping = DataMapper.ovPsaMappingDTOMapTomodel(ovPsaMappingDTO, psaKeyMapping);
                mappingRepository.add(psaKeyMapping);
                psaKeyMapping = mappingRepository.findPsaMapping(ovPsaMappingDTO.getOvStandard(), ovPsaMappingDTO.getOvKey());
                responseDto.setId(psaKeyMapping.getId().toString());
            }
            logger.info("Exiting addOrUpdateMapping of PsaKeyMappingServiceImpl");
            flag = true;
            responseDto.setMsg(flag);
            return responseDto;
        } catch (Exception e) {
            logger.error("Error occurred while updating for PSA type :{} and PSA Key :{}", ovPsaMappingDTO.getPsaType(), ovPsaMappingDTO.getPsaKey());
            logger.error("Error occurred while updating {}", e.getMessage());
            logger.info("Exiting addOrUpdateMapping of PsaKeyMappingServiceImpl");
            responseDto.setMsg(flag);
            return responseDto;
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.PsaKeyMappingService#getMappingList()
     */
    @Override
    public List<OvPsaMappingDTO> getMappingList() {
        logger.info("Entering getMappingList of PsaKeyMappingServiceImpl");
        List<OvPsaMappingDTO> mappingDTOs = new ArrayList<>();
        SortOption opt = new SortOption();
        opt.add("psaDatatype", Direction.ASCENDING);
        Specification<PsaKeyMapping> spec = specificationBuilder.of(PsaKeyMapping.class).property("psaDatatype").not().equalTo(null).build();
        List<PsaKeyMapping> keyMappings = (mappingRepository.get(spec, opt)).collect(Collectors.toList());
        for (PsaKeyMapping psaKeyMapping : keyMappings) {
            OvPsaMappingDTO ovPsaMappingDTO = DataMapper.psaKeyMappingMapToDto(psaKeyMapping);
            mappingDTOs.add(ovPsaMappingDTO);
        }
        logger.info("Exiting getMappingList of PsaKeyMappingServiceImpl");
        return mappingDTOs;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceRulesService#findByIntNameAndPriority(java.lang.String, int)
     */
    public PsaKeyMapping findPsaMapping(String ovKey, String ovStd) {
        return mappingRepository.findPsaMapping(ovKey, ovStd);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceRulesService#deleteInterfaceRule(com.inetpsa.ovr.interfaces.rest.dto.InterfaceRulesDto)
     */
    @Override
    public boolean deleteMapping(Long mappingId) {
        logger.info("Entering deleteMapping of PsaKeyMappingServiceImpl");
        Optional<PsaKeyMapping> psaKeyMapping = null;
        try {
            psaKeyMapping = mappingRepository.get(mappingId);

            if (psaKeyMapping.isPresent()) {

                logger.info("Exiting deleteMapping of PsaKeyMappingServiceImpl");
                mappingRepository.remove(psaKeyMapping.get());
                return true;
            }
            logger.info("Exiting deleteMapping of PsaKeyMappingServiceImpl");
            return false;
        } catch (Exception e) {
            logger.error("Error occurred while deleting  Mapping Id: {}", mappingId);
            logger.error("Error occurred while updating {}", e.getMessage());
            return false;
        }
    }

    @Override
    public List<PsaKeyMapping> findOvMapping(String psaType, String psaKey) {
        return mappingRepository.findOvMapping(psaType, psaKey);
    }

}
