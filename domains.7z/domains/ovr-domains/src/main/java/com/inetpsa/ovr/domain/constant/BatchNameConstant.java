/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.constant;

/**
 * enum for batch name.
 *
 * @author E566559
 */
public enum BatchNameConstant {

    /** The batch name ovr ott resp. */
    BATCH_NAME_OVR_OTT_RESP("ottResponseJob"),

    /** The batch name ovr ott resp. */
    BATCH_NAME_OVR_REVOTT_RESP("revottResponseJob"),

    BATCH_NAME_OVR_THUB_RESP("thubResponseJob"),

    BATCH_NAME_CRONOS_OVR_REQS_RESP("cronosOvrReqsResponseJob"),

    BATCH_NAME_OVR_CORVET_RESP("corvetResponseJob")

    ;

    /** The const value. */
    String constValue;

    /**
     * Instantiates a new batch name constant.
     *
     * @param constValue the const value
     */
    BatchNameConstant(String constValue) {
        this.constValue = constValue;
    }

    /**
     * Gets the const value.
     *
     * @return the const value
     */
    public String getConstValue() {
        return constValue;
    }

}
