/*
 * Creation : 17 Apr 2020
 */
package com.inetpsa.ovr.interfaces.dto.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class OpVehiculeData.
 */
public class OpVehiculeData {

    /** The vin. */
    @SerializedName("VIN")
    @Expose
    private String vin;

    /** The veh. */
    @SerializedName("VEH")
    @Expose
    private String veh;

    /** The up. */
    @SerializedName("UP")
    @Expose
    private String up;

    /** The ccp. */
    @SerializedName("CCP")
    @Expose
    private String ccp;

    /** The of. */
    @SerializedName("OF")
    @Expose
    private String of;

    /** The lcdv 24. */
    @SerializedName("LCDV24")
    @Expose
    private String lcdv24;

    /** The oa. */
    @SerializedName("OA")
    @Expose
    private String oa;

    /** The apvpr. */
    @SerializedName("APVPR")
    @Expose
    private String apvpr;

    /** The model. */
    @SerializedName("MODEL")
    @Expose
    private String model;

    /** The model year. */
    @SerializedName("MODELYEAR")
    @Expose
    private String modelYear;

    /** The date emon. */
    @SerializedName(value = "DATE_EMON")
    @Expose
    private String dateEmon;

    /** The date ecom. */
    @SerializedName(value = "DATE_ECOM")
    @Expose
    private String dateEcom;

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the up.
     *
     * @return the up
     */
    public String getUp() {
        return up;
    }

    /**
     * Sets the up.
     *
     * @param up the new up
     */
    public void setUp(String up) {
        this.up = up;
    }

    /**
     * Gets the ccp.
     *
     * @return the ccp
     */
    public String getCcp() {
        return ccp;
    }

    /**
     * Sets the ccp.
     *
     * @param ccp the new ccp
     */
    public void setCcp(String ccp) {
        this.ccp = ccp;
    }

    /**
     * Gets the of.
     *
     * @return the of
     */
    public String getOf() {
        return of;
    }

    /**
     * Sets the of.
     *
     * @param of the new of
     */
    public void setOf(String of) {
        this.of = of;
    }

    /**
     * Gets the lcdv 24.
     *
     * @return the lcdv 24
     */
    public String getLcdv24() {
        return lcdv24;
    }

    /**
     * Sets the lcdv 24.
     *
     * @param lcdv24 the new lcdv 24
     */
    public void setLcdv24(String lcdv24) {
        this.lcdv24 = lcdv24;
    }

    /**
     * Gets the oa.
     *
     * @return the oa
     */
    public String getOa() {
        return oa;
    }

    /**
     * Sets the oa.
     *
     * @param oa the new oa
     */
    public void setOa(String oa) {
        this.oa = oa;
    }

    /**
     * Gets the apvpr.
     *
     * @return the apvpr
     */
    public String getApvpr() {
        return apvpr;
    }

    /**
     * Sets the apvpr.
     *
     * @param apvpr the new apvpr
     */
    public void setApvpr(String apvpr) {
        this.apvpr = apvpr;
    }

    /**
     * Gets the model.
     *
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model.
     *
     * @param model the new model
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Gets the model year.
     *
     * @return the model year
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the model year.
     *
     * @param modelYear the new model year
     */
    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    /**
     * Gets the veh.
     *
     * @return the veh
     */
    public String getVeh() {
        return veh;
    }

    /**
     * Sets the veh.
     *
     * @param veh the new veh
     */
    public void setVeh(String veh) {
        this.veh = veh;
    }

    /**
     * Gets the date emon.
     *
     * @return the date emon
     */
    public String getDateEmon() {
        return dateEmon;
    }

    /**
     * Sets the date emon.
     *
     * @param dateEmon the new date emon
     */
    public void setDateEmon(String dateEmon) {
        this.dateEmon = dateEmon;
    }

    /**
     * Gets the date ecom.
     *
     * @return the date ecom
     */
    public String getDateEcom() {
        return dateEcom;
    }

    /**
     * Sets the date ecom.
     *
     * @param dateEcom the new date ecom
     */
    public void setDateEcom(String dateEcom) {
        this.dateEcom = dateEcom;
    }

}