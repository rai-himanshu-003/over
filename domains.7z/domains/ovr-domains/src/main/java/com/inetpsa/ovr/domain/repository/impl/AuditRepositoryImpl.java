/*
 * Creation : 1 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.Audit;
import com.inetpsa.ovr.domain.model.AuditPk;
import com.inetpsa.ovr.domain.repository.AuditRepository;

/**
 * The Class AuditRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class AuditRepositoryImpl extends BaseJpaRepository<Audit, AuditPk> implements AuditRepository {

}
