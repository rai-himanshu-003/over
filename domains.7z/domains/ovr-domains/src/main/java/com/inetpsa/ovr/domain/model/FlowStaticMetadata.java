/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.FlowStaticMetadataDTO;

/**
 * The Class FlowStaticMetadata.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTFLMTDT")
public class FlowStaticMetadata extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTFLMTDT_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The type. */
    @Column(name = "TYPE")
    private String type;

    /** The value. */
    @Column(name = "VALUE")
    private String value;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Mapto dto.
     *
     * @return the flow static metadata DTO
     */
    public FlowStaticMetadataDTO maptoDto() {
        FlowStaticMetadataDTO flowStaticMetadataDTO = new FlowStaticMetadataDTO();
        flowStaticMetadataDTO.setType(this.getType());
        flowStaticMetadataDTO.setId(this.getId());
        flowStaticMetadataDTO.setValue(this.getValue());
        return flowStaticMetadataDTO;

    }

}
