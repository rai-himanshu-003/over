/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.util.List;
import java.util.Map;

/**
 * The Class ComposantsDTO added.
 */

public class OvCompPartFilterDTO {

    /** The max ID. */
    private int maxID;

    /** The max std. */
    private int maxStd;

    /** The max part. */
    private int maxPart;

    /** The max supplier. */
    private int maxSupplier;

    /** The max data. */
    private int maxData;

    /** The max label. */
    private int maxLabel;

    /** The std seq map. */
    Map<Integer, Long> stdSeqMap;

    /** The part seq. */
    Map<Integer, Long> partSeq;

    /** The std 22 part list. */
    List<Long> std22PartList;

    /** The std 23 part list. */
    List<Long> std23PartList;

    /** The std 24 part list. */
    List<Long> std24PartList;

    /** The separator. */
    private String separator;

    /** The int separator. */
    private String intSeparator;

    /** The alignment. */
    private Long alignment;

    /** The max occ. */
    private Long maxOcc;

    /**
     * Gets the separator.
     *
     * @return the separator
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "OvCompPartFilterDTO [maxID=" + maxID + ", maxStd=" + maxStd + ", maxPart=" + maxPart + ", maxSupplier=" + maxSupplier + ", maxData="
                + maxData + ", maxLabel=" + maxLabel + ", stdSeqMap=" + stdSeqMap + ", partSeq=" + partSeq + ", std22PartList=" + std22PartList
                + ", std23PartList=" + std23PartList + ", std24PartList=" + std24PartList + ", separator=" + separator + ", intSeparator="
                + intSeparator + ", alignment=" + alignment + ", maxOcc=" + maxOcc + "]";
    }

    /**
     * Gets the max std.
     *
     * @return the max std
     */
    public int getMaxStd() {
        return maxStd;
    }

    /**
     * Sets the max std.
     *
     * @param maxStd the new max std
     */
    public void setMaxStd(int maxStd) {
        this.maxStd = maxStd;
    }

    /**
     * Sets the separator.
     *
     * @param separator the new separator
     */
    public void setSeparator(String separator) {
        this.separator = separator;
    }

    /**
     * Gets the int separator.
     *
     * @return the int separator
     */
    public String getIntSeparator() {
        return intSeparator;
    }

    /**
     * Sets the int separator.
     *
     * @param intSeparator the new int separator
     */
    public void setIntSeparator(String intSeparator) {
        this.intSeparator = intSeparator;
    }

    /**
     * Gets the alignment.
     *
     * @return the alignment
     */
    public Long getAlignment() {
        return alignment;
    }

    /**
     * Sets the alignment.
     *
     * @param alignment the new alignment
     */
    public void setAlignment(Long alignment) {
        this.alignment = alignment;
    }

    /**
     * Gets the max occ.
     *
     * @return the max occ
     */
    public Long getMaxOcc() {
        return maxOcc;
    }

    /**
     * Sets the max occ.
     *
     * @param maxOcc the new max occ
     */
    public void setMaxOcc(Long maxOcc) {
        this.maxOcc = maxOcc;
    }

    /**
     * Gets the max ID.
     *
     * @return the max ID
     */
    public int getMaxID() {
        return maxID;
    }

    /**
     * Sets the max ID.
     *
     * @param maxID the new max ID
     */
    public void setMaxID(int maxID) {
        this.maxID = maxID;
    }

    /**
     * Gets the max part.
     *
     * @return the max part
     */
    public int getMaxPart() {
        return maxPart;
    }

    /**
     * Sets the max part.
     *
     * @param maxPart the new max part
     */
    public void setMaxPart(int maxPart) {
        this.maxPart = maxPart;
    }

    /**
     * Gets the max supplier.
     *
     * @return the max supplier
     */
    public int getMaxSupplier() {
        return maxSupplier;
    }

    /**
     * Sets the max supplier.
     *
     * @param maxSupplier the new max supplier
     */
    public void setMaxSupplier(int maxSupplier) {
        this.maxSupplier = maxSupplier;
    }

    /**
     * Gets the max data.
     *
     * @return the max data
     */
    public int getMaxData() {
        return maxData;
    }

    /**
     * Sets the max data.
     *
     * @param maxData the new max data
     */
    public void setMaxData(int maxData) {
        this.maxData = maxData;
    }

    /**
     * Gets the max label.
     *
     * @return the max label
     */
    public int getMaxLabel() {
        return maxLabel;
    }

    /**
     * Sets the max label.
     *
     * @param maxLabel the new max label
     */
    public void setMaxLabel(int maxLabel) {
        this.maxLabel = maxLabel;
    }

    /**
     * Gets the std seq map.
     *
     * @return the std seq map
     */
    public Map<Integer, Long> getStdSeqMap() {
        return stdSeqMap;
    }

    /**
     * Sets the std seq map.
     *
     * @param stdSeqMap the std seq map
     */
    public void setStdSeqMap(Map<Integer, Long> stdSeqMap) {
        this.stdSeqMap = stdSeqMap;
    }

    /**
     * Gets the part seq.
     *
     * @return the part seq
     */
    public Map<Integer, Long> getPartSeq() {
        return partSeq;
    }

    /**
     * Sets the part seq.
     *
     * @param partSeq the part seq
     */
    public void setPartSeq(Map<Integer, Long> partSeq) {
        this.partSeq = partSeq;
    }

    /**
     * Gets the std 22 part list.
     *
     * @return the std 22 part list
     */
    public List<Long> getStd22PartList() {
        return std22PartList;
    }

    /**
     * Sets the std 22 part list.
     *
     * @param std22PartList the new std 22 part list
     */
    public void setStd22PartList(List<Long> std22PartList) {
        this.std22PartList = std22PartList;
    }

    /**
     * Gets the std 23 part list.
     *
     * @return the std 23 part list
     */
    public List<Long> getStd23PartList() {
        return std23PartList;
    }

    /**
     * Sets the std 23 part list.
     *
     * @param std23PartList the new std 23 part list
     */
    public void setStd23PartList(List<Long> std23PartList) {
        this.std23PartList = std23PartList;
    }

    /**
     * Gets the std 24 part list.
     *
     * @return the std 24 part list
     */
    public List<Long> getStd24PartList() {
        return std24PartList;
    }

    /**
     * Sets the std 24 part list.
     *
     * @param std24PartList the new std 24 part list
     */
    public void setStd24PartList(List<Long> std24PartList) {
        this.std24PartList = std24PartList;
    }

}
