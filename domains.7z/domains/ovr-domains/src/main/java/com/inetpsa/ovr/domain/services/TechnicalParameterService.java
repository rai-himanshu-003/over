/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.TechnicalParameter;

/**
 * The Interface TechnicalParameterService.
 */
@Service
public interface TechnicalParameterService {

    /**
     * Gets the tech param by code.
     *
     * @param lable the lable
     * @return the tech param by code
     */
    Optional<TechnicalParameter> getTechParamByCode(String lable);

    /**
     * Gets the all tech param.
     *
     * @return the all tech param
     */
    List<TechnicalParameter> getAllTechParam();

    /**
     * Update param.
     *
     * @param technicalParameter the technical parameter
     * @return true, if successful
     */
    boolean updateParam(TechnicalParameter technicalParameter);

    /**
     * Delete param.
     *
     * @param technicalParameter the technical parameter
     * @return true, if successful
     */
    boolean deleteParam(TechnicalParameter technicalParameter);

    List<TechnicalParameter> getTechParamByType(String type);

}
