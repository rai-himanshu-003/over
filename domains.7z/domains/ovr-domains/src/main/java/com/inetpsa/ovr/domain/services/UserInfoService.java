/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.UserInfo;
import com.inetpsa.ovr.interfaces.dto.UserInformationDTO;

/**
 * The Interface UserInfoService.
 */
@Service
public interface UserInfoService {

    /**
     * Gets the user data by type.
     *
     * @param userId the user id
     * @param type the type
     * @param lang the lang
     * @return the user data by type
     */
    UserInfo getUserDataByType(String userId, String type, String lang);

    /**
     * Update user info.
     *
     * @param userInformationDTO the user information DTO
     * @return true, if successful
     */
    boolean updateUserInfo(UserInformationDTO userInformationDTO);

}
