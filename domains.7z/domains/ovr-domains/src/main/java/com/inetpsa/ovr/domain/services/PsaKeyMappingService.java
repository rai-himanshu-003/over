/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.interfaces.dto.OvPsaMappingDTO;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

/**
 * The Interface PsaKeyMappingService.
 */
@Service
public interface PsaKeyMappingService {

    /**
     * Gets the psa key mapping.
     *
     * @param id the id
     * @return the psa key mapping
     */
    Optional<PsaKeyMapping> getPsaKeyMapping(Long id);

    /**
     * Gets the psa key by ov key.
     *
     * @param eid the eid
     * @return the psa key by ov key
     */
    List<PsaKeyMapping> getPsaKeyByOvKey(String eid);

    /**
     * Adds the or update mapping.
     *
     * @param ovPsaMappingDTO the ov psa mapping DTO
     * @return true, if successful
     */
    ResponseDto addOrUpdateMapping(OvPsaMappingDTO ovPsaMappingDTO);

    /**
     * Find findPsa mapping.
     *
     * @param ovKey the ov key
     * @param ovStd the ov std
     * @return the psa key mapping
     */
    PsaKeyMapping findPsaMapping(String ovStd, String ovKey);

    List<PsaKeyMapping> findOvMapping(String psaType, String psaKey);

    /**
     * Delete interface rule.
     *
     * @param mappingId the mapping id
     * @return true, if successful
     */
    boolean deleteMapping(Long mappingId);

    /**
     * Gets the m apping list.
     *
     * @return the m apping list
     */
    List<OvPsaMappingDTO> getMappingList();

}
