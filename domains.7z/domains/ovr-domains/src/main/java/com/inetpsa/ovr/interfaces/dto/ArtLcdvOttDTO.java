/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.ArtLcdvOtt;

/**
 * The Class ArtLcdvOttDTO.
 */
public class ArtLcdvOttDTO {

    /** The id art lcdv dto. */
    private Long idArtLcdvDto;

    /** The code art lcdv dto. */
    private String codeArtLcdvDto;

    /** The vin art lcdv dto. */
    private String vinArtLcdvDto;

    /** The family art lcdv dto. */
    private String familyArtLcdvDto;

    /** The value art lcdv dto. */
    private String valueArtLcdvDto;

    /**
     * Gets the id art lcdv dto.
     *
     * @return the id art lcdv dto
     */
    public Long getIdArtLcdvDto() {
        return idArtLcdvDto;
    }

    /**
     * Sets the id art lcdv dto.
     *
     * @param idArtLcdvDto the new id art lcdv dto
     */
    public void setIdArtLcdvDto(Long idArtLcdvDto) {
        this.idArtLcdvDto = idArtLcdvDto;
    }

    /**
     * Gets the code art lcdv dto.
     *
     * @return the code art lcdv dto
     */
    public String getCodeArtLcdvDto() {
        return codeArtLcdvDto;
    }

    /**
     * Sets the code art lcdv dto.
     *
     * @param codeArtLcdvDto the new code art lcdv dto
     */
    public void setCodeArtLcdvDto(String codeArtLcdvDto) {
        this.codeArtLcdvDto = codeArtLcdvDto;
    }

    /**
     * Gets the vin art lcdv dto.
     *
     * @return the vin art lcdv dto
     */
    public String getVinArtLcdvDto() {
        return vinArtLcdvDto;
    }

    /**
     * Sets the vin art lcdv dto.
     *
     * @param vinArtLcdvDto the new vin art lcdv dto
     */
    public void setVinArtLcdvDto(String vinArtLcdvDto) {
        this.vinArtLcdvDto = vinArtLcdvDto;
    }

    /**
     * Gets the family art lcdv dto.
     *
     * @return the family art lcdv dto
     */
    public String getFamilyArtLcdvDto() {
        return familyArtLcdvDto;
    }

    /**
     * Sets the family art lcdv dto.
     *
     * @param familyArtLcdvDto the new family art lcdv dto
     */
    public void setFamilyArtLcdvDto(String familyArtLcdvDto) {
        this.familyArtLcdvDto = familyArtLcdvDto;
    }

    /**
     * Gets the value art lcdv dto.
     *
     * @return the value art lcdv dto
     */
    public String getValueArtLcdvDto() {
        return valueArtLcdvDto;
    }

    /**
     * Sets the value art lcdv dto.
     *
     * @param valueArtLcdvDto the new value art lcdv dto
     */
    public void setValueArtLcdvDto(String valueArtLcdvDto) {
        this.valueArtLcdvDto = valueArtLcdvDto;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ArtLcdvOttDTO [idArtLcdvDto=" + idArtLcdvDto + ", codeArtLcdvDto=" + codeArtLcdvDto + ", vinArtLcdvDto=" + vinArtLcdvDto
                + ", familyArtLcdvDto=" + familyArtLcdvDto + ", valueArtLcdvDto=" + valueArtLcdvDto + "]";
    }

    /**
     * Map tomodel.
     *
     * @return the art lcdv ott
     */
    public ArtLcdvOtt mapTomodel() {
        ArtLcdvOtt artLcdvOtt = new ArtLcdvOtt();

        artLcdvOtt.setId(this.getIdArtLcdvDto());
        artLcdvOtt.setCode(this.getCodeArtLcdvDto());
        artLcdvOtt.setFamily(this.getFamilyArtLcdvDto());
        artLcdvOtt.setValue(this.getValueArtLcdvDto());
        artLcdvOtt.setVin(this.getVinArtLcdvDto());

        return artLcdvOtt;
    }

}
