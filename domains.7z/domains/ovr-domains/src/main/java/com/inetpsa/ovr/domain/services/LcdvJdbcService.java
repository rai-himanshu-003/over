/*
 * Creation : 20 Feb 2020
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.interfaces.dto.ArtLcdvOttDTO;
import com.inetpsa.ovr.interfaces.dto.ComposantsDTO;
import com.inetpsa.ovr.interfaces.dto.ComposantsOvDTO;
import com.inetpsa.ovr.interfaces.dto.KeysOvDTO;
import com.inetpsa.ovr.interfaces.dto.LcdvOttDTO;
import com.inetpsa.ovr.interfaces.dto.OptionsDTO;
import com.inetpsa.ovr.interfaces.dto.ReferencesElectroniquesDTO;

/**
 * The Interface LcdvJdbcService.
 */
@Service
public interface LcdvJdbcService {

    /**
     * Gets the lcdv list.
     *
     * @param artLcdv the art lcdv
     * @param vinList the vin list
     * @return the lcdv list
     */
    List<ArtLcdvOttDTO> getLcdvList(List<String> artLcdv, List<String> vinList);

    /**
     * Gets the rpo list.
     *
     * @param rpoCodes the rpo codes
     * @param vinList the vin list
     * @return the rpo list
     */
    List<OptionsDTO> getRpoList(List<String> rpoCodes, List<String> vinList);

    /**
     * Gets the composants fr ws.
     *
     * @param psaKeyMappings the psa key mappings
     * @param vinList the vin list
     * @return the composants fr ws
     */
    List<ComposantsOvDTO> getComposantsFrWs(List<PsaKeyMapping> psaKeyMappings, List<String> vinList);

    /**
     * Gets the LCDV for corvet.
     *
     * @param vinList the vin list
     * @return the LCDV for corvet
     */
    public List<LcdvOttDTO> getLCDVForCorvet(List<String> vinList);

    /**
     * Gets the ref elect for corvet.
     *
     * @param vinList the vin list
     * @return the ref elect for corvet
     */
    public List<ReferencesElectroniquesDTO> getRefElectForCorvet(List<String> vinList);

    /**
     * Gets the keys OV for corvet.
     *
     * @param vinList the vin list
     * @return the keys OV for corvet
     */
    public List<KeysOvDTO> getKeysOVForCorvet(List<String> vinList);

    /**
     * Gets the compo sants for corvet.
     *
     * @param vinList the vin list
     * @return the compo sants for corvet
     */
    public List<ComposantsDTO> getCompoSantsForCorvet(List<String> vinList);
}
