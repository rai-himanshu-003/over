/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;

/**
 * The Class PsaKeyMapping.
 * 
 * @author E566559
 */
@Entity
@Table(name = "OVRQTVSTS")
@DynamicUpdate(value = true)
public class MultipleFlowStatus extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTVSTS_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The flow. */
    @Column(name = "FLOW")
    @NotNull
    private String flow;

    /** The vin. */
    @Column(name = "VIN")
    @NotNull
    private String vin;

    /** The status. */
    @Column(name = "STATUS")
    @NotNull
    private String status;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private LocalDateTime dateCreation;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The date modif. */
    @Column(name = "DATE_MODIF")
    private LocalDateTime dateModif;

    /** The user modif. */
    @Column(name = "USER_MODIF")
    private String userModif;

    /** The version. */
    @Version
    @Column(name = "VERSION")
    private Integer version;

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        dateCreation = LocalDateTime.now();
        userCreation = LoggedUser.get();
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();
    }

    /**
     * Pre update.
     */
    @PreUpdate
    public void preUpdate() {
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public LocalDateTime getDateModif() {
        return dateModif;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the flow.
     *
     * @return the flow
     */
    public String getFlow() {
        return flow;
    }

    /**
     * Sets the flow.
     *
     * @param flow the new flow
     */
    public void setFlow(String flow) {
        this.flow = flow;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "MultipleFlowStatus [id=" + id + ", flow=" + flow + ", vin=" + vin + ", status=" + status + ", dateCreation=" + dateCreation
                + ", userCreation=" + userCreation + ", dateModif=" + dateModif + ", userModif=" + userModif + "]";
    }

    /**
     * Mapto dto.
     *
     * @return the multiple flow status DTO
     */
    public MultipleFlowStatusDTO maptoDto() {

        MultipleFlowStatusDTO multipleFlowStatusDTO = new MultipleFlowStatusDTO();
        multipleFlowStatusDTO.setFlow(this.getFlow());
        multipleFlowStatusDTO.setId(this.getId());
        multipleFlowStatusDTO.setStatus(this.getStatus());
        multipleFlowStatusDTO.setVin(this.getVin());

        return multipleFlowStatusDTO;
    }

    /**
     * Instantiates a new multiple flow status.
     */
    public MultipleFlowStatus() {

    }

    /**
     * Instantiates a new multiple flow status.
     *
     * @param id the id
     * @param flow the flow
     * @param vin the vin
     * @param status the status
     */

    public MultipleFlowStatus(Long id, @NotNull String flow, @NotNull String vin, @NotNull String status) {
        super();
        this.id = id;
        this.flow = flow;
        this.vin = vin;
        this.status = status;

    }

}
