/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.KeysOv;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleKeysOvRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.VehicleKeysOvService;

/**
 * The Class VehicleKeysOvServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleKeysOvServiceImpl implements VehicleKeysOvService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleKeysOvServiceImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The vehicle keys ov repository. */
    @Inject
    private VehicleKeysOvRepository vehicleKeysOvRepository;

    /** The vehicle repo. */
    @Inject
    private VehicleRepository vehicleRepo;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleKeysOvService#getvehicleKeysOvByVin(java.lang.String)
     */
    @Override
    public List<KeysOv> getvehicleKeysOvByVin(String vin) {
        Specification<KeysOv> spec = specificationBuilder.of(KeysOv.class).property("vin").equalTo(vin).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        return vehicleKeysOvRepository.get(spec, opt).collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleKeysOvService#deleteKeysOvById(java.lang.Long)
     */
    @Override
    public boolean deleteKeysOvById(Long keysOv) {
        Optional<KeysOv> tobedeleted = vehicleKeysOvRepository.get(keysOv);
        if (tobedeleted.isPresent()) {
            vehicleKeysOvRepository.remove(tobedeleted.get());
            logger.info("keysOv {} : has been deleted successfully!", keysOv);
            Optional<Vehicle> optVehicle = vehicleRepo.get(tobedeleted.get().getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }
            return true;
        }
        logger.info("keysOv {} : is not present in DB", keysOv);
        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleKeysOvService#addOrUpdateKeysOv(com.inetpsa.ovr.domain.model.KeysOv)
     */
    @Override
    public boolean addOrUpdateKeysOv(KeysOv keysOv) {
        try {
            if (keysOv.getId() != null)
                vehicleKeysOvRepository.update(keysOv);
            else
                vehicleKeysOvRepository.add(keysOv);

            Optional<Vehicle> optVehicle = vehicleRepo.get(keysOv.getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }

            return true;
        } catch (Exception e) {
            logger.error("Error while adding/updating keysOv {} : {}", keysOv, e.getMessage());
        }
        return false;
    }

}
