/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.Composants;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleComposantsRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.VehicleComposantService;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

/**
 * The Class VehicleComposantServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleComposantServiceImpl implements VehicleComposantService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleComposantServiceImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The specification builder. */
    @Inject
    private VehicleComposantsRepository vehicleComposantsRepository;

    /** The vehicle repo. */
    @Inject
    private VehicleRepository vehicleRepo;
    @Inject
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleComposantService#getComposantsByVin(java.lang.String)
     */
    @Override
    public List<Composants> getComposantsByVin(String vin) {

        StringBuilder query;
        List<Composants> cList = new ArrayList<>();
        query = new StringBuilder(
                "select * from OVRQTVCOM where vin=? and NOT EXISTS(select 1 from OVRQTKEYMAP where PSA_DATA_TYPE='PSA_KEY' and OVRQTVCOM.DATA LIKE PSA_KEY || '%')");
        List list = this.entityManager.createNativeQuery(query.toString()).setParameter(1, vin).getResultList();

        Iterator itr = list.iterator();
        while (itr.hasNext()) {
            Object[] obj = (Object[]) (itr.next());
            Composants composants = new Composants();
            System.out.println("long");
            composants.setId(new Long(obj[OVERConstants.MAGICNUMBER0].toString()));
            composants.setVin(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER1]).orElse("").toString());
            composants.setData(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER2]).orElse("").toString());
            cList.add(composants);
        }
        return cList;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleComposantService#deleteComposantsById(java.lang.Long)
     */
    @Override
    public boolean deleteComposantsById(Long composants) {
        Optional<Composants> tobedeleted = vehicleComposantsRepository.get(composants);
        if (tobedeleted.isPresent()) {
            vehicleComposantsRepository.remove(tobedeleted.get());

            Optional<Vehicle> optVehicle = vehicleRepo.get(tobedeleted.get().getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }
            return true;
        }
        logger.info("Composants {} : is not present in DB", composants);

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleComposantService#addOrUpdateComposants(com.inetpsa.ovr.domain.model.Composants)
     */
    @Override
    public ResponseDto addOrUpdateComposants(Composants composants) {
        ResponseDto responseDto = new ResponseDto();
        boolean flag = false;
        try {

            if (composants.getId() != null) {
                responseDto.setId(composants.getId().toString());
                vehicleComposantsRepository.update(composants);
                flag = true;
            } else {

                List<BigDecimal> seqNumber = getSequenceCount(OVERConstants.MAGICNUMBER1);
                if (seqNumber != null) {
                    composants.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).longValue());
                    responseDto.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).toString());
                    vehicleComposantsRepository.add(composants);
                    flag = true;
                } else {
                    logger.error("Sequence Number is {} Empty from DB : {}", seqNumber, composants);

                }
            }
            Optional<Vehicle> optVehicle = vehicleRepo.get(composants.getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }
            responseDto.setMsg(flag);
            return responseDto;
        } catch (Exception e) {
            logger.error("Error while adding/updating composants {} : {}", composants, e.getMessage());
            responseDto.setMsg(flag);
            return responseDto;
        }

    }

    @Override
    public List<BigDecimal> getSequenceCount(int numberOfSeq) {
        return vehicleComposantsRepository.getSequenceCount(numberOfSeq);
    }

}
