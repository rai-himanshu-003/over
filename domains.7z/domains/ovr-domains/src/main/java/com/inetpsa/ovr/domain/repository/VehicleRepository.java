/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.interfaces.dto.IRMRequestDTO;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;

/**
 * The Interface VehicleRepository.
 */
public interface VehicleRepository extends Repository<Vehicle, String> {

    /**
     * Gets the vehicle details.
     *
     * @param vinNo the vin no
     * @return the vehicle details
     */
    Vehicle getVehicleDetails(String vinNo);

    /**
     * Gets the vehicles details.
     *
     * @param vehicleSearchDto the vehicle search dto
     * @param offsetPositionToStartFrom the offset position to start from
     * @param rowsPerPage the rows per page
     * @return the vehicles details
     */
    List<ResendToOTTDto> getVehiclesDetails(ResendToOTTDto vehicleSearchDto, int offsetPositionToStartFrom, int rowsPerPage);

    List<ResendToOTTDto> getVehiclesDetailsTest(ResendToOTTDto vehicleSearchDto, int offsetPositionToStartFrom, int rowsPerPage);

    /**
     * Gets the vehicles details count.
     *
     * @param vehicleSearchDto the vehicle search dto
     * @return the vehicles details count
     */
    Long getVehiclesDetailsCount(ResendToOTTDto vehicleSearchDto);

    /**
     * Apply rules and insert vehicles.
     *
     * @param interfaceRulesDto the interface rules dto
     * @param irmRequestDTO the irm request DTO
     * @param status the status
     * @param ignoreAll the ignore all
     * @return true, if successful
     */
    public boolean applyRulesAndInsertVehicles(InterfaceRulesDto interfaceRulesDto, IRMRequestDTO irmRequestDTO, String status, Boolean ignoreAll,
            List<String> vinList);

    /**
     * Delete OTT retried recs.
     *
     * @param flow the flow
     * @param status the status
     * @return true, if successful
     */
    boolean deleteOTTRetriedRecs(String flow, String status);

    public StringBuilder formInClause(List<String> dataList, String innerequery);

    public List<VehicleDetailsDto> getVehList(List<String> previousFlow, List<String> statusList, String currentFlow);

    boolean deleteOldOutflowEntry(String currentFlow);

    List<String> getVehicleForOutputFlow(OutputFlowDetails outputFlow);
}
