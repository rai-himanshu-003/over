/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.Optional;

import javax.inject.Inject;

import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.repository.InterfaceRepository;
import com.inetpsa.ovr.domain.services.InterfaceService;

/**
 * The Class InterfaceRulesServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class InterfaceServiceImpl implements InterfaceService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(InterfaceServiceImpl.class);

    /** The audit repository. */
    @Inject
    private InterfaceRepository interfaceRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    @Override
    public Interface getInterfaceByName(String name) {

        logger.info("Entering into interfaceName > getInterfaceByName with interface name : {}", name);

        Specification<Interface> spec = specificationBuilder.of(Interface.class).property("interfaceName").equalTo(name).build();
        Optional<Interface> i = interfaceRepository.get(spec).findFirst();

        return i.isPresent() ? i.get() : null;

    }

}