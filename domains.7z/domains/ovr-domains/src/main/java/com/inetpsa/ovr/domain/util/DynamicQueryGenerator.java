/*
 * Creation : 20 Dec 2019
 */
package com.inetpsa.ovr.domain.util;

import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;

import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.interfaces.dto.ws.ComponentsOv;

public class DynamicQueryGenerator {

    /**
     * Psa key query generator.
     *
     * @param componentsOv the components ov
     * @param specificationBuilder the specification builder
     * @return the specification
     */
    public static Specification<PsaKeyMapping> psaKeyQueryGenerator(ComponentsOv componentsOv, SpecificationBuilder specificationBuilder) {
        Specification<PsaKeyMapping> psaKeySpec;
        if (componentsOv.getId().contains("|WT")) {
            String[] strFields = componentsOv.getId().split("\\|");
            String psaKey = strFields[0];

            psaKeySpec = specificationBuilder.of(PsaKeyMapping.class).property("psaDatatype").matching(componentsOv.getStandard()).ignoringCase()
                    .and().property("psaKey").not().matching(psaKey + "%").ignoringCase().build();
        } else {
            psaKeySpec = specificationBuilder.of(PsaKeyMapping.class).property("psaDatatype").matching(componentsOv.getStandard()).ignoringCase()
                    .and().property("psaKey").matching(componentsOv.getId()).ignoringCase().build();
        }

        return psaKeySpec;
    }
}
