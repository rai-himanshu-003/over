/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.constant;

/**
 * enum for batch status.
 *
 * @author E566559
 */
public enum BatchStatusConstant {

    /** The batch stopped status. */
    BATCH_STOPPED_STATUS("STOPPED"),

    /** The batch active status. */
    BATCH_ACTIVE_STATUS("ACTIVE");

    /** The const value. */
    String constValue;

    /**
     * Instantiates a new batch status constant.
     *
     * @param constValue the const value
     */
    BatchStatusConstant(String constValue) {
        this.constValue = constValue;
    }

    /**
     * Gets the const value.
     *
     * @return the const value
     */
    public String getConstValue() {
        return constValue;
    }

}
