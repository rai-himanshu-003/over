/*
 * Creation : 17 Dec 2019
 */
package com.inetpsa.ovr.interfaces.dto.ws;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

/**
 * The Class ComponentsOv.
 */
public class ComponentsOv {

    /** The standard. */
    @JsonProperty("STANDARD")
    @SerializedName("STANDARD")
    private String standard;

    /** The id. */
    @JsonProperty("ID")
    @SerializedName("ID")
    private String id;

    /** The data. */
    @SerializedName("DATA")
    private String data;

    /** The label. */
    @SerializedName("LABEL")
    private String label;

    /** The part. */
    @SerializedName("PART")
    private String part;

    /** The supplier. */
    @SerializedName("SUPPLIER")
    private String supplier;

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public String getStandard() {
        return standard;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(String standard) {
        this.standard = standard;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the part.
     *
     * @return the part
     */
    public String getPart() {
        return part;
    }

    /**
     * Sets the part.
     *
     * @param part the new part
     */
    public void setPart(String part) {
        this.part = part;
    }

    /**
     * Gets the supplier.
     *
     * @return the supplier
     */
    public String getSupplier() {
        return supplier;
    }

    /**
     * Sets the supplier.
     *
     * @param supplier the new supplier
     */
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ComponentsOv [standard=" + standard + ", id=" + id + ", data=" + data + ", label=" + label + "]";
    }

}
