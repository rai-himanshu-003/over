/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.TechnicalParameter;
import com.inetpsa.ovr.domain.repository.TechnicalParameterRepository;
import com.inetpsa.ovr.domain.services.TechnicalParameterService;
import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The class TechnicalParameterServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class TechnicalParameterServiceImpl implements TechnicalParameterService {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(TechnicalParameterServiceImpl.class);

    /** The Constant techlogger. */
    private static final Logger techlogger = LoggerFactory.getLogger("technicallog");

    /** The technical parameter repository. */
    @Inject
    private TechnicalParameterRepository technicalParameterRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.TechnicalParameterService#getTechParamByCode(java.lang.String)
     */
    @Override
    public Optional<TechnicalParameter> getTechParamByCode(String lable) {
        return technicalParameterRepository.get(lable);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.TechnicalParameterService#getAllTechParam()
     */
    @Override
    public List<TechnicalParameter> getAllTechParam() {
        return technicalParameterRepository.getAllTechParam();
    }

    @Override
    public List<TechnicalParameter> getTechParamByType(String type) {

        Stream<TechnicalParameter> techParamDetailObj = technicalParameterRepository
                .get(specificationBuilder.ofAggregate(TechnicalParameter.class).property("type").equalTo(type).build());

        return techParamDetailObj.collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.TechnicalParameterService#updateParam(com.inetpsa.ovr.domain.model.TechnicalParameter)
     */
    @Override
    public boolean updateParam(TechnicalParameter technicalParameter) {
        try {
            Optional<TechnicalParameter> techParamDetailObj = technicalParameterRepository
                    .get(specificationBuilder.ofAggregate(TechnicalParameter.class).property("code").equalTo(technicalParameter.getCode()).build())
                    .findFirst();
            techlogger.info("Details of Technical paramater being Added/updated");
            techlogger.info("code :{} ", technicalParameter.getCode());
            techlogger.info("Current value : {} ", technicalParameter.getValue());
            techlogger.info("Current lable : {} ", technicalParameter.getLable());

            if (techParamDetailObj.isPresent() && techParamDetailObj.get() != null) {
                techlogger.info("Old Value : {} ", techParamDetailObj.get().getValue());
                techlogger.info("Old Lable : {} ", techParamDetailObj.get().getLable());
                techParamDetailObj.get().setLable(technicalParameter.getLable());
                techParamDetailObj.get().setValue(technicalParameter.getValue());
                technicalParameterRepository.update(techParamDetailObj.get());

            } else
                technicalParameterRepository.add(technicalParameter);

            Optional<TechnicalParameter> techParamDetailObjNew = technicalParameterRepository
                    .get(specificationBuilder.ofAggregate(TechnicalParameter.class).property("code").equalTo(technicalParameter.getCode()).build())
                    .findFirst();

            if (techParamDetailObj.isPresent() && techParamDetailObjNew.isPresent())
                techlogger.info("User Id of modifier :{} ,modified at :{} ", techParamDetailObjNew.get().getUserModif(),
                        DateTimeFormatter.ofPattern("yyy/MM/dd HH:mm:ss").format(techParamDetailObjNew.get().getDateModif()));
            else if (techParamDetailObjNew.isPresent())
                techlogger.info("User Id of creator :{} ,created at :{} ", techParamDetailObjNew.get().getUserCreation(),
                        DateTimeFormatter.ofPattern("yyy/MM/dd HH:mm:ss").format(techParamDetailObjNew.get().getDateCreation()));

            return true;
        } catch (Exception e) {
            logger.error("Error while updating technical Parameter: {} ", e.getMessage());
            return false;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.TechnicalParameterService#deleteParam(com.inetpsa.ovr.domain.model.TechnicalParameter)
     */
    @Override
    public boolean deleteParam(TechnicalParameter technicalParameter) {
        try {
            Optional<TechnicalParameter> technicalParameterOptional = technicalParameterRepository.get(technicalParameter.getCode());
            if (technicalParameterOptional.isPresent()) {
                techlogger.info("Details of technical paramater being Deleted");
                techlogger.info("Code: {} ", technicalParameter.getCode());
                techlogger.info("Value: {} ", technicalParameter.getValue());

                technicalParameterRepository.remove(technicalParameterOptional.get());
                techlogger.info("User Id : {} ,deleted at :{} ", LoggedUser.get(), new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()));

                String tostring = technicalParameter.toString();
                // techlogger.info("Deleting Technial Parameter : {} ", tostring);
            } else {
                String tostring = technicalParameter.toString();
                techlogger.info("Technial Parameter not found in Database : {} ", tostring);
                return false;
            }

            return true;
        } catch (Exception e) {
            logger.error("Error While Deleting technical Parameter :{} ", e.getMessage());
            return false;
        }
    }

}
