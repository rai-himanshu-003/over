/*
 * Creation : 18 Nov 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.Flow;

/**
 * The Interface InterfaceRepository.
 */
public interface FlowNameRepository extends Repository<Flow, Long> {

}
