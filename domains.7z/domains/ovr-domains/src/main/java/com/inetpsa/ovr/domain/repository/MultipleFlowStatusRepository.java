/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.MultipleFlowStatus;

/**
 * The Interface PsaKeyMappingRepository.
 */
public interface MultipleFlowStatusRepository extends Repository<MultipleFlowStatus, Long> {

}
