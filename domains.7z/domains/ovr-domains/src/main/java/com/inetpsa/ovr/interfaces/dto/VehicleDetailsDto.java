/*
 * Creation : 10 Oct 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * The Class VehicleDetailsDto.
 */
public class VehicleDetailsDto implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The vin. */
    private String vin;

    /** The date creation. */
    private Date dateCreation;

    /** The date modif. */
    private Date dateModif;

    /** The err code. */
    private String errCode;

    /** The err complement. */
    private String errComplement;

    /** The err desc. */
    private String errDesc;

    /** The err message. */
    private String errMessage;

    /** The user creation. */
    private String userCreation;

    /** The user modif. */
    private String userModif;

    /** The state id. */
    private String stateId;

    /** The ccp. */
    private String ccp;

    /** The veh. */
    private String veh;

    /** The lcdv ott. */
    private String lcdvOtt;

    /** The xml ov. */
    private String xmlOv;

    /** The oa. */
    private String oa;

    /** The of. */
    private String of;

    /** The nre. */
    private String nre;

    /** The tvv. */
    private String tvv;

    /** The up. */
    private String up;

    /** The lcdv 24. */
    private String lcdv24;

    /** The apvpr. */
    private String apvpr;

    /** The model. */
    private String model;

    /** The model year. */
    private String modelYear;

    /** The date extension. */
    private Date dateExtension;

    /** The date ecom. */
    private Date dateEcom;

    /** The date emon. */
    private Date dateEmon;

    /** The version. */
    private Integer version;

    /** The flow name. */
    private String flowName;

    /** The multiple flow status DTO. */
    List<MultipleFlowStatusDTO> multipleFlowStatusDTO;

    /** The engine. */
    private String engine;

    /** The country. */
    private String country;

    /** The transmission. */
    private String transmission;

    /** The model name. */
    private String modelName;

    /** The action type. */
    private String actionType;

    /** The type data. */
    private String typeData;

    /** The value. */
    private String value;

    /** The old value. */
    private String oldValue;

    /** The standard. */
    private String standard;

    /** The id. */
    private String id;

    /** The label. */
    private String label;

    /** The data. */
    private String data;

    /** The supplier. */
    private String supplier;

    /** The part. */
    private String part;

    /** The user id. */
    private String userId;

    /** The date operation. */
    private Date dateOperation;

    /**
     * Gets the action type.
     *
     * @return the action type
     */
    public String getActionType() {
        return actionType;
    }

    /**
     * Sets the action type.
     *
     * @param actionType the new action type
     */
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    /**
     * Gets the type data.
     *
     * @return the type data
     */
    public String getTypeData() {
        return typeData;
    }

    /**
     * Sets the type data.
     *
     * @param typeData the new type data
     */
    public void setTypeData(String typeData) {
        this.typeData = typeData;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public String getStandard() {
        return standard;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(String standard) {
        this.standard = standard;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * Gets the supplier.
     *
     * @return the supplier
     */
    public String getSupplier() {
        return supplier;
    }

    /**
     * Sets the supplier.
     *
     * @param supplier the new supplier
     */
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    /**
     * Gets the part.
     *
     * @return the part
     */
    public String getPart() {
        return part;
    }

    /**
     * Sets the part.
     *
     * @param part the new part
     */
    public void setPart(String part) {
        this.part = part;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     *
     * @param userId the new user id
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets the date operation.
     *
     * @return the date operation
     */
    public Date getDateOperation() {
        return dateOperation;
    }

    /**
     * Sets the date operation.
     *
     * @param dateOperation the new date operation
     */
    public void setDateOperation(Date dateOperation) {
        this.dateOperation = dateOperation;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the ccp.
     *
     * @return the ccp
     */
    public String getCcp() {
        return ccp;
    }

    /**
     * Sets the ccp.
     *
     * @param ccp the new ccp
     */
    public void setCcp(String ccp) {
        this.ccp = ccp;
    }

    /**
     * Gets the veh.
     *
     * @return the veh
     */
    public String getVeh() {
        return veh;
    }

    /**
     * Sets the veh.
     *
     * @param veh the new veh
     */
    public void setVeh(String veh) {
        this.veh = veh;
    }

    /**
     * Gets the lcdv ott.
     *
     * @return the lcdv ott
     */
    public String getLcdvOtt() {
        return lcdvOtt;
    }

    /**
     * Sets the lcdv ott.
     *
     * @param lcdvOtt the new lcdv ott
     */
    public void setLcdvOtt(String lcdvOtt) {
        this.lcdvOtt = lcdvOtt;
    }

    /**
     * Gets the xml ov.
     *
     * @return the xml ov
     */
    public String getXmlOv() {
        return xmlOv;
    }

    /**
     * Sets the xml ov.
     *
     * @param xmlOv the new xml ov
     */
    public void setXmlOv(String xmlOv) {
        this.xmlOv = xmlOv;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public Date getDateCreation() {
        return dateCreation;
    }

    /**
     * Sets the date creation.
     *
     * @param dateCreation the new date creation
     */
    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * Gets the err code.
     *
     * @return the err code
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the err code.
     *
     * @param errCode the new err code
     */
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    /**
     * Gets the err complement.
     *
     * @return the err complement
     */
    public String getErrComplement() {
        return errComplement;
    }

    /**
     * Sets the err complement.
     *
     * @param errComplement the new err complement
     */
    public void setErrComplement(String errComplement) {
        this.errComplement = errComplement;
    }

    /**
     * Gets the err desc.
     *
     * @return the err desc
     */
    public String getErrDesc() {
        return errDesc;
    }

    /**
     * Sets the err desc.
     *
     * @param errDesc the new err desc
     */
    public void setErrDesc(String errDesc) {
        this.errDesc = errDesc;
    }

    /**
     * Gets the err message.
     *
     * @return the err message
     */
    public String getErrMessage() {
        return errMessage;
    }

    /**
     * Sets the err message.
     *
     * @param errMessage the new err message
     */
    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Sets the user creation.
     *
     * @param userCreation the new user creation
     */
    public void setUserCreation(String userCreation) {
        this.userCreation = userCreation;
    }

    /**
     * Gets the state id.
     *
     * @return the state id
     */
    public String getStateId() {
        return stateId;
    }

    /**
     * Sets the state id.
     *
     * @param stateId the new state id
     */
    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    /**
     * Gets the oa.
     *
     * @return the oa
     */
    public String getOa() {
        return oa;
    }

    /**
     * Sets the oa.
     *
     * @param oa the new oa
     */
    public void setOa(String oa) {
        this.oa = oa;
    }

    /**
     * Gets the of.
     *
     * @return the of
     */
    public String getOf() {
        return of;
    }

    /**
     * Sets the of.
     *
     * @param of the new of
     */
    public void setOf(String of) {
        this.of = of;
    }

    /**
     * Gets the nre.
     *
     * @return the nre
     */
    public String getNre() {
        return nre;
    }

    /**
     * Sets the nre.
     *
     * @param nre the new nre
     */
    public void setNre(String nre) {
        this.nre = nre;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Sets the tvv.
     *
     * @param tvv the new tvv
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * Gets the up.
     *
     * @return the up
     */
    public String getUp() {
        return up;
    }

    /**
     * Sets the up.
     *
     * @param up the new up
     */
    public void setUp(String up) {
        this.up = up;
    }

    /**
     * Gets the lcdv 24.
     *
     * @return the lcdv 24
     */
    public String getLcdv24() {
        return lcdv24;
    }

    /**
     * Sets the lcdv 24.
     *
     * @param lcdv24 the new lcdv 24
     */
    public void setLcdv24(String lcdv24) {
        this.lcdv24 = lcdv24;
    }

    /**
     * Gets the apvpr.
     *
     * @return the apvpr
     */
    public String getApvpr() {
        return apvpr;
    }

    /**
     * Sets the apvpr.
     *
     * @param apvpr the new apvpr
     */
    public void setApvpr(String apvpr) {
        this.apvpr = apvpr;
    }

    /**
     * Gets the model.
     *
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model.
     *
     * @param model the new model
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Gets the model year.
     *
     * @return the model year
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the model year.
     *
     * @param modelYear the new model year
     */
    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    /**
     * Gets the date extension.
     *
     * @return the date extension
     */
    public Date getDateExtension() {
        return dateExtension;
    }

    /**
     * Sets the date extension.
     *
     * @param dateExtension the new date extension
     */
    public void setDateExtension(Date dateExtension) {
        this.dateExtension = dateExtension;
    }

    /**
     * Gets the date ecom.
     *
     * @return the date ecom
     */
    public Date getDateEcom() {
        return dateEcom;
    }

    /**
     * Sets the date ecom.
     *
     * @param dateEcom the new date ecom
     */
    public void setDateEcom(Date dateEcom) {
        this.dateEcom = dateEcom;
    }

    /**
     * Gets the date emon.
     *
     * @return the date emon
     */
    public Date getDateEmon() {
        return dateEmon;
    }

    /**
     * Sets the date emon.
     *
     * @param dateEmon the new date emon
     */
    public void setDateEmon(Date dateEmon) {
        this.dateEmon = dateEmon;
    }

    /**
     * Gets the flow name.
     *
     * @return the flow name
     */
    public String getFlowName() {
        return flowName;
    }

    /**
     * Sets the flow name.
     *
     * @param flowName the new flow name
     */
    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public Date getDateModif() {
        return dateModif;
    }

    /**
     * Sets the date modif.
     *
     * @param dateModif the new date modif
     */
    public void setDateModif(Date dateModif) {
        this.dateModif = dateModif;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Sets the user modif.
     *
     * @param userModif the new user modif
     */
    public void setUserModif(String userModif) {
        this.userModif = userModif;
    }

    /**
     * Gets the multiple flow status DTO.
     *
     * @return the multiple flow status DTO
     */
    public List<MultipleFlowStatusDTO> getMultipleFlowStatusDTO() {
        return multipleFlowStatusDTO;
    }

    /**
     * Sets the multiple flow status DTO.
     *
     * @param multipleFlowStatusDTO the new multiple flow status DTO
     */
    public void setMultipleFlowStatusDTO(List<MultipleFlowStatusDTO> multipleFlowStatusDTO) {
        this.multipleFlowStatusDTO = multipleFlowStatusDTO;
    }

    /**
     * Gets the engine.
     *
     * @return the engine
     */
    public String getEngine() {
        return engine;
    }

    /**
     * Sets the engine.
     *
     * @param engine the new engine
     */
    public void setEngine(String engine) {
        this.engine = engine;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the transmission.
     *
     * @return the transmission
     */
    public String getTransmission() {
        return transmission;
    }

    /**
     * Sets the transmission.
     *
     * @param transmission the new transmission
     */
    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    /**
     * Gets the model name.
     *
     * @return the model name
     */
    public String getModelName() {
        return modelName;
    }

    /**
     * Sets the model name.
     *
     * @param modelName the new model name
     */
    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    /**
     * Gets the old value.
     *
     * @return the old value
     */
    public String getOldValue() {
        return oldValue;
    }

    /**
     * Sets the old value.
     *
     * @param oldValue the new old value
     */
    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
