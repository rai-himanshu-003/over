/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.ReferencesElectroniques;
import com.inetpsa.ovr.domain.repository.VehicleReferencesElectroniquesRepository;

/**
 * The Class VehicleReferencesElectroniquesRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleReferencesElectroniquesRepositoryImpl extends BaseJpaRepository<ReferencesElectroniques, Long>
        implements VehicleReferencesElectroniquesRepository {
    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The connection. */
    @Inject
    private Connection connection;

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(VehicleReferencesElectroniquesRepositoryImpl.class);

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleOptionsRepository#getSequenceCount(int)
     */
    @Override
    public List<BigDecimal> getSequenceCountForRfee(long size) {
        logger.info("Entering getSequenceCountForRfee");
        List<BigDecimal> list = new ArrayList<>();
        try {

            Query rfeeQuery = super.getEntityManager()
                    .createNativeQuery("select OVRQTVRFEE_SEQ.nextval from ( select level from dual connect by level <= :optionsCount )");
            rfeeQuery.setParameter("optionsCount", size);
            list = rfeeQuery.getResultList();
            logger.info("Exiting getSequenceCountForRfee");
            return list;

        } catch (Exception e) {
            logger.error("Error while genereting OVRQTVRFEE_SEQ Number : {}", e.getMessage());

        }
        return list;

    }

}