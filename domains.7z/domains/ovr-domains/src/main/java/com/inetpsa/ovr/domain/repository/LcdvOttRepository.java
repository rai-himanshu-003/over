/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.math.BigDecimal;
import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.LcdvOtt;

/**
 * The Interface LcdvOttRepository.
 */
public interface LcdvOttRepository extends Repository<LcdvOtt, Long> {

    /**
     * Gets the sequence count.
     *
     * @param size the size
     * @return the sequence count
     */
    List<BigDecimal> getSequenceCount(long size);

}
