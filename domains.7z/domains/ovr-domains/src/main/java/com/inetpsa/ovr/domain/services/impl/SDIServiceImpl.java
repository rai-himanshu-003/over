/*
 * Creation : 4 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.seedstack.seed.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.services.SDIService;
import com.inetpsa.ovr.domain.util.OVERConstants;

/**
 * The Class SDIServiceImpl.
 */
public class SDIServiceImpl implements SDIService {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(SDIServiceImpl.class);

    /** The sdi file path. */
    @Configuration("sdi.filepath")
    private String sdiFilePath;

    /** The sdi file name. */
    @Configuration("sdi.filename")
    private String sdiFileName;

    /** The reflex name. */
    @Configuration("sdi.reflex_name")
    private String reflexName;

    /** The prd. */
    @Configuration("sdi.prd")
    private String prd;

    /** The occ. */
    @Configuration("sdi.occ")
    private String occ;

    /** The sysid. */
    @Configuration("sdi.sysid")
    private String sysid;

    /** The secure random. */
    private SecureRandom random = new SecureRandom();

    /** The sdi date formatter. */
    SimpleDateFormat sdiDateFormatter = new SimpleDateFormat("dd/MM/yy HH:mm:ss");

    /**
     * Sets the sdi file path.
     *
     * @param sdiFilePath the new sdi file path
     */
    public void setSdiFilePath(String sdiFilePath) {
        this.sdiFilePath = sdiFilePath;
    }

    /**
     * Sets the sdi file name.
     *
     * @param sdiFileName the new sdi file name
     */
    public void setSdiFileName(String sdiFileName) {
        this.sdiFileName = sdiFileName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.SDIService#rasieSDIIncident(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public boolean rasieSDIIncident(String type, String sdiShortName, String sdiLongDescription) {
        logger.info("Raising sdi Incident ");
        String sdiMessage = getSDIErrorMessage(type, sdiShortName, sdiLongDescription);

        StringBuilder sdiFileContents = new StringBuilder(sdiMessage);
        File dir = new File(sdiFilePath);
        if (dir.exists()) {
            File sdiFile = new File(dir, sdiFileName);
            try (FileOutputStream outStream = new FileOutputStream(sdiFile, true)) {

                outStream.write(sdiFileContents.toString().getBytes());
                logger.info("Batch {} : SDI incident has been raised Successfully !!!", OVERConstants.BATCH_NAME);

            } catch (Exception e) {
                logger.error("Batch {} : Exception while raising SDI incident : {}", OVERConstants.BATCH_NAME, e.getMessage());
                return false;
            }

        } else {
            logger.error("Batch {} : SDI folder path not found {}", OVERConstants.BATCH_NAME, sdiFilePath);
            return false;
        }
        return true;

    }

    /**
     * Gets the SDI error message.
     *
     * @param type the type
     * @param sdiShortName the sdi short name
     * @param sdiLongDescription the sdi long description
     * @return the SDI error message
     */
    public String getSDIErrorMessage(String type, String sdiShortName, String sdiLongDescription) {
        return sdiDateFormatter.format(new Date()) + " " + sysid + " " + reflexName + " " + type + " " + prd + occ + " " + prd
                + String.format("%04d", random.nextInt(CommonConstant.RANDOM_NUMBER_SDI.getConstValueInt())) + " "
                + String.format("%1$-48s", sdiShortName) + " |" + sdiLongDescription + "\n";
    }

}
