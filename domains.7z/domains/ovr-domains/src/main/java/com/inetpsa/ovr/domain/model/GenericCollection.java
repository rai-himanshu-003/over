/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;

/**
 * The Class GenericCollection.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTFLGNCL")
public class GenericCollection extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTFLGNCL_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The flow id. */
    @Column(name = "FLOW_ID")
    private Long flowIdGenCol;

    /** The seq. */
    @Column(name = "SEQ")
    private Long seqGenCol;

    /** The value. */
    @Column(name = "VALUE")
    private Long valueGenCol;

    /** The filter. */
    @Column(name = "FILTER")
    private String filterGenCol;

    /** The int separator. */
    @Column(name = "INT_SEPARATOR")
    private String intSeparatorGenCol;

    /** The separator. */
    @Column(name = "SEPARATOR")
    private String separatorGenCol;

    /** The alignment. */
    @Column(name = "ALIGNMENT")
    private Long alignmentGenCol;

    /** The max occ. */
    @Column(name = "MAX_OCC")
    private Long maxOccGenCol;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the flow id.
     *
     * @return the flow id
     */
    public Long getFlowId() {
        return flowIdGenCol;
    }

    /**
     * Sets the flow id.
     *
     * @param flowId the new flow id
     */
    public void setFlowId(Long flowId) {
        this.flowIdGenCol = flowId;
    }

    /**
     * Gets the seq.
     *
     * @return the seq
     */
    public Long getSeq() {
        return seqGenCol;
    }

    /**
     * Sets the seq.
     *
     * @param seq the new seq
     */
    public void setSeq(Long seq) {
        this.seqGenCol = seq;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return valueGenCol;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.valueGenCol = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filterGenCol;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filterGenCol = filter;
    }

    /**
     * Gets the separator.
     *
     * @return the separator
     */
    public String getSeparator() {
        return separatorGenCol;
    }

    /**
     * Sets the separator.
     *
     * @param separator the new separator
     */
    public void setSeparator(String separator) {
        this.separatorGenCol = separator;
    }

    /**
     * Gets the int separator.
     *
     * @return the int separator
     */
    public String getIntSeparator() {
        return intSeparatorGenCol;
    }

    /**
     * Sets the int separator.
     *
     * @param intSeparator the new int separator
     */
    public void setIntSeparator(String intSeparator) {
        this.intSeparatorGenCol = intSeparator;
    }

    /**
     * Gets the alignment.
     *
     * @return the alignment
     */
    public Long getAlignment() {
        return alignmentGenCol;
    }

    /**
     * Sets the alignment.
     *
     * @param alignment the new alignment
     */
    public void setAlignment(Long alignment) {
        this.alignmentGenCol = alignment;
    }

    /**
     * Gets the max occ.
     *
     * @return the max occ
     */
    public Long getMaxOcc() {
        return maxOccGenCol;
    }

    /**
     * Sets the max occ.
     *
     * @param maxOcc the new max occ
     */
    public void setMaxOcc(Long maxOcc) {
        this.maxOccGenCol = maxOcc;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((alignmentGenCol == null) ? 0 : alignmentGenCol.hashCode());
        result = prime * result + ((filterGenCol == null) ? 0 : filterGenCol.hashCode());
        result = prime * result + ((flowIdGenCol == null) ? 0 : flowIdGenCol.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((intSeparatorGenCol == null) ? 0 : intSeparatorGenCol.hashCode());
        result = prime * result + ((maxOccGenCol == null) ? 0 : maxOccGenCol.hashCode());
        result = prime * result + ((separatorGenCol == null) ? 0 : separatorGenCol.hashCode());
        result = prime * result + ((seqGenCol == null) ? 0 : seqGenCol.hashCode());
        result = prime * result + ((valueGenCol == null) ? 0 : valueGenCol.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        GenericCollection other = (GenericCollection) obj;
        if (alignmentGenCol == null) {
            if (other.alignmentGenCol != null)
                return false;
        } else if (!alignmentGenCol.equals(other.alignmentGenCol))
            return false;
        if (filterGenCol == null) {
            if (other.filterGenCol != null)
                return false;
        } else if (!filterGenCol.equals(other.filterGenCol))
            return false;
        if (flowIdGenCol == null) {
            if (other.flowIdGenCol != null)
                return false;
        } else if (!flowIdGenCol.equals(other.flowIdGenCol))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (intSeparatorGenCol == null) {
            if (other.intSeparatorGenCol != null)
                return false;
        } else if (!intSeparatorGenCol.equals(other.intSeparatorGenCol))
            return false;
        if (maxOccGenCol == null) {
            if (other.maxOccGenCol != null)
                return false;
        } else if (!maxOccGenCol.equals(other.maxOccGenCol))
            return false;
        if (separatorGenCol == null) {
            if (other.separatorGenCol != null)
                return false;
        } else if (!separatorGenCol.equals(other.separatorGenCol))
            return false;
        if (seqGenCol == null) {
            if (other.seqGenCol != null)
                return false;
        } else if (!seqGenCol.equals(other.seqGenCol))
            return false;
        if (valueGenCol == null) {
            if (other.valueGenCol != null)
                return false;
        } else if (!valueGenCol.equals(other.valueGenCol))
            return false;
        return true;
    }

    /**
     * Mapto dto.
     *
     * @return the flow static metadata DTO
     */
    public GenericCollectionDTO maptoDto() {
        GenericCollectionDTO genericCollectionDTO = new GenericCollectionDTO();
        genericCollectionDTO.setFlowId(this.getFlowId());// need to change
        genericCollectionDTO.setId(this.getId());
        genericCollectionDTO.setSeq(this.getSeq());
        genericCollectionDTO.setSeparator(this.getSeparator());
        genericCollectionDTO.setIntSeparator(this.getIntSeparator());
        genericCollectionDTO.setMaxOcc(this.getMaxOcc());
        genericCollectionDTO.setAlignment(this.getAlignment());
        genericCollectionDTO.setValue(this.getValue());
        genericCollectionDTO.setFilter(this.getFilter());
        return genericCollectionDTO;

    }

}
