/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.FlowVhlMetadata;

/**
 * The Interface FlowStaticMetadataRepository.
 */
public interface FlowVhlMetadataRepository extends Repository<FlowVhlMetadata, Long> {
}
