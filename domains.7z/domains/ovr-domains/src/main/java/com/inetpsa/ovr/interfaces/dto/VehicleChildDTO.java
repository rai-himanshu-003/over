/*
 * Creation : 2 Jul 2019
 */
package com.inetpsa.ovr.interfaces.dto;

/**
 * The Class VehicleChildDTO.
 */

public class VehicleChildDTO {

    /** The composants. */

    private boolean composants;

    /** The references electroniques. */

    private boolean referencesElectroniques;

    /** The composants ov. */

    private boolean composantsOv;

    /** The options. */

    private boolean options;

    /** The keys ov. */

    private boolean keysOv;

    /** The lcdv ott ov. */

    private boolean lcdvOttOv;

    /**
     * Checks if is composants.
     *
     * @return true, if is composants
     */
    public boolean isComposants() {
        return composants;
    }

    /**
     * Sets the composants.
     *
     * @param composants the new composants
     */
    public void setComposants(boolean composants) {
        this.composants = composants;
    }

    /**
     * Checks if is references electroniques.
     *
     * @return true, if is references electroniques
     */
    public boolean isReferencesElectroniques() {
        return referencesElectroniques;
    }

    /**
     * Sets the references electroniques.
     *
     * @param referencesElectroniques the new references electroniques
     */
    public void setReferencesElectroniques(boolean referencesElectroniques) {
        this.referencesElectroniques = referencesElectroniques;
    }

    /**
     * Checks if is composants ov.
     *
     * @return true, if is composants ov
     */
    public boolean isComposantsOv() {
        return composantsOv;
    }

    /**
     * Sets the composants ov.
     *
     * @param composantsOv the new composants ov
     */
    public void setComposantsOv(boolean composantsOv) {
        this.composantsOv = composantsOv;
    }

    /**
     * Checks if is options.
     *
     * @return true, if is options
     */
    public boolean isOptions() {
        return options;
    }

    /**
     * Sets the options.
     *
     * @param options the new options
     */
    public void setOptions(boolean options) {
        this.options = options;
    }

    /**
     * Checks if is keys ov.
     *
     * @return true, if is keys ov
     */
    public boolean isKeysOv() {
        return keysOv;
    }

    /**
     * Sets the keys ov.
     *
     * @param keysOv the new keys ov
     */
    public void setKeysOv(boolean keysOv) {
        this.keysOv = keysOv;
    }

    /**
     * Checks if is lcdv ott ov.
     *
     * @return true, if is lcdv ott ov
     */
    public boolean isLcdvOttOv() {
        return lcdvOttOv;
    }

    /**
     * Sets the lcdv ott ov.
     *
     * @param lcdvOttOv the new lcdv ott ov
     */
    public void setLcdvOttOv(boolean lcdvOttOv) {
        this.lcdvOttOv = lcdvOttOv;
    }

}
