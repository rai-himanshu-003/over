/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.util.List;

import org.seedstack.business.Service;
import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.TechnicalParameter;

/**
 * The Interface TechnicalParameterRepository.
 */
@Service
public interface TechnicalParameterRepository extends Repository<TechnicalParameter, String> {

    /**
     * Gets the all tech param.
     *
     * @return the all tech param
     */
    List<TechnicalParameter> getAllTechParam();

}
