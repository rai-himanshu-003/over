/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.ArtLcdvOttRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.VehicleArtLcdvOttService;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

/**
 * The Class VehicleLcdvOttServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleArtLcdvOttServiceImpl implements VehicleArtLcdvOttService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleArtLcdvOttServiceImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The specification builder. */
    @Inject
    private ArtLcdvOttRepository artLcdvOttRepository;

    /** The vehicle repo. */
    @Inject
    private VehicleRepository vehicleRepo;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#getLcdvOttByVin(java.lang.String)
     */
    @Override
    public List<ArtLcdvOtt> getArtLcdvOttByVin(String vin) {

        Specification<ArtLcdvOtt> spec = specificationBuilder.of(ArtLcdvOtt.class).property("vin").equalTo(vin).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        return artLcdvOttRepository.get(spec, opt).collect(Collectors.toList());

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#deleteLcdvOttById(com.inetpsa.ovr.domain.model.LcdvOtt)
     */
    @Override
    public boolean deleteArtLcdvOttById(Long lcdvOtt) {

        Optional<ArtLcdvOtt> tobedeleted = artLcdvOttRepository.get(lcdvOtt);

        if (tobedeleted.isPresent()) {
            artLcdvOttRepository.remove(tobedeleted.get());
            logger.info("LCDV {} : has been deleted successfully!", lcdvOtt);

            Optional<Vehicle> optVehicle = vehicleRepo.get(tobedeleted.get().getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }
            return true;
        }
        logger.info("LCDV {} : is not present in DB", lcdvOtt);

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#addOrUpdateLcdvOtt(com.inetpsa.ovr.domain.model.LcdvOtt)
     */
    @Override
    public ResponseDto addOrUpdateArtLcdvOtt(ArtLcdvOtt artLcdvOtt) {
        ResponseDto responseDto = new ResponseDto();
        boolean flag = false;
        try {

            if (artLcdvOtt.getId() != null) {
                responseDto.setId(artLcdvOtt.getId().toString());
                artLcdvOttRepository.update(artLcdvOtt);
                flag = true;
            } else {

                List<BigDecimal> seqNumber = getSequenceCount(OVERConstants.MAGICNUMBER1);
                if (seqNumber != null) {
                    artLcdvOtt.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).longValue());
                    responseDto.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).toString());
                    artLcdvOttRepository.add(artLcdvOtt);
                    flag = true;
                } else {
                    logger.error("Sequence Number is {} Empty from DB : {}", seqNumber, artLcdvOtt);

                }
            }

            Optional<Vehicle> optVehicle = vehicleRepo.get(artLcdvOtt.getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }
            responseDto.setMsg(flag);
            return responseDto;
        } catch (Exception e) {
            logger.error("Error while adding/updating LCDV {} : {}", artLcdvOtt, e.getMessage());
            responseDto.setMsg(flag);
            return responseDto;
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#getSequenceCount(int)
     */
    @Override
    public List<BigDecimal> getSequenceCount(int numberOfSeq) {
        return artLcdvOttRepository.getSequenceCount(numberOfSeq);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleArtLcdvOttService#checkLcdvExist(java.lang.String, java.lang.String)
     */
    @Override
    public boolean checkLcdvExist(String vin, String lcdv) {
        String family = lcdv.substring(0, 2);
        String code = lcdv.substring(2, 3);
        String value = lcdv.substring(3, 5);
        Specification<ArtLcdvOtt> spec = specificationBuilder.of(ArtLcdvOtt.class).property("vin").equalTo(vin).and().property("family")
                .equalTo(family).and().property("code").equalTo(code).and().property("value").equalTo(value).build();

        return artLcdvOttRepository.contains(spec);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleArtLcdvOttService#getLcdvExist(java.lang.String, java.lang.String)
     */
    @Override
    public Map<Long, ArtLcdvOtt> getLcdvExist(String vin, String lcdv) {
        String family = lcdv.substring(0, 2);
        String code = lcdv.substring(2, 3);
        String value = lcdv.substring(3, 5);
        Specification<ArtLcdvOtt> spec = specificationBuilder.of(ArtLcdvOtt.class).property("vin").equalTo(vin).and().property("family")
                .equalTo(family).and().property("code").equalTo(code).and().property("value").equalTo(value).build();

        List<ArtLcdvOtt> artList = artLcdvOttRepository.get(spec).collect(Collectors.toList());
        Map<Long, ArtLcdvOtt> artMap = new HashMap<>();
        for (ArtLcdvOtt artlcdv : artList) {
            artMap.put(artlcdv.getId(), artlcdv);
        }

        return artMap;
    }

}
