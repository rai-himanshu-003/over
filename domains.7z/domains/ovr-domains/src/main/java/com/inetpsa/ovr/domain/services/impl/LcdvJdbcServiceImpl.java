/*
 * Creation : 20 Feb 2020
 */
package com.inetpsa.ovr.domain.services.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import org.seedstack.jdbc.Jdbc;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.FormatManagementConstant;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.LcdvJdbcService;
import com.inetpsa.ovr.interfaces.dto.ArtLcdvOttDTO;
import com.inetpsa.ovr.interfaces.dto.ComposantsDTO;
import com.inetpsa.ovr.interfaces.dto.ComposantsOvDTO;
import com.inetpsa.ovr.interfaces.dto.KeysOvDTO;
import com.inetpsa.ovr.interfaces.dto.LcdvOttDTO;
import com.inetpsa.ovr.interfaces.dto.OptionsDTO;
import com.inetpsa.ovr.interfaces.dto.ReferencesElectroniquesDTO;

public class LcdvJdbcServiceImpl implements LcdvJdbcService {

    /** The connection. */
    @Inject
    private Connection connection;
    @Inject
    private VehicleRepository vehicleRepository;

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(LcdvJdbcServiceImpl.class);

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.LcdvJdbcService#getLcdvList(java.util.List, java.util.List)
     */
    @Override
    @Transactional(readOnly = true)
    @Jdbc("ovr-jpa-unit-ds")
    public List<ArtLcdvOttDTO> getLcdvList(List<String> artLcdv, List<String> vinList) {

        logger.info("Entering getLcdvList");

        StringBuilder concat = new StringBuilder("select FAMILY, CODE, VALUE, VIN from OVRQTVARTLCDV where ( ");
        for (String vin : vinList) {
            concat = concat.append("vin = '" + vin + "' OR ");
        }
        String vinQuery = concat.substring(0, concat.length() - FormatManagementConstant.LENGTH3.getConstValueInteger());
        StringBuilder vinQueryAll = new StringBuilder(vinQuery);
        vinQueryAll = vinQueryAll.append(")");
        String selectedQuery = vinQueryAll.toString();

        if (!artLcdv.contains("%")) {

            StringBuilder fullQuery = new StringBuilder(vinQuery);

            fullQuery = fullQuery.append(") and (");

            for (String lcdv : artLcdv) {
                if (lcdv.contains("%")) {
                    fullQuery = fullQuery.append(" FAMILY || CODE || VALUE like '" + lcdv + "' OR");
                } else {
                    fullQuery = fullQuery.append(" FAMILY || CODE || VALUE = '" + lcdv + "' OR");
                }
            }
            String rpoQuery = fullQuery.substring(0, fullQuery.length() - FormatManagementConstant.LENGTH3.getConstValueInteger());
            StringBuilder finalQuery = new StringBuilder(rpoQuery);
            finalQuery = finalQuery.append(" ) and");
            selectedQuery = finalQuery.toString().substring(0, finalQuery.length() - FormatManagementConstant.LENGTH4.getConstValueInteger());
        }
        logger.info("lcdv Query {}", selectedQuery);
        try (PreparedStatement statement = connection.prepareStatement(selectedQuery)) {

            logger.info("before execution query ");
            ResultSet rs = statement.executeQuery();
            logger.info("After execution query ");
            List<ArtLcdvOttDTO> ottDTOs = new LinkedList<>();

            while (rs.next()) {
                ArtLcdvOttDTO lcdvOttDTO = new ArtLcdvOttDTO();
                lcdvOttDTO.setFamilyArtLcdvDto(rs.getString("FAMILY"));
                lcdvOttDTO.setValueArtLcdvDto(rs.getString("VALUE"));
                lcdvOttDTO.setCodeArtLcdvDto(rs.getString("CODE"));
                lcdvOttDTO.setVinArtLcdvDto(rs.getString("VIN"));
                ottDTOs.add(lcdvOttDTO);

            }
            logger.info("After preparing resultset ");

            return ottDTOs;

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.LcdvJdbcService#getRpoList(java.util.List, java.util.List)
     */
    @Override
    @Transactional(readOnly = true)
    @Jdbc("ovr-jpa-unit-ds")
    public List<OptionsDTO> getRpoList(List<String> rpoCodes, List<String> vinList) {
        logger.info("Entering getRpoList");

        StringBuilder concat = new StringBuilder("select RPO, VIN from OVRQTVRPO where ( ");
        for (String vin : vinList) {

            concat = concat.append("vin = '" + vin + "' OR ");

        }
        String vinQuery = concat.substring(0, concat.length() - FormatManagementConstant.LENGTH3.getConstValueInteger());
        StringBuilder vinQueryAll = new StringBuilder(vinQuery);
        vinQueryAll = vinQueryAll.append(")");
        String selectedQuery = vinQueryAll.toString();

        if (!rpoCodes.contains("%")) {

            StringBuilder fullQuery = new StringBuilder(vinQuery);

            fullQuery = fullQuery.append(") and (");

            for (String rpo : rpoCodes) {
                if (rpo.contains("%")) {
                    fullQuery = fullQuery.append(" RPO like '" + rpo + "' OR");
                } else {
                    fullQuery = fullQuery.append(" RPO = '" + rpo + "' OR");
                }
            }
            String rpoQuery = fullQuery.substring(0, fullQuery.length() - FormatManagementConstant.LENGTH3.getConstValueInteger());
            StringBuilder finalQuery = new StringBuilder(rpoQuery);
            finalQuery = finalQuery.append(" ) and");
            selectedQuery = finalQuery.toString().substring(0, finalQuery.length() - FormatManagementConstant.LENGTH4.getConstValueInteger());
        }
        logger.info("rpo Query {}", selectedQuery);
        try (PreparedStatement statement = connection.prepareStatement(selectedQuery)) {

            logger.info("before rpo query execution");
            ResultSet rs = statement.executeQuery();
            logger.info("After rpo query execution ");
            List<OptionsDTO> rpoDTOs = new LinkedList<>();

            while (rs.next()) {
                OptionsDTO optDto = new OptionsDTO();
                optDto.setRpoData(rs.getString("RPO"));
                optDto.setVin(rs.getString("VIN"));
                rpoDTOs.add(optDto);

            }
            logger.info("After preparing rpo resultset ");

            return rpoDTOs;

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    @Override
    @Transactional(readOnly = true)
    @Jdbc("ovr-jpa-unit-ds")
    public List<ComposantsOvDTO> getComposantsFrWs(List<PsaKeyMapping> psaKeyMappings, List<String> vinList) {

        StringBuilder concat = new StringBuilder("select STANDARD,E_ID,DATA,LABEL,VIN from OVRQTVCOMOV where ( ");
        for (String vin : vinList) {

            concat = concat.append("vin = '" + vin + "' OR ");
        }

        String compQuery = concat.substring(0, concat.length() - FormatManagementConstant.LENGTH3.getConstValueInteger());
        StringBuilder vinQuery = new StringBuilder(compQuery);
        vinQuery = vinQuery.append(") and (");

        for (PsaKeyMapping keyMapping : psaKeyMappings) {

            vinQuery = vinQuery.append(" ( STANDARD = '" + keyMapping.getOvStandard() + "' AND E_ID = '" + keyMapping.getOvKey() + "' ) OR ");
        }
        String psaQuery = vinQuery.substring(0, vinQuery.length() - FormatManagementConstant.LENGTH3.getConstValueInteger());
        StringBuilder finalQuery = new StringBuilder(psaQuery);
        finalQuery = finalQuery.append(" )");
        String selectedQuery = finalQuery.toString();

        logger.info("psa comp Query {}", selectedQuery);
        try (PreparedStatement statement = connection.prepareStatement(selectedQuery)) {

            logger.info("before psa query execution");
            ResultSet rs = statement.executeQuery();
            logger.info("After psa query execution ");
            List<ComposantsOvDTO> composantsOvDTOs = new LinkedList<>();

            while (rs.next()) {
                ComposantsOvDTO ovDTO = new ComposantsOvDTO();
                ovDTO.setStandard(rs.getString("STANDARD"));
                ovDTO.setData(rs.getString("DATA"));
                ovDTO.setLabel(rs.getString("LABEL"));
                ovDTO.setEid(rs.getString("E_ID"));
                ovDTO.setVin(rs.getString("VIN"));
                composantsOvDTOs.add(ovDTO);

            }
            logger.info("After preparing psa comp ov resultset ");

            return composantsOvDTOs;

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    @Override
    @Transactional(readOnly = true)
    @Jdbc("ovr-jpa-unit-ds")
    public List<LcdvOttDTO> getLCDVForCorvet(List<String> vinList) {
        logger.info(" Fetching LCDVs For corvet");
        StringBuilder finalQuery = null;
        String query = "(SELECT * FROM OVRQTVLCDV WHERE ";
        finalQuery = vehicleRepository.formInClause(vinList, " vin in (");

        System.out.println("query--------" + query.concat(finalQuery.toString()));
        try (PreparedStatement statement = connection.prepareStatement(query.concat(finalQuery.toString()))) {

            ResultSet rs = statement.executeQuery();

            List<LcdvOttDTO> lcdvOttDTOs = new LinkedList<>();

            while (rs.next()) {
                LcdvOttDTO lcdvOttDTO = new LcdvOttDTO();
                lcdvOttDTO.setCharacteristic(rs.getString("CHARACTERISTIC"));
                lcdvOttDTO.setIndicator(rs.getString("INDICATOR"));
                lcdvOttDTO.setValue(rs.getString("VALUE"));
                lcdvOttDTO.setVin(rs.getString("VIN"));
                lcdvOttDTO.setNature(rs.getString("NATURE"));
                lcdvOttDTOs.add(lcdvOttDTO);

            }
            logger.info("Fetching LCDv Completed ");

            return lcdvOttDTOs;

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
            return Collections.emptyList();
        }

    }

    @Override
    @Transactional(readOnly = true)
    @Jdbc("ovr-jpa-unit-ds")
    public List<ReferencesElectroniquesDTO> getRefElectForCorvet(List<String> vinList) {
        logger.info(" Fetching Re electrinics For corvet started");
        StringBuilder finalQuery = null;
        String query = "(SELECT DATA,VIN FROM OVRQTVRFEE WHERE";
        finalQuery = vehicleRepository.formInClause(vinList, " vin in (");
        try (PreparedStatement statement = connection.prepareStatement(query.concat(finalQuery.toString()))) {

            ResultSet rs = statement.executeQuery();

            List<ReferencesElectroniquesDTO> referencesElectroniquesDTOs = new LinkedList<>();

            while (rs.next()) {
                ReferencesElectroniquesDTO referencesElectroniquesDTO = new ReferencesElectroniquesDTO();
                referencesElectroniquesDTO.setData(rs.getString("DATA"));
                referencesElectroniquesDTO.setVin(rs.getString("VIN"));
                referencesElectroniquesDTOs.add(referencesElectroniquesDTO);

            }
            logger.info("Fetching Ref Electronics Completed ");

            return referencesElectroniquesDTOs;

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
            return Collections.emptyList();
        }

    }

    @Override
    @Transactional(readOnly = true)
    @Jdbc("ovr-jpa-unit-ds")
    public List<KeysOvDTO> getKeysOVForCorvet(List<String> vinList) {
        logger.info(" Fetching Keys OV For corvet started");
        String query = "(SELECT E_ID,DATA ,VIN FROM OVRQTVKEYOV WHERE ";

        StringBuilder finalQuery = vehicleRepository.formInClause(vinList, " vin in (");
        try (PreparedStatement statement = connection.prepareStatement(query.concat(finalQuery.toString()))) {

            ResultSet rs = statement.executeQuery();

            List<KeysOvDTO> keysOvDTOs = new LinkedList<>();

            while (rs.next()) {
                KeysOvDTO keysOvDTO = new KeysOvDTO();
                keysOvDTO.setData(rs.getString("DATA"));
                keysOvDTO.setVin(rs.getString("VIN"));
                keysOvDTO.setEid(rs.getString("E_ID"));
                keysOvDTOs.add(keysOvDTO);

            }
            logger.info("Fetching Keys OV Completed ");

            return keysOvDTOs;

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
            return Collections.emptyList();
        }

    }

    @Override
    @Transactional(readOnly = true)
    @Jdbc("ovr-jpa-unit-ds")
    public List<ComposantsDTO> getCompoSantsForCorvet(List<String> vinList) {
        logger.info(" Fetching Composants For corvet started");
        StringBuilder finalQuery = null;
        String query = "(SELECT DATA ,VIN FROM OVRQTVCOM WHERE ";

        finalQuery = vehicleRepository.formInClause(vinList, " vin in (");
        try (PreparedStatement statement = connection.prepareStatement(query.concat(finalQuery.toString()))) {

            ResultSet rs = statement.executeQuery();

            List<ComposantsDTO> composantsDTOs = new LinkedList<>();

            while (rs.next()) {
                ComposantsDTO composantsDTO = new ComposantsDTO();
                composantsDTO.setData(rs.getString("DATA"));
                composantsDTO.setVin(rs.getString("VIN"));
                composantsDTOs.add(composantsDTO);

            }
            logger.info("Fetching Composants Completed ");

            return composantsDTOs;

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
            return Collections.emptyList();
        }

    }

}
