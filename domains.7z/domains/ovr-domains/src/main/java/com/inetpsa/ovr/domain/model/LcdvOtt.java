/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.LcdvOttDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class ComposantsOv.
 */
@Entity
@Table(name = "OVRQTVLCDV")
@DynamicUpdate(value = true)
public class LcdvOtt extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    private Long id;

    /** The data. */
    @Column(name = "CHARACTERISTIC")
    private String characteristic;

    /** The vin. */
    @Column(name = "VIN")
    private String vin;

    /** The eid. */
    @Column(name = "INDICATOR")
    private String indicator;

    /** The label. */
    /**
     * 
     */
    @Column(name = "NATURE")
    private String nature;

    /** The standard. */
    @Column(name = "VALUE")
    private String value;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the characteristic.
     *
     * @return the characteristic
     */
    public String getCharacteristic() {
        return characteristic;
    }

    /**
     * Sets the characteristic.
     *
     * @param characteristic the new characteristic
     */
    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the indicator.
     *
     * @return the indicator
     */
    public String getIndicator() {
        return indicator;
    }

    /**
     * Sets the indicator.
     *
     * @param indicator the new indicator
     */
    public void setIndicator(String indicator) {
        this.indicator = indicator;
    }

    /**
     * Gets the nature.
     *
     * @return the nature
     */
    public String getNature() {
        return nature;
    }

    /**
     * Sets the nature.
     *
     * @param nature the new nature
     */
    public void setNature(String nature) {
        this.nature = nature;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((characteristic == null) ? 0 : characteristic.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((indicator == null) ? 0 : indicator.hashCode());
        result = prime * result + ((nature == null) ? 0 : nature.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        result = prime * result + ((vin == null) ? 0 : vin.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        LcdvOtt other = (LcdvOtt) obj;
        if (characteristic == null) {
            if (other.characteristic != null)
                return false;
        } else if (!characteristic.equals(other.characteristic))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (indicator == null) {
            if (other.indicator != null)
                return false;
        } else if (!indicator.equals(other.indicator))
            return false;
        if (nature == null) {
            if (other.nature != null)
                return false;
        } else if (!nature.equals(other.nature))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        } else if (!value.equals(other.value))
            return false;
        if (vin == null) {
            if (other.vin != null)
                return false;
        } else if (!vin.equals(other.vin))
            return false;
        return true;
    }

    /**
     * Mapto dto.
     *
     * @return the lcdv ott DTO
     */
    public LcdvOttDTO maptoDto() {

        LcdvOttDTO lcdvOttDTO = new LcdvOttDTO();
        lcdvOttDTO.setId(this.getId());
        lcdvOttDTO.setCharacteristic(this.getCharacteristic());
        lcdvOttDTO.setIndicator(this.getIndicator());
        lcdvOttDTO.setNature(this.getNature());
        lcdvOttDTO.setValue(this.getValue());
        lcdvOttDTO.setVin(this.getVin());

        return lcdvOttDTO;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "LcdvOtt [id=" + id + ", characteristic=" + characteristic + ", vin=" + vin + ", indicator=" + indicator + ", nature=" + nature
                + ", value=" + value + "]";
    }

}
