/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.io.File;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.cache.annotation.CacheResult;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.MMVehicleHistory;
import com.inetpsa.ovr.domain.model.TrackChanges;
import com.inetpsa.ovr.domain.repository.MMVehicleHistoryRepository;
import com.inetpsa.ovr.domain.repository.TrackChangesRepository;
import com.inetpsa.ovr.domain.services.MassMovementService;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.TrackChangesDto;

/**
 * The Class VehicleKeysOvServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class MassMovementServiceImpl implements MassMovementService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(MassMovementServiceImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The vehicle keys ov repository. */
    @Inject
    private TrackChangesRepository trackChangesRepository;

    @Inject
    private MMVehicleHistoryRepository historyRepository;

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    @Override
    @CacheResult(cacheName = "vehicleMetadata")
    public Map<String, Integer> findMaxSize(String tableName) {
        try {
            logger.info("Entering findMaxSize. Creating Cache");
            Query hql = entityManager.createNativeQuery("select column_name, char_length from dba_tab_columns where table_name = :tableName");
            hql.setParameter("tableName", tableName);
            List list = hql.getResultList();

            return generateResponse(list);
        } catch (Exception e) {
            logger.error("Exception findMaxSize {}", e);
            return Collections.emptyMap();
        }
    }

    @Override
    public Long addTrackChanges(String status) {
        try {
            TrackChanges trackChanges = new TrackChanges();
            trackChanges.setStatus(status);
            trackChanges.setStartDate(new Date());

            trackChanges.setDateCreation(new Date());
            trackChanges.setId(trackChangesRepository.generateSequence());
            trackChangesRepository.add(trackChanges);
            return trackChanges.getId();
        } catch (Exception e) {
            logger.error("Error {}", e);
            return 0l;
        }

    }

    @Override
    public void updateTrackChanges(TrackChanges trackChanges) {
        try {
            logger.info("Entering update Track changes");
            trackChangesRepository.addOrUpdate(trackChanges);
            logger.info("Exiting update Track changes");
        } catch (Exception e) {
            logger.error("Error {}", e);

        }

    }

    @Override
    public void addMMHistory(MMVehicleHistory mmVehicleHistory) {
        try {

            historyRepository.add(mmVehicleHistory);

        } catch (Exception e) {
            logger.error("Error {}", e);

        }

    }

    @Override
    public Optional<TrackChanges> getById(Long id) {
        try {

            return trackChangesRepository.get(id);

        } catch (Exception e) {
            logger.error("Error {}", e);
            return Optional.empty();

        }
    }

    @Override
    public List<TrackChangesDto> getAllTrackChanges() {
        try {
            Specification<TrackChanges> spec = specificationBuilder.of(TrackChanges.class).property("id").not().equalTo(null).build();
            SortOption opt = new SortOption();
            opt.add("dateCreation", Direction.DESCENDING);
            return convertToDto(trackChangesRepository.get(spec, opt).collect(Collectors.toList()));

        } catch (Exception e) {
            logger.error("Error {}", e);
            return null;

        }
    }

    private List<TrackChangesDto> convertToDto(List<TrackChanges> trackList) {
        List<TrackChangesDto> list = new ArrayList<>();
        try {

            for (TrackChanges trackChanges : trackList)
                list.add(this.getTrackDto(trackChanges));
        } catch (Exception e) {
            logger.error("Exception in fetching Audit Data {}", e);
        }
        return list;
    }

    private TrackChangesDto getTrackDto(TrackChanges trackChanges) {
        TimeUnit timeUnit = TimeUnit.SECONDS;
        TrackChangesDto trackChangesDto = new TrackChangesDto();
        trackChangesDto.setDateCreation(trackChanges.getDateCreation());
        trackChangesDto.setEndDate(trackChanges.getEndDate());
        trackChangesDto.setErrorCount(trackChanges.getErrorCount());
        trackChangesDto.setFileName(trackChanges.getFileName());
        trackChangesDto.setStartDate(trackChanges.getStartDate());
        trackChangesDto.setStatus(trackChanges.getStatus());
        trackChangesDto.setSuccessCount(trackChanges.getSuccessCount());
        trackChangesDto.setTotalCount(trackChanges.getTotalCount());
        trackChangesDto.setUserCreation(trackChanges.getUserCreation());
        trackChangesDto.setId(trackChanges.getId());
        if (trackChanges.getEndDate() != null && trackChanges.getStartDate() != null) {
            long diffInMillies = trackChanges.getEndDate().getTime() - trackChanges.getStartDate().getTime();
            Long seconds = timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);

            LocalTime lt = LocalTime.MIN.plusSeconds(seconds);
            DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm:ss");
            String output = lt.format(f);
            trackChangesDto.setDuration(output);
            logger.info("Duration {}", trackChangesDto.getDuration());
        }
        return trackChangesDto;
    }

    private Map<String, Integer> generateResponse(List arrayList) {
        Iterator itr = arrayList.iterator();
        Map<String, Integer> map = new HashMap<>();
        while (itr.hasNext()) {
            Object[] obj = (Object[]) (itr.next());
            map.put(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER0]).orElse("").toString(),
                    Integer.parseInt(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER1]).orElse("").toString()));

        }
        return map;

    }

    @Override
    public Boolean purgeMMTCData(String folder, Integer purgedatadurationindays) {
        LocalDateTime date = LocalDateTime.now().minusDays(purgedatadurationindays);
        Date ltdToDate = Date.from(date.atZone(ZoneId.systemDefault()).toInstant());

        try {
            Specification<TrackChanges> spec = specificationBuilder.of(TrackChanges.class).property("endDate").lessThan(ltdToDate).build();

            List<TrackChanges> data = trackChangesRepository.get(spec).collect(Collectors.toList());

            for (TrackChanges record : data) {

                if (record.getFileName() != null && !record.getFileName().isEmpty()) {

                    File file = new File(folder, record.getFileName());

                    if (file.exists()) {
                        file.delete();
                        trackChangesRepository.remove(record);
                        logger.info("Record has been deleted successfully : {} : {} ", file.getPath(), record.toString());
                    } else
                        logger.error("File is not available for delete : {} ", file.getPath());
                }

            }

            logger.info("Number of records purged : {} ", data.size());
            return true;

        } catch (Exception e) {
            logger.error("Error while purging records for {} days from {} folder", folder, purgedatadurationindays);
            return false;
        }

    }
}