/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 * The Class CardinalityPk.
 * 
 * @author E566559
 */
@Embeddable
public class CardinalityPk implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The psa data type. */
    @Column(name = "PSA_DATA_TYPE")
    @NotNull
    private String psaDataType;

    /** The psa key. */
    @Column(name = "PSA_KEY")
    @NotNull
    private String psaKey;

    /**
     * Gets the psa data type.
     *
     * @return the psa data type
     */
    public String getPsaDataType() {
        return psaDataType;
    }

    /**
     * Sets the psa data type.
     *
     * @param psaDataType the new psa data type
     */
    public void setPsaDataType(String psaDataType) {
        this.psaDataType = psaDataType;
    }

    /**
     * Gets the psa key.
     *
     * @return the psa key
     */
    public String getPsaKey() {
        return psaKey;
    }

    /**
     * Sets the psa key.
     *
     * @param psaKey the new psa key
     */
    public void setPsaKey(String psaKey) {
        this.psaKey = psaKey;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CardinalityPk [psaDataType=" + psaDataType + ", psaKey=" + psaKey + "]";
    }

}
