package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;

import com.inetpsa.ovr.domain.model.FlowVhlMetadata;

/**
 * The Class FlowVhlMetadataDTO.
 */
public class FlowVhlMetadataDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The id. */
    private Long id;

    /** The flow id. */
    private Long flowId;

    /** The seq. */
    private Long seq;

    /** The value. */
    private Long value;

    /** The filter. */
    private String filter;

    /** The separator. */
    private String separator;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the flow id.
     *
     * @return the flow id
     */
    public Long getFlowId() {
        return flowId;
    }

    /**
     * Sets the flow id.
     *
     * @param flowId the new flow id
     */
    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    /**
     * Gets the seq.
     *
     * @return the seq
     */
    public Long getSeq() {
        return seq;
    }

    /**
     * Sets the seq.
     *
     * @param seq the new seq
     */
    public void setSeq(Long seq) {
        this.seq = seq;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * Gets the separator.
     *
     * @return the separator
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * Sets the separator.
     *
     * @param separator the new separator
     */
    public void setSeparator(String separator) {
        this.separator = separator;
    }

    /**
     * Map tomodel.
     *
     * @return the output flow details
     */
    public FlowVhlMetadata mapTomodel() {
        FlowVhlMetadata flowVhlMetadata = new FlowVhlMetadata();
        flowVhlMetadata.setFlowId(this.getFlowId());
        flowVhlMetadata.setSeq(this.getSeq());
        flowVhlMetadata.setSeparator(this.getSeparator());
        flowVhlMetadata.setValue(this.getValue());

        flowVhlMetadata.setFilter(this.getFilter());
        return flowVhlMetadata;
    }

}
