/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;

/**
 * The Interface VehicleReferencesElectroniquesService.
 */
@Service
public interface FlowManagementDetailsService {

    /**
     * Gets the vehicle references electroniques by vin.
     *
     * @return the vehicle references electroniques by vin
     */
    List<OutputFlowDetails> getflowDetails();

    /**
     * Delete references electroniques by id.
     *
     * @param id the id
     * @return true, if successful
     */
    boolean deleteflowDetails(Long id);

    /**
     * Adds the or update references electroniques.
     *
     * @param outputFlowDetailsDTO the output flow details DTO
     * @return true, if successful
     */
    boolean addOrUpdateflowDetails(OutputFlowDetailsDTO outputFlowDetailsDTO);

    /**
     * Gets the flow details by name.
     *
     * @param flowName the flow name
     * @return the flow details by name
     */
    OutputFlowDetails getFlowDetailsByName(String flowName);

    /**
     * Removeflow details.
     *
     * @param id the id
     * @return true, if successful
     */
    boolean removeflowDetails(Long id);

}
