/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.MultipleFlowStatus;

/**
 * The Class MultipleFlowStatusDTO.
 */
public class MultipleFlowStatusDTO {

    /** The id. */
    private Long idMultiStateDto;

    /** The flow. */
    private String flowMultiStateDto;

    /** The vin. */
    private String vinMultiStateDto;

    /** The status. */
    private String statusMultiStateDto;

    /** The version. */
    private Integer versionMultiStateDto;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return idMultiStateDto;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idMultiStateDto = id;
    }

    /**
     * Gets the flow.
     *
     * @return the flow
     */
    public String getFlow() {
        return flowMultiStateDto;
    }

    /**
     * Sets the flow.
     *
     * @param flow the new flow
     */
    public void setFlow(String flow) {
        this.flowMultiStateDto = flow;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vinMultiStateDto;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vinMultiStateDto = vin;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return statusMultiStateDto;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.statusMultiStateDto = status;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return versionMultiStateDto;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.versionMultiStateDto = version;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "MultipleFlowStatus [id=" + idMultiStateDto + ", flow=" + flowMultiStateDto + ", vin=" + vinMultiStateDto + ", status=" + statusMultiStateDto + ", getId()=" + getId() + ", getFlow()="
                + getFlow() + ", getVin()=" + getVin() + ", getStatus()=" + getStatus() + ", hashCode()=" + hashCode() + ", toString()="
                + super.toString() + ", getClass()=" + getClass() + "]";
    }

    /**
     * Map to model.
     *
     * @return the multiple flow status
     */
    public MultipleFlowStatus mapToModel() {

        MultipleFlowStatus multipleFlowStatus = new MultipleFlowStatus();
        multipleFlowStatus.setFlow(this.getFlow());
        multipleFlowStatus.setId(this.getId());
        multipleFlowStatus.setStatus(this.getStatus());
        multipleFlowStatus.setVin(this.getVin());
        return multipleFlowStatus;
    }

}
