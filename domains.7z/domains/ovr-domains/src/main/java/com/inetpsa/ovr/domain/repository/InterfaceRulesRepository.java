/*
 * Creation : 1 Jul 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.interfaces.dto.CorvetRulesDto;

/**
 * The Interface InterfaceRulesRepository.
 */
public interface InterfaceRulesRepository extends Repository<InterfaceRule, Long> {

    /**
     * Gets the interface rules.
     *
     * @param id the id
     * @return the interface rules
     */
    List<InterfaceRule> getInterfaceRules(Long id);

    /**
     * Find by int name and priority.
     *
     * @param id the id
     * @param priority the priority
     * @return the interface rule
     */
    InterfaceRule findByIntNameAndPriority(Long id, int priority);

    /**
     * Gets the all interface rules.
     *
     * @return the all interface rules
     */
    List<CorvetRulesDto> getAllInterfaceRules();

}
