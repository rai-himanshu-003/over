/*
 * Creation : 16 Jan 2020
 */
package com.inetpsa.ovr.domain.repository.impl;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.ovr.domain.model.Cardinality;
import com.inetpsa.ovr.domain.model.CardinalityPk;
import com.inetpsa.ovr.domain.repository.CardinalityRepository;

/**
 * The Class CardinalityRepositoryImpl.
 */
public class CardinalityRepositoryImpl extends BaseJpaRepository<Cardinality, CardinalityPk> implements CardinalityRepository {

}
