/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.Optional;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.UserInfo;
import com.inetpsa.ovr.domain.repository.UserInfoRepository;
import com.inetpsa.ovr.domain.services.UserInfoService;
import com.inetpsa.ovr.interfaces.dto.UserInformationDTO;

/**
 * The class UserInfoServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class UserInfoServiceImpl implements UserInfoService {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(UserInfoServiceImpl.class);

    /** The user info repository. */
    @Inject
    private UserInfoRepository userInfoRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.UserInfoService#getUserDataByType(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public UserInfo getUserDataByType(String userId, String type, String lang) {
        Specification<UserInfo> spec = specificationBuilder.of(UserInfo.class).property("userId").equalTo(userId).and().property("type").equalTo(type)
                .build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        Optional<UserInfo> userinfo = userInfoRepository.get(spec, opt).findFirst();
        if (userinfo.isPresent())
            return userinfo.get();
        else
            return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.UserInfoService#updateUserInfo(com.inetpsa.ovr.interfaces.dto.UserInformationDTO)
     */
    @Override
    public boolean updateUserInfo(UserInformationDTO userInformationDTO) {
        try {
            if (userInformationDTO.getId() != null) {
                Optional<UserInfo> userInfo = userInfoRepository.get(userInformationDTO.getId());
                UserInfo userInfoObj = userInformationDTO.mapTomodel(userInfo.get());
                userInfoRepository.update(userInfoObj);
            } else {
                UserInfo userInfo = userInformationDTO.mapTomodel(new UserInfo());
                userInfoRepository.add(userInfo);
            }
            return true;
        } catch (Exception e) {
            return false;
        }

    }

}
