/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.FlowStaticMetadata;

/**
 * The Interface FlowStaticMetadataRepository.
 */
public interface FlowStaticMetadataRepository extends Repository<FlowStaticMetadata, Long> {
}
