/*
 * Creation : 22 Sep 2020
 */
package com.inetpsa.ovr.interfaces.dto.ws;

// TODO: Auto-generated Javadoc
/**
 * The Class VehicleWsDto.
 */
public class VehicleWsDto {

    /** The vin number. */
    private String vinNumber;

    /** The state. */
    private String state;

    /** The prod center. */
    private String prodCenter;

    /** The vehicle. */
    private String vehicle;

    /** The xml data. */
    private String xmlData;

    /** The lcdv ott data. */
    private String lcdvOttData;

    /** The oa data. */
    private String oaData;

    /** The nre data. */
    private String nreData;

    /** The tvv data. */
    private String tvvData;

    /** The model data. */
    private String modelData;

    /** The apvpr data. */
    private String apvprData;

    /**
     * Gets the vin number.
     *
     * @return the vin number
     */
    public String getVinNumber() {
        return vinNumber;
    }

    /**
     * Sets the vin number.
     *
     * @param vinNumber the new vin number
     */
    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the state.
     *
     * @param state the new state
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Gets the prod center.
     *
     * @return the prod center
     */
    public String getProdCenter() {
        return prodCenter;
    }

    /**
     * Sets the prod center.
     *
     * @param prodCenter the new prod center
     */
    public void setProdCenter(String prodCenter) {
        this.prodCenter = prodCenter;
    }

    /**
     * Gets the vehicle.
     *
     * @return the vehicle
     */
    public String getVehicle() {
        return vehicle;
    }

    /**
     * Sets the vehicle.
     *
     * @param vehicle the new vehicle
     */
    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    /**
     * Gets the xml data.
     *
     * @return the xml data
     */
    public String getXmlData() {
        return xmlData;
    }

    /**
     * Sets the xml data.
     *
     * @param xmlData the new xml data
     */
    public void setXmlData(String xmlData) {
        this.xmlData = xmlData;
    }

    /**
     * Gets the lcdv ott data.
     *
     * @return the lcdv ott data
     */
    public String getLcdvOttData() {
        return lcdvOttData;
    }

    /**
     * Sets the lcdv ott data.
     *
     * @param lcdvOttData the new lcdv ott data
     */
    public void setLcdvOttData(String lcdvOttData) {
        this.lcdvOttData = lcdvOttData;
    }

    /**
     * Gets the oa data.
     *
     * @return the oa data
     */
    public String getOaData() {
        return oaData;
    }

    /**
     * Sets the oa data.
     *
     * @param oaData the new oa data
     */
    public void setOaData(String oaData) {
        this.oaData = oaData;
    }

    /**
     * Gets the nre data.
     *
     * @return the nre data
     */
    public String getNreData() {
        return nreData;
    }

    /**
     * Sets the nre data.
     *
     * @param nreData the new nre data
     */
    public void setNreData(String nreData) {
        this.nreData = nreData;
    }

    /**
     * Gets the tvv data.
     *
     * @return the tvv data
     */
    public String getTvvData() {
        return tvvData;
    }

    /**
     * Sets the tvv data.
     *
     * @param tvvData the new tvv data
     */
    public void setTvvData(String tvvData) {
        this.tvvData = tvvData;
    }

    /**
     * Gets the model data.
     *
     * @return the model data
     */
    public String getModelData() {
        return modelData;
    }

    /**
     * Sets the model data.
     *
     * @param modelData the new model data
     */
    public void setModelData(String modelData) {
        this.modelData = modelData;
    }

    /**
     * Gets the apvpr data.
     *
     * @return the apvpr data
     */
    public String getApvprData() {
        return apvprData;
    }

    /**
     * Sets the apvpr data.
     *
     * @param apvprData the new apvpr data
     */
    public void setApvprData(String apvprData) {
        this.apvprData = apvprData;
    }

}
