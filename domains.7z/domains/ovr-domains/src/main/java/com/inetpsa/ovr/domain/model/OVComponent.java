/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;

/**
 * The Class OVComponent.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTFLOVCM")
public class OVComponent extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTFLOVCM_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long idOvComp;

    /** The flow id. */
    @Column(name = "FLOW_ID")
    private Long flowIdOvComp;

    /** The seq. */
    @Column(name = "SEQ")
    private Long seqOvComp;

    /** The value. */
    @Column(name = "VALUE")
    private Long valueOvComp;

    /** The filter. */
    @Column(name = "FILTER")
    private String filterOvComp;

    /** The int separator. */
    @Column(name = "INT_SEPARATOR")
    private String intSeparatorOvComp;

    /** The separator. */
    @Column(name = "SEPARATOR")
    private String separatorOvComp;

    /** The alignment. */
    @Column(name = "ALIGNMENT")
    private Long alignmentOvComp;

    /** The max occ. */
    @Column(name = "MAX_OCC")
    private Long maxOccOvComp;

    /** The ov component parts. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "OVCOMP_ID")
    private Set<OVComponentPart> ovComponentPartsOvComp;

    /**
     * Gets the ov component parts.
     *
     * @return the ov component parts
     */
    public Set<OVComponentPart> getOvComponentParts() {
        return ovComponentPartsOvComp;
    }

    /**
     * Sets the ov component parts.
     *
     * @param ovComponentParts the new ov component parts
     */
    public void setOvComponentParts(Set<OVComponentPart> ovComponentParts) {
        this.ovComponentPartsOvComp = ovComponentParts;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return idOvComp;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idOvComp = id;
    }

    /**
     * Gets the flow id.
     *
     * @return the flow id
     */
    public Long getFlowId() {
        return flowIdOvComp;
    }

    /**
     * Sets the flow id.
     *
     * @param flowId the new flow id
     */
    public void setFlowId(Long flowId) {
        this.flowIdOvComp = flowId;
    }

    /**
     * Gets the seq.
     *
     * @return the seq
     */
    public Long getSeq() {
        return seqOvComp;
    }

    /**
     * Sets the seq.
     *
     * @param seq the new seq
     */
    public void setSeq(Long seq) {
        this.seqOvComp = seq;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return valueOvComp;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.valueOvComp = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filterOvComp;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filterOvComp = filter;
    }

    /**
     * Gets the separator.
     *
     * @return the separator
     */
    public String getSeparator() {
        return separatorOvComp;
    }

    /**
     * Sets the separator.
     *
     * @param separator the new separator
     */
    public void setSeparator(String separator) {
        this.separatorOvComp = separator;
    }

    /**
     * Gets the int separator.
     *
     * @return the int separator
     */
    public String getIntSeparator() {
        return intSeparatorOvComp;
    }

    /**
     * Sets the int separator.
     *
     * @param intSeparator the new int separator
     */
    public void setIntSeparator(String intSeparator) {
        this.intSeparatorOvComp = intSeparator;
    }

    /**
     * Gets the alignment.
     *
     * @return the alignment
     */
    public Long getAlignment() {
        return alignmentOvComp;
    }

    /**
     * Sets the alignment.
     *
     * @param alignment the new alignment
     */
    public void setAlignment(Long alignment) {
        this.alignmentOvComp = alignment;
    }

    /**
     * Gets the max occ.
     *
     * @return the max occ
     */
    public Long getMaxOcc() {
        return maxOccOvComp;
    }

    /**
     * Sets the max occ.
     *
     * @param maxOcc the new max occ
     */
    public void setMaxOcc(Long maxOcc) {
        this.maxOccOvComp = maxOcc;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((alignmentOvComp == null) ? 0 : alignmentOvComp.hashCode());
        result = prime * result + ((filterOvComp == null) ? 0 : filterOvComp.hashCode());
        result = prime * result + ((flowIdOvComp == null) ? 0 : flowIdOvComp.hashCode());
        result = prime * result + ((idOvComp == null) ? 0 : idOvComp.hashCode());
        result = prime * result + ((intSeparatorOvComp == null) ? 0 : intSeparatorOvComp.hashCode());
        result = prime * result + ((maxOccOvComp == null) ? 0 : maxOccOvComp.hashCode());
        result = prime * result + ((ovComponentPartsOvComp == null) ? 0 : ovComponentPartsOvComp.hashCode());
        result = prime * result + ((separatorOvComp == null) ? 0 : separatorOvComp.hashCode());
        result = prime * result + ((seqOvComp == null) ? 0 : seqOvComp.hashCode());
        result = prime * result + ((valueOvComp == null) ? 0 : valueOvComp.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        OVComponent other = (OVComponent) obj;
        if (alignmentOvComp == null) {
            if (other.alignmentOvComp != null)
                return false;
        } else if (!alignmentOvComp.equals(other.alignmentOvComp))
            return false;
        if (filterOvComp == null) {
            if (other.filterOvComp != null)
                return false;
        } else if (!filterOvComp.equals(other.filterOvComp))
            return false;
        if (flowIdOvComp == null) {
            if (other.flowIdOvComp != null)
                return false;
        } else if (!flowIdOvComp.equals(other.flowIdOvComp))
            return false;
        if (idOvComp == null) {
            if (other.idOvComp != null)
                return false;
        } else if (!idOvComp.equals(other.idOvComp))
            return false;
        if (intSeparatorOvComp == null) {
            if (other.intSeparatorOvComp != null)
                return false;
        } else if (!intSeparatorOvComp.equals(other.intSeparatorOvComp))
            return false;
        if (maxOccOvComp == null) {
            if (other.maxOccOvComp != null)
                return false;
        } else if (!maxOccOvComp.equals(other.maxOccOvComp))
            return false;
        if (ovComponentPartsOvComp == null) {
            if (other.ovComponentPartsOvComp != null)
                return false;
        } else if (!ovComponentPartsOvComp.equals(other.ovComponentPartsOvComp))
            return false;
        if (separatorOvComp == null) {
            if (other.separatorOvComp != null)
                return false;
        } else if (!separatorOvComp.equals(other.separatorOvComp))
            return false;
        if (seqOvComp == null) {
            if (other.seqOvComp != null)
                return false;
        } else if (!seqOvComp.equals(other.seqOvComp))
            return false;
        if (valueOvComp == null) {
            if (other.valueOvComp != null)
                return false;
        } else if (!valueOvComp.equals(other.valueOvComp))
            return false;
        return true;
    }

    /**
     * Mapto dto.
     *
     * @return the flow static metadata DTO
     */
    public OVComponentDTO maptoDto() {
        Set<OVComponentPartDTO> ovComponentPartDTOs = new HashSet<>();
        OVComponentDTO ovComponentDTO = new OVComponentDTO();
        ovComponentDTO.setFlowId(this.getFlowId());// need to change
        ovComponentDTO.setId(this.getId());
        ovComponentDTO.setSeq(this.getSeq());
        ovComponentDTO.setSeparator(this.getSeparator());
        ovComponentDTO.setIntSeparator(this.getIntSeparator());
        ovComponentDTO.setMaxOcc(this.getMaxOcc());
        ovComponentDTO.setAlignment(this.getAlignment());
        ovComponentDTO.setValue(this.getValue());
        ovComponentDTO.setFilter(this.getFilter());

        if (this.getOvComponentParts() != null && !this.getOvComponentParts().isEmpty()) {
            for (OVComponentPart ovComponentPart : this.getOvComponentParts()) {
                OVComponentPartDTO ovComponentPartDTO = ovComponentPart.maptoDto();
                ovComponentPartDTOs.add(ovComponentPartDTO);
            }
            ovComponentDTO.setOvComponentPartDTOs(ovComponentPartDTOs);
        }

        return ovComponentDTO;

    }

    /**
     * Mapto gen col dto.
     *
     * @return the generic collection DTO
     */
    public GenericCollectionDTO maptoGenColDto() {
        GenericCollectionDTO genCol = new GenericCollectionDTO();
        genCol.setFlowId(this.getFlowId());// need to change
        genCol.setId(this.getId());
        genCol.setSeq(this.getSeq());
        genCol.setIntSeparator(this.getIntSeparator());
        genCol.setMaxOcc(this.getMaxOcc());
        genCol.setAlignment(this.getAlignment());
        genCol.setValue(this.getValue());
        genCol.setFilter(this.getFilter());
        return genCol;
    }

}
