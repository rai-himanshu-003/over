/*
 * Creation : 1 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class Audit.
 */
@Entity
@Table(name = "OVRQTADT")
public class Audit extends BaseAggregateRoot<AuditPk> {

    /** The audit pk. */
    @Identity
    @EmbeddedId
    private AuditPk auditPk;

    /** The error count. */
    @Column(name = "ERROR_COUNT")
    private int errorCount;

    /** The success count. */
    @Column(name = "SUCCESS_COUNT")
    private int successCount;

    /** The interface name. */
    @Column(name = "INTERFACE")
    private String interfaceName;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The flowname. */
    @Column(name = "FLOWNAME")
    private String flowname;

    /**
     * Instantiates a new audit.
     */
    public Audit() {
    }

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        auditPk.setDateCreation(new Date());
        userCreation = LoggedUser.get();
    }

    /**
     * Instantiates a new audit.
     *
     * @param auditPk the audit pk
     * @param errorCount the error count
     * @param successCount the success count
     * @param interfaceName the interface name
     */
    public Audit(AuditPk auditPk, int errorCount, int successCount, String interfaceName) {
        super();
        this.auditPk = auditPk;
        this.errorCount = errorCount;
        this.successCount = successCount;
        this.interfaceName = interfaceName;
    }

    /**
     * Gets the error count.
     *
     * @return the error count
     */
    public int getErrorCount() {
        return errorCount;
    }

    /**
     * Sets the error count.
     *
     * @param errorCount the new error count
     */
    public void setErrorCount(int errorCount) {
        this.errorCount = errorCount;
    }

    /**
     * Gets the success count.
     *
     * @return the success count
     */
    public int getSuccessCount() {
        return successCount;
    }

    /**
     * Sets the success count.
     *
     * @param successCount the new success count
     */
    public void setSuccessCount(int successCount) {
        this.successCount = successCount;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the audit model pk.
     *
     * @return the audit model pk
     */
    public AuditPk getAuditModelPk() {
        return auditPk;
    }

    /**
     * Sets the audit model pk.
     *
     * @param auditPk the new audit model pk
     */
    public void setAuditModelPk(AuditPk auditPk) {
        this.auditPk = auditPk;
    }

    /**
     * Gets the interface name.
     *
     * @return the interface name
     */
    public String getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the interface name.
     *
     * @param interfaceName the new interface name
     */
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    /**
     * Gets the flowname.
     *
     * @return the flowname
     */
    public String getFlowname() {
        return flowname;
    }

    /**
     * Sets the flowname.
     *
     * @param flowname the new flowname
     */
    public void setFlowname(String flowname) {
        this.flowname = flowname;
    }

    @Override
    public String toString() {
        return "Audit [auditPk=" + auditPk + ", errorCount=" + errorCount + ", successCount=" + successCount + ", interfaceName=" + interfaceName
                + ", userCreation=" + userCreation + ", flowname=" + flowname + "]";
    }

}
