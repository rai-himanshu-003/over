/*
 * Creation : 18 Dec 2019
 */
package com.inetpsa.ovr.interfaces.dto.ws;

import com.google.gson.annotations.SerializedName;

/**
 * The Class VehiculeData.
 */
public class VehiculeData {

    /** The up. */
    @SerializedName(value = "UP")
    private String up;

    /** The lcdv 24. */
    @SerializedName(value = "LCDV24")
    private String lcdv24;

    /** The of. */
    @SerializedName(value = "OF")
    private String of;

    /** The date emon. */
    @SerializedName(value = "DATE_EMON")
    private String dateEmon;

    /** The date ecom. */
    @SerializedName(value = "DATE_ECOM")
    private String dateEcom;

    /** The date extension. */
    @SerializedName(value = "DATE_EXTENSION")
    private String dateExtension;

    /** The oa. */
    @SerializedName(value = "OA")
    private String oa;

    /** The apvpr. */
    @SerializedName(value = "APVPR")
    private String apvpr;

    /** The nre. */
    @SerializedName(value = "NRE")
    private String nre;

    /** The tvv. */
    @SerializedName(value = "TVV")
    private String tvv;

    /** The model. */
    @SerializedName(value = "MODEL")
    private String model;

    /** The model year. */
    @SerializedName(value = "MODELYEAR")
    private String modelYear;

    /**
     * Gets the up.
     *
     * @return the up
     */
    public String getUp() {
        return up;
    }

    /**
     * Sets the up.
     *
     * @param up the new up
     */
    public void setUp(String up) {
        this.up = up;
    }

    /**
     * Gets the lcdv 24.
     *
     * @return the lcdv 24
     */
    public String getLcdv24() {
        return lcdv24;
    }

    /**
     * Sets the lcdv 24.
     *
     * @param lcdv24 the new lcdv 24
     */
    public void setLcdv24(String lcdv24) {
        this.lcdv24 = lcdv24;
    }

    /**
     * Gets the of.
     *
     * @return the of
     */
    public String getOf() {
        return of;
    }

    /**
     * Sets the of.
     *
     * @param of the new of
     */
    public void setOf(String of) {
        this.of = of;
    }

    /**
     * Sets the date emon.
     *
     * @param dateEmon the new date emon
     */
    public void setDateEmon(String dateEmon) {
        this.dateEmon = dateEmon;
    }

    /**
     * Gets the date emon.
     *
     * @return the date emon
     */
    public String getDateEmon() {
        return dateEmon;
    }

    /**
     * Gets the oa.
     *
     * @return the oa
     */
    public String getOa() {
        return oa;
    }

    /**
     * Sets the oa.
     *
     * @param oa the new oa
     */
    public void setOa(String oa) {
        this.oa = oa;
    }

    /**
     * Gets the apvpr.
     *
     * @return the apvpr
     */
    public String getApvpr() {
        return apvpr;
    }

    /**
     * Sets the apvpr.
     *
     * @param apvpr the new apvpr
     */
    public void setApvpr(String apvpr) {
        this.apvpr = apvpr;
    }

    /**
     * Gets the nre.
     *
     * @return the nre
     */
    public String getNre() {
        return nre;
    }

    /**
     * Sets the nre.
     *
     * @param nre the new nre
     */
    public void setNre(String nre) {
        this.nre = nre;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Sets the tvv.
     *
     * @param tvv the new tvv
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * Gets the model.
     *
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model.
     *
     * @param model the new model
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Gets the model year.
     *
     * @return the model year
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the model year.
     *
     * @param modelYear the new model year
     */
    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    /**
     * Gets the date ecom.
     *
     * @return the date ecom
     */
    public String getDateEcom() {
        return dateEcom;
    }

    /**
     * Sets the date ecom.
     *
     * @param dateEcom the new date ecom
     */
    public void setDateEcom(String dateEcom) {
        this.dateEcom = dateEcom;
    }

    /**
     * Gets the date extension.
     *
     * @return the date extension
     */
    public String getDateExtension() {
        return dateExtension;
    }

    /**
     * Sets the date extension.
     *
     * @param dateExtension the new date extension
     */
    public void setDateExtension(String dateExtension) {
        this.dateExtension = dateExtension;
    }

}
