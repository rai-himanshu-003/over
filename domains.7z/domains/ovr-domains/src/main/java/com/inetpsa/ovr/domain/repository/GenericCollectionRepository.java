/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.GenericCollection;

/**
 * The Interface FlowStaticMetadataRepository.
 */
public interface GenericCollectionRepository extends Repository<GenericCollection, Long> {
}
