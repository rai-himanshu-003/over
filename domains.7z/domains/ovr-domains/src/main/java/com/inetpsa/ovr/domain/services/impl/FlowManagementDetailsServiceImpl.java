/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.repository.FlowManagementDetailsRepository;
import com.inetpsa.ovr.domain.services.FlowManagementDetailsService;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;

/**
 * The Class VehicleReferencesElectroniquesServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class FlowManagementDetailsServiceImpl implements FlowManagementDetailsService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(FlowManagementDetailsServiceImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The specification builder. */
    @Inject
    private FlowManagementDetailsRepository flowManagementDetailsRepository;

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleReferencesElectroniquesService#getvehicleReferencesElectroniquesByVin(java.lang.String)
     */

    @Override
    public List<OutputFlowDetails> getflowDetails() {

        Specification<OutputFlowDetails> spec = specificationBuilder.of(OutputFlowDetails.class).property("flow").not().equalTo(null).and()
                .property("isDeleted").not().equalTo(CommonConstant.YES.getConstValue()).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        return flowManagementDetailsRepository.get(spec, opt).collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.FlowManagementDetailsService#getFlowDetailsByName(java.lang.String)
     */
    @Override
    public OutputFlowDetails getFlowDetailsByName(String flowName) {

        CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<OutputFlowDetails> criteria = builder.createQuery(OutputFlowDetails.class);
        Root<OutputFlowDetails> c = criteria.from(OutputFlowDetails.class);
        criteria.select(c);
        criteria.where(builder.equal(c.get("flow"), flowName), builder.equal(c.get("isDeleted"), CommonConstant.NO.getConstValue()));
        TypedQuery<OutputFlowDetails> typed = this.entityManager.createQuery(criteria);

        return typed.getSingleResult();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleReferencesElectroniquesService#deleteReferencesElectroniquesById(java.lang.Long)
     */
    @Override
    public boolean deleteflowDetails(Long id) {
        Optional<OutputFlowDetails> tobedeleted = flowManagementDetailsRepository.get(id);
        if (tobedeleted.isPresent()) {
            OutputFlowDetails aggregate = tobedeleted.get();
            aggregate.setIsDeleted(CommonConstant.YES.getConstValue());
            flowManagementDetailsRepository.update(aggregate);

            logger.info("OutputFlowDetails {} : has been soft deleted successfully!", id);

            return true;
        }
        logger.info("OutputFlowDetails {} : is not present in DB", id);

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.FlowManagementDetailsService#removeflowDetails(java.lang.Long)
     */
    @Override
    public boolean removeflowDetails(Long id) {
        logger.info("Entering removeFlowDetails");
        Optional<OutputFlowDetails> tobedeleted = flowManagementDetailsRepository.get(id);
        if (tobedeleted.isPresent()) {
            flowManagementDetailsRepository.remove(tobedeleted.get());
            return true;
        }
        logger.info("OutputFlowDetails {} : is not present in DB", id);

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleReferencesElectroniquesService#addOrUpdateReferencesElectroniques(com.inetpsa.ovr.domain.model.ReferencesElectroniques)
     */
    @Override
    public boolean addOrUpdateflowDetails(OutputFlowDetailsDTO outputFlowDetailsDTO) {
        try {
            if (outputFlowDetailsDTO.getId() != null) {
                Optional<OutputFlowDetails> aggregate = flowManagementDetailsRepository.get(outputFlowDetailsDTO.getId());
                if (aggregate.isPresent() && aggregate.get() != null
                        && aggregate.get().getIsDeleted().equalsIgnoreCase(CommonConstant.NO.getConstValue())) {
                    logger.info("Vehicle version from database {}", aggregate.get().getVersion());
                    logger.info("Vehicle version from ui {}", outputFlowDetailsDTO.getVersion());
                    OutputFlowDetails outputFlowDetails = outputFlowDetailsDTO.mapTomodel(aggregate.get());
                    if (aggregate.get().getVersion().equals(outputFlowDetailsDTO.getVersion())) {
                        flowManagementDetailsRepository.update(outputFlowDetails);
                    } else {
                        logger.info("Version did not match for Flow : {}", outputFlowDetails.getFlow());
                        return false;
                    }

                } else {
                    logger.info("Record is not present or soft delted, can not modify the details of the Flow : {}", outputFlowDetailsDTO.getFlow());
                    return false;
                }

            } else {
                OutputFlowDetails outputFlowDetails = outputFlowDetailsDTO.mapTomodel(new OutputFlowDetails());
                outputFlowDetails.setIsDeleted(CommonConstant.NO.getConstValue());
                flowManagementDetailsRepository.add(outputFlowDetails);

            }
            return true;
        } catch (Exception e) {
            logger.error("Error while adding/updating flow  {} : {}", outputFlowDetailsDTO.getFlow(), e.getMessage());
        }
        return false;
    }

}
