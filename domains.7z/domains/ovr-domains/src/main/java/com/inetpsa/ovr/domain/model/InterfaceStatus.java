package com.inetpsa.ovr.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class InterfaceStatus.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTSTS")
public class InterfaceStatus extends BaseAggregateRoot<String> {

    /** The interface name. */
    @Identity
    @Id
    @Column(name = "INTERFACE")
    private String interfaceName;

    /** The status. */
    @Column(name = "status")
    private String status;

    /** The date modif. */
    @Column(name = "DATE_MODIF")
    private Date dateModif;

    /** The user modif. */
    @Column(name = "USER_MODIF")
    private String userModif;

    /** The statusList. */
    @Column(name = "status_list")
    private String statusList;

    /** The remark. */
    @Column(name = "remark")
    private String remark;

    /** The version. */
    @Version
    @Column(name = "VERSION")
    private Integer version;

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the remark.
     *
     * @return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * Sets the remark.
     *
     * @param remark the new remark
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * Gets the status list.
     *
     * @return the status list
     */
    public String getStatusList() {
        return statusList;
    }

    /**
     * Sets the status list.
     *
     * @param statusList the new status list
     */
    public void setStatusList(String statusList) {
        this.statusList = statusList;
    }

    /**
     * Pre update.
     */
    @PreUpdate
    public void preUpdate() {
        dateModif = new Date();
        userModif = LoggedUser.get();
    }

    /**
     * Gets the interface name.
     *
     * @return the interface name
     */
    public String getInterfaceName() {
        return interfaceName;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public Date getDateModif() {
        return dateModif;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Sets the interface name.
     *
     * @param interfaceName the new interface name
     */
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Instantiates a new interface status.
     */
    public InterfaceStatus() {
        super();

    }

    /**
     * Instantiates a new interface status.
     *
     * @param interfaceName the interface name
     * @param status the status
     */
    public InterfaceStatus(String interfaceName, String status) {
        super();
        this.interfaceName = interfaceName;
        this.status = status;

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "InterfaceStatus [interfaceName=" + interfaceName + ", status=" + status + ", dateModif=" + dateModif + ", userModif=" + userModif
                + "]";
    }

}
