/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.VehicleHistory;
import com.inetpsa.ovr.domain.model.VehicleHistoryPk;
import com.inetpsa.ovr.domain.repository.VehicleHistoryRepository;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;

/**
 * The Class VehicleHistoryRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleHistoryRepositoryImpl extends BaseJpaRepository<VehicleHistory, VehicleHistoryPk> implements VehicleHistoryRepository {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleHistoryRepositoryImpl.class);

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public List<VehicleDetailsDto> getVehHistList(String vin) {

        logger.info("Entering getErrList of VehicleErrorRepositoryImpl");

        List<VehicleDetailsDto> vehicleError = null;
        List list = null;
        try {

            Query hql = super.getEntityManager().createNativeQuery(
                    "select vh.vin, vh.date_creation,vh.user_creation,vh.state_id,vh.flowname from ovrqthis vh where vh.vin =:vin order by vh.date_creation desc");
            hql.setParameter("vin", vin);
            list = hql.getResultList();
            vehicleError = this.generateHisList(list);

            logger.info("Exiting getErrList of VehicleErrorRepositoryImpl");
            return vehicleError;
        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return vehicleError;
    }

    private List<VehicleDetailsDto> generateHisList(List arrayList) {
        try {
            List<VehicleDetailsDto> vehicleDetailsDtoList = new ArrayList<>();
            Iterator itr = arrayList.iterator();
            while (itr.hasNext()) {
                Object[] obj = (Object[]) (itr.next());
                VehicleDetailsDto vehicleDetailsDto = new VehicleDetailsDto();
                vehicleDetailsDto.setVin(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER0]).orElse("").toString());
                vehicleDetailsDto.setUserCreation(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER2]).orElse("").toString());
                if (obj[OVERConstants.MAGICNUMBER1] != null) {
                    vehicleDetailsDto.setDateCreation(dateFormat.parse(obj[OVERConstants.MAGICNUMBER1].toString()));
                }
                vehicleDetailsDto.setStateId(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER3]).orElse("").toString());
                vehicleDetailsDto.setFlowName(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER4]).orElse("").toString());
                vehicleDetailsDtoList.add(vehicleDetailsDto);

            }
            return vehicleDetailsDtoList;
        } catch (Exception e) {
            logger.error("Error in generateHisList() {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    public long getVehHistListCount(String vin) {

        logger.info("Entering getErrList of VehicleErrorRepositoryImpl");

        try {

            Query hql = super.getEntityManager().createNativeQuery("select count(*) from ovrqthis vh where vh.vin =:vin");
            hql.setParameter("vin", vin);

            return ((BigDecimal) hql.getSingleResult()).longValue();

        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return 0;
    }

}
