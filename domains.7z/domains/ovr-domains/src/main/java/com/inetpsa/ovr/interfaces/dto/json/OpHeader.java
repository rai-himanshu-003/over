/*
 * Creation : 17 Apr 2020
 */
package com.inetpsa.ovr.interfaces.dto.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class OpHeader.
 */
public class OpHeader {

    /** The sender. */
    @SerializedName("SENDER")
    @Expose
    private String sender;

    /** The client. */
    @SerializedName("CLIENT")
    @Expose
    private String client;

    /** The sending date. */
    @SerializedName("SENDING_DATE")
    @Expose
    private String sendingDate;

    /**
     * Gets the sender.
     *
     * @return the sender
     */
    public String getSender() {
        return sender;
    }

    /**
     * Sets the sender.
     *
     * @param sender the new sender
     */
    public void setSender(String sender) {
        this.sender = sender;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Gets the sending date.
     *
     * @return the sending date
     */
    public String getSendingDate() {
        return sendingDate;
    }

    /**
     * Sets the sending date.
     *
     * @param sendingDate the new sending date
     */
    public void setSendingDate(String sendingDate) {
        this.sendingDate = sendingDate;
    }

}