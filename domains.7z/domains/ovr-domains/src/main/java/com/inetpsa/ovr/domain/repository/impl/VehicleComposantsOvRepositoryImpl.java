/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.repository.VehicleComposantsOvRepository;
import com.inetpsa.ovr.interfaces.dto.ws.Criteria;

/**
 * The Class VehicleComposantsOvRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleComposantsOvRepositoryImpl extends BaseJpaRepository<ComposantsOv, Long> implements VehicleComposantsOvRepository {

    @Inject
    private EntityManager entityManager;

    private static final Logger logger = LoggerFactory.getLogger(VehicleComposantsOvRepositoryImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    @Override
    public List<ComposantsOv> getComposants(List<PsaKeyMapping> psaKeyMappings, String vin) {

        CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<ComposantsOv> criteria = builder.createQuery(ComposantsOv.class);
        Root<ComposantsOv> root = criteria.from(ComposantsOv.class);
        List<Predicate> predicates = new ArrayList<>();

        builder.equal((root.get("vin")), vin);
        for (PsaKeyMapping psaKeyMapping : psaKeyMappings) {

            setPredicatesForRules(predicates, builder, root, psaKeyMapping);

        }

        criteria.where(builder.and(builder.or(predicates.toArray(new Predicate[predicates.size()])), builder.equal((root.get("vin")), vin)));
        logger.info("Fetching vehicle details completed for inclusive rule for interface :{}", vin);
        return this.entityManager.createQuery(criteria).getResultList();

    }

    private void setPredicatesForRules(List<Predicate> predicates, CriteriaBuilder builder, Root<ComposantsOv> root, PsaKeyMapping psaKeyMapping) {
        List<Predicate> predicatesTemp = new ArrayList<>();
        if (psaKeyMapping.getOvKey() != null)
            predicatesTemp.add(builder.equal((root.get("eid")), psaKeyMapping.getOvKey()));
        if (psaKeyMapping.getOvStandard() != null)
            predicatesTemp.add(builder.equal((root.get("standard")), psaKeyMapping.getOvStandard()));
        predicates.add(builder.and(predicatesTemp.toArray(new Predicate[predicatesTemp.size()])));
    }

    @Override
    public List<ComposantsOv> getComposantsFrWs(List<PsaKeyMapping> psaKeyMappings, List<Criteria> criteriaList) {

        CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<ComposantsOv> psaKeyMapCriteria = builder.createQuery(ComposantsOv.class);
        Root<ComposantsOv> c = psaKeyMapCriteria.from(ComposantsOv.class);
        psaKeyMapCriteria.select(c);
        List<Predicate> predicates = new ArrayList<>();

        for (Criteria criteria : criteriaList) {
            String vin = criteria.getVin();
            for (PsaKeyMapping psaKeyMapping : psaKeyMappings) {

                Predicate predicate = builder.and(builder.equal((c.get("eid")), psaKeyMapping.getOvKey()),
                        builder.equal((c.get("standard")), psaKeyMapping.getOvStandard()), builder.equal((c.get("vin")), vin));

                predicates.add(predicate);

            }
        }

        psaKeyMapCriteria.where(builder.or(predicates.toArray(new Predicate[] {})));
        return this.entityManager.createQuery(psaKeyMapCriteria).getResultList();

    }

    @Override
    public List<BigDecimal> getSequenceCount(long size) {
        logger.info("Entering getSequenceCount");
        List<BigDecimal> qlist = new ArrayList<>();
        try {

            Query query = super.getEntityManager()
                    .createNativeQuery("select OVRQTVCOMOV_SEQ.nextval from ( select level from dual connect by level <= :countOfOptions )");
            query.setParameter("countOfOptions", size);
            qlist = query.getResultList();
            logger.info("Exiting getSequenceCount");
            return qlist;

        } catch (Exception e) {
            logger.error("Error while genereting OVRQTVCOMOV number : {}", e.getMessage());

        }
        return qlist;

    }
}