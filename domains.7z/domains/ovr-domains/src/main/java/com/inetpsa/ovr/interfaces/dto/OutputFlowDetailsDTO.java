package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.model.FlowVhlMetadata;
import com.inetpsa.ovr.domain.model.GenericCollection;
import com.inetpsa.ovr.domain.model.OVComponent;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;

/**
 * The Class OutputFlowDetailsDTO.
 */
public class OutputFlowDetailsDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;
    /** The interface id. */
    private Long id;

    /** The flow. */
    private String flow;

    /** The description. */
    private String description;

    /** The file format id. */
    private Long fileFormatId;

    /** The frequency. */
    private String frequency;

    /** The action. */
    private Long action;

    /** The folder location. */
    private String folderLocation;

    /** The file Name. */
    private String fileName;

    /** The last run. */
    private LocalDateTime lastRun;

    /** The version. */
    private Integer version;

    /** The flow vhl metadata DT os. */
    private Set<FlowVhlMetadataDTO> flowVhlMetadataDTOs;

    /** The collection DT os. */
    private Set<GenericCollectionDTO> collectionDTOs;

    /** The ov component DT os. */
    private Set<OVComponentDTO> ovComponentDTOs;

    /**
     * Gets the last run.
     *
     * @return the last run
     */
    public LocalDateTime getLastRun() {
        return lastRun;
    }

    /**
     * Sets the last run.
     *
     * @param lastRun the new last run
     */
    public void setLastRun(LocalDateTime lastRun) {
        this.lastRun = lastRun;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the new file name
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the flow.
     *
     * @return the flow
     */
    public String getFlow() {
        return flow;
    }

    /**
     * Sets the flow.
     *
     * @param flow the new flow
     */
    public void setFlow(String flow) {
        this.flow = flow;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the file format id.
     *
     * @return the file format id
     */
    public Long getFileFormatId() {
        return fileFormatId;
    }

    /**
     * Sets the file format id.
     *
     * @param fileFormatId the new file format id
     */
    public void setFileFormatId(Long fileFormatId) {
        this.fileFormatId = fileFormatId;
    }

    /**
     * Gets the frequency.
     *
     * @return the frequency
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * Sets the frequency.
     *
     * @param frequency the new frequency
     */
    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    /**
     * Gets the action.
     *
     * @return the action
     */
    public Long getAction() {
        return action;
    }

    /**
     * Sets the action.
     *
     * @param action the new action
     */
    public void setAction(Long action) {
        this.action = action;
    }

    /**
     * Gets the folder location.
     *
     * @return the folder location
     */
    public String getFolderLocation() {
        return folderLocation;
    }

    /**
     * Sets the folder location.
     *
     * @param folderLocation the new folder location
     */
    public void setFolderLocation(String folderLocation) {
        this.folderLocation = folderLocation;
    }

    /**
     * Gets the flow vhl metadata DT os.
     *
     * @return the flow vhl metadata DT os
     */
    public Set<FlowVhlMetadataDTO> getFlowVhlMetadataDTOs() {
        return flowVhlMetadataDTOs;
    }

    /**
     * Sets the flow vhl metadata DT os.
     *
     * @param flowVhlMetadataDTOs the new flow vhl metadata DT os
     */
    public void setFlowVhlMetadataDTOs(Set<FlowVhlMetadataDTO> flowVhlMetadataDTOs) {
        this.flowVhlMetadataDTOs = flowVhlMetadataDTOs;
    }

    /**
     * Gets the collection DT os.
     *
     * @return the collection DT os
     */
    public Set<GenericCollectionDTO> getCollectionDTOs() {
        return collectionDTOs;
    }

    /**
     * Sets the collection DT os.
     *
     * @param collectionDTOs the new collection DT os
     */
    public void setCollectionDTOs(Set<GenericCollectionDTO> collectionDTOs) {
        this.collectionDTOs = collectionDTOs;
    }

    /**
     * Gets the ov component DT os.
     *
     * @return the ov component DT os
     */
    public Set<OVComponentDTO> getOvComponentDTOs() {
        return ovComponentDTOs;
    }

    /**
     * Sets the ov component DT os.
     *
     * @param ovComponentDTOs the new ov component DT os
     */
    public void setOvComponentDTOs(Set<OVComponentDTO> ovComponentDTOs) {
        this.ovComponentDTOs = ovComponentDTOs;
    }

    /**
     * Map tomodel.
     *
     * @param outputFlowDetails the output flow details
     * @return the output flow details
     */
    public OutputFlowDetails mapTomodel(OutputFlowDetails outputFlowDetails) {

        outputFlowDetails.setFlow(this.getFlow());
        outputFlowDetails.setId(this.getId());
        outputFlowDetails.setDescription(this.getDescription());
        outputFlowDetails.setFrequency(this.getFrequency());
        outputFlowDetails.setAction(this.getAction());
        outputFlowDetails.setFolder(this.getFolderLocation());
        outputFlowDetails.setFormat(this.getFileFormatId());
        outputFlowDetails.setFileName(this.getFileName());
        outputFlowDetails.setIsDeleted(CommonConstant.NO.getConstValue());

        return outputFlowDetails;
    }

    /**
     * Map tomodel for FMGMT.
     *
     * @param outputFlowDetails the output flow details
     * @return the output flow details
     */
    public OutputFlowDetails mapTomodelForFMGMT(OutputFlowDetails outputFlowDetails) {
        Set<FlowVhlMetadata> flowVhlMetadatas = new HashSet();
        Set<GenericCollection> genericCollections = new HashSet();
        Set<OVComponent> ovComponents = new HashSet();

        outputFlowDetails.setId(this.getId());
        outputFlowDetails.setFormat(this.getFileFormatId());
        if (outputFlowDetails.getFlowVhlMetadatas() != null && !outputFlowDetails.getFlowVhlMetadatas().isEmpty())
            outputFlowDetails.getFlowVhlMetadatas().clear();

        if (outputFlowDetails.getGenericCollections() != null && !outputFlowDetails.getGenericCollections().isEmpty())
            outputFlowDetails.getGenericCollections().clear();

        if (outputFlowDetails.getOvComponents() != null && !outputFlowDetails.getOvComponents().isEmpty()) {
            outputFlowDetails.getOvComponents().clear();
        }

        if (this.getFlowVhlMetadataDTOs() != null && !this.getFlowVhlMetadataDTOs().isEmpty()) {
            for (FlowVhlMetadataDTO flowVhlMetadataDTO : this.getFlowVhlMetadataDTOs()) {
                flowVhlMetadatas.add(flowVhlMetadataDTO.mapTomodel());

            }
            outputFlowDetails.getFlowVhlMetadatas().addAll(flowVhlMetadatas);
        }
        if (this.getCollectionDTOs() != null && !this.getCollectionDTOs().isEmpty()) {
            for (GenericCollectionDTO genericCollectionDTO : this.getCollectionDTOs()) {
                genericCollections.add(genericCollectionDTO.mapTomodel());
            }
            outputFlowDetails.getGenericCollections().addAll(genericCollections);
        }

        if (this.getOvComponentDTOs() != null && !this.getOvComponentDTOs().isEmpty()) {
            for (OVComponentDTO ovComponentDTO : this.getOvComponentDTOs()) {
                ovComponents.add(ovComponentDTO.mapTomodel());
            }
            outputFlowDetails.getOvComponents().addAll(ovComponents);

        }

        return outputFlowDetails;
    }

    @Override
    public String toString() {
        return "OutputFlowDetailsDTO [id=" + id + ", flow=" + flow + ", description=" + description + ", fileFormatId=" + fileFormatId
                + ", frequency=" + frequency + ", action=" + action + ", folderLocation=" + folderLocation + ", fileName=" + fileName + ", lastRun="
                + lastRun + ", version=" + version + ", flowVhlMetadataDTOs=" + flowVhlMetadataDTOs + ", collectionDTOs=" + collectionDTOs
                + ", ovComponentDTOs=" + ovComponentDTOs + "]";
    }
}
