/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.constant.TranslationState;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.FormatManagementService;
import com.inetpsa.ovr.domain.services.InterfaceRuleMgmtService;
import com.inetpsa.ovr.domain.services.InterfaceRulesService;
import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.IRMRequestDTO;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;
import com.inetpsa.ovr.interfaces.dto.PreviousFlowDetailsDTO;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;

/**
 * The Class VehicleServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class InterfaceRuleMgmtServiceImpl implements InterfaceRuleMgmtService {

    @Inject
    InterfaceRulesService interfaceRuleService;

    @Inject
    FormatManagementService formatManagementService;

    @Inject
    VehicleRepository vehicleRepository;
    private static final Logger logger = LoggerFactory.getLogger(InterfaceRuleMgmtServiceImpl.class);

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceRuleMgmtService#applyAndGetInterfaceRulesFor(com.inetpsa.ovr.interfaces.dto.IRMRequestDTO)
     */
    @Override
    public Boolean applyAndGetInterfaceRulesFor(IRMRequestDTO irmRequestDTO) {
        logger.info("Entering applyAndGetInterfaceRulesFor of InterfaceRuleMgmtServiceImpl for Interface  : {} ", irmRequestDTO.getCurrentFlow());
        // Get list of rules for particular interface
        try {
            List<String> previousFlow = new ArrayList<>();
            List<String> vinList = new ArrayList<>();
            List<String> statusList = null;
            String creationUser = LoggedUser.get();

            List<InterfaceRulesDto> interfaceRulesDtos = interfaceRuleService.getInterfaceRules(irmRequestDTO.getIntId());

            if (interfaceRulesDtos != null && !interfaceRulesDtos.isEmpty()) {

                if (!CommonConstant.OUTPUT_FLOW.getConstValue()
                        .equalsIgnoreCase(irmRequestDTO.getPreviousFlowDetailsDTOs().get(0).getPreviousFlow())) {

                    // old code as is
                    for (PreviousFlowDetailsDTO previousFlowDetailsDTO : irmRequestDTO.getPreviousFlowDetailsDTOs()) {
                        if (previousFlowDetailsDTO.getPreviousFlow() != null) {

                            String[] splitList = previousFlowDetailsDTO.getPreviousFlow().split(",");

                            for (String str : splitList)
                                previousFlow.add(str);
                        }
                        statusList = previousFlowDetailsDTO.getStatus();
                    }
                    List<VehicleDetailsDto> mainList = new ArrayList<>();

                    vehicleRepository.deleteOTTRetriedRecs(irmRequestDTO.getCurrentFlow(), "REIN");

                    mainList = vehicleRepository.getVehList(previousFlow, statusList, irmRequestDTO.getCurrentFlow());
                    logger.info("htting DB to fetch the main list *** {} ", mainList.size());

                    if (null != mainList && mainList.size() > 0) {
                        for (VehicleDetailsDto vehicleDetailsDto : mainList) {
                            vinList.add(vehicleDetailsDto.getVin());
                        }
                    } else {
                        return true;
                    }
                }

                else // new code for output flow rules
                {
                    vehicleRepository.deleteOldOutflowEntry(irmRequestDTO.getCurrentFlow());

                    OutputFlowDetails outputFlow = formatManagementService.getflowDetailsByName(irmRequestDTO.getCurrentFlow());

                    if (outputFlow != null)
                        vinList = vehicleRepository.getVehicleForOutputFlow(outputFlow);
                    else
                        logger.error("Flow not found into OVRQTOPFL table : {} ", irmRequestDTO.getCurrentFlow());

                    if (vinList != null && !vinList.isEmpty()) {
                        logger.info("Applying rule on {} ", vinList);
                    } else
                        return true;
                }

                String status = null;

                for (InterfaceRulesDto interfaceRulesDto : interfaceRulesDtos) {
                    if (interfaceRulesDto != null) {
                        logger.info("Applying rules and fetching vehicles  for interface :{}", interfaceRulesDto.getPriority());
                        if (interfaceRulesDto.getTypeOfFilter().equals(CommonConstant.INCLUSIVE.getConstValueInt())) {
                            // update matching records in ovrqtvhl table
                            status = TranslationState.INIT.getConstValue();
                            vehicleRepository.applyRulesAndInsertVehicles(interfaceRulesDto, irmRequestDTO, status, true, vinList);

                        } else {
                            status = TranslationState.IGNORE.getConstValue();
                            vehicleRepository.applyRulesAndInsertVehicles(interfaceRulesDto, irmRequestDTO, status, true, vinList);

                        }

                    }
                }
                status = TranslationState.IGNORE.getConstValue();
                vehicleRepository.applyRulesAndInsertVehicles(null, irmRequestDTO, status, false, vinList);

            } else
                logger.info("No rules found for the given interface");
            logger.info("Exiting applyAndGetInterfaceRulesFor of InterfaceRuleMgmtServiceImpl for Interface  : {} ", irmRequestDTO.getCurrentFlow());
            return true;
        } catch (Exception e) {
            logger.error("Error occured while fetching vehicle  for flow {} detailed exception :{}", irmRequestDTO.getCurrentFlow(), e.getMessage());
            return false;
        }

    }

}
