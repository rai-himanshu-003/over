/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.util.List;

import org.seedstack.business.Service;
import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.VehicleError;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;

/**
 * The Interface VehicleErrorRepository.
 */
@Service
public interface VehicleErrorRepository extends Repository<VehicleError, String> {

    /**
     * This method get details of vin with given filter criteria.
     *
     * @param resendToOTTDto of type {@link ResendToOTTDto} represents the code attribute
     * @param offsetPositionToStartFrom of type {@literal int} represent the start position of the range
     * @param rowsPerPage of type {@literal int} represent the number of elements to get.
     * @param toIgnore of type {@literal boolean} represent if toIgnore vehicles to fetch.
     * @return a {@link List} of {@link ResendToOTTDto}
     */
    List<ResendToOTTDto> getErrList(ResendToOTTDto resendToOTTDto, int offsetPositionToStartFrom, int rowsPerPage, boolean toIgnore);

    /**
     * This method get the total of records.
     *
     * @param resendToOTTDto of type {@link ResendToOTTDto} represents the code attribute
     * @param toIgnore the to ignore
     * @return a number of type {@link Long}
     */
    long getTotalErrRecords(ResendToOTTDto resendToOTTDto, boolean toIgnore);

    /**
     * Gets the veh err hist list count.
     *
     * @param vin the vin
     * @return the veh err hist list count
     */
    long getVehErrHistListCount(String vin);
}
