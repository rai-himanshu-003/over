/*
 * Creation : 20 Feb 2020
 */
package com.inetpsa.ovr.domain.services.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.constant.FormatManagementConstant;
import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.FlowVhlMetadata;
import com.inetpsa.ovr.domain.model.GenericCollection;
import com.inetpsa.ovr.domain.model.OVComponent;
import com.inetpsa.ovr.domain.model.OVComponentPart;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.services.FlatFileService;
import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;
import com.inetpsa.ovr.interfaces.dto.OvCompPartFilterDTO;

/**
 * The Class FlatFileServiceImpl.
 */
public class FlatFileServiceImpl implements FlatFileService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(FlatFileServiceImpl.class);

    String dateFormat = "yyyyMMddHHmmss";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.FlatFileService#returnFlatFormat(java.util.List, com.inetpsa.ovr.domain.model.OutputFlowDetails)
     */
    @Override
    public List<StringBuilder> returnFlatFormat(List<Vehicle> vehicles, OutputFlowDetails flowDetails) {

        logger.info("{} : Flat file generation started : {} ", flowDetails.getFlow(), flowDetails);
        List<StringBuilder> flatFile = new ArrayList<>();

        String header = generateFlatFileHeader(flowDetails);
        List<String> body = generateFlatFileBody(vehicles, flowDetails);
        String footer = generateFlatFileFooter(flowDetails, vehicles.size());

        flatFile.add(new StringBuilder(header));
        for (String line : body)
            flatFile.add(new StringBuilder(line));
        flatFile.add(new StringBuilder(footer));

        logger.info("{} : Flat file generation ended {} ", flowDetails.getFlow(), flatFile);
        return flatFile;
    }

    /**
     * Generate flat file footer.
     *
     * @param flowDetails the flow details
     * @param size the size
     * @return the string
     */
    private String generateFlatFileFooter(OutputFlowDetails flowDetails, int size) {

        String pad0 = "00000000000000";
        String zeroPaddedSequenceNumber = (pad0 + size).substring((size + "").length());
        return CommonConstant.APPLICATION_OVER.getConstValue() + " " + String.format("%1$-20s", flowDetails.getFlow().toUpperCase()) + " "
                + zeroPaddedSequenceNumber;
    }

    /**
     * Generate flat file header.
     *
     * @param flowDetails the flow details
     * @return the string
     */
    private String generateFlatFileHeader(OutputFlowDetails flowDetails) {

        SimpleDateFormat format = new SimpleDateFormat(dateFormat);
        return CommonConstant.APPLICATION_OVER.getConstValue() + " " + String.format("%1$-20s", flowDetails.getFlow().toUpperCase()) + " "
                + format.format(new Date());
    }

    /**
     * Generate flat file body.
     *
     * @param vehicles the vehicles
     * @param flowDetails the flow details
     * @return the list
     */
    private List<String> generateFlatFileBody(List<Vehicle> vehicles, OutputFlowDetails flowDetails) {

        Map<Long, GenericCollectionDTO> seqValueMap = getSortedSeqValueMap(flowDetails);
        logger.info("{} : Generated sequence and value map for flat file : {} ", flowDetails.getFlow(), seqValueMap);

        OvCompPartFilterDTO compPartFilter = setupOVCompFilterDTO(flowDetails);
        logger.info("{} : Generated component part filter for flat file : {} ", flowDetails.getFlow(), compPartFilter);

        List<String> body = new ArrayList<>();

        try {

            if (seqValueMap != null && !seqValueMap.isEmpty()) {
                for (Vehicle vhl : vehicles) {
                    StringBuilder newLine = new StringBuilder();
                    for (Map.Entry<Long, GenericCollectionDTO> entry : seqValueMap.entrySet()) {

                        GenericCollectionDTO genCol = entry.getValue();

                        switch (genCol.getValue().toString()) {

                        case "7":
                            if (vhl.getVinNo() != null)
                                newLine.append(vhl.getVinNo());
                            else
                                newLine.append(String.format("%1$-17s", " "));

                            break;

                        case "8":

                            if (vhl.getCcp() != null)
                                newLine.append(vhl.getCcp());
                            else
                                newLine.append(String.format("%1$-2s", " "));
                            break;

                        case "9":

                            if (vhl.getVeh() != null)
                                newLine.append(vhl.getVeh());
                            else
                                newLine.append(String.format("%1$-3s", " "));
                            break;

                        case "10":
                            if (vhl.getUp() != null)
                                newLine.append(vhl.getUp());
                            else
                                newLine.append(String.format("%1$-2s", " "));
                            break;

                        case "11":
                            if (vhl.getOf() != null)
                                newLine.append(vhl.getOf());
                            else
                                newLine.append(String.format("%1$-8s", " "));
                            break;

                        case "12":
                            if (vhl.getLcdv24() != null)
                                newLine.append(vhl.getLcdv24());
                            else
                                newLine.append(String.format("%1$-24s", " "));
                            break;

                        case "13":
                            SimpleDateFormat frmt = null;

                            if (genCol.getFilter() != null) {
                                try {
                                    frmt = new SimpleDateFormat(genCol.getFilter());
                                } catch (IllegalArgumentException ie) {
                                    logger.error("{} : Error while formatting date emon {}, swtiching to default date format {} ",
                                            flowDetails.getFlow(), ie.getMessage(), dateFormat);
                                    frmt = new SimpleDateFormat(dateFormat);
                                }
                            } else
                                frmt = new SimpleDateFormat(dateFormat);

                            String frmtLengthEmon = "%1$-" + (frmt.format(new Date())).length() + "s";

                            if (vhl.getDateEmon() != null)
                                newLine.append(frmt.format(vhl.getDateEmon()));
                            else
                                newLine.append(String.format(frmtLengthEmon, " "));

                            break;

                        case "14":

                            SimpleDateFormat frmt1 = null;

                            if (genCol.getFilter() != null) {
                                try {
                                    frmt1 = new SimpleDateFormat(genCol.getFilter());
                                } catch (IllegalArgumentException ie) {
                                    logger.error("{} : Error while formatting date ecom {}, swtiching to default date format {} ",
                                            flowDetails.getFlow(), ie.getMessage(), dateFormat);
                                    frmt1 = new SimpleDateFormat(dateFormat);
                                }
                            } else
                                frmt1 = new SimpleDateFormat(dateFormat);

                            String frmtLengthEcom = "%1$-" + (frmt1.format(new Date())).length() + "s";

                            if (vhl.getDateEcom() != null)
                                newLine.append(frmt1.format(vhl.getDateEcom()));

                            else
                                newLine.append(String.format(frmtLengthEcom, " "));

                            break;

                        case "15":
                            if (vhl.getOa() != null)
                                newLine.append(vhl.getOa());
                            else
                                newLine.append(String.format("%1$-8s", " "));
                            break;

                        case "16":
                            if (vhl.getApvpr() != null)
                                newLine.append(vhl.getApvpr());
                            else
                                newLine.append(String.format("%1$-12s", " "));
                            break;

                        case "17":
                            if (vhl.getModel() != null)
                                newLine.append(vhl.getModel());
                            else
                                newLine.append(String.format("%1$-5s", " "));
                            break;

                        case "18":
                            if (vhl.getModelYear() != null)
                                newLine.append(vhl.getModelYear());
                            else
                                newLine.append(String.format("%1$-4s", " "));
                            break;

                        case "19":

                            Long maxOcc = genCol.getMaxOcc();
                            String alignFormat = "";

                            if (genCol.getAlignment().toString().equals("5"))
                                alignFormat = "%1$-5s";
                            else if (genCol.getAlignment().toString().equals("6"))
                                alignFormat = "%1$5s";
                            else
                                alignFormat = "%1$5s";
                            // Changes done for ARTLCDV in lot 5
                            if (vhl.getArtLcdvOtt() != null && !vhl.getArtLcdvOtt().isEmpty())
                                for (ArtLcdvOtt lcdv : vhl.getArtLcdvOtt()) {
                                    if (maxOcc == 0)
                                        break;

                                    newLine.append(String.format(alignFormat, (lcdv.getFamily() + lcdv.getCode() + lcdv.getValue())));

                                    if (maxOcc != 1 && genCol.getIntSeparator() != null)
                                        newLine.append(genCol.getIntSeparator());

                                    maxOcc--;
                                }
                            // Changes completed
                            while (maxOcc > 0) {
                                newLine.append(String.format("%1$-5s", " "));

                                if (maxOcc != 1 && genCol.getIntSeparator() != null)
                                    newLine.append(genCol.getIntSeparator());

                                maxOcc--;
                            }

                            break;

                        case "20":

                            Long maxOccOp = genCol.getMaxOcc();

                            String alignFormatOp = "";

                            if (genCol.getAlignment().toString().equals("5"))
                                alignFormatOp = "%1$-4s";
                            else if (genCol.getAlignment().toString().equals("6"))
                                alignFormatOp = "%1$4s";
                            else
                                alignFormatOp = "%1$4s";

                            if (vhl.getOptions() != null && !vhl.getOptions().isEmpty())
                                for (Options rpo : vhl.getOptions()) {
                                    if (maxOccOp == 0)
                                        break;

                                    if (rpo.getRpoData() != null && !rpo.getRpoData().isEmpty())
                                        newLine.append(String.format(alignFormatOp, (rpo.getRpoData() + " ")));

                                    else
                                        newLine.append(String.format(alignFormatOp, " "));

                                    if (maxOccOp != 1 && genCol.getIntSeparator() != null)
                                        newLine.append(genCol.getIntSeparator());

                                    maxOccOp--;
                                }

                            while (maxOccOp > 0) {
                                newLine.append(String.format("%1$-4s", " "));

                                if (maxOccOp != 1 && genCol.getIntSeparator() != null)
                                    newLine.append(genCol.getIntSeparator());

                                maxOccOp--;
                            }

                            break;

                        case "21":

                            String alignFormatCompPart = "";

                            if (genCol.getAlignment().toString().equals("5"))
                                alignFormatCompPart = "%1$-";
                            else if (genCol.getAlignment().toString().equals("6"))
                                alignFormatCompPart = "%1$";
                            else
                                alignFormatCompPart = "%1$";

                            StringBuilder compPart = addCompOvPart(compPartFilter, vhl.getComposantsOv(), alignFormatCompPart);

                            String sep = "";

                            if (compPartFilter.getSeparator() != null)
                                sep = compPartFilter.getSeparator();

                            if (compPart != null && compPart.length() != 0)
                                newLine.append(compPart.toString());

                            newLine.append(sep);

                            break;

                        default:
                            logger.info("{} : INVALID VALUE in Flow Vehicle Metadata : {} ", flowDetails.getFlow(), genCol.getValue());
                            break;

                        }

                        if (genCol.getSeparator() != null)
                            newLine.append(genCol.getSeparator());

                    }
                    body.add(newLine.toString());
                }

            }

        } catch (Exception e) {
            logger.error("{} : ERROR while generating body {} ", flowDetails.getFlow(), e);
        }

        return body;
    }

    /**
     * Adds the comp ov part.
     *
     * @param compPartFilter the comp part filter
     * @param compSet the comp set
     * @return the string builder
     */
    private StringBuilder addCompOvPart(OvCompPartFilterDTO compPartFilter, Set<ComposantsOv> compSet, String align) {
        Long maxOcc = compPartFilter.getMaxOcc();
        StringBuilder compPartBuilder = new StringBuilder();
        String intSep = "";

        try {

            if (compPartFilter.getIntSeparator() != null)
                intSep = compPartFilter.getIntSeparator();

            int intSepFlag = 0;

            Map<Integer, Long> stdMap = compPartFilter.getStdSeqMap();
            for (Map.Entry<Integer, Long> entry : stdMap.entrySet()) {

                if (compSet != null && !compSet.isEmpty())
                    for (ComposantsOv compOv : compSet) {

                        if (maxOcc == 0)
                            break;

                        if (compOv.getStandard().equalsIgnoreCase(FormatManagementConstant.GM1737.getConstValue())
                                && entry.getValue() == FormatManagementConstant.STD22.getConstValueInt()) {
                            StringBuilder stdGM1737 = ovCompPartMapper(compPartFilter, compPartFilter.getStd22PartList(), compOv, align);
                            if (stdGM1737 != null && stdGM1737.length() != 0) {
                                String maxId = align + compPartFilter.getMaxStd() + "s";
                                if (intSepFlag == 0) {
                                    compPartBuilder
                                            .append(String.format(maxId, FormatManagementConstant.GM1737.getConstValue()) + stdGM1737.toString());
                                    maxOcc--;
                                    intSepFlag = 1;
                                } else {
                                    compPartBuilder.append(
                                            intSep + String.format(maxId, FormatManagementConstant.GM1737.getConstValue()) + stdGM1737.toString());
                                    maxOcc--;
                                }
                            }
                        }

                        if (compOv.getStandard().equalsIgnoreCase(FormatManagementConstant.GMW15862.getConstValue())
                                && entry.getValue() == FormatManagementConstant.STD23.getConstValueInt()) {
                            StringBuilder stdGMw15862 = ovCompPartMapper(compPartFilter, compPartFilter.getStd23PartList(), compOv, align);
                            if (stdGMw15862 != null && stdGMw15862.length() != 0) {
                                String maxId = align + compPartFilter.getMaxStd() + "s";
                                if (intSepFlag == 0) {
                                    compPartBuilder
                                            .append(String.format(maxId, FormatManagementConstant.GMW15862.getConstValue()) + stdGMw15862.toString());
                                    maxOcc--;
                                    intSepFlag = 1;
                                } else {
                                    compPartBuilder.append(intSep + FormatManagementConstant.GMW15862.getConstValue() + stdGMw15862.toString());
                                    maxOcc--;
                                }
                            }
                        }

                        if (compOv.getStandard().equalsIgnoreCase(FormatManagementConstant.OTHER.getConstValue())
                                && entry.getValue() == FormatManagementConstant.STD24.getConstValueInt()) {
                            StringBuilder stdOTHER = ovCompPartMapper(compPartFilter, compPartFilter.getStd24PartList(), compOv, align);
                            if (stdOTHER != null && stdOTHER.length() != 0) {
                                String maxId = align + compPartFilter.getMaxStd() + "s";
                                if (intSepFlag == 0) {

                                    compPartBuilder
                                            .append(String.format(maxId, FormatManagementConstant.OTHER.getConstValue()) + stdOTHER.toString());
                                    maxOcc--;
                                    intSepFlag = 1;
                                } else {
                                    compPartBuilder.append(
                                            intSep + String.format(maxId, FormatManagementConstant.OTHER.getConstValue()) + stdOTHER.toString());
                                    maxOcc--;
                                }
                            }
                        }
                    }
            }
            while (maxOcc > 0) {
                int maxLength = compPartFilter.getMaxStd() + compPartFilter.getMaxID() + compPartFilter.getMaxPart() + compPartFilter.getMaxData()
                        + compPartFilter.getMaxSupplier() + compPartFilter.getMaxLabel();
                String maxId = align + maxLength + "s";

                if (intSepFlag == 0) {

                    compPartBuilder.append(String.format(maxId, " "));
                    maxOcc--;
                    intSepFlag = 1;
                } else {
                    compPartBuilder.append(intSep + String.format(maxId, " "));
                    maxOcc--;
                }
            }
        } catch (Exception e) {
            logger.error("Error while adding standards into body line : {} ", e);
        }

        return compPartBuilder;
    }

    /**
     * Ov comp part mapper.
     *
     * @param compPartFilter the comp part filter
     * @param stdPartList the std part list
     * @param compOv the comp ov
     * @return the string builder
     */
    private StringBuilder ovCompPartMapper(OvCompPartFilterDTO compPartFilter, List<Long> stdPartList, ComposantsOv compOv, String align) {

        StringBuilder compPartBuilder = new StringBuilder();
        Map<Integer, Long> partMap = compPartFilter.getPartSeq();
        try {

            for (Map.Entry<Integer, Long> part : partMap.entrySet()) {

                if (part.getValue() == FormatManagementConstant.STD_ID.getConstValueInt()) {
                    String maxId = align + compPartFilter.getMaxID() + "s";
                    if (stdPartList.contains(part.getValue()) && compOv.getEid() != null)
                        compPartBuilder.append(String.format(maxId, compOv.getEid()));
                    else
                        compPartBuilder.append(String.format(maxId, " "));
                }

                if (part.getValue() == FormatManagementConstant.STD_PART.getConstValueInt()) {
                    String maxId = align + compPartFilter.getMaxPart() + "s";
                    if (stdPartList.contains(part.getValue()) && compOv.getPart() != null)
                        compPartBuilder.append(String.format(maxId, compOv.getPart()));
                    else
                        compPartBuilder.append(String.format(maxId, " "));
                }

                if (part.getValue() == FormatManagementConstant.STD_SUPPLIER.getConstValueInt()) {
                    String maxId = align + compPartFilter.getMaxSupplier() + "s";
                    if (stdPartList.contains(part.getValue()) && compOv.getSupplier() != null)
                        compPartBuilder.append(String.format(maxId, compOv.getSupplier()));
                    else
                        compPartBuilder.append(String.format(maxId, " "));
                }

                if (part.getValue() == FormatManagementConstant.STD_DATA.getConstValueInt()) {
                    String maxId = align + compPartFilter.getMaxData() + "s";
                    if (stdPartList.contains(part.getValue()) && compOv.getData() != null)
                        compPartBuilder.append(String.format(maxId, compOv.getData()));
                    else
                        compPartBuilder.append(String.format(maxId, " "));
                }

                if (part.getValue() == FormatManagementConstant.STD_LABEL.getConstValueInt()) {
                    String maxId = align + compPartFilter.getMaxLabel() + "s";
                    if (stdPartList.contains(part.getValue()) && compOv.getLabel() != null)
                        compPartBuilder.append(String.format(maxId, compOv.getLabel()));
                    else
                        compPartBuilder.append(String.format(maxId, " "));
                }

            }

        } catch (Exception e) {
            logger.error("Error while adding componets parts into body line : {} ", e);
        }

        return compPartBuilder;
    }

    /**
     * Setup OV comp filter DTO.
     *
     * @param opflow the opflow
     * @return the ov comp part filter DTO
     */
    private OvCompPartFilterDTO setupOVCompFilterDTO(OutputFlowDetails opflow) {

        OvCompPartFilterDTO compPartFilter = new OvCompPartFilterDTO();
        Map<Integer, Long> stdSeqMap = new TreeMap<>();
        Map<Integer, Long> partSeq = new TreeMap<>();
        List<Long> std22PartList = new ArrayList<>();
        List<Long> std23PartList = new ArrayList<>();
        List<Long> std24PartList = new ArrayList<>();

        try {

            if (opflow != null) {

                Set<OVComponent> oVComponent = opflow.getOvComponents();
                if (oVComponent != null && !oVComponent.isEmpty())
                    for (OVComponent ovcomp : oVComponent) {

                        compPartFilter.setIntSeparator(ovcomp.getIntSeparator());
                        compPartFilter.setSeparator(ovcomp.getSeparator());
                        compPartFilter.setMaxOcc(ovcomp.getMaxOcc());
                        compPartFilter.setAlignment(ovcomp.getAlignment());

                        if (ovcomp.getOvComponentParts() != null && !ovcomp.getOvComponentParts().isEmpty())
                            for (OVComponentPart ovcompPart : ovcomp.getOvComponentParts()) {

                                if (ovcompPart.getIntSeq() != null) {
                                    String[] seq = ovcompPart.getIntSeq().trim().split("\\.");
                                    stdSeqMap.put(Integer.parseInt(seq[0]), ovcompPart.getStandard());

                                    partSeq.put(Integer.parseInt(seq[1]), ovcompPart.getValue());

                                    // Label is always 255
                                    if (ovcompPart.getValue().toString().equals("29"))
                                        compPartFilter.setMaxLabel(FormatManagementConstant.LENGTH255.getConstValueInteger());

                                    // for std GM1737
                                    if (ovcompPart.getStandard() == FormatManagementConstant.STD22.getConstValueInt()) {

                                        // for std
                                        if (compPartFilter.getMaxStd() < FormatManagementConstant.LENGTH6.getConstValueInteger())
                                            compPartFilter.setMaxStd(FormatManagementConstant.LENGTH6.getConstValueInteger());

                                        // ID of 25
                                        if (ovcompPart.getValue().toString().equals("25")
                                                && (compPartFilter.getMaxID() < FormatManagementConstant.LENGTH2.getConstValueInt()))
                                            compPartFilter.setMaxID(FormatManagementConstant.LENGTH2.getConstValueInteger());

                                        // Part 26
                                        if (ovcompPart.getValue().toString().equals("26")
                                                && (compPartFilter.getMaxPart() < FormatManagementConstant.LENGTH4.getConstValueInt()))
                                            compPartFilter.setMaxPart(FormatManagementConstant.LENGTH4.getConstValueInteger());

                                        // Supplier 27
                                        if (ovcompPart.getValue().toString().equals("27")
                                                && (compPartFilter.getMaxSupplier() < FormatManagementConstant.LENGTH1.getConstValueInt()))
                                            compPartFilter.setMaxSupplier(FormatManagementConstant.LENGTH1.getConstValueInteger());

                                        // data 28
                                        if (ovcompPart.getValue().toString().equals("28")
                                                && (compPartFilter.getMaxData() < FormatManagementConstant.LENGTH9.getConstValueInt()))
                                            compPartFilter.setMaxData(FormatManagementConstant.LENGTH9.getConstValueInteger());

                                        std22PartList.add(ovcompPart.getValue());
                                    }

                                    if (ovcompPart.getStandard() == FormatManagementConstant.STD23.getConstValueInt()) {

                                        // for std
                                        if (compPartFilter.getMaxStd() < FormatManagementConstant.LENGTH8.getConstValueInteger())
                                            compPartFilter.setMaxStd(FormatManagementConstant.LENGTH8.getConstValueInteger());

                                        // ID of 25
                                        if (ovcompPart.getValue().toString().equals("25")
                                                && (compPartFilter.getMaxID() < FormatManagementConstant.LENGTH15.getConstValueInt()))
                                            compPartFilter.setMaxID(FormatManagementConstant.LENGTH15.getConstValueInteger());

                                        // Part 26
                                        if (ovcompPart.getValue().toString().equals("26")
                                                && (compPartFilter.getMaxPart() < FormatManagementConstant.LENGTH9.getConstValueInt()))
                                            compPartFilter.setMaxPart(FormatManagementConstant.LENGTH9.getConstValueInteger());

                                        // Supplier 27
                                        if (ovcompPart.getValue().toString().equals("27")
                                                && (compPartFilter.getMaxSupplier() < FormatManagementConstant.LENGTH12.getConstValueInt()))
                                            compPartFilter.setMaxSupplier(FormatManagementConstant.LENGTH12.getConstValueInteger());

                                        // data 28
                                        if (ovcompPart.getValue().toString().equals("28")
                                                && (compPartFilter.getMaxData() < FormatManagementConstant.LENGTH17.getConstValueInt()))
                                            compPartFilter.setMaxData(FormatManagementConstant.LENGTH17.getConstValueInteger());

                                        std23PartList.add(ovcompPart.getValue());
                                    }

                                    if (ovcompPart.getStandard() == FormatManagementConstant.STD24.getConstValueInt()) {

                                        // for std
                                        if (compPartFilter.getMaxStd() < FormatManagementConstant.LENGTH5.getConstValueInteger())
                                            compPartFilter.setMaxStd(FormatManagementConstant.LENGTH5.getConstValueInteger());

                                        // ID of 25
                                        if (ovcompPart.getValue().toString().equals("25")
                                                && (compPartFilter.getMaxID() < FormatManagementConstant.LENGTH2.getConstValueInt()))
                                            compPartFilter.setMaxID(FormatManagementConstant.LENGTH2.getConstValueInteger());

                                        // Part 26
                                        if (ovcompPart.getValue().toString().equals("26")
                                                && (compPartFilter.getMaxPart() < FormatManagementConstant.LENGTH9.getConstValueInt()))
                                            compPartFilter.setMaxPart(FormatManagementConstant.LENGTH9.getConstValueInteger());

                                        // Supplier 27
                                        if (ovcompPart.getValue().toString().equals("27")
                                                && (compPartFilter.getMaxSupplier() < FormatManagementConstant.LENGTH12.getConstValueInt()))
                                            compPartFilter.setMaxSupplier(FormatManagementConstant.LENGTH12.getConstValueInteger());

                                        // data 28
                                        if (ovcompPart.getValue().toString().equals("28")
                                                && (compPartFilter.getMaxData() < FormatManagementConstant.LENGTH255.getConstValueInt()))
                                            compPartFilter.setMaxData(FormatManagementConstant.LENGTH255.getConstValueInteger());

                                        std24PartList.add(ovcompPart.getValue());
                                    }

                                }

                            }
                    } // comp for loop

            }

            compPartFilter.setStdSeqMap(stdSeqMap);
            compPartFilter.setPartSeq(partSeq);
            compPartFilter.setStd22PartList(std22PartList);
            compPartFilter.setStd23PartList(std23PartList);
            compPartFilter.setStd24PartList(std24PartList);

        } catch (Exception e) {
            logger.error("{} : Error while generating sorted seq for comp part {} ", opflow.getFlow(), e);
        }

        return compPartFilter;
    }

    /**
     * Gets the sorted seq value map.
     *
     * @param opflow the opflow
     * @return the sorted seq value map
     */
    private Map<Long, GenericCollectionDTO> getSortedSeqValueMap(OutputFlowDetails opflow) {

        Map<Long, GenericCollectionDTO> seqValueMap = new HashMap<>();
        try {

            if (opflow != null) {

                Set<FlowVhlMetadata> flowVhlMetadataSet = opflow.getFlowVhlMetadatas();
                if (flowVhlMetadataSet != null && !flowVhlMetadataSet.isEmpty())
                    for (FlowVhlMetadata flowVhlMtdt : flowVhlMetadataSet)
                        if (flowVhlMtdt.getSeq() != null && flowVhlMtdt.getValue() != null)
                            seqValueMap.put(flowVhlMtdt.getSeq(), flowVhlMtdt.mapToGenCol());

                Set<GenericCollection> genericCollection = opflow.getGenericCollections();
                if (genericCollection != null && !genericCollection.isEmpty())
                    for (GenericCollection genflow : genericCollection)
                        if (genflow.getSeq() != null && genflow.getValue() != null)
                            seqValueMap.put(genflow.getSeq(), genflow.maptoDto());

                Set<OVComponent> oVComponent = opflow.getOvComponents();
                if (oVComponent != null && !oVComponent.isEmpty())
                    for (OVComponent ovcomp : oVComponent)
                        if (ovcomp.getSeq() != null && ovcomp.getValue() != null)
                            seqValueMap.put(ovcomp.getSeq(), ovcomp.maptoGenColDto());

            }

            if (!seqValueMap.isEmpty())
                new TreeMap<Long, GenericCollectionDTO>(seqValueMap);
        } catch (Exception e) {
            logger.error("{} : ERROR while generating sorted seq of components {} ", opflow.getFlow(), e);
        }

        return seqValueMap;

    }

}
