/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.model.Audit;
import com.inetpsa.ovr.domain.repository.AuditRepository;
import com.inetpsa.ovr.domain.services.AuditService;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.InterfaceAuditDto;

/**
 * The Class AuditServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class AuditServiceImpl implements AuditService {

    /** The audit repository. */
    @Inject
    private AuditRepository auditRepository;

    /**
     * The SpecificationBuilder
     */
    @Inject
    private SpecificationBuilder specificationBuilder;

    private Logger logger = LoggerFactory.getLogger(AuditServiceImpl.class);

    SimpleDateFormat formatter = new SimpleDateFormat(CommonConstant.DATE_FORMAT.getConstValue());
    private static final int CONST23 = 23;
    private static final int CONST59 = 59;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.AuditService#addAudit(com.inetpsa.ovr.domain.model.Audit)
     */
    @Override
    public void addAudit(Audit audit) {
        auditRepository.add(audit);
    }

    @Override
    public Optional<Audit> getLatestAuditByIntName(String interfaceName) {
        logger.info("Entering getLatestAuditByIntName of AuditServiceImpl class ");
        Specification<Audit> auditSpec = specificationBuilder.of(Audit.class).property("interfaceName").equalTo(interfaceName.toUpperCase())
                .ignoringCase().build();
        SortOption opt = new SortOption();
        opt.add("auditPk.dateCreation", Direction.DESCENDING);
        logger.info("Exiting getLatestAuditByIntName of AuditServiceImpl class ");
        return auditRepository.get(auditSpec, opt).findFirst();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.AuditService#getAuditList(com.inetpsa.ovr.interfaces.rest.dto.InterfaceAuditDto, int, int)
     */
    @Override
    public List<InterfaceAuditDto> getAuditList(InterfaceAuditDto interfaceAuditDto, int offsetPositionToStartFrom, int rowsPerPage) {

        SortOption opt = null;
        Specification<Audit> spec = null;
        try {
            logger.info("Entering getAuditList of AuditServiceImpl class ");
            opt = createSortOrder(interfaceAuditDto);
            spec = createAuditFilter(interfaceAuditDto);
            logger.info("Exiting getAuditList of AuditServiceImpl class");
        } catch (Exception e) {
            logger.error("Exception in fetching Audit Data {}", e);
        }

        if (rowsPerPage == CommonConstant.NEGATIVE_MAGIC_NUMBER.getConstValueInt() || rowsPerPage == OVERConstants.MAGICNUMBER0) {

            return auditToInterfaceAuditDto(auditRepository.get(spec, opt).collect(Collectors.toList()));
        }

        return auditToInterfaceAuditDto(
                auditRepository.get(spec, opt).skip(offsetPositionToStartFrom).limit(rowsPerPage).collect(Collectors.toList()));

    }

    private Specification<Audit> createAuditFilter(InterfaceAuditDto interfaceAuditDto) throws ParseException {
        Specification<Audit> spec = specificationBuilder.of(Audit.class).property("auditPk").not().equalTo(null).build();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");

        if (interfaceAuditDto.getInterfaceName() != null) {
            logger.info("Interface get interface {}", interfaceAuditDto.getInterfaceName());
            Specification<Audit> interfaceSpec = specificationBuilder.of(Audit.class).property(CommonConstant.INTERFACE_NAME.getConstValue())
                    .matching("%" + interfaceAuditDto.getInterfaceName().toUpperCase() + "%").ignoringCase().build();
            spec = spec.and(interfaceSpec);
        }
        if (interfaceAuditDto.getFileName() != null) {
            Specification<Audit> fileNameSpec = specificationBuilder.of(Audit.class).property(CommonConstant.AUDIT_FILENAME.getConstValue())
                    .matching("%" + interfaceAuditDto.getFileName().toUpperCase() + "%").ignoringCase().build();
            spec = spec.and(fileNameSpec);
        }
        if (interfaceAuditDto.getErrorCount() != null) {
            Specification<Audit> errorCountSpec = specificationBuilder.of(Audit.class).property(CommonConstant.ERROR_COUNT.getConstValue())
                    .equalTo(interfaceAuditDto.getErrorCount()).build();
            spec = spec.and(errorCountSpec);
        }
        if (interfaceAuditDto.getSuccessCount() != null) {
            Specification<Audit> successCountSpec = specificationBuilder.of(Audit.class).property(CommonConstant.SUCCESS_COUNT.getConstValue())
                    .equalTo(interfaceAuditDto.getSuccessCount()).build();
            spec = spec.and(successCountSpec);
        }
        if (interfaceAuditDto.getFromDateCreation() != null) {

            Specification<Audit> fromDateCreationSpec = specificationBuilder.of(Audit.class)
                    .property(CommonConstant.AUDIT_DATECREATION.getConstValue())
                    .greaterThanOrEqualTo(dateFormatter.parse(interfaceAuditDto.getFromDateCreation())).build();
            spec = spec.and(fromDateCreationSpec);
        }

        if (interfaceAuditDto.getToDateCreation() != null) {
            Date toDate = dateFormatter.parse(interfaceAuditDto.getToDateCreation());
            toDate.setHours(CONST23);
            toDate.setMinutes(CONST59);
            toDate.setSeconds(CONST59);
            Specification<Audit> toDateCreationSpec = specificationBuilder.of(Audit.class).property(CommonConstant.AUDIT_DATECREATION.getConstValue())
                    .lessThanOrEqualTo(toDate).build();
            spec = spec.and(toDateCreationSpec);
        }
        if (interfaceAuditDto.getUserCreation() != null) {
            Specification<Audit> userCreationSpec = specificationBuilder.of(Audit.class).property(CommonConstant.USER_CREATION.getConstValue())
                    .matching("%" + interfaceAuditDto.getUserCreation().toUpperCase() + "%").ignoringCase().build();
            spec = spec.and(userCreationSpec);
        }
        return spec;
    }

    private SortOption createSortOrder(InterfaceAuditDto interfaceAuditDto) {
        SortOption opt = new SortOption();
        Boolean flag = true;

        if (interfaceAuditDto.getInterfaceOrder() != null) {

            if (interfaceAuditDto.getInterfaceOrder().equalsIgnoreCase("asc"))
                opt.add("interfaceName", Direction.ASCENDING);
            else if (interfaceAuditDto.getInterfaceOrder().equalsIgnoreCase("desc"))
                opt.add("interfaceName", Direction.DESCENDING);

            flag = false;
        }
        if (interfaceAuditDto.getFileNameOrder() != null) {
            if (interfaceAuditDto.getFileNameOrder().equalsIgnoreCase("asc"))
                opt.add("auditPk.fileName", Direction.ASCENDING);
            else if (interfaceAuditDto.getFileNameOrder().equalsIgnoreCase("desc"))
                opt.add("auditPk.fileName", Direction.DESCENDING);
            flag = false;
        }
        if (interfaceAuditDto.getErrorCountOrder() != null) {
            if (interfaceAuditDto.getErrorCountOrder().equalsIgnoreCase("asc"))
                opt.add("errorCount", Direction.ASCENDING);
            else if (interfaceAuditDto.getErrorCountOrder().equalsIgnoreCase("desc"))
                opt.add("errorCount", Direction.DESCENDING);

            flag = false;
        }
        if (interfaceAuditDto.getSuccessCountOrder() != null) {
            if (interfaceAuditDto.getSuccessCountOrder().equalsIgnoreCase("asc"))
                opt.add("successCount", Direction.ASCENDING);
            else if (interfaceAuditDto.getSuccessCountOrder().equalsIgnoreCase("desc"))
                opt.add("successCount", Direction.DESCENDING);

            flag = false;
        }
        if (interfaceAuditDto.getDateCreationOrder() != null) {
            if (interfaceAuditDto.getDateCreationOrder().equalsIgnoreCase("asc"))
                opt.add("auditPk.dateCreation", Direction.ASCENDING);
            else if (interfaceAuditDto.getDateCreationOrder().equalsIgnoreCase("desc"))
                opt.add("auditPk.dateCreation", Direction.DESCENDING);

            flag = false;
        }
        if (interfaceAuditDto.getUserCreationOrder() != null) {
            if (interfaceAuditDto.getUserCreationOrder().equalsIgnoreCase("asc"))
                opt.add("userCreation", Direction.ASCENDING);
            else if (interfaceAuditDto.getUserCreationOrder().equalsIgnoreCase("desc"))
                opt.add("userCreation", Direction.DESCENDING);

            flag = false;
        }

        if (flag) {
            logger.info("Setting default Filter");
            opt.add("auditPk.dateCreation", Direction.DESCENDING);
        }
        return opt;
    }

    private List<InterfaceAuditDto> auditToInterfaceAuditDto(List<Audit> auditList) {
        List<InterfaceAuditDto> list = new ArrayList<>();
        try {

            for (Audit audit : auditList)
                list.add(this.getAuditDto(audit));
        } catch (Exception e) {
            logger.error("Exception in fetching Audit Data {}", e);
        }
        return list;
    }

    private InterfaceAuditDto getAuditDto(Audit audit) {

        InterfaceAuditDto interfaceAuditDto = new InterfaceAuditDto();
        interfaceAuditDto.setInterfaceName(audit.getInterfaceName());
        interfaceAuditDto.setFileName(audit.getAuditModelPk().getFileName());
        interfaceAuditDto.setDateCreation(formatter.format(audit.getAuditModelPk().getDateCreation()));
        interfaceAuditDto.setErrorCount(audit.getErrorCount());
        interfaceAuditDto.setSuccessCount(audit.getSuccessCount());
        interfaceAuditDto.setUserCreation(audit.getUserCreation());

        return interfaceAuditDto;
    }

    @Override
    public long getAuditListCount() {
        Specification<Audit> spec = specificationBuilder.of(Audit.class).property("auditPk").not().equalTo(null).build();
        return auditRepository.count(spec);
    }

}
