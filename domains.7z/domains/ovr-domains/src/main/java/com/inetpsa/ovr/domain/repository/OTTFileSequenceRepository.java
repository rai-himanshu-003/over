/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.Service;
import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.FIleSequence;

/**
 * The Interface OTTFileSequenceRepository.
 */
@Service
public interface OTTFileSequenceRepository extends Repository<FIleSequence, Long> {

    /**
     * Gets the OTTF ile sequence number.
     *
     * @return the OTTF ile sequence number
     */
    Number getOTTFIleSequenceNumber();

}
