package com.inetpsa.ovr.interfaces.dto.ws;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Criteria.
 */
public class Criteria {

    /** The vin. */
    @JsonProperty("VIN")
    @SerializedName("VIN")
    private String vin;

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Criteria [vin=" + vin + "]";
    }

}
