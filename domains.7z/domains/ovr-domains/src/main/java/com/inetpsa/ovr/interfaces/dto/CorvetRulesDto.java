/*
 * Creation : 28 Feb 2020
 */
package com.inetpsa.ovr.interfaces.dto;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * The Class CorvetRulesDto.
 */
public class CorvetRulesDto {

    /** The id. */
    private Long id;

    /** The priority. */
    private Integer priority;

    /** The filter type. */
    private Integer filterType;

    /** The vehicle family. */
    private String vehicleFamily;

    /** The production centre. */
    private String productionCentre;

    /** The country. */
    private String country;

    /** The min ecom. */
    private Date minEcom;

    /** The max ecom. */
    private Date maxEcom;

    /** The date creation. */
    private Date dateCreation;

    /** The user creation. */
    private String userCreation;

    /** The date modif. */
    private LocalDateTime dateModif;

    /** The user modif. */
    private String userModif;

    /** The version. */
    private Integer version;

    /** The interface name. */
    private String interfaceName;

    /** The vin. */
    private String vin;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the priority.
     *
     * @param priority the new priority
     */
    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    /**
     * Gets the filter type.
     *
     * @return the filter type
     */
    public Integer getFilterType() {
        return filterType;
    }

    /**
     * Sets the filter type.
     *
     * @param filterType the new filter type
     */
    public void setFilterType(Integer filterType) {
        this.filterType = filterType;
    }

    /**
     * Gets the vehicle family.
     *
     * @return the vehicle family
     */
    public String getVehicleFamily() {
        return vehicleFamily;
    }

    /**
     * Sets the vehicle family.
     *
     * @param vehicleFamily the new vehicle family
     */
    public void setVehicleFamily(String vehicleFamily) {
        this.vehicleFamily = vehicleFamily;
    }

    /**
     * Gets the production centre.
     *
     * @return the production centre
     */
    public String getProductionCentre() {
        return productionCentre;
    }

    /**
     * Sets the production centre.
     *
     * @param productionCentre the new production centre
     */
    public void setProductionCentre(String productionCentre) {
        this.productionCentre = productionCentre;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the min ecom.
     *
     * @return the min ecom
     */
    public Date getMinEcom() {
        return minEcom;
    }

    /**
     * Sets the min ecom.
     *
     * @param minEcom the new min ecom
     */
    public void setMinEcom(Date minEcom) {
        this.minEcom = minEcom;
    }

    /**
     * Gets the max ecom.
     *
     * @return the max ecom
     */
    public Date getMaxEcom() {
        return maxEcom;
    }

    /**
     * Sets the max ecom.
     *
     * @param maxEcom the new max ecom
     */
    public void setMaxEcom(Date maxEcom) {
        this.maxEcom = maxEcom;
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public Date getDateCreation() {
        return dateCreation;
    }

    /**
     * Sets the date creation.
     *
     * @param dateCreation the new date creation
     */
    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Sets the user creation.
     *
     * @param userCreation the new user creation
     */
    public void setUserCreation(String userCreation) {
        this.userCreation = userCreation;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public LocalDateTime getDateModif() {
        return dateModif;
    }

    /**
     * Sets the date modif.
     *
     * @param dateModif the new date modif
     */
    public void setDateModif(LocalDateTime dateModif) {
        this.dateModif = dateModif;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Sets the user modif.
     *
     * @param userModif the new user modif
     */
    public void setUserModif(String userModif) {
        this.userModif = userModif;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the interface name.
     *
     * @return the interface name
     */
    public String getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the interface name.
     *
     * @param interfaceName the new interface name
     */
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Instantiates a new corvet rules dto.
     *
     * @param id the id
     * @param priority the priority
     * @param filterType the filter type
     * @param vehicleFamily the vehicle family
     * @param productionCentre the production centre
     * @param country the country
     * @param minEcom the min ecom
     * @param maxEcom the max ecom
     * @param dateCreation the date creation
     * @param userCreation the user creation
     * @param dateModif the date modif
     * @param userModif the user modif
     * @param version the version
     * @param interfaceName the interface name
     * @param vin the vin
     */

    public CorvetRulesDto(Long id, Integer priority, Integer filterType, String vehicleFamily, String productionCentre, String country, Date minEcom,
            Date maxEcom, Date dateCreation, String userCreation, LocalDateTime dateModif, String userModif, Integer version, String interfaceName,
            String vin) {
        super();
        this.id = id;
        this.priority = priority;
        this.filterType = filterType;
        this.vehicleFamily = vehicleFamily;
        this.productionCentre = productionCentre;
        this.country = country;
        this.minEcom = minEcom;
        this.maxEcom = maxEcom;
        this.dateCreation = dateCreation;
        this.userCreation = userCreation;
        this.dateModif = dateModif;
        this.userModif = userModif;
        this.version = version;
        this.interfaceName = interfaceName;
        this.vin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CorvetRulesDto [id=" + id + ", priority=" + priority + ", filterType=" + filterType + ", vehicleFamily=" + vehicleFamily
                + ", productionCentre=" + productionCentre + ", country=" + country + ", minEcom=" + minEcom + ", maxEcom=" + maxEcom
                + ", dateCreation=" + dateCreation + ", userCreation=" + userCreation + ", dateModif=" + dateModif + ", userModif=" + userModif
                + ", version=" + version + ", interfaceName=" + interfaceName + "]";
    }

}
