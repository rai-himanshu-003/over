/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.cache.annotation.CacheResult;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Hibernate;
import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.model.Cardinality;
import com.inetpsa.ovr.domain.model.CardinalityPk;
import com.inetpsa.ovr.domain.model.Composants;
import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.domain.model.MMVehicleHistory;
import com.inetpsa.ovr.domain.model.MultipleFlowStatus;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.Options2;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.model.ReferencesElectroniques;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.model.VehicleError;
import com.inetpsa.ovr.domain.model.VehicleHistory;
import com.inetpsa.ovr.domain.model.VehicleHistoryPk;
import com.inetpsa.ovr.domain.repository.ArtLcdvOttRepository;
import com.inetpsa.ovr.domain.repository.CardinalityRepository;
import com.inetpsa.ovr.domain.repository.LcdvOttRepository;
import com.inetpsa.ovr.domain.repository.MMVehicleHistoryRepository;
import com.inetpsa.ovr.domain.repository.PsaKeyMappingRepository;
import com.inetpsa.ovr.domain.repository.VehicleComposantsOvRepository;
import com.inetpsa.ovr.domain.repository.VehicleComposantsRepository;
import com.inetpsa.ovr.domain.repository.VehicleErrorRepository;
import com.inetpsa.ovr.domain.repository.VehicleHistoryRepository;
import com.inetpsa.ovr.domain.repository.VehicleOptions2Repository;
import com.inetpsa.ovr.domain.repository.VehicleOptionsRepository;
import com.inetpsa.ovr.domain.repository.VehicleReferencesElectroniquesRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.AuditService;
import com.inetpsa.ovr.domain.services.LcdvJdbcService;
import com.inetpsa.ovr.domain.services.MultipleFlowStatusService;
import com.inetpsa.ovr.domain.services.VehicleService;
import com.inetpsa.ovr.domain.util.DynamicQueryGenerator;
import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.ArtLcdvOttDTO;
import com.inetpsa.ovr.interfaces.dto.ComposantsOvDTO;
import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;
import com.inetpsa.ovr.interfaces.dto.OptionsDTO;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;
import com.inetpsa.ovr.interfaces.dto.ws.ComponentsOv;
import com.inetpsa.ovr.interfaces.dto.ws.Criteria;
import com.inetpsa.ovr.interfaces.dto.ws.Header;
import com.inetpsa.ovr.interfaces.dto.ws.RequestObj;
import com.inetpsa.ovr.interfaces.dto.ws.Response;
import com.inetpsa.ovr.interfaces.dto.ws.ResponseObj;
import com.inetpsa.ovr.interfaces.dto.ws.VehiculeData;
import com.inetpsa.ovr.interfaces.dto.ws.Vehicules;
import com.inetpsa.ovr.interfaces.mapper.DataMapper;

/**
 * The Class VehicleServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")

public class VehicleServiceImpl implements VehicleService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleServiceImpl.class);

    /** The vehicle repository. */
    @Inject
    private VehicleRepository vehicleRepository;

    /** The vehicle history repository. */
    @Inject
    private VehicleHistoryRepository vehicleHistoryRepository;

    /** The vehicle error repository. */
    @Inject
    private VehicleErrorRepository vehicleErrorRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The specification builder. */
    @Inject
    private LcdvOttRepository lcdvOttRepository;

    /** The art lcdv ott repository. */
    @Inject
    private ArtLcdvOttRepository artLcdvOttRepository;

    /** The vehicle options repository. */
    @Inject
    private VehicleOptionsRepository vehicleOptionsRepository;

    /** The composants ov repository. */
    @Inject
    private VehicleComposantsOvRepository composantsOvRepository;

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The mapping repository. */
    @Inject
    private PsaKeyMappingRepository mappingRepository;

    /** The cardinality repository. */
    @Inject
    private CardinalityRepository cardinalityRepository;

    /** The multiple flow status service. */
    @Inject
    private MultipleFlowStatusService multipleFlowStatusService;

    /** The references electroniques repository. */
    @Inject
    private VehicleReferencesElectroniquesRepository referencesElectroniquesRepository;

    /** The composants repository. */
    @Inject
    private VehicleComposantsRepository composantsRepository;

    /** The lcdv jdbc service. */
    @Inject
    private LcdvJdbcService lcdvJdbcService;

    /** The connection. */
    @Inject
    private Connection connection;

    /** The vehicle options repository. */
    @Inject
    private VehicleOptions2Repository vehicleOptions2Repository;

    /** The audit service. */
    @Inject
    private AuditService auditService;
    @Inject
    private MMVehicleHistoryRepository mmVehicleHistoryRepository;

    /** The Constant FILE_FORMAT_DATE_EXT. */
    private static final String FILE_FORMAT_DATE_EXT = "yyyyMMdd";

    /** The Constant FILE_FORMAT_DATE_OTH. */
    private static final String FILE_FORMAT_DATE_OTH = "yyyyMMddHHmmss";

    /**
     * Method to set the audit service.
     *
     * @param auditService the auditService
     */
    public void setAuditService(AuditService auditService) {
        this.auditService = auditService;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#updateVehiclesAndLcdv(java.util.List, java.util.List)
     */
    @Override
    public void updateVehiclesAndLcdv(List<Vehicle> vehicles, List<String[]> lcdvTokenList, String flowname, List<String> multipleFlowStatusList,
            String statusCode, long count) {
        int tokenIndex = 0;
        List<BigDecimal> seqList = lcdvOttRepository.getSequenceCount(count);
        int seqIndex = 0;

        StringBuilder vinString = new StringBuilder();
        List<String> listOfVin = new ArrayList<>();
        int index = 0;

        // As per over 73, deleting old LCDV before saving new list
        logger.info("Before removing the existing lcdv");
        if (vehicles != null && !vehicles.isEmpty()) {
            for (Vehicle vehicle : vehicles) {
                vinString.append("'" + vehicle.getVinNo() + "',");

                if ((index % CommonConstant.CONSTANT_1000.getConstValueInt() == CommonConstant.CONSTANT_999.getConstValueInt())
                        || (index == (vehicles.size() - CommonConstant.CONSTANT_1.getConstValueInt()))) {
                    listOfVin.add(vinString.toString().substring(0, vinString.length() - CommonConstant.CONSTANT_1.getConstValueInt()));
                    vinString.setLength(CommonConstant.CONSTANT_0.getConstValueInt());
                }

                index++;
            }

            if (listOfVin != null && !listOfVin.isEmpty()) {

                StringBuilder idInClouse = new StringBuilder();
                index = 0;
                for (String vin : listOfVin) {
                    idInClouse.append(" lcdv.vin in (" + vin + ")  ");

                    if (listOfVin.size() - CommonConstant.CONSTANT_1.getConstValueInt() != index)
                        idInClouse.append(" OR ");

                    index++;
                }

                String queryForMfs = "delete from  LcdvOtt lcdv where " + idInClouse;

                int numberOfRecordsUpdated = this.entityManager.createQuery(queryForMfs).executeUpdate();

                logger.info("LCDV delete query : {} ", queryForMfs);
                logger.info("Number of records deleted :: {} ", numberOfRecordsUpdated);

            }
        }
        logger.info("After removing the existing lcdv");

        logger.info("Saving Vehicle History, Vehicle Data and lcdv Started");
        for (Vehicle vehicle : vehicles) {
            this.addVehicleHistory(vehicle, flowname);

            Optional<Vehicle> aggr = vehicleRepository.get(vehicle.getVinNo());
            if (aggr.isPresent()) {
                aggr.get().setCurrentState(null);
                aggr.get().setLcdv24(vehicle.getLcdv24());
                aggr.get().setCcp(vehicle.getCcp());
                vehicleRepository.update(aggr.get());
            }

            String[] lcdvToken = lcdvTokenList.get(tokenIndex);

            for (String spString : lcdvToken) {

                LcdvOtt lcdvOtt = new LcdvOtt();
                lcdvOtt.setVin(vehicle.getVinNo());
                lcdvOtt.setId(seqList.get(seqIndex).longValue());
                seqIndex++;
                lcdvOtt.setCharacteristic(
                        spString.substring(CommonConstant.CONSTANT_0.getConstValueInt(), CommonConstant.CONSTANT_3.getConstValueInt()));
                lcdvOtt.setValue(spString.substring(CommonConstant.CONSTANT_3.getConstValueInt(), CommonConstant.CONSTANT_5.getConstValueInt()));
                lcdvOtt.setNature(spString.substring(CommonConstant.CONSTANT_5.getConstValueInt(), CommonConstant.CONSTANT_6.getConstValueInt()));
                lcdvOtt.setIndicator(spString.substring(CommonConstant.CONSTANT_6.getConstValueInt(), CommonConstant.CONSTANT_7.getConstValueInt()));

                lcdvOttRepository.add(lcdvOtt);

            }

            tokenIndex++;

        }
        logger.info("Saving Vehicle History, Vehicle Data and LCDV ended");

        logger.info("Saving multiple Flow Status started ");
        multipleFlowStatusService.updateflowstate(multipleFlowStatusList, statusCode);
        logger.info("Saving multiple Flow Status ended ");

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#addVehiclesAndLcdv(java.util.List, java.util.List, java.lang.String, long)
     */
    @Override
    public void addVehiclesAndLcdv(List<Vehicle> vehicles, List<String[]> lcdvTokenList, String flowname, long count) {
        int tokenIndex = 0;
        List<BigDecimal> seqList = lcdvOttRepository.getSequenceCount(count);
        int seqIndex = 0;

        logger.info("Saving Vehicle History, Vehicle Data and Lcdv started");
        for (Vehicle vehicle : vehicles) {
            this.addVehicleHistory(vehicle, flowname);
            vehicleRepository.addOrUpdate(vehicle);

            String[] lcdvToken = lcdvTokenList.get(tokenIndex);

            for (String spString : lcdvToken) {
                LcdvOtt lcdvOtt = new LcdvOtt();
                lcdvOtt.setVin(vehicle.getVinNo());
                lcdvOtt.setId(seqList.get(seqIndex).longValue());
                seqIndex++;
                lcdvOtt.setCharacteristic(spString.substring(0, 3));
                lcdvOtt.setValue(spString.substring(3, 5));
                lcdvOtt.setNature(spString.substring(5, 6));
                lcdvOtt.setIndicator(spString.substring(6, 7));
                lcdvOttRepository.add(lcdvOtt);

            }

            tokenIndex++;

        }
        logger.info("Saving Vehicle History, Vehicle Data and LCDV ENDED");

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#updateVehiclesAndArtLcdv(java.util.List, java.util.Map, java.lang.String, java.util.List,
     *      java.lang.String, long)
     */
    @Override
    public void updateVehiclesAndArtLcdv(List<Vehicle> vehicles, Map<String, List<ArtLcdvOtt>> lcdvs, String flowname,
            List<String> multipleFlowStatusList, String statusCode, long count) {

        List<BigDecimal> seqList = artLcdvOttRepository.getSequenceCount(count);
        int seqIndex = 0;

        StringBuilder vinString = new StringBuilder();
        List<String> vinList = new ArrayList<>();
        int index = 0;

        // deleting old LCDV before saving new list
        logger.info("Before removing the existing lcdvs");
        if (vehicles != null && !vehicles.isEmpty()) {
            for (Vehicle vehicle : vehicles) {
                vinString.append("'" + vehicle.getVinNo() + "',");

                if ((index % CommonConstant.CONSTANT_1000.getConstValueInt() == CommonConstant.CONSTANT_999.getConstValueInt())
                        || (index == (vehicles.size() - CommonConstant.CONSTANT_1.getConstValueInt()))) {
                    vinList.add(vinString.toString().substring(CommonConstant.CONSTANT_0.getConstValueInt(),
                            vinString.length() - CommonConstant.CONSTANT_1.getConstValueInt()));
                    vinString.setLength(CommonConstant.CONSTANT_0.getConstValueInt());
                }

                index++;
            }

            if (vinList != null && !vinList.isEmpty()) {

                StringBuilder inClouse = new StringBuilder();
                index = 0;
                for (String vin : vinList) {
                    inClouse.append(" lcdv.vin in (" + vin + ")  ");

                    if (vinList.size() - CommonConstant.CONSTANT_1.getConstValueInt() != index)
                        inClouse.append(" OR ");

                    index++;
                }

                String query = "delete from  ArtLcdvOtt lcdv where " + inClouse;

                int numberOfRecordsUpdated = this.entityManager.createQuery(query).executeUpdate();

                logger.info("LCDV delete query : {} ", query);
                logger.info("Number of records deleted : {} ", numberOfRecordsUpdated);

                // New code to update all vehicles in one go

                String inClouseForVehicle = (inClouse.toString()).replaceAll("lcdv.vin", "lcdv.vinNo");

                String queryForVinUpdate = "update Vehicle lcdv set lcdv.currentState= null , lcdv.dateModif =  SYSDATE , lcdv.userModif = '"
                        + flowname + "' where " + inClouseForVehicle;

                logger.info("Update vehicle query : {} ", queryForVinUpdate);

                int numberOfRecordsUpdated1 = this.entityManager.createQuery(queryForVinUpdate).executeUpdate();

                logger.info("Number of records updated : {} ", numberOfRecordsUpdated1);

            }
        }
        logger.info("After removing the existing lcdv");

        for (Vehicle vehicle : vehicles) {
            this.addVehicleHistory(vehicle, flowname);
            List<ArtLcdvOtt> list = lcdvs.get(vehicle.getVinNo());
            for (ArtLcdvOtt artLcdvOtt : list) {
                artLcdvOtt.setId(seqList.get(seqIndex).longValue());
                seqIndex++;
                artLcdvOttRepository.add(artLcdvOtt);
            }

        }
        logger.info("Saving Vehicle History, Vehicle Data and LCDV Ended");

        logger.info("Saving Multiple Flow Status Started ");
        multipleFlowStatusService.updateflowstate(multipleFlowStatusList, statusCode);
        logger.info("Saving Multiple Flow Status Ended ");

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#addVehicles(java.util.List)
     */
    @Override
    public void addVehicles(List<Vehicle> vehicles, String flowname) {
        try {
            for (Vehicle vehicle : vehicles) {
                this.addVehicleHistory(vehicle, flowname);
                vehicle.setCurrentState(null);
                if (vehicle.getComposants() != null && !vehicle.getComposants().isEmpty()) {
                    vehicle.getComposants().clear();
                }
                if (vehicle.getComposantsOv() != null && !vehicle.getComposantsOv().isEmpty()) {
                    vehicle.getComposantsOv().clear();
                }
                if (vehicle.getOptions() != null && !vehicle.getOptions().isEmpty()) {
                    vehicle.getOptions().clear();
                }
                if (vehicle.getReferencesElectroniques() != null && !vehicle.getReferencesElectroniques().isEmpty()) {
                    vehicle.getReferencesElectroniques().clear();
                }
                vehicleRepository.addOrUpdate(vehicle);
            }
        } catch (Exception e) {
            logger.info("Exception in adding vehicle", e);
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#addVehiclesandRpo(java.util.List, java.util.List, java.lang.String, java.util.List,
     *      java.lang.String, long)
     */
    @Override
    public void addVehiclesandRpo(List<Vehicle> vehicles, List<String[]> rpoTokenList, String flowname, List<String> multipleFlowStatusList,
            String statusCode, long count) {
        int tokenIndex = 0;
        List<BigDecimal> seqList = vehicleOptionsRepository.getSequenceCount(count);
        int seqIndex = 0;

        StringBuilder vinString = new StringBuilder();
        List<String> listOfVin = new ArrayList<>();
        int index = 0;

        // deleting old RPO before saving new list
        logger.info("Before removing the existing rpo");
        if (vehicles != null && !vehicles.isEmpty()) {
            for (Vehicle vehicle : vehicles) {
                vinString.append("'" + vehicle.getVinNo() + "',");

                if ((index % 1000 == 999) || (index == (vehicles.size() - 1))) {
                    listOfVin.add(vinString.toString().substring(0, vinString.length() - 1));
                    vinString.setLength(0);
                }

                index++;
            }

            if (listOfVin != null && !listOfVin.isEmpty()) {

                StringBuilder idInClouse = new StringBuilder();
                index = 0;
                for (String vin : listOfVin) {
                    idInClouse.append(" rpo.vin in (" + vin + ")  ");

                    if (listOfVin.size() - 1 != index)
                        idInClouse.append(" OR ");

                    index++;
                }

                String queryForMfs = "delete from  Options rpo where " + idInClouse;

                int numberOfRecordsUpdated = this.entityManager.createQuery(queryForMfs).executeUpdate();

                logger.info("Rpo delete query : {} ", queryForMfs);
                logger.info("Number of records deleted : {} ", numberOfRecordsUpdated);

            }
        }
        logger.info("After removing the existing rpos ,Saving Vehicle History, Vehicle Data and LCDV STARTED");
        for (Vehicle vehicle : vehicles) {
            this.addVehicleHistory(vehicle, flowname);
            vehicle.setCurrentState(null);
            vehicleRepository.addOrUpdate(vehicle);
            String[] rpoToken = rpoTokenList.get(tokenIndex);

            for (String spString : rpoToken) {
                Options opt = new Options();
                opt.setVin(vehicle.getVinNo());
                opt.setId(seqList.get(seqIndex).longValue());
                seqIndex++;
                opt.setRpoData(spString);
                vehicleOptionsRepository.add(opt);

            }

            tokenIndex++;

        }
        logger.info("Saving Vehicle History, Vehicle Data and RPO ENDED");

        logger.info("Saving Multiple Flow Status Started ");
        multipleFlowStatusService.updateflowstate(multipleFlowStatusList, statusCode);
        logger.info("Saving Multiple Flow Status Ended ");

    }

    /**
     * method to add vehicle history called by addVehicles method.
     *
     * @param vehicle the vehicle
     * @param flowname the flowname
     */
    private void addVehicleHistory(Vehicle vehicle, String flowname) {
        VehicleHistory history = new VehicleHistory();
        VehicleHistoryPk historyPk = new VehicleHistoryPk();
        historyPk.setStateId(vehicle.getCurrentState());
        historyPk.setVinNo(vehicle.getVinNo());
        history.setHistoryModelPk(historyPk);
        history.setFlowname(flowname);

        vehicleHistoryRepository.add(history);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#updateVehicle(com.inetpsa.ovr.domain.model.Vehicle)
     */
    @Override
    public void updateVehicle(Vehicle vehicle, String flowname) {
        this.addVehicleHistory(vehicle, flowname);
        vehicle.setCurrentState(null);
        vehicleRepository.update(vehicle);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getErrList(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto, int, int)
     */
    @Override
    public List<ResendToOTTDto> getErrList(ResendToOTTDto resendToOTTDto, int offsetPositionToStartFrom, int rowsPerPage, boolean toIgnore) {
        return this.vehicleErrorRepository.getErrList(resendToOTTDto, offsetPositionToStartFrom, rowsPerPage, toIgnore);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#updateStatus(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto, java.lang.String)
     */

    public boolean updateStatus(ResendToOTTDto resendToOTTDto, String vehStatus) {
        boolean status = false;
        List<String> mfs = new ArrayList<>();
        logger.info("Entering updateStatus of VehicleServiceImpl > updateStatus()");
        try {
            MultipleFlowStatusDTO multipleFlowStatusDTO = DataMapper.getFlowDtoFromResendToOTTDto(resendToOTTDto);
            MultipleFlowStatus aggregate = this.multipleFlowStatusService.getByVinFlowState(multipleFlowStatusDTO);
            logger.info("Vehicle version from database {}", aggregate.getVersion());
            logger.info("Vehicle version from ui {}", resendToOTTDto.getVersion());
            if (aggregate.getVersion().equals(resendToOTTDto.getVersion())) {
                multipleFlowStatusDTO.setStatus(vehStatus);
                multipleFlowStatusDTO.setId(aggregate.getId());
                mfs.add(aggregate.getId() + "");
                multipleFlowStatusService.updateflowstate(mfs, vehStatus);
                Vehicle vehicle = this.vehicleRepository.getVehicleDetails(multipleFlowStatusDTO.getVin());
                vehicle.setCurrentState(vehStatus);
                addVehicleHistory(vehicle, multipleFlowStatusDTO.getFlow());

                status = true;
            } else {
                logger.error("Version did not match :{}", resendToOTTDto.getVin());
            }
        } catch (Exception e) {
            logger.error("Error occurred while updating for vin : {} ", resendToOTTDto);
            logger.error("Error occurred while updating ", e);
            return status;
        }
        logger.info("Exiting updateStatus of VehicleServiceImpl > updateStatus()");
        return status;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getTotalErrRecords(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto)
     */
    @Override
    public long getTotalErrRecords(ResendToOTTDto resendToOTTDto, boolean toIgnore) {
        return this.vehicleErrorRepository.getTotalErrRecords(resendToOTTDto, toIgnore);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleDetails(java.lang.String)
     */
    @Override
    public Vehicle getVehicleDetails(String vinNo) {

        Vehicle vehicle = vehicleRepository.getVehicleDetails(vinNo);

        Hibernate.initialize(vehicle.getVinNo());
        Hibernate.initialize(vehicle.getReferencesElectroniques());
        Hibernate.initialize(vehicle.getOptions());
        Hibernate.initialize(vehicle.getLcdvOttOv());
        Hibernate.initialize(vehicle.getKeysOv());
        Hibernate.initialize(vehicle.getComposants());
        Hibernate.initialize(vehicle.getComposantsOv());

        return vehicle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleDetailsFrOttResp(java.lang.String)
     */
    @Override
    public Vehicle getVehicleDetailsFrOttResp(String vinNo) {

        return vehicleRepository.getVehicleDetails(vinNo);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getOvVehicleDetails(java.lang.String)
     */
    @Override
    public Optional<Vehicle> getOvVehicleDetails(String vinNo) {

        Optional<Vehicle> vehicle = vehicleRepository.get(vinNo);
        if (vehicle.isPresent() && vehicle.get() != null)
            Hibernate.initialize(vehicle.get().getMultipleFlowStatus());
        return vehicle;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#addVehicleError(com.inetpsa.ovr.domain.model.VehicleError)
     */
    @Override
    public void addVehicleError(VehicleError vehicleError) {
        vehicleErrorRepository.add(vehicleError);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getErrList(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto, int, int)
     */
    @Override
    public List<VehicleDetailsDto> getVehErrHistList(String vin) {

        Specification<VehicleError> spec = null;
        List<VehicleDetailsDto> dtos = new ArrayList<>();

        try {
            logger.info("Entering getVehErrHistList with vin : {} ", vin);

            SortOption opt = new SortOption();
            spec = specificationBuilder.of(VehicleError.class).property("vehicleErrorPk.vinNo").equalTo(vin).build();
            opt.add("vehicleErrorPk.dateCreation", Direction.DESCENDING);
            List<VehicleError> vehicleErrors = this.vehicleErrorRepository.get(spec, opt).collect(Collectors.toList());

            for (VehicleError vehicleError : vehicleErrors) {
                VehicleDetailsDto vehicleDetailsDto = new VehicleDetailsDto();
                vehicleDetailsDto.setVin(vehicleError.getVehicleErrorPk().getVinNo());
                vehicleDetailsDto
                        .setDateCreation(Date.from(vehicleError.getVehicleErrorPk().getDateCreation().atZone(ZoneId.systemDefault()).toInstant()));
                vehicleDetailsDto.setErrCode(vehicleError.getVehicleErrorPk().getErrCode());
                vehicleDetailsDto.setErrComplement(vehicleError.getErrComplement());
                vehicleDetailsDto.setErrMessage(vehicleError.getErrMessage());
                vehicleDetailsDto.setErrDesc(vehicleError.getErrDescription());
                vehicleDetailsDto.setUserCreation(vehicleError.getUserCreation());
                vehicleDetailsDto.setFlowName(vehicleError.getFlowname());
                dtos.add(vehicleDetailsDto);
            }

        } catch (Exception e) {
            logger.error("Exception in getVehErrHistList {}", e);
        }

        return dtos;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehErrHistListCount(java.lang.String)
     */
    @Override
    public long getVehErrHistListCount(String vin) {

        return this.vehicleErrorRepository.getVehErrHistListCount(vin);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehHistList(java.lang.String)
     */
    @Override
    public List<VehicleDetailsDto> getVehHistList(String vin) {

        return this.vehicleHistoryRepository.getVehHistList(vin);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehHistListCount(java.lang.String)
     */
    @Override
    public long getVehHistListCount(String vin) {

        return this.vehicleHistoryRepository.getVehHistListCount(vin);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#updateVehicleDetails(com.inetpsa.ovr.interfaces.rest.dto.VehicleDetailsDto)
     */
    public Boolean updateVehicleDetails(VehicleDetailsDto vehicle, String flowname) {
        Boolean status = false;
        logger.info("Entering updateVehicle of VehicleServiceImpl > updateVehicleDetails()");
        try {
            String newValueLogger = " new value ";
            Vehicle aggregate = this.vehicleRepository.getVehicleDetails(vehicle.getVin());
            logger.info("Vehicle version from database {}", aggregate.getVersion());
            logger.info("Vehicle version from ui {}", vehicle.getVersion());
            StringBuilder changeLog = new StringBuilder();
            if (aggregate.getVersion().equals(vehicle.getVersion())) {
                changeLog.append("CCP (old value: " + aggregate.getCcp() + newValueLogger + vehicle.getCcp() + ") ");
                aggregate.setCcp(vehicle.getCcp());
                changeLog.append("VEH (old value: " + aggregate.getVeh() + newValueLogger + vehicle.getVeh() + ") ");
                aggregate.setVeh(vehicle.getVeh());
                changeLog.append("OA (old value: " + aggregate.getOa() + newValueLogger + vehicle.getOa() + ") ");
                aggregate.setOa(vehicle.getOa());
                changeLog.append("OF (old value: " + aggregate.getOf() + newValueLogger + vehicle.getOf() + ") ");
                aggregate.setOf(vehicle.getOf());
                changeLog.append("UP (old value: " + aggregate.getUp() + newValueLogger + vehicle.getUp() + ") ");
                aggregate.setUp(vehicle.getUp());
                changeLog.append("APVPR (old value: " + aggregate.getApvpr() + newValueLogger + vehicle.getApvpr() + ") ");
                aggregate.setApvpr(vehicle.getApvpr());
                changeLog.append("LCDV24 (old value: " + aggregate.getLcdv24() + newValueLogger + vehicle.getLcdv24() + ") ");
                aggregate.setLcdv24(vehicle.getLcdv24());
                changeLog.append("NRE (old value: " + aggregate.getNre() + newValueLogger + vehicle.getNre() + ") ");
                aggregate.setNre(vehicle.getNre());
                changeLog.append("TVV (old value: " + aggregate.getTvv() + newValueLogger + vehicle.getTvv() + ") ");
                aggregate.setTvv(vehicle.getTvv());
                changeLog.append("Model (old value: " + aggregate.getModel() + newValueLogger + vehicle.getModel() + ") ");
                aggregate.setModel(vehicle.getModel());
                changeLog.append("Model year (old value: " + aggregate.getModelYear() + newValueLogger + vehicle.getModelYear() + ") ");
                aggregate.setModelYear(vehicle.getModelYear());
                changeLog.append("Extension date (old value: " + aggregate.getDateExtension() + newValueLogger + vehicle.getDateExtension() + ") ");
                aggregate.setDateExtension(vehicle.getDateExtension());

                changeLog.append("ECOM date (old value: " + aggregate.getDateEcom() + newValueLogger + vehicle.getDateEcom() + ") ");
                aggregate.setDateEcom(vehicle.getDateEcom());

                changeLog.append("EMON date (old value: " + aggregate.getDateEmon() + newValueLogger + vehicle.getDateEmon() + ") ");
                aggregate.setDateEmon(vehicle.getDateEmon());

                changeLog.append("Country (old value: " + aggregate.getRpoCountry() + newValueLogger + vehicle.getCountry() + ") ");
                aggregate.setRpoCountry(vehicle.getCountry());

                changeLog.append("Engine (old value: " + aggregate.getRpoEngine() + newValueLogger + vehicle.getEngine() + ") ");
                aggregate.setRpoEngine(vehicle.getEngine());

                changeLog.append("Transmission  (old value: " + aggregate.getRpoTransmission() + newValueLogger + vehicle.getTransmission() + ") ");
                aggregate.setRpoTransmission(vehicle.getTransmission());

                changeLog.append("Model name (old value: " + aggregate.getModelName() + newValueLogger + vehicle.getModelName() + ") ");
                aggregate.setModelName(vehicle.getModelName());

                List<MultipleFlowStatus> multipleFlowStatusList = aggregate.getMultipleFlowStatus();

                List<MultipleFlowStatusDTO> multipleFlowStatusDTONew = vehicle.getMultipleFlowStatusDTO();

                logger.info("{}  User : {} update Vehicle : {} on fields {} ", new Date(), LoggedUser.get(), vehicle.getVin(), changeLog);
                Vehicle veh = aggregate;
                vehicleRepository.update(aggregate);

                for (MultipleFlowStatusDTO multipleFlowStatusDTO : multipleFlowStatusDTONew) {
                    for (MultipleFlowStatus multipleFlowStatus : multipleFlowStatusList) {
                        if ((multipleFlowStatus.getId().equals(multipleFlowStatusDTO.getId()))
                                && (!multipleFlowStatus.getStatus().equalsIgnoreCase(multipleFlowStatusDTO.getStatus()))) {
                            List<String> mfs = new ArrayList<>();
                            mfs.add(multipleFlowStatusDTO.getId() + "");
                            multipleFlowStatusService.updateflowstate(mfs, multipleFlowStatusDTO.getStatus());

                            veh.setCurrentState(multipleFlowStatusDTO.getStatus());
                            addVehicleHistory(veh, multipleFlowStatusDTO.getFlow());
                        }
                    }

                }
                veh.setCurrentState(null);
                status = true;
            } else {
                logger.error("Version did not match :{}", vehicle.getVin());
            }
        } catch (

        Exception e) {
            logger.error("Error occurred while updating for vin : {} ", vehicle);
            logger.error("Error occurred while updating ", e);
            return status;
        }
        logger.info("Exiting updateStatus of VehicleServiceImpl > updateVehicleDetails() ");
        return status;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehiclesDetails(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto, int, int)
     */
    @Override
    public List<ResendToOTTDto> getVehiclesDetails(ResendToOTTDto vehicleSearchDto, int offsetPositionToStartFrom, int rowsPerPage) {
        return vehicleRepository.getVehiclesDetailsTest(vehicleSearchDto, offsetPositionToStartFrom, rowsPerPage);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getTotalVehicleCount(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto)
     */
    @Override
    public long getTotalVehicleCount(ResendToOTTDto vehicleSearchDto) {
        try {
            return vehicleRepository.getVehiclesDetailsCount(vehicleSearchDto);
        } catch (Exception e) {
            logger.error("Error occured while calculating filtered vehicle search count {}", e.getMessage());
            return 0;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleInformationWs(com.inetpsa.ovr.interfaces.dto.ws.RequestObj)
     */
    @Override
    public ResponseObj getVehicleInformationWs(RequestObj requestObj) {

        ResponseObj responseObj = null;
        logger.info("Entering into getVehicleInformationWs() ");
        try {
            CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
            CriteriaQuery<Vehicle> vehicleCriteria = builder.createQuery(Vehicle.class);
            Root<Vehicle> c = vehicleCriteria.from(Vehicle.class);
            vehicleCriteria.select(c);
            List<Predicate> vehPredicates = new ArrayList<>();

            Response response = requestObj.getResponse();

            List<Vehicules> list = new ArrayList<>();

            List<String> vehicleData = response.getVehiculeData();
            List<String> rpoCodes = response.getRpoCodes();
            List<String> artLcdv = response.getArtificialLcdv();
            List<ComponentsOv> componentsList = response.getComponentsOv();
            List<String> vinList = new ArrayList<>();
            List<Criteria> criteriaList = requestObj.getCriteria();
            logger.info("Fetching vehicle object");
            for (Criteria criteria : criteriaList) {
                String vin = criteria.getVin();
                vinList.add(vin);
                Predicate vehPredicate = builder.equal((c.get("vinNo")), vin);
                vehPredicates.add(vehPredicate);
            }
            vehicleCriteria.where(builder.or(vehPredicates.toArray(new Predicate[] {})));
            List<Vehicle> vehicleList = this.entityManager.createQuery(vehicleCriteria).getResultList();
            logger.info("After fetching vehicle object");
            Map<String, List<String>> optionsMap = new HashMap<>();
            List<String> validVinList = new ArrayList<>();
            logger.info("Checking non existing VIN");
            for (Vehicle vehicle : vehicleList) {
                String vin = vehicle.getVinNo();
                validVinList.add(vin);
            }
            for (String vin : vinList) {
                if (!validVinList.contains(vin)) {
                    Vehicules vehicules = new Vehicules();
                    vehicules.setVin(vin);
                    vehicules.setExists("N");
                    list.add(vehicules);
                }
            }

            logger.info("Non existing VIN checked");
            if (rpoCodes != null && !rpoCodes.isEmpty() && !validVinList.isEmpty()) {

                List<OptionsDTO> optionsList = lcdvJdbcService.getRpoList(rpoCodes, validVinList);

                for (OptionsDTO options : optionsList) {

                    if (optionsMap.get(options.getVin()) != null) {
                        List<String> listOptions = optionsMap.get(options.getVin());
                        listOptions.add(options.getRpoData());
                        optionsMap.put(options.getVin(), listOptions);
                    } else {
                        List<String> listOptions = new ArrayList<>();
                        listOptions.add(options.getRpoData());
                        optionsMap.put(options.getVin(), listOptions);
                    }
                }
            }

            Map<String, List<String>> lcdvMap = new HashMap<>();

            if (artLcdv != null && !artLcdv.isEmpty() && !validVinList.isEmpty()) {
                logger.info("Before Fetching Artificial LCDV");
                List<ArtLcdvOttDTO> dtoList = lcdvJdbcService.getLcdvList(artLcdv, validVinList);

                for (ArtLcdvOttDTO lcdvOtt : dtoList) {

                    if (lcdvMap.get(lcdvOtt.getVinArtLcdvDto()) != null) {
                        List<String> lcdvList = lcdvMap.get(lcdvOtt.getVinArtLcdvDto());
                        lcdvList.add(lcdvOtt.getFamilyArtLcdvDto() + lcdvOtt.getCodeArtLcdvDto() + lcdvOtt.getValueArtLcdvDto());
                        lcdvMap.put(lcdvOtt.getVinArtLcdvDto(), lcdvList);
                    } else {
                        List<String> lcdvList = new ArrayList<>();
                        lcdvList.add(lcdvOtt.getFamilyArtLcdvDto() + lcdvOtt.getCodeArtLcdvDto() + lcdvOtt.getValueArtLcdvDto());
                        lcdvMap.put(lcdvOtt.getVinArtLcdvDto(), lcdvList);
                    }
                }
                logger.info("After Fetching Artificial LCDV");
            }

            logger.info("Before Fetching PSA KEY and Composant ov");
            // fetching componantsov
            List<PsaKeyMapping> fullPsaMappingList = new LinkedList<>();

            Map<String, List<ComposantsOv>> compOvMap = new HashMap<>();
            Map<String, List<ComposantsOvDTO>> compOvMapPsaStd = new HashMap<>();

            CriteriaBuilder compBuilder = this.entityManager.getCriteriaBuilder();
            CriteriaQuery<ComposantsOv> compCriteria = compBuilder.createQuery(ComposantsOv.class);
            Root<ComposantsOv> compRoot = compCriteria.from(ComposantsOv.class);
            compCriteria.select(compRoot);
            List<Predicate> compPredicates = new ArrayList<>();

            if (componentsList != null && !componentsList.isEmpty() && !validVinList.isEmpty()) {
                for (ComponentsOv componentsOv : componentsList) {
                    logger.info("Componenets Ov {}", componentsOv);
                    if (!(componentsOv.getStandard().contains("PSA_ORGAN") || componentsOv.getStandard().contains("PSA_ELECTRONICS"))) {
                        for (String vin : validVinList) {
                            Predicate compPredicate = this.composantPredicateGenerator(componentsOv, vin, compBuilder, compRoot);
                            compPredicates.add(compPredicate);
                        }
                    } else {
                        Specification<PsaKeyMapping> psaKeySpec = DynamicQueryGenerator.psaKeyQueryGenerator(componentsOv, specificationBuilder);
                        List<PsaKeyMapping> psaKeyList = mappingRepository.get(psaKeySpec).collect(Collectors.toList());
                        fullPsaMappingList.addAll(psaKeyList);

                    }
                }

                compCriteria.where(compBuilder.or(compPredicates.toArray(new Predicate[] {})));
                List<ComposantsOv> composantsListOv = this.entityManager.createQuery(compCriteria).getResultList();

                logger.info("composantsListOv fetched ");

                // for psa key

                List<ComposantsOvDTO> psaComposantsList = null;

                logger.info("before fetching psacomposantSpec");
                if (!fullPsaMappingList.isEmpty() && !validVinList.isEmpty()) {
                    psaComposantsList = lcdvJdbcService.getComposantsFrWs(fullPsaMappingList, validVinList);
                }

                if (composantsListOv != null && !composantsListOv.isEmpty()) {
                    for (ComposantsOv composantsOv : composantsListOv) {

                        if (compOvMap.get(composantsOv.getVin()) != null) {
                            List<ComposantsOv> listCompOv = compOvMap.get(composantsOv.getVin());
                            listCompOv.add(composantsOv);
                            compOvMap.put(composantsOv.getVin(), listCompOv);
                        } else {
                            List<ComposantsOv> listCompOv = new ArrayList<>();
                            listCompOv.add(composantsOv);
                            compOvMap.put(composantsOv.getVin(), listCompOv);
                        }

                    }

                }

                if (psaComposantsList != null && !psaComposantsList.isEmpty()) {
                    for (ComposantsOvDTO composantsOv : psaComposantsList) {

                        if (compOvMapPsaStd.get(composantsOv.getVin()) != null) {
                            List<ComposantsOvDTO> listCompOv = compOvMapPsaStd.get(composantsOv.getVin());
                            listCompOv.add(composantsOv);
                            compOvMapPsaStd.put(composantsOv.getVin(), listCompOv);
                        } else {
                            List<ComposantsOvDTO> listCompOv = new ArrayList<>();
                            listCompOv.add(composantsOv);
                            compOvMapPsaStd.put(composantsOv.getVin(), listCompOv);
                        }

                    }

                }

            }
            for (Vehicle vehicle : vehicleList) {

                String vin = vehicle.getVinNo();
                List<VehiculeData> vehiculeDatas = new ArrayList<>();
                VehiculeData vehiculeData = new VehiculeData();
                Vehicules vehicules = new Vehicules();
                if (vehicleData != null) {
                    if (vehicleData.contains("UP")) {
                        vehiculeData.setUp(vehicle.getUp());
                    }
                    if (vehicleData.contains("LCDV24")) {
                        vehiculeData.setLcdv24(vehicle.getLcdv24());
                    }

                    if (vehicleData.contains("OF")) {
                        vehiculeData.setOf(vehicle.getOf());
                    }

                    if (vehicleData.contains("OA")) {
                        vehiculeData.setOa(vehicle.getOa());
                    }

                    if (vehicleData.contains("DATE_EXTENSION") && vehicle.getDateExtension() != null) {
                        vehiculeData.setDateExtension(new SimpleDateFormat(FILE_FORMAT_DATE_EXT).format(vehicle.getDateExtension()));
                    }

                    if (vehicleData.contains("DATE_ECOM") && vehicle.getDateEcom() != null) {
                        vehiculeData.setDateEcom(new SimpleDateFormat(FILE_FORMAT_DATE_OTH).format(vehicle.getDateEcom()));
                    }

                    if (vehicleData.contains("DATE_EMON") && vehicle.getDateEmon() != null) {
                        vehiculeData.setDateEmon(new SimpleDateFormat(FILE_FORMAT_DATE_OTH).format(vehicle.getDateEmon()));
                    }

                    if (vehicleData.contains("APVPR")) {
                        vehiculeData.setApvpr(vehicle.getApvpr());
                    }

                    if (vehicleData.contains("NRE")) {
                        vehiculeData.setNre(vehicle.getNre());
                    }

                    if (vehicleData.contains("TVV")) {
                        vehiculeData.setTvv(vehicle.getTvv());
                    }

                    if (vehicleData.contains("MODEL")) {
                        vehiculeData.setModel(vehicle.getModel());
                    }

                    if (vehicleData.contains("MODELYEAR")) {
                        vehiculeData.setModelYear(vehicle.getModelYear());
                    }
                }

                List<ComponentsOv> componentsOvs = new ArrayList<>();
                if (!compOvMap.isEmpty() && compOvMap.get(vin) != null) {

                    List<ComposantsOv> compList = compOvMap.get(vin);

                    for (ComposantsOv composantsOv : compList) {
                        ComponentsOv ov = new ComponentsOv();
                        ov.setId(composantsOv.getEid());
                        ov.setLabel(composantsOv.getLabel());
                        ov.setStandard(composantsOv.getStandard());
                        ov.setData(composantsOv.getData());
                        componentsOvs.add(ov);

                    }

                }
                if (!compOvMapPsaStd.isEmpty() && compOvMapPsaStd.get(vin) != null) {

                    List<String> keyList = new ArrayList<>();
                    List<ComposantsOvDTO> compListPsaStd = compOvMapPsaStd.get(vin);
                    for (ComposantsOvDTO psaComposantsOv : compListPsaStd) {
                        PsaKeyMapping psaKeyMapping = psaMappingByOvStd(psaComposantsOv.getStandard(), psaComposantsOv.getEid());
                        String psaKey = psaKeyMapping.getPsaKey();
                        String psaType = psaKeyMapping.getPsaDatatype();
                        keyList.add(psaType + psaKey);
                    }

                    Map<String, Long> psaKeyCount = this.countByStreamToMap(keyList);

                    for (ComposantsOvDTO composantsOv : compListPsaStd) {
                        ComponentsOv ov = new ComponentsOv();

                        PsaKeyMapping psaKeyMapping = psaMappingByOvStd(composantsOv.getStandard(), composantsOv.getEid());
                        Long count = psaKeyCount.get(psaKeyMapping.getPsaDatatype() + psaKeyMapping.getPsaKey());
                        if (count == 1) {
                            logger.info("Count is 1 setting data");
                            ov.setId(psaKeyMapping.getPsaKey());
                            ov.setLabel(composantsOv.getLabel());
                            ov.setStandard(psaKeyMapping.getPsaDatatype());
                            ov.setData(composantsOv.getData());
                            componentsOvs.add(ov);
                        } else {
                            logger.info("Count is more than 1 checking cardinality");
                            int cardinality = this.findCardinality(psaKeyMapping.getPsaDatatype(), psaKeyMapping.getPsaKey());
                            logger.info("cardinality is {}", cardinality);
                            if (count <= cardinality) {
                                logger.info("count is less or equal to cardinality returning all data");
                                ov.setId(psaKeyMapping.getPsaKey());
                                ov.setLabel(composantsOv.getLabel());
                                ov.setStandard(psaKeyMapping.getPsaDatatype());
                                ov.setData(composantsOv.getData());
                                componentsOvs.add(ov);
                            } else {
                                logger.error("Vehicle VIN : {} | ERR_CODE = CARDINALITY | ERR_DESCRITPION = “Too many components of type {}", vin,
                                        psaKeyMapping.getPsaKey());
                            }
                        }

                    }

                }

                vehiculeDatas.add(vehiculeData);

                // packaging all the data
                vehicules.setVin(vin);
                vehicules.setExists("Y");
                if (vehicleData != null)
                    vehicules.setVehiculeData(vehiculeDatas);

                if (!optionsMap.isEmpty())
                    vehicules.setRpoCodes(optionsMap.get(vin));

                if (!lcdvMap.isEmpty())
                    vehicules.setArtificialLcdv(lcdvMap.get(vin));

                if (!componentsOvs.isEmpty())
                    vehicules.setComponentsOv(componentsOvs);

                list.add(vehicules);
            }

            // generating response
            Header header = new Header();
            header.setClient(requestObj.getHeader().getClient());

            responseObj = new ResponseObj();
            responseObj.setVehicules(list);
            responseObj.setHeader(header);

            logger.info("Exiting getVehicleInformationWs() ");

        } catch (Exception e) {
            logger.error("Exception e {}", e);
            return responseObj;

        }
        return responseObj;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#fetchCardinalityByOvStd(java.lang.String, java.lang.String)
     */
    @Override
    @CacheResult(cacheName = "ovCardinality")
    public int fetchCardinalityByOvStd(String ovStd, String ovKey) {

        PsaKeyMapping psaKeyMapping = this.psaMappingByOvStd(ovStd, ovKey);
        if (psaKeyMapping != null) {
            return findCardinality(psaKeyMapping.getPsaDatatype(), psaKeyMapping.getPsaKey());
        }
        return 0;
    }

    /**
     * Psa mapping by ov std.
     *
     * @param ovStd the ov std
     * @param ovKey the ov key
     * @return the psa key mapping
     */
    @CacheResult(cacheName = "psaMapping")
    public PsaKeyMapping psaMappingByOvStd(String ovStd, String ovKey) {

        return mappingRepository.findPsaMapping(ovStd, ovKey);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#findCardinality(java.lang.String, java.lang.String)
     */
    @CacheResult(cacheName = "psaCardinality")
    public int findCardinality(String psaType, String psaKey) {
        logger.info("Entering cache cardinality. Creating Cache");
        CardinalityPk cardinalityPk = new CardinalityPk();
        cardinalityPk.setPsaDataType(psaType);
        cardinalityPk.setPsaKey(psaKey);
        Optional<Cardinality> cardinality = cardinalityRepository.get(cardinalityPk);
        logger.info("Exiting cache cardinality");
        if (cardinality.isPresent()) {
            return cardinality.get().getCardinalityValue();
        }
        return 1;
    }

    /**
     * Count by stream to map.
     *
     * @param inputList the input list
     * @return the map
     */
    public Map<String, Long> countByStreamToMap(List<String> inputList) {
        return inputList.stream().collect(Collectors.toMap(Function.identity(), v -> 1L, Long::sum));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#updateVehicles(java.util.List, java.lang.String, java.util.List)
     */
    @Override
    public void updateVehicles(List<Vehicle> vehicles, String flowname, List<String> multipleFlowStatusList, String statusCode) {

        logger.info("Saving Vehicle History Started");
        for (Vehicle vehicle : vehicles) {
            this.addVehicleHistory(vehicle, flowname);
        }
        logger.info("Saving Vehicle History Ended");

        logger.info("Saving Vehicle Started");

        StringBuilder vinString = new StringBuilder();
        List<String> vinList = new ArrayList<>();
        int index = 0;

        if (vehicles != null && !vehicles.isEmpty()) {
            for (Vehicle vehicle : vehicles) {
                vinString.append("'" + vehicle.getVinNo() + "',");

                if ((index % CommonConstant.CONSTANT_1000.getConstValueInt() == CommonConstant.CONSTANT_999.getConstValueInt())
                        || (index == (vehicles.size() - CommonConstant.CONSTANT_1.getConstValueInt()))) {
                    vinList.add(vinString.toString().substring(CommonConstant.CONSTANT_0.getConstValueInt(),
                            vinString.length() - CommonConstant.CONSTANT_1.getConstValueInt()));
                    vinString.setLength(CommonConstant.CONSTANT_0.getConstValueInt());
                }

                index++;
            }

            if (vinList != null && !vinList.isEmpty()) {

                StringBuilder inClouse = new StringBuilder();
                index = 0;
                for (String vin : vinList) {
                    inClouse.append(" vhl.vinNo in (" + vin + ")  ");

                    if (vinList.size() - CommonConstant.CONSTANT_1.getConstValueInt() != index)
                        inClouse.append(" OR ");

                    index++;
                }

                String queryForVinUpdate = "update Vehicle vhl set vhl.currentState= null , vhl.dateModif =  SYSDATE , vhl.userModif = '" + flowname
                        + "' where " + inClouse;

                logger.info("Update vehicle query : {} ", queryForVinUpdate);

                int numberOfRecordsUpdated1 = this.entityManager.createQuery(queryForVinUpdate).executeUpdate();

                logger.info("Number of records updated : {} ", numberOfRecordsUpdated1);

                /*
                 * for (Vehicle vehicle : vehicles) { Optional<Vehicle> aggr = vehicleRepository.get(vehicle.getVinNo()); if (aggr.isPresent()) {
                 * aggr.get().setCurrentState(null); vehicleRepository.update(aggr.get()); } }
                 */

                logger.info("Saving Vehicle Ended");

            }
        }

        logger.info("Saving multipleFlowStatusDTO Started");
        multipleFlowStatusService.updateflowstate(multipleFlowStatusList, statusCode);
        logger.info("Saving multipleFlowStatusDTO Ended");

    }

    /**
     * Composant predicate generator.
     *
     * @param componentsOv the components ov
     * @param vin the vin
     * @param compBuilder the comp builder
     * @param compRoot the comp root
     * @return the predicate
     */
    private Predicate composantPredicateGenerator(ComponentsOv componentsOv, String vin, CriteriaBuilder compBuilder, Root<ComposantsOv> compRoot) {

        Predicate compPredicate;

        if (componentsOv.getId().contains("|WT")) {
            String[] strFields = componentsOv.getId().split("\\|");
            String compOv = strFields[0];
            if (componentsOv.getStandard().equals("%")) {
                compPredicate = compBuilder.and(compBuilder.notLike((compRoot.get("eid")), compOv + "%"),
                        compBuilder.equal((compRoot.get("vin")), vin));
            } else {
                compPredicate = compBuilder.and(compBuilder.notLike((compRoot.get("eid")), compOv + "%"),
                        compBuilder.like((compRoot.get("standard")), componentsOv.getStandard()), compBuilder.equal((compRoot.get("vin")), vin));
            }

        } else {
            if (componentsOv.getStandard().equals("%") && componentsOv.getId().equals("%")) {
                compPredicate = compBuilder.equal((compRoot.get("vin")), vin);
            } else if (componentsOv.getStandard().equals("%")) {
                compPredicate = compBuilder.and(compBuilder.like((compRoot.get("eid")), componentsOv.getId()),
                        compBuilder.equal((compRoot.get("vin")), vin));
            }

            else if (componentsOv.getId().equals("%")) {
                compPredicate = compBuilder.and(compBuilder.like((compRoot.get("standard")), componentsOv.getStandard()),
                        compBuilder.equal((compRoot.get("vin")), vin));
            }

            else {
                compPredicate = compBuilder.and(compBuilder.like((compRoot.get("eid")), componentsOv.getId()),
                        compBuilder.like((compRoot.get("standard")), componentsOv.getStandard()), compBuilder.equal((compRoot.get("vin")), vin));

            }
        }

        return compPredicate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#addAllCompData(java.util.Set, java.util.Set, java.util.Set, java.util.Set, long, long,
     *      long, long)
     */
    @Override
    public void addAllCompData(Set<Options> vehOptions, Set<Composants> comp, Set<ReferencesElectroniques> ref, Set<ComposantsOv> compOv,
            long optCount, long compCount, long compovCount, long refECount) {
        logger.info("Entering addAllCompData ");
        int seqIndex = 0;
        int compseqIndex = 0;
        int refEseqIndex = 0;

        int compovSeqIndex = 0;
        List<BigDecimal> optSeqList = vehicleOptionsRepository.getSequenceCount(optCount);
        List<BigDecimal> compSeqList = composantsRepository.getSequenceCount(compCount);
        List<BigDecimal> refElecSeqList = referencesElectroniquesRepository.getSequenceCountForRfee(refECount);
        List<BigDecimal> compovSeqList = composantsOvRepository.getSequenceCount(compovCount);

        for (Options options : vehOptions) {
            options.setId(optSeqList.get(seqIndex).longValue());
            seqIndex++;

            vehicleOptionsRepository.add(options);
        }
        if (!comp.isEmpty()) {
            for (Composants composants : comp) {

                composants.setId(compSeqList.get(compseqIndex).longValue());
                compseqIndex++;
                composantsRepository.add(composants);
            }

        }
        if (!ref.isEmpty()) {
            for (ReferencesElectroniques referencesElectroniques : ref) {
                referencesElectroniques.setId(refElecSeqList.get(refEseqIndex).longValue());
                refEseqIndex++;
                referencesElectroniquesRepository.add(referencesElectroniques);
            }

        }
        if (!compOv.isEmpty()) {
            for (ComposantsOv composantsOv : compOv) {
                composantsOv.setId(compovSeqList.get(compovSeqIndex).longValue());
                compovSeqIndex++;
                composantsOvRepository.add(composantsOv);
            }

        }

        logger.info("Exiting addAllCompData ");
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleDetailsToOttReq(java.lang.String)
     */
    public Vehicle getVehicleDetailsToOttReq(String vinNo) {

        Vehicle vehicle = vehicleRepository.getVehicleDetails(vinNo);
        Hibernate.initialize(vehicle.getOptions());

        return vehicle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleDetailsToCorvet(java.lang.String)
     */
    @Override
    public Vehicle getVehicleDetailsToCorvet(String vinNo) {

        Vehicle vehicle = vehicleRepository.getVehicleDetails(vinNo);
        Hibernate.initialize(vehicle.getOptions());
        logger.info("Exiting getVehicleDetailsToCorvet");
        return vehicle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleList(java.util.List)
     */
    @Override
    public List<Vehicle> getVehicleList(List<String> vinList) {
        CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
        CriteriaQuery<Vehicle> vehicleCriteria = builder.createQuery(Vehicle.class);
        Root<Vehicle> c = vehicleCriteria.from(Vehicle.class);
        List<Predicate> vehPredicates = new ArrayList<>();
        for (String item : vinList) {
            Predicate vehPredicate = builder.equal((c.get("vinNo")), item);
            vehPredicates.add(vehPredicate);
        }
        vehicleCriteria.where(builder.or(vehPredicates.toArray(new Predicate[] {})));
        return this.entityManager.createQuery(vehicleCriteria).getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleDetailsToRevOttReq(java.lang.String)
     */
    @Override
    public Vehicle getVehicleDetailsToRevOttReq(String vinNo) {

        Vehicle vehicle = vehicleRepository.getVehicleDetails(vinNo);
        Hibernate.initialize(vehicle.getLcdvOttOv());

        return vehicle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleDetailsToThubReq(java.util.List)
     */
    @Override
    public Map<String, Vehicle> getVehicleDetailsToThubReq(List<String> vinList) {

        logger.info("Started reading vehicle data for THUB {} ", vinList.size());

        StringBuilder vinString = new StringBuilder();
        List<String> listOfVin = new ArrayList<>();
        StringBuilder vinInClouse = new StringBuilder();

        Map<String, Set<Composants>> compMap = new HashMap<>();
        Map<String, Set<Options>> rpoMap = new HashMap<>();
        Map<String, Set<ComposantsOv>> compOvMap = new HashMap<>();

        Map<String, Vehicle> finalVehicleMap = new HashMap<>();

        List<Vehicle> vehicleList = new LinkedList<>();

        int index = 0;

        if (vinList != null && !vinList.isEmpty()) {
            for (String vin : vinList) {
                vinString.append("'" + vin.trim() + "',");

                if ((index % 1000 == 999) || (index == (vinList.size() - 1))) {
                    listOfVin.add(vinString.toString().substring(0, vinString.length() - 1));
                    vinString.setLength(0);
                }

                index++;
            }

        }

        if (listOfVin != null && !listOfVin.isEmpty()) {

            List<Vehicle> vehicles = new LinkedList<>();
            vinInClouse.setLength(0);
            index = 0;
            for (String listVin : listOfVin) {
                vinInClouse.append(" vhl.vinNo in (" + listVin + ")  ");

                if (listOfVin.size() - 1 != index)
                    vinInClouse.append(" OR ");

                index++;
            }

            String queryForvhl = "SELECT vhl  FROM Vehicle vhl where " + vinInClouse;

            vehicles = this.entityManager.createQuery(queryForvhl).getResultList();

            logger.info("Query for vehicle : {} ", queryForvhl);

            List<Options> rpoList = new LinkedList<>();
            vinInClouse.setLength(0);
            index = 0;
            for (String listVin : listOfVin) {
                vinInClouse.append(" rpo.vin in (" + listVin + ")  ");

                if (listOfVin.size() - 1 != index)
                    vinInClouse.append(" OR ");

                index++;
            }

            String queryForRpo = "SELECT rpo  FROM Options rpo where " + vinInClouse;

            rpoList = this.entityManager.createQuery(queryForRpo).getResultList();

            logger.info("Query for Options : {} ", queryForRpo);

            if (rpoList != null && !rpoList.isEmpty()) {
                for (Options rpo : rpoList) {

                    if (rpoMap.get(rpo.getVin()) != null) {
                        Set<Options> rpoDataList = rpoMap.get(rpo.getVin());
                        rpoDataList.add(rpo);
                        rpoMap.put(rpo.getVin(), rpoDataList);
                    } else {
                        Set<Options> rpoDataList = new HashSet<>();
                        rpoDataList.add(rpo);
                        rpoMap.put(rpo.getVin(), rpoDataList);
                    }
                }

            }

            List<ComposantsOv> compOvList = new LinkedList<>();
            vinInClouse.setLength(0);
            index = 0;
            for (String listVin : listOfVin) {
                vinInClouse.append(" compov.vin in (" + listVin + ")  ");

                if (listOfVin.size() - 1 != index)
                    vinInClouse.append(" OR ");

                index++;
            }

            String queryForCompOv = "SELECT compov  FROM ComposantsOv compov where  " + vinInClouse;

            compOvList = this.entityManager.createQuery(queryForCompOv).getResultList();

            logger.info("Query for Composant OV : {} ", queryForCompOv);

            if (compOvList != null && !compOvList.isEmpty()) {
                for (ComposantsOv compOv : compOvList) {

                    if (compOvMap.get(compOv.getVin()) != null) {
                        Set<ComposantsOv> compOvDataList = compOvMap.get(compOv.getVin());
                        compOvDataList.add(compOv);
                        compOvMap.put(compOv.getVin(), compOvDataList);
                    } else {
                        Set<ComposantsOv> compOvDataList = new HashSet<>();
                        compOvDataList.add(compOv);
                        compOvMap.put(compOv.getVin(), compOvDataList);
                    }
                }

            }

            // composants
            List<Composants> compList = new LinkedList<>();
            vinInClouse.setLength(0);
            index = 0;
            for (String listVin : listOfVin) {
                vinInClouse.append(" comp.vin in (" + listVin + ")  ");

                if (listOfVin.size() - 1 != index)
                    vinInClouse.append(" OR ");

                index++;
            }

            String queryForComp = "SELECT comp  FROM Composants comp where  " + vinInClouse;

            compList = this.entityManager.createQuery(queryForComp).getResultList();

            logger.info("Query for Composants : {} ", queryForComp);

            if (compList != null && !compList.isEmpty()) {
                for (Composants comp : compList) {

                    if (compMap.get(comp.getVin()) != null) {
                        Set<Composants> compDataList = compMap.get(comp.getVin());
                        compDataList.add(comp);
                        compMap.put(comp.getVin(), compDataList);
                    } else {
                        Set<Composants> compDataList = new HashSet<>();
                        compDataList.add(comp);
                        compMap.put(comp.getVin(), compDataList);
                    }
                }

            }

            if (vehicles != null && !vehicles.isEmpty()) {

                for (Vehicle vhl : vehicles) {
                    Vehicle detached = new Vehicle();

                    detached.createShallowCopy(vhl);
                    detached.setComposants(compMap.get(detached.getVinNo()));
                    detached.setComposantsOv(compOvMap.get(detached.getVinNo()));
                    detached.setOptions(rpoMap.get(detached.getVinNo()));

                    finalVehicleMap.put(detached.getVinNo(), detached);
                }
            }

        } // if vin list is not null

        logger.info("Ended reading vehicle data for THUB {} ", finalVehicleMap.size());

        return finalVehicleMap;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#saveGepicsData(java.util.List, java.lang.String, java.util.Set, java.util.Set,
     *      java.util.Set, java.util.Set, long, long, long, long)
     */
    @Override
    public void saveGepicsData(List<Vehicle> vehicles, String flowname, Set<Options> vehOptions, Set<Composants> comp,
            Set<ReferencesElectroniques> ref, Set<ComposantsOv> compOv, long optCount, long compCount, long compovCount, long refECount) {
        logger.info("Entering saveGepicsData");
        try {
            for (Vehicle vehicle : vehicles) {
                this.addVehicleHistory(vehicle, flowname);
                vehicle.setCurrentState(null);
                if (vehicle.getComposants() != null && !vehicle.getComposants().isEmpty()) {
                    vehicle.getComposants().clear();
                }
                if (vehicle.getComposantsOv() != null && !vehicle.getComposantsOv().isEmpty()) {
                    vehicle.getComposantsOv().clear();
                }
                if (vehicle.getOptions() != null && !vehicle.getOptions().isEmpty()) {
                    vehicle.getOptions().clear();
                }
                if (vehicle.getReferencesElectroniques() != null && !vehicle.getReferencesElectroniques().isEmpty()) {
                    vehicle.getReferencesElectroniques().clear();
                }
                vehicleRepository.addOrUpdate(vehicle);
            }

            logger.info("After Saving Vehicle data");

            int seqIndex = 0;
            int compseqIndex = 0;
            int refEseqIndex = 0;

            int compovSeqIndex = 0;
            List<BigDecimal> optSeqList = vehicleOptionsRepository.getSequenceCount(optCount);
            List<BigDecimal> compSeqList = composantsRepository.getSequenceCount(compCount);
            List<BigDecimal> refElecSeqList = referencesElectroniquesRepository.getSequenceCountForRfee(refECount);
            List<BigDecimal> compovSeqList = composantsOvRepository.getSequenceCount(compovCount);

            for (Options options : vehOptions) {
                options.setId(optSeqList.get(seqIndex).longValue());
                seqIndex++;

                vehicleOptionsRepository.add(options);
            }
            if (!comp.isEmpty()) {
                for (Composants composants : comp) {

                    composants.setId(compSeqList.get(compseqIndex).longValue());
                    compseqIndex++;
                    composantsRepository.add(composants);
                }

            }
            if (!ref.isEmpty()) {
                for (ReferencesElectroniques referencesElectroniques : ref) {
                    referencesElectroniques.setId(refElecSeqList.get(refEseqIndex).longValue());
                    refEseqIndex++;
                    referencesElectroniquesRepository.add(referencesElectroniques);
                }

            }
            if (!compOv.isEmpty()) {
                for (ComposantsOv composantsOv : compOv) {
                    composantsOv.setId(compovSeqList.get(compovSeqIndex).longValue());
                    compovSeqIndex++;
                    composantsOvRepository.add(composantsOv);
                }

            }
            logger.info("After Saving component data");

        } catch (Exception e) {
            logger.info("Exception in adding vehicle", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#saveGepicsRpo(java.util.List, java.lang.String, java.util.Set, long)
     */
    @Override
    public void saveGepicsRpo(List<Vehicle> vehicles, String flowname, Set<Options> vehOptions, long optCount) {
        logger.info("Entering saveGepicsRpo");
        try {

            StringBuilder vinString = new StringBuilder();
            List<String> vinList = new ArrayList<>();
            int index = 0;
            if (vehicles != null && !vehicles.isEmpty()) {
                for (Vehicle vehicle : vehicles) {

                    this.addVehicleHistory(vehicle, flowname);

                    vinString.append("'" + vehicle.getVinNo() + "',");

                    if ((index % CommonConstant.CONSTANT_1000.getConstValueInt() == CommonConstant.CONSTANT_999.getConstValueInt())
                            || (index == (vehicles.size() - CommonConstant.CONSTANT_1.getConstValueInt()))) {
                        vinList.add(vinString.toString().substring(CommonConstant.CONSTANT_0.getConstValueInt(),
                                vinString.length() - CommonConstant.CONSTANT_1.getConstValueInt()));
                        vinString.setLength(CommonConstant.CONSTANT_0.getConstValueInt());
                    }

                    index++;
                }

                if (vinList != null && !vinList.isEmpty()) {

                    StringBuilder inClouse = new StringBuilder();
                    index = 0;
                    for (String vin : vinList) {
                        inClouse.append(" rpo.vin in (" + vin + ")  ");

                        if (vinList.size() - CommonConstant.CONSTANT_1.getConstValueInt() != index)
                            inClouse.append(" OR ");

                        index++;
                    }

                    String query = "delete from Options rpo where " + inClouse;

                    int numberOfRecordsUpdated = this.entityManager.createQuery(query).executeUpdate();

                    logger.info("Options delete query : {} ", query);
                    logger.info("Number of records deleted : {} ", numberOfRecordsUpdated);

                    // New code to update all vehicles in one go

                    String inClouseForVehicle = (inClouse.toString()).replaceAll("rpo.vin", "rpo.vinNo");

                    String queryForVinUpdate = "update Vehicle rpo set rpo.currentState= null , rpo.dateModif =  SYSDATE , rpo.userModif = '"
                            + flowname + "' where " + inClouseForVehicle;

                    logger.info("Update vehicle query : {} ", queryForVinUpdate);

                    int numberOfRecordsUpdated1 = this.entityManager.createQuery(queryForVinUpdate).executeUpdate();

                    logger.info("Number of records updated : {} ", numberOfRecordsUpdated1);

                }
            }
            logger.info("Saving only rpo data");

            int seqIndex = 0;

            List<BigDecimal> optSeqList = vehicleOptionsRepository.getSequenceCount(optCount);

            for (Options options : vehOptions) {
                options.setId(optSeqList.get(seqIndex).longValue());
                seqIndex++;

                vehicleOptionsRepository.add(options);
            }

            logger.info("After Saving only rpo data");

        } catch (Exception e) {
            logger.info("Exception in adding vehicle", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#saveGepicsDataRpo2(java.util.List, java.lang.String, java.util.Set, java.util.Set,
     *      java.util.Set, java.util.Set, long, long, long, long)
     */
    @Override
    public void saveGepicsDataRpo2(List<Vehicle> vehicles, String flowname, Set<Options2> vehOptions2, Set<Composants> comp,
            Set<ReferencesElectroniques> ref, Set<ComposantsOv> compOv, long optCount, long compCount, long compovCount, long refECount) {
        logger.info("Entering saveGepicsDataRpo2");
        try {
            for (Vehicle vehicle : vehicles) {
                this.addVehicleHistory(vehicle, flowname);
                vehicle.setCurrentState(null);
                if (vehicle.getComposants() != null && !vehicle.getComposants().isEmpty()) {
                    vehicle.getComposants().clear();
                }
                if (vehicle.getComposantsOv() != null && !vehicle.getComposantsOv().isEmpty()) {
                    vehicle.getComposantsOv().clear();
                }
                if (vehicle.getOptions2() != null && !vehicle.getOptions2().isEmpty()) {
                    vehicle.getOptions2().clear();
                }
                if (vehicle.getReferencesElectroniques() != null && !vehicle.getReferencesElectroniques().isEmpty()) {
                    vehicle.getReferencesElectroniques().clear();
                }
                vehicleRepository.addOrUpdate(vehicle);
            }

            logger.info("Saving component data and rpo2");

            int seqIndex = 0;
            int compseqIndex = 0;
            int refEseqIndex = 0;

            int compovSeqIndex = 0;
            List<BigDecimal> optSeqList = vehicleOptions2Repository.getSequenceCount(optCount);
            List<BigDecimal> compSeqList = composantsRepository.getSequenceCount(compCount);
            List<BigDecimal> refElecSeqList = referencesElectroniquesRepository.getSequenceCountForRfee(refECount);
            List<BigDecimal> compovSeqList = composantsOvRepository.getSequenceCount(compovCount);

            for (Options2 options : vehOptions2) {
                options.setId(optSeqList.get(seqIndex).longValue());
                seqIndex++;

                vehicleOptions2Repository.add(options);
            }
            if (!comp.isEmpty()) {
                for (Composants composants : comp) {

                    composants.setId(compSeqList.get(compseqIndex).longValue());
                    compseqIndex++;
                    composantsRepository.add(composants);
                }

            }
            if (!ref.isEmpty()) {
                for (ReferencesElectroniques referencesElectroniques : ref) {
                    referencesElectroniques.setId(refElecSeqList.get(refEseqIndex).longValue());
                    refEseqIndex++;
                    referencesElectroniquesRepository.add(referencesElectroniques);
                }

            }
            if (!compOv.isEmpty()) {
                for (ComposantsOv composantsOv : compOv) {
                    composantsOv.setId(compovSeqList.get(compovSeqIndex).longValue());
                    compovSeqIndex++;
                    composantsOvRepository.add(composantsOv);
                }

            }
            logger.info("After Saving component data and rpo2");

        } catch (Exception e) {
            logger.info("Exception in adding vehicle", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#addOrUpdateVehicle(com.inetpsa.ovr.domain.model.Vehicle)
     */
    @Override
    public boolean addOrUpdateVehicle(Vehicle vehicle) {
        try {
            vehicleRepository.addOrUpdate(vehicle);
            return true;
        } catch (Exception e) {
            logger.info("Exception in adding vehicle", e);
            return false;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleService#getVehicleHistoryList(java.lang.String)
     */
    @Override
    public List<VehicleDetailsDto> getMMVehicleHistoryList(String vin) {
        Specification<MMVehicleHistory> spec = null;
        List<VehicleDetailsDto> dtos = new ArrayList<>();

        try {
            logger.info("Entering getMMVehicleHistoryList with vin : {} ", vin);

            SortOption opt = new SortOption();
            spec = specificationBuilder.of(MMVehicleHistory.class).property("vin").equalTo(vin).build();
            opt.add("operationDate", Direction.DESCENDING);
            List<MMVehicleHistory> mmVehicleHistories = this.mmVehicleHistoryRepository.get(spec, opt).collect(Collectors.toList());
            for (MMVehicleHistory mmVehicleHistory : mmVehicleHistories) {
                VehicleDetailsDto vehicleDetailsDto = new VehicleDetailsDto();
                vehicleDetailsDto.setVin(mmVehicleHistory.getVin());
                vehicleDetailsDto.setDateOperation(mmVehicleHistory.getOperationDate());
                vehicleDetailsDto.setActionType(mmVehicleHistory.getActionType());
                vehicleDetailsDto.setTypeData(mmVehicleHistory.getTypeData());
                vehicleDetailsDto.setValue(mmVehicleHistory.getValue());
                vehicleDetailsDto.setOldValue(mmVehicleHistory.getOldValue());
                vehicleDetailsDto.setStandard(mmVehicleHistory.getStandard());
                vehicleDetailsDto.setId(mmVehicleHistory.getId1());
                vehicleDetailsDto.setData(mmVehicleHistory.getData());
                vehicleDetailsDto.setLabel(mmVehicleHistory.getLabel());
                vehicleDetailsDto.setSupplier(mmVehicleHistory.getSupplier());
                vehicleDetailsDto.setPart(mmVehicleHistory.getPart());
                vehicleDetailsDto.setUserId(mmVehicleHistory.getUserId());
                dtos.add(vehicleDetailsDto);
            }

        } catch (Exception e) {
            logger.error("Exception in getMMVehicleHistoryList {}", e);
        }

        return dtos;
    }
}
