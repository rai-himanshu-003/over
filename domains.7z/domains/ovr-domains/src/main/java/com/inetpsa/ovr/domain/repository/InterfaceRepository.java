/*
 * Creation : 18 Nov 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.Interface;

/**
 * The Interface InterfaceRepository.
 */
public interface InterfaceRepository extends Repository<Interface, Long> {

}
