package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;

import com.inetpsa.ovr.domain.model.FlowStaticMetadata;

/**
 * The Class FlowStaticMetadataDTO.
 */
public class FlowStaticMetadataDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The id. */
    private Long idFlowDto;

    /** The type. */
    private String typeFlowDto;

    /** The value. */
    private String valueFlowDto;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return idFlowDto;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idFlowDto = id;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return typeFlowDto;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
        this.typeFlowDto = type;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return valueFlowDto;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.valueFlowDto = value;
    }

    /**
     * Map tomodel.
     *
     * @return the output flow details
     */
    public FlowStaticMetadata mapTomodel() {
        FlowStaticMetadata flowStaticMetadata = new FlowStaticMetadata();
        flowStaticMetadata.setType(this.getType());
        flowStaticMetadata.setId(this.getId());
        flowStaticMetadata.setValue(this.getValue());
        return flowStaticMetadata;
    }

}
