/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.FIleSequence;
import com.inetpsa.ovr.domain.repository.OTTFileSequenceRepository;

/**
 * The Class OTTFileSequenceRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class OTTFileSequenceRepositoryImpl extends BaseJpaRepository<FIleSequence, Long> implements OTTFileSequenceRepository {

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.OTTFileSequenceRepository#getOTTFIleSequenceNumber()
     */
    @Override
    public Number getOTTFIleSequenceNumber() {
        return (Number) (entityManager.createNativeQuery("select OVRQTOTH.NEXTVAL from dual")).getSingleResult();
    }

}
