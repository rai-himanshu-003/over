/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.OutputFlowDetails;

/**
 * The Interface FlowManagementDetailsRepository.
 */
public interface FlowManagementDetailsRepository extends Repository<OutputFlowDetails, Long> {
}
