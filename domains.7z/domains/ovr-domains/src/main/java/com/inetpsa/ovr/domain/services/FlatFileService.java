/*
 * Creation : 20 Feb 2020
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;

/**
 * The Interface FlatFileService.
 */
@Service
public interface FlatFileService {

    /**
     * Return flat format.
     *
     * @param vehicles the vehicles
     * @param flowDetails the flow details
     * @return the string
     */
    List<StringBuilder> returnFlatFormat(List<Vehicle> vehicles, OutputFlowDetails flowDetails);
}
