/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.MovanoSequence;
import com.inetpsa.ovr.domain.repository.MovanoSequenceRepository;

/**
 * The Class MovanoSequenceRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class MovanoSequenceRepositoryImpl extends BaseJpaRepository<MovanoSequence, Long> implements MovanoSequenceRepository {

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.MovanoSequenceRepository#getMovanoFIleSequenceNumber()
     */
    @Override
    public Number getMovanoFIleSequenceNumber() {
        return (Number) (entityManager.createNativeQuery("select OVRQTMOVANO_SEQ.NEXTVAL from dual")).getSingleResult();
    }

}
