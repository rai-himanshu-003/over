/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.constant;

/**
 * enum for response status constants.
 *
 * @author E566559
 */
public enum ResponseConstant {

    /** The header check. */
    HEADER_CHECK("HRES"),

    /** The success check. */
    SUCCESS_CHECK("BPCD"),

    SUCCESS_CHECK_REVOTT("BOV0"),

    /** The error check. */
    ERROR_CHECK("BERR"),

    /** The footer check. */
    FOOTER_CHECK("F000"),;

    /** The const value. */
    String constValue;

    /**
     * Instantiates a new response constant.
     *
     * @param constValue the const value
     */
    ResponseConstant(String constValue) {
        this.constValue = constValue;
    }

    /**
     * Gets the const value.
     *
     * @return the const value
     */
    public String getConstValue() {
        return constValue;
    }

}
