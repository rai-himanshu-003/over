/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.Interface;

/**
 * The Interface InterfaceRulesService.
 */
@Service
public interface InterfaceService {

    Interface getInterfaceByName(String name);

}
