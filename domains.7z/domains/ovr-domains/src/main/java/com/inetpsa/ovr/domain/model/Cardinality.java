/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

/**
 * The Class Cardinality.
 * 
 * @author E566559
 */
@Entity
@Table(name = "OVRQTCAR")
public class Cardinality extends BaseAggregateRoot<CardinalityPk> {

    /** The cardinality pk. */
    @Identity
    @EmbeddedId
    private CardinalityPk cardinalityPk;

    /** The error count. */
    @Column(name = "CARDINALITY")
    @NotNull
    private Integer cardinalityValue;

    /**
     * Gets the cardinality pk.
     *
     * @return the cardinality pk
     */
    public CardinalityPk getCardinalityPk() {
        return cardinalityPk;
    }

    /**
     * Sets the cardinality pk.
     *
     * @param cardinalityPk the new cardinality pk
     */
    public void setCardinalityPk(CardinalityPk cardinalityPk) {
        this.cardinalityPk = cardinalityPk;
    }

    /**
     * Gets the cardinality value.
     *
     * @return the cardinality value
     */
    public Integer getCardinalityValue() {
        return cardinalityValue;
    }

    /**
     * Sets the cardinality value.
     *
     * @param cardinalityValue the new cardinality value
     */
    public void setCardinalityValue(Integer cardinalityValue) {
        this.cardinalityValue = cardinalityValue;
    }

}
