/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.ReferencesElectroniques;

/**
 * The Class ReferencesElectroniquesDTO.
 */
public class ReferencesElectroniquesDTO {

    /** The id. */

    private Long idRefDto;

    /** The data. */
    private String dataRefDto;

    /** The vin. */

    private String vinRefDto;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return idRefDto;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idRefDto = id;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return dataRefDto;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.dataRefDto = data;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vinRefDto;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vinRefDto = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ReferencesElectroniques [id=" + idRefDto + ", data=" + dataRefDto + ", vin=" + vinRefDto + "]";
    }

    /**
     * Map tomodel.
     *
     * @return the references electroniques
     */
    public ReferencesElectroniques mapTomodel() {

        ReferencesElectroniques referencesElectroniques = new ReferencesElectroniques();
        referencesElectroniques.setData(this.getData());
        referencesElectroniques.setId(this.getId());
        referencesElectroniques.setVin(this.getVin());
        return referencesElectroniques;
    }

}
