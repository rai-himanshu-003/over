/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.interfaces.dto.InterfaceDto;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;

/**
 * The Interface InterfaceRulesService.
 */
@Service
public interface InterfaceRulesService {

    /**
     * Adds the or update interface rule.
     *
     * @param interfaceRulesDto the interface rules dto
     * @return true, if successful
     */
    boolean addOrUpdateInterfaceRule(InterfaceRulesDto interfaceRulesDto);

    /**
     * Gets the interface rules.
     *
     * @param id the id
     * @return the interface rules
     */
    List<InterfaceRulesDto> getInterfaceRules(Long id);

    /**
     * Find by int and priority.
     *
     * @param id the id
     * @param priority the priority
     * @return the interface rule
     */
    InterfaceRule findByIntNameAndPriority(Long id, int priority);

    /**
     * Delete interface rule.
     *
     * @param interfaceId the interface id
     * @return true, if successful
     */
    boolean deleteInterfaceRule(Long interfaceId);

    /**
     * Gets the interface list.
     *
     * @return the interface list
     */
    List<InterfaceDto> getInterfaceList();
}
