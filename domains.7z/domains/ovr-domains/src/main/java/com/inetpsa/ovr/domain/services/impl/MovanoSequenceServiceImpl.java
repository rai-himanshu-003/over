/*
 * Creation : 6 Aug 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import javax.inject.Inject;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.repository.MovanoSequenceRepository;
import com.inetpsa.ovr.domain.services.MovanoSequenceService;

/**
 * The Class MovanoSequenceServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class MovanoSequenceServiceImpl implements MovanoSequenceService {

    /** The movano sequence repository. */
    @Inject
    MovanoSequenceRepository movanoSequenceRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.MovanoSequenceService#getFIleSequenceNumber()
     */
    @Override
    public Number getFIleSequenceNumber() {
        return movanoSequenceRepository.getMovanoFIleSequenceNumber();
    }

}
