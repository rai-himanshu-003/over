/*
 * Creation : 6 Aug 2019
 */
package com.inetpsa.ovr.domain.services;

import org.seedstack.business.Service;

/**
 * The Interface MovanoSequenceService.
 */
@Service
public interface MovanoSequenceService {

    /**
     * Gets the f ile sequence number.
     *
     * @return the f ile sequence number
     */
    Number getFIleSequenceNumber();
}
