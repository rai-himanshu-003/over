/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import javax.inject.Inject;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.repository.OTTFileSequenceRepository;
import com.inetpsa.ovr.domain.services.OTTFileSequenceService;

/**
 * The Class OTTFileSequenceServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class OTTFileSequenceServiceImpl implements OTTFileSequenceService {

    /** The o TT file sequence repository. */
    @Inject
    private OTTFileSequenceRepository oTTFileSequenceRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.OTTFileSequenceService#getOTTFIleSequenceNumber()
     */
    @Override
    public Number getOTTFIleSequenceNumber() {
        return oTTFileSequenceRepository.getOTTFIleSequenceNumber();
    }

}
