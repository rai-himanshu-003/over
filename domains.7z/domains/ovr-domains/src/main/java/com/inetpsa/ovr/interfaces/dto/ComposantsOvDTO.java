/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.ComposantsOv;

/**
 * The Class ComposantsOvDTO added.
 */

public class ComposantsOvDTO {

    /** The id. */

    private Long idComposantsOvDTO;

    /** The data. */

    private String dataComposantsOvDTO;

    /** The vin. */

    private String vinComposantsOvDTO;

    /** The eid. */
    private String eidComposantsOvDTO;

    /** The label. */
    private String labelComposantsOvDTO;

    /** The part. */
    private String partComposantsOvDTO;

    /** The standard. */
    private String standardComposantsOvDTO;

    /** The supplier. */
    private String supplierComposantsOvDTO;

    /**
     * Gets the eid.
     *
     * @return the eid
     */
    public String getEid() {
        return eidComposantsOvDTO;
    }

    /**
     * Sets the eid.
     *
     * @param eid the new eid
     */
    public void setEid(String eid) {
        this.eidComposantsOvDTO = eid;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return labelComposantsOvDTO;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.labelComposantsOvDTO = label;
    }

    /**
     * Gets the part.
     *
     * @return the part
     */
    public String getPart() {
        return partComposantsOvDTO;
    }

    /**
     * Sets the part.
     *
     * @param part the new part
     */
    public void setPart(String part) {
        this.partComposantsOvDTO = part;
    }

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public String getStandard() {
        return standardComposantsOvDTO;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(String standard) {
        this.standardComposantsOvDTO = standard;
    }

    /**
     * Gets the supplier.
     *
     * @return the supplier
     */
    public String getSupplier() {
        return supplierComposantsOvDTO;
    }

    /**
     * Sets the supplier.
     *
     * @param supplier the new supplier
     */
    public void setSupplier(String supplier) {
        this.supplierComposantsOvDTO = supplier;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return idComposantsOvDTO;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idComposantsOvDTO = id;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return dataComposantsOvDTO;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.dataComposantsOvDTO = data;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vinComposantsOvDTO;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vinComposantsOvDTO = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ComposantsOv [id=" + idComposantsOvDTO + ", data=" + dataComposantsOvDTO + ", vin=" + vinComposantsOvDTO + ", eid=" + eidComposantsOvDTO + ", label=" + labelComposantsOvDTO + ", part=" + partComposantsOvDTO + ", standard="
                + standardComposantsOvDTO + ", supplier=" + supplierComposantsOvDTO + "]";
    }

    /**
     * Map tomodel.
     *
     * @return the composants ov
     */
    public ComposantsOv mapTomodel() {
        ComposantsOv composantsOv = new ComposantsOv();
        composantsOv.setData(this.getData());
        composantsOv.setEid(this.getEid());
        composantsOv.setId(this.getId());
        composantsOv.setLabel(this.getLabel());
        composantsOv.setPart(this.getPart());
        composantsOv.setStandard(this.getStandard());
        composantsOv.setSupplier(this.getSupplier());
        composantsOv.setVin(this.getVin());
        return composantsOv;
    }

}
