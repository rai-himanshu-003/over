/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class TechnicalParameter.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTPAR")
public class TechnicalParameter extends BaseAggregateRoot<String> {

    /** The code. */
    @Identity
    @Id
    @Column(name = "CODE")
    private String code;

    /** The lable. */
    @Column(name = "LABEL")
    private String lable;

    /** The value. */
    @Column(name = "VALUE")
    private String value;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private LocalDateTime dateCreation;

    /** The date modif. */
    @Column(name = "DATE_MODIF")
    private LocalDateTime dateModif;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The user modif. */
    @Column(name = "USER_MODIF")
    private String userModif;

    /** The type. */
    @Column(name = "TYPE_OF_DATA")
    private String type;

    /**
     * Instantiates a new technical parameter.
     */
    public TechnicalParameter() {
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the lable.
     *
     * @return the lable
     */
    public String getLable() {
        return lable;
    }

    /**
     * Sets the lable.
     *
     * @param lable the new lable
     */
    public void setLable(String lable) {
        this.lable = lable;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    /**
     * Sets the date creation.
     *
     * @param dateCreation the new date creation
     */
    public void setDateCreation(LocalDateTime dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public LocalDateTime getDateModif() {
        return dateModif;
    }

    /**
     * Sets the date modif.
     *
     * @param dateModif the new date modif
     */
    public void setDateModif(LocalDateTime dateModif) {
        this.dateModif = dateModif;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Sets the user creation.
     *
     * @param userCreation the new user creation
     */
    public void setUserCreation(String userCreation) {
        this.userCreation = userCreation;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Sets the user modif.
     *
     * @param userModif the new user modif
     */
    public void setUserModif(String userModif) {
        this.userModif = userModif;
    }

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        dateCreation = LocalDateTime.now();
        userCreation = LoggedUser.get();
    }

    /**
     * Pre update.
     */
    @PreUpdate
    public void preUpdate() {
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();
    }

    /**
     * Instantiates a new technical parameter.
     *
     * @param code the code
     * @param lable the lable
     * @param value the value
     * @param dateCreation the date creation
     * @param dateModif the date modif
     * @param userCreation the user creation
     * @param userModif the user modif
     * @param type the type
     */
    public TechnicalParameter(String code, String lable, String value, LocalDateTime dateCreation, LocalDateTime dateModif, String userCreation,
            String userModif, String type) {
        super();
        this.code = code;
        this.lable = lable;
        this.value = value;
        this.dateCreation = dateCreation;
        this.dateModif = dateModif;
        this.userCreation = userCreation;
        this.userModif = userModif;
        this.type = type;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "TechnicalParameter [code=" + code + ", lable=" + lable + ", value=" + value + ", dateCreation=" + dateCreation + ", dateModif="
                + dateModif + ", userCreation=" + userCreation + ", userModif=" + userModif + ", type=" + type + "]";
    }

}
