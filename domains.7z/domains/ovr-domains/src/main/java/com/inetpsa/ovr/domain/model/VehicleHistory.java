/*
 * Creation : 2 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class VehicleHistory.
 */
@Entity
@Table(name = "OVRQTHIS")
@DynamicUpdate
public class VehicleHistory extends BaseAggregateRoot<VehicleHistoryPk> {

    /** The vehicle history pk. */
    @Identity
    @EmbeddedId
    private VehicleHistoryPk vehicleHistoryPk;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The flowname. */
    @Column(name = "FLOWNAME")
    private String flowname;

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        userCreation = LoggedUser.get();
        vehicleHistoryPk.setDateCreation(LocalDateTime.now());
    }

    /**
     * Gets the history model pk.
     *
     * @return the history model pk
     */
    public VehicleHistoryPk getHistoryModelPk() {
        return vehicleHistoryPk;
    }

    /**
     * Sets the history model pk.
     *
     * @param vehicleHistoryPk the new history model pk
     */
    public void setHistoryModelPk(VehicleHistoryPk vehicleHistoryPk) {
        this.vehicleHistoryPk = vehicleHistoryPk;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the flowname.
     *
     * @return the flowname
     */
    public String getFlowname() {
        return flowname;
    }

    /**
     * Sets the flowname.
     *
     * @param flowname the new flowname
     */
    public void setFlowname(String flowname) {
        this.flowname = flowname;
    }

    /**
     * Instantiates a new vehicle history.
     *
     * @param vehicleHistoryPk the vehicle history pk
     * @param userCreation the user creation
     * @param flowname the flowname
     */
    public VehicleHistory(VehicleHistoryPk vehicleHistoryPk, String userCreation, String flowname) {
        this.vehicleHistoryPk = vehicleHistoryPk;
        this.userCreation = userCreation;
        this.flowname = flowname;
    }

    /**
     * Instantiates a new vehicle history.
     */
    public VehicleHistory() {
        super();

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "VehicleHistory [vehicleHistoryPk=" + vehicleHistoryPk + ", userCreation=" + userCreation + "]";
    }

}
