/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.PsaKeyMapping;

/**
 * The Interface PsaKeyMappingRepository.
 */
public interface PsaKeyMappingRepository extends Repository<PsaKeyMapping, Long> {

    /**
     * Find unique mapping.
     *
     * @param psaType the psa type
     * @param psaKey the psa key
     * @param ovKey the ov key
     * @param ovStd the ov std
     * @return the psa key mapping
     */
    PsaKeyMapping findUniqueMapping(String psaType, String psaKey, String ovKey, String ovStd);

    /**
     * Find psa mapping.
     *
     * @param ovStd the ov std
     * @param ovKey the ov key
     * @return the psa key mapping
     */
    PsaKeyMapping findPsaMapping(String ovStd, String ovKey);

    /**
     * Find ov mapping.
     *
     * @param psaType the psa type
     * @param psaKey the psa key
     * @return the list
     */
    List<PsaKeyMapping> findOvMapping(String psaType, String psaKey);

}
