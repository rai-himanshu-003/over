/*
 * Creation : 27 May 2021
 */
package com.inetpsa.ovr.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

@Entity
@Table(name = "OVRQTMMTC")
@DynamicUpdate(value = true)
public class TrackChanges extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    // @SequenceGenerator(name = "SEQ_TRA", sequenceName = "OVRQTMMTC_SEQ", allocationSize = 1)
    // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRA")
    private Long id;

    /** The error count. */
    @Column(name = "ERROR_COUNT")
    private int errorCount;

    /** The success count. */
    @Column(name = "SUCCESS_COUNT")
    private int successCount;

    /** The success count. */
    @Column(name = "TOTAL_COUNT")
    private int totalCount;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    @Column(name = "END_DATE")
    private Date endDate;

    @Column(name = "START_DATE")
    private Date startDate;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "STATUS")
    private String status;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private Date dateCreation;

    @PrePersist
    public void prePersist() {

        userCreation = LoggedUser.get();

    }

    public int getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(int errorCount) {
        this.errorCount = errorCount;
    }

    public int getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(int successCount) {
        this.successCount = successCount;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public String getUserCreation() {
        return userCreation;
    }

    public void setUserCreation(String userCreation) {
        this.userCreation = userCreation;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "TrackChanges [id=" + id + ", errorCount=" + errorCount + ", successCount=" + successCount + ", totalCount=" + totalCount
                + ", userCreation=" + userCreation + ", endDate=" + endDate + ", startDate=" + startDate + ", fileName=" + fileName + ", status="
                + status + ", dateCreation=" + dateCreation + "]";
    }

}
