/*
 * Creation : 21 Aug 2019
 */
package com.inetpsa.ovr.domain.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;

/**
 * The VehicleErrorPk class
 * 
 * @author E566559
 */
public class VehicleErrorPk implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The vin no. */
    @Column(name = "VIN")
    private String vinNo;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private LocalDateTime dateCreation;

    /** The err code. */
    @Column(name = "ERR_CODE")
    private String errCode;

    /**
     * Instantiates a new vehicle error pk.
     */
    public VehicleErrorPk() {
    }

    /**
     * Method to get the Vin No
     * 
     * @return String vinNo
     */
    public String getVinNo() {
        return vinNo;
    }

    /**
     * Method to set the VinNo
     * 
     * @param vinNo the vinNo
     */
    public void setVinNo(String vinNo) {
        this.vinNo = vinNo;
    }

    /**
     * Method to get the dateCreation
     * 
     * @return the LocalDateTime
     */
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    /**
     * Method to get the dateCreation
     * 
     * @param dateCreation the DateCreation
     */
    public void setDateCreation(LocalDateTime dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * Method to get the errCode
     * 
     * @return the string
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * method to set the errCode
     * 
     * @param errCode the errCode
     */
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((dateCreation == null) ? 0 : dateCreation.hashCode());
        result = prime * result + ((errCode == null) ? 0 : errCode.hashCode());
        result = prime * result + ((vinNo == null) ? 0 : vinNo.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        VehicleErrorPk other = (VehicleErrorPk) obj;
        if (dateCreation == null) {
            if (other.dateCreation != null)
                return false;
        } else if (!dateCreation.equals(other.dateCreation))
            return false;
        if (errCode == null) {
            if (other.errCode != null)
                return false;
        } else if (!errCode.equals(other.errCode))
            return false;
        if (vinNo == null) {
            if (other.vinNo != null)
                return false;
        } else if (!vinNo.equals(other.vinNo))
            return false;
        return true;
    }

    /**
     * Instantiates a new vehicle error pk.
     * 
     * @param vinNo the vinNo
     * @param errCode the errCode
     */
    public VehicleErrorPk(String vinNo, String errCode) {
        this.vinNo = vinNo;
        this.errCode = errCode;
    }

}
