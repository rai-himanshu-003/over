/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.constant;

/**
 * enum for response status constants.
 *
 * @author E566559
 */
public enum FormatManagementConstant {

    /** The header check. */
    GMW15862("GMW15862"),

    /** The success check. */
    GM1737("GM1737"),

    /** The error check. */
    OTHER("OTHER"),

    /** The footer check. */
    AND(" AND "),

    OR(" OR "), STD22(22l), STD23(23l), STD24(24l), STD_ID(25l), STD_PART(26l), STD_SUPPLIER(27l), STD_DATA(28l), STD_LABEL(29l), LENGTH15(
            15l), LENGTH12(12l), LENGTH3(3l), LENGTH5(5l), LENGTH6(6l), LENGTH7(7l), LENGTH8(8l), LENGTH9(9l), LENGTH10(10l), LENGTH11(11l), LENGTH13(
                    13l), LENGTH14(14l), LENGTH16(16l), LENGTH17(
                            17l), LENGTH18(18l), LENGTH19(19l), LENGTH20(20l), LENGTH21(21l), LENGTH2(2l), LENGTH1(1l), LENGTH4(4l), LENGTH255(255l);

    /** The const value. */
    String constValue;

    /**
     * Instantiates a new common constant.
     *
     * @param constValueInt the const value int
     */
    FormatManagementConstant(long constValueInt) {
        this.constValueInt = constValueInt;
    }

    /** The const value int. */
    Long constValueInt;

    int constValueInteger;

    /**
     * Gets the const value int.
     *
     * @return the const value int
     */
    public long getConstValueInt() {
        return constValueInt;
    }

    public int getConstValueInteger() {
        return constValueInt.intValue();

    }

    /**
     * Instantiates a new response constant.
     *
     * @param constValue the const value
     */
    FormatManagementConstant(String constValue) {
        this.constValue = constValue;
    }

    /**
     * Gets the const value.
     *
     * @return the const value
     */
    public String getConstValue() {
        return constValue;
    }

}
