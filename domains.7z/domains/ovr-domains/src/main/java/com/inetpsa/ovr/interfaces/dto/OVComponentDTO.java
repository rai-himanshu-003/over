package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import com.inetpsa.ovr.domain.model.OVComponent;
import com.inetpsa.ovr.domain.model.OVComponentPart;

/**
 * The Class OVComponentDTO.
 */
public class OVComponentDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The id. */
    private Long id;

    /** The flow id. */
    private Long flowId;

    /** The seq. */
    private Long seq;

    /** The value. */
    private Long value;

    /** The filter. */
    private String filter;

    /** The separator. */
    private String separator;

    /** The alignment. */
    private Long alignment;

    /** The int separator. */
    private String intSeparator;

    /** The max occ. */
    private Long maxOcc;

    /** The ov component part DT os. */
    private Set<OVComponentPartDTO> ovComponentPartDTOs;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the flow id.
     *
     * @return the flow id
     */
    public Long getFlowId() {
        return flowId;
    }

    /**
     * Sets the flow id.
     *
     * @param flowId the new flow id
     */
    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    /**
     * Gets the seq.
     *
     * @return the seq
     */
    public Long getSeq() {
        return seq;
    }

    /**
     * Sets the seq.
     *
     * @param seq the new seq
     */
    public void setSeq(Long seq) {
        this.seq = seq;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * Gets the separator.
     *
     * @return the separator
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * Sets the separator.
     *
     * @param separator the new separator
     */
    public void setSeparator(String separator) {
        this.separator = separator;
    }

    /**
     * Gets the alignment.
     *
     * @return the alignment
     */
    public Long getAlignment() {
        return alignment;
    }

    /**
     * Sets the alignment.
     *
     * @param alignment the new alignment
     */
    public void setAlignment(Long alignment) {
        this.alignment = alignment;
    }

    /**
     * Gets the int separator.
     *
     * @return the int separator
     */
    public String getIntSeparator() {
        return intSeparator;
    }

    /**
     * Sets the int separator.
     *
     * @param intSeparator the new int separator
     */
    public void setIntSeparator(String intSeparator) {
        this.intSeparator = intSeparator;
    }

    /**
     * Gets the max occ.
     *
     * @return the max occ
     */
    public Long getMaxOcc() {
        return maxOcc;
    }

    /**
     * Sets the max occ.
     *
     * @param maxOcc the new max occ
     */
    public void setMaxOcc(Long maxOcc) {
        this.maxOcc = maxOcc;
    }

    /**
     * Gets the ov component part DT os.
     *
     * @return the ov component part DT os
     */
    public Set<OVComponentPartDTO> getOvComponentPartDTOs() {
        return ovComponentPartDTOs;
    }

    /**
     * Sets the ov component part DT os.
     *
     * @param ovComponentPartDTOs the new ov component part DT os
     */
    public void setOvComponentPartDTOs(Set<OVComponentPartDTO> ovComponentPartDTOs) {
        this.ovComponentPartDTOs = ovComponentPartDTOs;
    }

    /**
     * Map tomodel.
     *
     * @return the output flow details
     */
    public OVComponent mapTomodel() {
        Set<OVComponentPart> ovComponentParts = new HashSet();

        OVComponent ovComponent = new OVComponent();
        ovComponent.setFlowId(this.getFlowId());
        ovComponent.setSeq(this.getSeq());
        ovComponent.setSeparator(this.getSeparator());
        ovComponent.setIntSeparator(this.getIntSeparator());
        ovComponent.setMaxOcc(this.getMaxOcc());
        ovComponent.setAlignment(this.getAlignment());
        ovComponent.setValue(this.getValue());
        ovComponent.setFilter(this.getFilter());

        if (this.getOvComponentPartDTOs() != null && !this.getOvComponentPartDTOs().isEmpty()) {
            for (OVComponentPartDTO ovComponentPartDTO : this.getOvComponentPartDTOs()) {
                ovComponentPartDTO.setOvCompId(ovComponent.getId());
                ovComponentParts.add(ovComponentPartDTO.mapTomodel());
            }
            ovComponent.setOvComponentParts(ovComponentParts);

        }
        return ovComponent;
    }

}
