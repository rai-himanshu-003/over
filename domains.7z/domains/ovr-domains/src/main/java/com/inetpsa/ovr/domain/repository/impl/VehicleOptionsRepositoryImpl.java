/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.repository.VehicleOptionsRepository;

/**
 * The Class VehicleOptionsRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleOptionsRepositoryImpl extends BaseJpaRepository<Options, Long> implements VehicleOptionsRepository {
    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The connection. */
    @Inject
    private Connection connection;

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(VehicleOptionsRepositoryImpl.class);

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleOptionsRepository#getSequenceCount(int)
     */
    @Override
    public List<BigDecimal> getSequenceCount(long size) {
        logger.info("Entering getSequenceCount");
        List<BigDecimal> qlist = new ArrayList<>();
        try {

            Query query = super.getEntityManager()
                    .createNativeQuery("select OVRQTVRPO_SEQ.nextval from ( select level from dual connect by level <= :countOfOptions )");
            query.setParameter("countOfOptions", size);
            qlist = query.getResultList();
            logger.info("Exiting getSequenceCount");
            return qlist;

        } catch (Exception e) {
            logger.error("Error while genereting OVRQTVRPO_SEQ number : {}", e.getMessage());

        }
        return qlist;

    }
}