/*
 * Creation : 05 July 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * The Class ResendToOTTDto.
 */
public class ResendToOTTDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -4527943607165453814L;

    /** The vin. */
    private String vin;

    /** The ccp. */
    private String ccp;

    /** The veh. */
    private String veh;

    /** The ext from date. */
    private String extFromDate;

    /** The ext to date. */
    private String extToDate;

    /** The current state. */
    private String currentState;

    /** The flow name. */
    private String flowName;

    /** The vin order. */
    private String vinOrder;

    /** The ccp order. */
    private String ccpOrder;

    /** The veh order. */
    private String vehOrder;

    /** The date creation order. */
    private String dateCreationOrder;

    /** The ext date order. */
    private String extDateOrder;

    /** The code err. */
    private String codeErr;

    /** The label err. */
    private String labelErr;

    /** The complement err. */
    private String complementErr;

    /** The err from date. */
    private String errFromDate;

    /** The err to date. */
    private String errToDate;

    /** The code err order. */
    private String codeErrOrder;

    /** The label err order. */
    private String labelErrOrder;

    /** The complement err order. */
    private String complementErrOrder;

    /** The err date order. */
    private String errDateOrder;

    /** The flow order. */
    private String ottFlow;

    /** The revott flow. */
    private String revottFlow;

    /** The thub flow. */
    private String thubFlow;

    /** The corvet flow. */
    private String corvetFlow;

    /** The ott flow order. */
    private String ottFlowOrder;

    /** The revott flow order. */
    private String revottFlowOrder;

    /** The thub flow order. */
    private String thubFlowOrder;

    /** The corvet flow order. */
    private String corvetFlowOrder;

    /** The user creation order. */
    private String userCreationOrder;

    /** The user creation. */
    private String userCreation;

    /**
     * Gets the user creation order.
     *
     * @return the user creation order
     */
    public String getUserCreationOrder() {
        return userCreationOrder;
    }

    /**
     * Sets the user creation order.
     *
     * @param userCreationOrder the new user creation order
     */
    public void setUserCreationOrder(String userCreationOrder) {
        this.userCreationOrder = userCreationOrder;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Sets the user creation.
     *
     * @param userCreation the new user creation
     */
    public void setUserCreation(String userCreation) {
        this.userCreation = userCreation;
    }

    /**
     * Gets the ott flow order.
     *
     * @return the ott flow order
     */
    public String getOttFlowOrder() {
        return ottFlowOrder;
    }

    /**
     * Sets the ott flow order.
     *
     * @param ottFlowOrder the new ott flow order
     */
    public void setOttFlowOrder(String ottFlowOrder) {
        this.ottFlowOrder = ottFlowOrder;
    }

    /**
     * Gets the revott flow order.
     *
     * @return the revott flow order
     */
    public String getRevottFlowOrder() {
        return revottFlowOrder;
    }

    /**
     * Sets the revott flow order.
     *
     * @param revottFlowOrder the new revott flow order
     */
    public void setRevottFlowOrder(String revottFlowOrder) {
        this.revottFlowOrder = revottFlowOrder;
    }

    /**
     * Gets the thub flow order.
     *
     * @return the thub flow order
     */
    public String getThubFlowOrder() {
        return thubFlowOrder;
    }

    /**
     * Sets the thub flow order.
     *
     * @param thubFlowOrder the new thub flow order
     */
    public void setThubFlowOrder(String thubFlowOrder) {
        this.thubFlowOrder = thubFlowOrder;
    }

    /**
     * Gets the corvet flow order.
     *
     * @return the corvet flow order
     */
    public String getCorvetFlowOrder() {
        return corvetFlowOrder;
    }

    /**
     * Sets the corvet flow order.
     *
     * @param corvetFlowOrder the new corvet flow order
     */
    public void setCorvetFlowOrder(String corvetFlowOrder) {
        this.corvetFlowOrder = corvetFlowOrder;
    }

    /**
     * Gets the ott flow.
     *
     * @return the ott flow
     */
    public String getOttFlow() {
        return ottFlow;
    }

    /**
     * Sets the ott flow.
     *
     * @param ottFlow the new ott flow
     */
    public void setOttFlow(String ottFlow) {
        this.ottFlow = ottFlow;
    }

    /**
     * Gets the revott flow.
     *
     * @return the revott flow
     */
    public String getRevottFlow() {
        return revottFlow;
    }

    /**
     * Sets the revott flow.
     *
     * @param revottFlow the new revott flow
     */
    public void setRevottFlow(String revottFlow) {
        this.revottFlow = revottFlow;
    }

    /**
     * Gets the thub flow.
     *
     * @return the thub flow
     */
    public String getThubFlow() {
        return thubFlow;
    }

    /**
     * Sets the thub flow.
     *
     * @param thubFlow the new thub flow
     */
    public void setThubFlow(String thubFlow) {
        this.thubFlow = thubFlow;
    }

    /**
     * Gets the corvet flow.
     *
     * @return the corvet flow
     */
    public String getCorvetFlow() {
        return corvetFlow;
    }

    /**
     * Sets the corvet flow.
     *
     * @param corvetFlow the new corvet flow
     */
    public void setCorvetFlow(String corvetFlow) {
        this.corvetFlow = corvetFlow;
    }

    /**
     * Gets the date creation order.
     *
     * @return the date creation order
     */
    public String getDateCreationOrder() {
        return dateCreationOrder;
    }

    /**
     * Sets the date creation order.
     *
     * @param dateCreationOrder the new date creation order
     */
    public void setDateCreationOrder(String dateCreationOrder) {
        this.dateCreationOrder = dateCreationOrder;
    }

    /** The Version. */
    private Integer version;

    /**
     * Gets the vin order.
     *
     * @return the vin order
     */
    public String getVinOrder() {
        return vinOrder;
    }

    /**
     * Sets the vin order.
     *
     * @param vinOrder the new vin order
     */
    public void setVinOrder(String vinOrder) {
        this.vinOrder = vinOrder;
    }

    /**
     * Gets the ccp order.
     *
     * @return the ccp order
     */
    public String getCcpOrder() {
        return ccpOrder;
    }

    /**
     * Sets the ccp order.
     *
     * @param ccpOrder the new ccp order
     */
    public void setCcpOrder(String ccpOrder) {
        this.ccpOrder = ccpOrder;
    }

    /**
     * Gets the veh order.
     *
     * @return the veh order
     */
    public String getVehOrder() {
        return vehOrder;
    }

    /**
     * Sets the veh order.
     *
     * @param vehOrder the new veh order
     */
    public void setVehOrder(String vehOrder) {
        this.vehOrder = vehOrder;
    }

    /**
     * Gets the code err order.
     *
     * @return the code err order
     */
    public String getCodeErrOrder() {
        return codeErrOrder;
    }

    /**
     * Sets the code err order.
     *
     * @param codeErrOrder the new code err order
     */
    public void setCodeErrOrder(String codeErrOrder) {
        this.codeErrOrder = codeErrOrder;
    }

    /**
     * Gets the label err order.
     *
     * @return the label err order
     */
    public String getLabelErrOrder() {
        return labelErrOrder;
    }

    /**
     * Sets the label err order.
     *
     * @param labelErrOrder the new label err order
     */
    public void setLabelErrOrder(String labelErrOrder) {
        this.labelErrOrder = labelErrOrder;
    }

    /**
     * Gets the complement err order.
     *
     * @return the complement err order
     */
    public String getComplementErrOrder() {
        return complementErrOrder;
    }

    /**
     * Sets the complement err order.
     *
     * @param complementErrOrder the new complement err order
     */
    public void setComplementErrOrder(String complementErrOrder) {
        this.complementErrOrder = complementErrOrder;
    }

    /**
     * Gets the ext date order.
     *
     * @return the ext date order
     */
    public String getExtDateOrder() {
        return extDateOrder;
    }

    /**
     * Sets the ext date order.
     *
     * @param extDateOrder the new ext date order
     */
    public void setExtDateOrder(String extDateOrder) {
        this.extDateOrder = extDateOrder;
    }

    /**
     * Gets the err date order.
     *
     * @return the err date order
     */
    public String getErrDateOrder() {
        return errDateOrder;
    }

    /**
     * Sets the err date order.
     *
     * @param errDateOrder the new err date order
     */
    public void setErrDateOrder(String errDateOrder) {
        this.errDateOrder = errDateOrder;
    }

    /**
     * Gets the serialversionuid.
     *
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the ccp.
     *
     * @return the ccp
     */
    public String getCcp() {
        return ccp;
    }

    /**
     * Sets the ccp.
     *
     * @param ccp the new ccp
     */
    public void setCcp(String ccp) {
        this.ccp = ccp;
    }

    /**
     * Gets the veh.
     *
     * @return the veh
     */
    public String getVeh() {
        return veh;
    }

    /**
     * Sets the veh.
     *
     * @param veh the new veh
     */
    public void setVeh(String veh) {
        this.veh = veh;
    }

    /**
     * Gets the label err.
     *
     * @return the label err
     */
    public String getLabelErr() {
        return labelErr;
    }

    /**
     * Gets the code err.
     *
     * @return the code err
     */
    public String getCodeErr() {
        return codeErr;
    }

    /**
     * Sets the code err.
     *
     * @param codeErr the new code err
     */
    public void setCodeErr(String codeErr) {
        this.codeErr = codeErr;
    }

    /**
     * Sets the label err.
     *
     * @param labelErr the new label err
     */
    public void setLabelErr(String labelErr) {
        this.labelErr = labelErr;
    }

    /**
     * Gets the ext from date.
     *
     * @return the ext from date
     */
    public String getExtFromDate() {
        return extFromDate;
    }

    /**
     * Sets the ext from date.
     *
     * @param extFromDate the new ext from date
     */
    public void setExtFromDate(String extFromDate) {
        this.extFromDate = extFromDate;
    }

    /**
     * Gets the ext to date.
     *
     * @return the ext to date
     */
    public String getExtToDate() {
        return extToDate;
    }

    /**
     * Sets the ext to date.
     *
     * @param extToDate the new ext to date
     */
    public void setExtToDate(String extToDate) {
        this.extToDate = extToDate;
    }

    /**
     * Gets the err from date.
     *
     * @return the err from date
     */
    public String getErrFromDate() {
        return errFromDate;
    }

    /**
     * Sets the err from date.
     *
     * @param errFromDate the new err from date
     */
    public void setErrFromDate(String errFromDate) {
        this.errFromDate = errFromDate;
    }

    /**
     * Gets the err to date.
     *
     * @return the err to date
     */
    public String getErrToDate() {
        return errToDate;
    }

    /**
     * Sets the err to date.
     *
     * @param errToDate the new err to date
     */
    public void setErrToDate(String errToDate) {
        this.errToDate = errToDate;
    }

    /**
     * Gets the complement err.
     *
     * @return the complement err
     */
    public String getComplementErr() {
        return complementErr;
    }

    /**
     * Sets the complement err.
     *
     * @param complementErr the new complement err
     */
    public void setComplementErr(String complementErr) {
        this.complementErr = complementErr;
    }

    /**
     * Gets the current State.
     *
     * @return the currentState
     */
    public String getCurrentState() {
        return currentState;
    }

    /**
     * Sets the currentState.
     *
     * @param currentState the currentState
     */
    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    /**
     * the current version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the flow name.
     *
     * @return the flow name
     */
    public String getFlowName() {
        return flowName;
    }

    /**
     * Sets the flow name.
     *
     * @param flowName the new flow name
     */
    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    /**
     * Instantiates a new resend to OTT dto.
     */
    public ResendToOTTDto() {
        super();
    }

    /**
     * Instantiates a new resend to OTT dto.
     *
     * @param vin the vin
     * @param ccp the ccp
     * @param up the up
     * @param veh the veh
     * @param model the model
     * @param extFromDate the ext from date
     * @param currentState the current state
     * @param flowName the flow name
     */
    public ResendToOTTDto(String vin, String ccp, String up, String veh, String model, Date extFromDate, String currentState, String flowName) {
        super();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy HH24:mm:ss");
        this.vin = vin;
        ccp = ccp != null ? ccp : "";
        up = up != null ? up : "";
        this.ccp = ccp + "/" + up;
        veh = veh != null ? veh : "";
        model = model != null ? model : "";

        this.veh = veh + "/" + model;

        if (extFromDate != null)
            this.extFromDate = formatter.format(extFromDate);

        this.currentState = currentState;
        this.flowName = flowName;
    }

}
