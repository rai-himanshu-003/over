/*
 * Creation : 17 Apr 2020
 */
package com.inetpsa.ovr.interfaces.dto.json;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.inetpsa.ovr.interfaces.dto.ws.ComponentsOv;

/**
 * The Class OpVehicule.
 */
public class OpVehicule {

    /** The vehicule data. */
    @SerializedName("VEHICULE_DATAS")
    @Expose
    private OpVehiculeData vehiculeData;

    /** The art lcdv. */
    @SerializedName("ART_LCDV")
    @Expose
    private List<String> artLcdv;

    /** The rpo. */
    @SerializedName("RPO")
    @Expose
    private List<String> rpo;

    /** The components ov. */
    @SerializedName("COMPONENTS_OV")
    @Expose
    private List<ComponentsOv> componentsOv;

    /**
     * Gets the vehicule data.
     *
     * @return the vehicule data
     */
    public OpVehiculeData getVehiculeData() {
        return vehiculeData;
    }

    /**
     * Sets the vehicule data.
     *
     * @param vehiculeData the new vehicule data
     */
    public void setVehiculeData(OpVehiculeData vehiculeData) {
        this.vehiculeData = vehiculeData;
    }

    /**
     * Gets the art lcdv.
     *
     * @return the art lcdv
     */
    public List<String> getArtLcdv() {
        return artLcdv;
    }

    /**
     * Sets the art lcdv.
     *
     * @param artLcdv the new art lcdv
     */
    public void setArtLcdv(List<String> artLcdv) {
        this.artLcdv = artLcdv;
    }

    /**
     * Gets the components ov.
     *
     * @return the components ov
     */
    public List<ComponentsOv> getComponentsOv() {
        return componentsOv;
    }

    /**
     * Sets the components ov.
     *
     * @param componentsOv the new components ov
     */
    public void setComponentsOv(List<ComponentsOv> componentsOv) {
        this.componentsOv = componentsOv;
    }

    /**
     * Gets the rpo.
     *
     * @return the rpo
     */
    public List<String> getRpo() {
        return rpo;
    }

    /**
     * Sets the rpo.
     *
     * @param rpo the new rpo
     */
    public void setRpo(List<String> rpo) {
        this.rpo = rpo;
    }

}