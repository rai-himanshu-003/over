/*
 * Creation : 6 Aug 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.Service;
import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.MovanoSequence;

/**
 * The Interface MovanoSequenceRepository.
 */
@Service
public interface MovanoSequenceRepository extends Repository<MovanoSequence, Long> {

    /**
     * Gets the movano F ile sequence number.
     *
     * @return the movano F ile sequence number
     */
    Number getMovanoFIleSequenceNumber();

}
