/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleOptionsRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.VehicleOptionsService;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

// TODO: Auto-generated Javadoc
/**
 * The Class VehicleOptionsServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleOptionsServiceImpl implements VehicleOptionsService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleOptionsServiceImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The vehicle options repository. */
    @Inject
    private VehicleOptionsRepository vehicleOptionsRepository;

    /** The vehicle repo. */
    @Inject
    private VehicleRepository vehicleRepo;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleOptionsService#getOptionsByVin(java.lang.String)
     */
    @Override
    public List<Options> getOptionsByVin(String vin) {
        Specification<Options> spec = specificationBuilder.of(Options.class).property("vin").equalTo(vin).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        return vehicleOptionsRepository.get(spec, opt).collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleOptionsService#deleteOptionsById(java.lang.Long)
     */
    @Override
    public boolean deleteOptionsById(Long options) {
        Optional<Options> tobedeleted = vehicleOptionsRepository.get(options);
        if (tobedeleted.isPresent()) {
            vehicleOptionsRepository.remove(tobedeleted.get());
            logger.info("options {} : has been deleted successfully!", options);

            Optional<Vehicle> optVehicle = vehicleRepo.get(tobedeleted.get().getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }
            return true;
        }
        logger.info("options {} : is not present in DB", options);

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleOptionsService#addOrUpdateOptions(com.inetpsa.ovr.domain.model.Options)
     */
    @Override
    public ResponseDto addOrUpdateOptions(Options options) {
        ResponseDto responseDto = new ResponseDto();
        boolean flag = false;
        try {

            if (options.getId() != null) {
                responseDto.setId(options.getId().toString());
                vehicleOptionsRepository.update(options);

                flag = true;
            } else {

                List<BigDecimal> seqNumber = getSequenceCount(OVERConstants.MAGICNUMBER1);
                if (seqNumber != null) {
                    options.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).longValue());
                    responseDto.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).toString());
                    vehicleOptionsRepository.add(options);
                    flag = true;
                } else {
                    logger.error("Sequence Number is {} Empty from DB : {}", seqNumber, options);

                }
            }
            Optional<Vehicle> optVehicle = vehicleRepo.get(options.getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }

            responseDto.setMsg(flag);
            return responseDto;
        } catch (Exception e) {
            logger.error("Error while adding/updating Options {} : {}", options, e.getMessage());
            responseDto.setMsg(flag);
            return responseDto;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleOptionsService#getSequenceCount(int)
     */
    @Override
    public List<BigDecimal> getSequenceCount(int numberOfSeq) {
        return vehicleOptionsRepository.getSequenceCount(numberOfSeq);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleOptionsService#checkOptionsExist(java.lang.String, java.lang.String)
     */
    @Override
    public boolean checkOptionsExist(String vin, String rpo) {
        Specification<Options> spec = specificationBuilder.of(Options.class).property("vin").equalTo(vin).and().property("rpoData").equalTo(rpo)
                .build();

        return vehicleOptionsRepository.contains(spec);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleOptionsService#getOptionsExist(java.lang.String, java.lang.String)
     */
    @Override
    public Map<Long, Options> getOptionsExist(String vin, String rpo) {
        Specification<Options> spec = specificationBuilder.of(Options.class).property("vin").equalTo(vin).and().property("rpoData").equalTo(rpo)
                .build();
        List<Options> listOpt = vehicleOptionsRepository.get(spec).collect(Collectors.toList());
        Map<Long, Options> optMap = new HashMap<>();
        for (Options options : listOpt) {
            optMap.put(options.getId(), options);
        }
        return optMap;
    }

}