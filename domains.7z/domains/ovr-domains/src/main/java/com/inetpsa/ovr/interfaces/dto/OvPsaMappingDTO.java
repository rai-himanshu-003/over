/*
 * Creation : 10 Oct 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;

/**
 * The Class OvPsaMappingDTO.
 */
public class OvPsaMappingDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The id. */
    private Long id;

    /** The psa type. */
    private String psaType;

    /** The psa key. */
    private String psaKey;

    /** The ov standard. */
    private String ovStandard;

    /** The ov key. */
    private String ovKey;

    /** The description. */
    private String description;

    /** The version. */
    private Integer version;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the psa type.
     *
     * @return the psa type
     */
    public String getPsaType() {
        return psaType;
    }

    /**
     * Sets the psa type.
     *
     * @param psaType the new psa type
     */
    public void setPsaType(String psaType) {
        this.psaType = psaType;
    }

    /**
     * Gets the psa key.
     *
     * @return the psa key
     */
    public String getPsaKey() {
        return psaKey;
    }

    /**
     * Sets the psa key.
     *
     * @param psaKey the new psa key
     */
    public void setPsaKey(String psaKey) {
        this.psaKey = psaKey;
    }

    /**
     * Gets the ov standard.
     *
     * @return the ov standard
     */
    public String getOvStandard() {
        return ovStandard;
    }

    /**
     * Sets the ov standard.
     *
     * @param ovStandard the new ov standard
     */
    public void setOvStandard(String ovStandard) {
        this.ovStandard = ovStandard;
    }

    /**
     * Gets the ov key.
     *
     * @return the ov key
     */
    public String getOvKey() {
        return ovKey;
    }

    /**
     * Sets the ov key.
     *
     * @param ovKey the new ov key
     */
    public void setOvKey(String ovKey) {
        this.ovKey = ovKey;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

}
