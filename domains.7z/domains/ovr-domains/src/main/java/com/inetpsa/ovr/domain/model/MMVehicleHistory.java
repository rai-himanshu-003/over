/*
 * Creation : 27 May 2021
 */
package com.inetpsa.ovr.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class MMVehicleHistory.
 */
@Entity
@Table(name = "OVRQTVHIS")
@DynamicUpdate(value = true)
public class MMVehicleHistory extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    @SequenceGenerator(name = "SEQ_HIS", sequenceName = "OVRQTVHIS_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_HIS")
    private Long id;

    @Column(name = "VIN")
    private String vin;

    /** The action type. */
    @Column(name = "ACTION_TYPE")
    private String actionType;

    /** The type data. */
    @Column(name = "TYPE_DATA")
    private String typeData;

    /** The old value. */
    @Column(name = "OLD_VALUE")
    private String oldValue;

    /** The value. */
    @Column(name = "VALUE")
    private String value;

    /** The standard. */
    @Column(name = "STANDARD")
    private String standard;

    /** The id. */
    @Column(name = "ID_COMP")
    private String id1;

    /** The label. */
    @Column(name = "LABEL")
    private String label;

    /** The part. */
    @Column(name = "PART")
    private String part;

    /** The supplier. */
    @Column(name = "SUPPLIER")
    private String supplier;

    /** The data. */
    @Column(name = "DATA")
    private String data;

    /** The id tech. */
    @Column(name = "ID_TECH")
    private String idTech;

    /** The user id. */
    @Column(name = "USER_ID")
    private String userId;

    /** The operation date. */
    @Column(name = "DATE_OPERATION")
    private Date operationDate;

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the action type.
     *
     * @return the action type
     */
    public String getActionType() {
        return actionType;
    }

    /**
     * Sets the action type.
     *
     * @param actionType the new action type
     */
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    /**
     * Gets the type data.
     *
     * @return the type data
     */
    public String getTypeData() {
        return typeData;
    }

    /**
     * Sets the type data.
     *
     * @param typeData the new type data
     */
    public void setTypeData(String typeData) {
        this.typeData = typeData;
    }

    /**
     * Gets the old value.
     *
     * @return the old value
     */
    public String getOldValue() {
        return oldValue;
    }

    /**
     * Sets the old value.
     *
     * @param oldValue the new old value
     */
    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public String getStandard() {
        return standard;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(String standard) {
        this.standard = standard;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getId1() {
        return id1;
    }

    public void setId1(String id1) {
        this.id1 = id1;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the part.
     *
     * @return the part
     */
    public String getPart() {
        return part;
    }

    /**
     * Sets the part.
     *
     * @param part the new part
     */
    public void setPart(String part) {
        this.part = part;
    }

    /**
     * Gets the supplier.
     *
     * @return the supplier
     */
    public String getSupplier() {
        return supplier;
    }

    /**
     * Sets the supplier.
     *
     * @param supplier the new supplier
     */
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * Gets the id tech.
     *
     * @return the id tech
     */
    public String getIdTech() {
        return idTech;
    }

    /**
     * Sets the id tech.
     *
     * @param idTech the new id tech
     */
    public void setIdTech(String idTech) {
        this.idTech = idTech;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     *
     * @param userId the new user id
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets the operation date.
     *
     * @return the operation date
     */
    public Date getOperationDate() {
        return operationDate;
    }

    /**
     * Sets the operation date.
     *
     * @param operationDate the new operation date
     */
    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    @PrePersist
    public void prePersist() {
        operationDate = new Date();
        userId = LoggedUser.get();

    }

}
