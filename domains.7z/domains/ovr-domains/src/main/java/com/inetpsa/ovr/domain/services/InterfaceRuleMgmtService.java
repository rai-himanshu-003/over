/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import org.seedstack.business.Service;

import com.inetpsa.ovr.interfaces.dto.IRMRequestDTO;

/**
 * The Interface VehicleService.
 *
 * @author E567673
 */
@Service
public interface InterfaceRuleMgmtService {

    /**
     * Apply and get interface rules for.
     *
     * @param irmRequestDTO the irm request DTO
     * @return the boolean
     */
    Boolean applyAndGetInterfaceRulesFor(IRMRequestDTO irmRequestDTO);
}
