/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.io.File;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.FlowStaticMetadata;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;

/**
 * The Interface FormatManagementService.
 */
@Service
public interface FormatManagementService {

    /**
     * Gets the flow static metadata.
     *
     * @return the flow static metadata
     */
    List<FlowStaticMetadata> getFlowStaticMetadata();

    /**
     * Gets the flow details by id.
     *
     * @param flowId the flow id
     * @return the flow details by id
     */
    OutputFlowDetailsDTO getflowDetailsById(Long flowId);

    /**
     * Adds the or update format details.
     *
     * @param outputFlowDetailsDTO the output flow details DTO
     * @return true, if successful
     */
    boolean addOrUpdateFormatDetails(OutputFlowDetailsDTO outputFlowDetailsDTO);

    /**
     * Generate file fr format.
     *
     * @param path the path
     * @param fileName the file name
     * @param extension the extension
     * @param flowDetails the flow details
     * @param isExport the is export
     * @return the file
     */
    File generateFileFrFormat(String path, String fileName, String extension, OutputFlowDetails flowDetails, Boolean isExport);

    /**
     * Fetch filtered data.
     *
     * @param opflow the opflow
     * @return the list
     */
    List<Vehicle> fetchFilteredData(OutputFlowDetails opflow);

    /**
     * Output flow details validator.
     *
     * @param outputFlowDetailsDTO the output flow details DTO
     * @return true, if successful
     */
    boolean outputFlowDetailsValidator(OutputFlowDetailsDTO outputFlowDetailsDTO);

    /**
     * Update last run.
     *
     * @param details the details
     */
    void updateLastRun(OutputFlowDetails details);

    OutputFlowDetails getflowDetailsByName(String flowname);
}
