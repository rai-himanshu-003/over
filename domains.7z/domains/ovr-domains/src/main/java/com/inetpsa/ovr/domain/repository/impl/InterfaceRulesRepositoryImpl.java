/*
 * Creation : 1 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.domain.repository.InterfaceRulesRepository;
import com.inetpsa.ovr.interfaces.dto.CorvetRulesDto;

/**
 * The Class InterfaceRulesRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class InterfaceRulesRepositoryImpl extends BaseJpaRepository<InterfaceRule, Long> implements InterfaceRulesRepository {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(InterfaceRulesRepositoryImpl.class);

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.InterfaceRulesRepository#getInterfaceRules()
     */
    @Override
    public List<InterfaceRule> getInterfaceRules(Long id) {
        logger.info("Entering getInterfaceRules of InterfaceRulesRepositoryImpl to fetch interface rules");
        CriteriaBuilder criteriaBuilder = super.getEntityManager().getCriteriaBuilder();
        CriteriaQuery<InterfaceRule> criteriaQuery = criteriaBuilder.createQuery(InterfaceRule.class);
        Root<InterfaceRule> root = criteriaQuery.from(InterfaceRule.class);
        criteriaQuery.select(root);
        criteriaQuery.where(criteriaBuilder.equal(root.get("intId"), (id)));
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get("priority")));
        TypedQuery<InterfaceRule> typedQuery = super.getEntityManager().createQuery(criteriaQuery);
        logger.info("Exiting getInterfaceRules of InterfaceRulesRepositoryImpl");

        return typedQuery.getResultList();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.InterfaceRulesRepository#findByIntNameAndPriority(java.lang.String, int)
     */
    @Override
    public InterfaceRule findByIntNameAndPriority(Long id, int priority) {
        InterfaceRule interfaceRule = null;
        logger.info("Entering findByIntNameAndPriority of InterfaceRulesRepositoryImpl to fetch interface rules fr interface :{} and priority :{}",
                id, priority);
        try {

            Query query = super.getEntityManager().createQuery("From InterfaceRule where intId=:interfaceId and priority=:priority",
                    InterfaceRule.class);

            query.setParameter("interfaceId", id);
            query.setParameter("priority", priority);
            logger.info("Exiting findByIntNameAndPriority of InterfaceRulesRepositoryImpl");
            return (InterfaceRule) query.getSingleResult();
        } catch (Exception e) {
            return interfaceRule;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.InterfaceRulesRepository#getAllInterfaceRules()
     */
    @Override
    public List<CorvetRulesDto> getAllInterfaceRules() {

        List<CorvetRulesDto> list = new ArrayList<>();
        try {
            logger.info("Entering into VehicleRepositoryImpl getVehiclesDetails ");
            CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
            CriteriaQuery<CorvetRulesDto> criteria = builder.createQuery(CorvetRulesDto.class);
            Root<Interface> c = criteria.from(Interface.class);

            Join<Object, Object> interfaceRule = (Join<Object, Object>) c.join("interfaceRules", JoinType.INNER);
            criteria.multiselect(interfaceRule.get("id"), interfaceRule.get("priority"), interfaceRule.get("filterType"),
                    interfaceRule.get("vehicleFamily"), interfaceRule.get("productionCentre"), interfaceRule.get("country"),
                    interfaceRule.get("minEcom"), interfaceRule.get("maxEcom"), interfaceRule.get("dateCreation"), interfaceRule.get("userCreation"),
                    interfaceRule.get("dateModif"), interfaceRule.get("userModif"), interfaceRule.get("version"), c.get("interfaceName"),
                    interfaceRule.get("vin"));

            list = this.entityManager.createQuery(criteria).getResultList();

            logger.info("Exiting from VehicleRepositoryImpl getAllInterfaceRules ");
        } catch (Exception e) {
            logger.error("Error occured in getVehiclesDetails {}", e.getMessage());
        }

        return list;

    }

}
