/*
 * Creation : 5 Jul 2019
 */
/*
 * Creation : 5 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class AuditPk.
 */
@Embeddable
public class AuditPk implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private Date dateCreation;

    /** The file name. */
    @Column(name = "FILE_NAME")
    private String fileName;

    /**
     * Instantiates a new audit pk.
     */
    public AuditPk() {
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public Date getDateCreation() {
        return dateCreation;
    }

    /**
     * Sets the date creation.
     *
     * @param date the new date creation
     */
    public void setDateCreation(Date date) {
        this.dateCreation = date;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the new file name
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Gets the serialversionuid.
     *
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "AuditPk [dateCreation=" + dateCreation + ", fileName=" + fileName + "]";
    }

    /**
     * Instantiates a new audit pk.
     *
     * @param fileName the file name
     */
    public AuditPk(String fileName) {
        super();
        this.fileName = fileName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        int resultTest = 0;

        if (dateCreation != null)
            resultTest = dateCreation.hashCode();

        result = prime * result + resultTest;

        resultTest = 0;
        if (fileName != null)
            resultTest = fileName.hashCode();

        result = prime * result + resultTest;

        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean returnFlag = true;

        try {

            if (obj == null)
                return false;

            if (getClass() != obj.getClass())
                returnFlag = false;

            if (this == obj)
                returnFlag = true;

            AuditPk other = (AuditPk) obj;
            if (dateCreation == null) {
                if (other.dateCreation != null)
                    returnFlag = false;
            } else if (!dateCreation.equals(other.dateCreation))
                returnFlag = false;

            if (fileName == null) {
                if (other.fileName != null)
                    returnFlag = false;

            } else if (!fileName.equals(other.fileName))
                returnFlag = false;
        } catch (Exception e) {
            returnFlag = false;
        }

        return returnFlag;

    }

}
