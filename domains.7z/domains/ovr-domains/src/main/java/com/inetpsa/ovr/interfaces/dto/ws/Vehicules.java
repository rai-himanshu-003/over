/*
 * Creation : 13 Jan 2020
 */
package com.inetpsa.ovr.interfaces.dto.ws;

import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 * The Class Vehicules.
 */
public class Vehicules {

    /** The vin. */
    @SerializedName(value = "VIN")
    private String vin;

    /** The exists. */
    @SerializedName(value = "EXISTS")
    private String exists;

    /** The vehicule data. */
    @SerializedName(value = "VEHICULE_DATA")
    private List<VehiculeData> vehiculeData;

    /** The rpo codes. */
    @SerializedName(value = "RPO_CODES")
    private List<String> rpoCodes;

    /** The components ov. */
    @SerializedName(value = "COMPONENTS_OV")
    private List<ComponentsOv> componentsOv;

    /** The artificial lcdv. */
    @SerializedName(value = "ARTIFICIAL_LCDV")
    private List<String> artificialLcdv;

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the exists.
     *
     * @return the exists
     */
    public String getExists() {
        return exists;
    }

    /**
     * Sets the exists.
     *
     * @param exists the new exists
     */
    public void setExists(String exists) {
        this.exists = exists;
    }

    /**
     * Gets the vehicule data.
     *
     * @return the vehicule data
     */
    public List<VehiculeData> getVehiculeData() {
        return vehiculeData;
    }

    /**
     * Sets the vehicule data.
     *
     * @param vehiculeData the new vehicule data
     */
    public void setVehiculeData(List<VehiculeData> vehiculeData) {
        this.vehiculeData = vehiculeData;
    }

    /**
     * Gets the rpo codes.
     *
     * @return the rpo codes
     */
    public List<String> getRpoCodes() {
        return rpoCodes;
    }

    /**
     * Sets the rpo codes.
     *
     * @param rpoCodes the new rpo codes
     */
    public void setRpoCodes(List<String> rpoCodes) {
        this.rpoCodes = rpoCodes;
    }

    /**
     * Gets the components ov.
     *
     * @return the components ov
     */
    public List<ComponentsOv> getComponentsOv() {
        return componentsOv;
    }

    /**
     * Sets the components ov.
     *
     * @param componentsOv the new components ov
     */
    public void setComponentsOv(List<ComponentsOv> componentsOv) {
        this.componentsOv = componentsOv;
    }

    /**
     * Gets the artificial lcdv.
     *
     * @return the artificial lcdv
     */
    public List<String> getArtificialLcdv() {
        return artificialLcdv;
    }

    /**
     * Sets the artificial lcdv.
     *
     * @param artificialLcdv the new artificial lcdv
     */
    public void setArtificialLcdv(List<String> artificialLcdv) {
        this.artificialLcdv = artificialLcdv;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Vehicules [vin=" + vin + ", exists=" + exists + ", vehiculeData=" + vehiculeData + ", rpoCodes=" + rpoCodes + ", componentsOv="
                + componentsOv + ", artificialLcdv=" + artificialLcdv + "]";
    }

}
