/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.domain.model.TechnicalParameter;
import com.inetpsa.ovr.domain.repository.InterfaceRepository;
import com.inetpsa.ovr.domain.repository.InterfaceRulesRepository;
import com.inetpsa.ovr.domain.services.InterfaceRulesService;
import com.inetpsa.ovr.domain.services.TechnicalParameterService;
import com.inetpsa.ovr.interfaces.dto.InterfaceDto;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;
import com.inetpsa.ovr.interfaces.mapper.DataMapper;

/**
 * The Class InterfaceRulesServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class InterfaceRulesServiceImpl implements InterfaceRulesService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(InterfaceRulesServiceImpl.class);

    /** The audit repository. */
    @Inject
    private InterfaceRulesRepository interfaceRulesRepository;

    /** The Interface repository. */
    @Inject
    private InterfaceRepository interfaceRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    @Inject
    private TechnicalParameterService technicalParameterService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceRulesService#addOrUpdateInterfaceRule(com.inetpsa.ovr.interfaces.rest.dto.InterfaceRulesDto)
     */
    public boolean addOrUpdateInterfaceRule(InterfaceRulesDto interfaceRulesDto) {
        try {
            logger.info("Entering addOrUpdateInterfaceRule of InterfaceRulesServiceImpl");
            InterfaceRule interfaceRule = null;
            Boolean flag = true;
            interfaceRule = findByIntNameAndPriority(interfaceRulesDto.getInterfaceId(), interfaceRulesDto.getPriority());

            if (interfaceRule != null) {
                logger.info("Vehicle version from database {}", interfaceRule.getVersion());
                logger.info("Vehicle version from ui {}", interfaceRulesDto.getVersion());
                if (interfaceRule.getVersion().equals(interfaceRulesDto.getVersion())) {
                    interfaceRule = DataMapper.mapTomodel(interfaceRulesDto, interfaceRule);
                    interfaceRulesRepository.update(interfaceRule);
                } else {

                    logger.error("Version did not match for Interface :{}", interfaceRulesDto.getInterfaceId());
                    flag = false;
                }

            } else {

                interfaceRule = new InterfaceRule();
                interfaceRule = DataMapper.mapTomodel(interfaceRulesDto, interfaceRule);
                interfaceRulesRepository.add(interfaceRule);

            }
            logger.info("Exiting addOrUpdateInterfaceRule of InterfaceRulesServiceImpl");
            if (flag) {

                this.setTechnicalParameter();
            }
            return flag;
        } catch (

        Exception e) {
            logger.error("Error occurred while updating for Interface : {}", interfaceRulesDto);
            logger.error("Error occurred while updating {}", e.getMessage());
            return false;
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceRulesService#getInterfaceRules()
     */
    @Override
    public List<InterfaceRulesDto> getInterfaceRules(Long id) {
        List<InterfaceRule> interfaceRules = interfaceRulesRepository.getInterfaceRules(id);
        List<InterfaceRulesDto> interfaceRulesDtos = new ArrayList<>();
        if (interfaceRules != null) {
            for (InterfaceRule entity : interfaceRules) {
                logger.info("Entity {}", entity);
                InterfaceRulesDto interfaceRulesDto = DataMapper.interfaceRulemapToDto(entity);
                interfaceRulesDtos.add(interfaceRulesDto);
            }
        }
        return interfaceRulesDtos;
    }

    @Override
    public List<InterfaceDto> getInterfaceList() {
        List<InterfaceDto> interfaceNames = new ArrayList<>();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        Specification<Interface> spec = specificationBuilder.of(Interface.class).property("interfaceName").not().equalTo(null).build();
        List<Interface> interfaceList = (interfaceRepository.get(spec, opt)).collect(Collectors.toList());
        for (Interface interfaceObj : interfaceList) {
            InterfaceDto interfaceDto = DataMapper.interfacemapToDto(interfaceObj);
            interfaceNames.add(interfaceDto);
        }
        return interfaceNames;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceRulesService#findByIntNameAndPriority(java.lang.String, int)
     */
    public InterfaceRule findByIntNameAndPriority(Long id, int priority) {
        return interfaceRulesRepository.findByIntNameAndPriority(id, priority);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceRulesService#deleteInterfaceRule(com.inetpsa.ovr.interfaces.rest.dto.InterfaceRulesDto)
     */
    @Override
    public boolean deleteInterfaceRule(Long interfaceId) {
        logger.info("Entering deleteInterfaceRule of InterfaceRulesServiceImpl");
        Optional<InterfaceRule> optIntRule = null;
        try {
            optIntRule = interfaceRulesRepository.get(interfaceId);

            if (optIntRule.isPresent()) {

                logger.info("Exiting deleteInterfaceRule of InterfaceRulesServiceImpl");
                interfaceRulesRepository.remove(optIntRule.get());
                this.setTechnicalParameter();

                return true;
            }
            return false;
        } catch (Exception e) {
            logger.error("Error occurred while deleting  Interface Id: {}", interfaceId);
            logger.error("Error occurred while updating ", e);
            return false;
        }
    }

    private void setTechnicalParameter() {

        logger.info("Setting the technical paratameter Send_to_corvet to OK");
        Optional<TechnicalParameter> optTechPara = technicalParameterService.getTechParamByCode(CommonConstant.SEND_RULES_CONSTANT.getConstValue());
        if (optTechPara.isPresent()) {
            TechnicalParameter parameter = optTechPara.get();
            parameter.setValue(CommonConstant.PARAMETER_OK.getConstValue());
            technicalParameterService.updateParam(parameter);
        }
    }
}