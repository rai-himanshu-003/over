/*
 * Creation : 05 July 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;

/**
 * * The Class ResponseDto.
 */
public class ResponseDto implements Serializable {

    /** The serial version UID. */
    private static long serialVersionUID = -4527943607165453814L;

    /** The id. */
    private String id;

    /** The msg. */
    private boolean msg;

    private String message;

    /**
     * Gets the serial version UID.
     *
     * @return the serial version UID
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    /**
     * Sets the serial version UID.
     *
     * @param serialVersionUID the new serial version UID
     */
    public static void setSerialVersionUID(long serialVersionUID) {
        ResponseDto.serialVersionUID = serialVersionUID;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Checks if is msg.
     *
     * @return true, if is msg
     */
    public boolean isMsg() {
        return msg;
    }

    /**
     * Sets the msg.
     *
     * @param msg the new msg
     */
    public void setMsg(boolean msg) {
        this.msg = msg;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
