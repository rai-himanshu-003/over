/*
 * Creation : 17 Dec 2019
 */
package com.inetpsa.ovr.interfaces.dto.ws;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

/**
 * The Class RequestObj.
 */
public class RequestObj {

    /** The header. */
    @JsonProperty("HEADER")
    @SerializedName("HEADER")
    private Header header;

    /** The criteria. */
    @JsonProperty("CRITERIA")
    @SerializedName("CRITERIA")
    private List<Criteria> criteria;

    /** The response. */
    @JsonProperty("RESPONSE")
    @SerializedName("RESPONSE")
    private Response response;

    /**
     * Gets the header.
     *
     * @return the header
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the header.
     *
     * @param header the new header
     */
    public void setHeader(Header header) {
        this.header = header;
    }

    /**
     * Gets the criteria.
     *
     * @return the criteria
     */
    public List<Criteria> getCriteria() {
        return criteria;
    }

    /**
     * Sets the criteria.
     *
     * @param criteria the new criteria
     */
    public void setCriteria(List<Criteria> criteria) {
        this.criteria = criteria;
    }

    /**
     * Gets the response.
     *
     * @return the response
     */
    public Response getResponse() {
        return response;
    }

    /**
     * Sets the response.
     *
     * @param response the new response
     */
    public void setResponse(Response response) {
        this.response = response;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RequestObj [header=" + header + ", criteria=" + criteria + ", response=" + response + "]";
    }

}