/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.LcdvOtt;

/**
 * The Class LcdvOttDTO.
 */

public class LcdvOttDTO {

    /** The id. */

    private Long idLcdvDto;

    /** The data. */
    private String characteristicLcdvDto;

    /** The vin. */
    private String vinLcdvDto;

    /** The eid. */
    private String indicatorLcdvDto;

    /** The label. */
    private String natureLcdvDto;

    /** The standard. */
    private String valueLcdvDto;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return idLcdvDto;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idLcdvDto = id;
    }

    /**
     * Gets the characteristic.
     *
     * @return the characteristic
     */
    public String getCharacteristic() {
        return characteristicLcdvDto;
    }

    /**
     * Sets the characteristic.
     *
     * @param characteristic the new characteristic
     */
    public void setCharacteristic(String characteristic) {
        this.characteristicLcdvDto = characteristic;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vinLcdvDto;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vinLcdvDto = vin;
    }

    /**
     * Gets the indicator.
     *
     * @return the indicator
     */
    public String getIndicator() {
        return indicatorLcdvDto;
    }

    /**
     * Sets the indicator.
     *
     * @param indicator the new indicator
     */
    public void setIndicator(String indicator) {
        this.indicatorLcdvDto = indicator;
    }

    /**
     * Gets the nature.
     *
     * @return the nature
     */
    public String getNature() {
        return natureLcdvDto;
    }

    /**
     * Sets the nature.
     *
     * @param nature the new nature
     */
    public void setNature(String nature) {
        this.natureLcdvDto = nature;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return valueLcdvDto;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.valueLcdvDto = value;
    }

    /**
     * Map tomodel.
     *
     * @return the lcdv ott
     */
    public LcdvOtt mapTomodel() {
        LcdvOtt lcdvOtt = new LcdvOtt();

        lcdvOtt.setId(this.getId());
        lcdvOtt.setCharacteristic(this.getCharacteristic());
        lcdvOtt.setIndicator(this.getIndicator());
        lcdvOtt.setNature(this.getNature());
        lcdvOtt.setValue(this.getValue());
        lcdvOtt.setVin(this.getVin());

        return lcdvOtt;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "LcdvOttDTO [id=" + idLcdvDto + ", characteristic=" + characteristicLcdvDto + ", vin=" + vinLcdvDto + ", indicator=" + indicatorLcdvDto + ", nature=" + natureLcdvDto
                + ", value=" + valueLcdvDto + "]";
    }

}
