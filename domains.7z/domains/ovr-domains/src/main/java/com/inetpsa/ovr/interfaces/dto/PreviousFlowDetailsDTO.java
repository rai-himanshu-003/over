package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.util.List;

/**
 * The Class IRMRequestDTO.
 */
public class PreviousFlowDetailsDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;
    /** The interface id. */
    private String previousFlow;
    private List<String> status;

    public List<String> getStatus() {
        return status;
    }

    public String getPreviousFlow() {
        return previousFlow;
    }

    public void setPreviousFlow(String previousFlow) {
        this.previousFlow = previousFlow;
    }

    public void setStatus(List<String> status) {
        this.status = status;
    }

}
