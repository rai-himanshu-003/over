/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.OptionsDTO;

/**
 * The Class Options.
 */
@Entity
@Table(name = "OVRQTVRPO")
@DynamicUpdate(value = true)
public class Options extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    // @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTVRPO_SEQ", allocationSize = 1)
    // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The data. */
    @Column(name = "RPO")
    private String rpoData;

    /** The vin. */
    // @JsonBackReference
    // @ManyToOne
    // @JoinColumn(name = "VIN", nullable = false)
    @Column(name = "VIN")
    private String vin;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the rpo data.
     *
     * @return the rpo data
     */
    public String getRpoData() {
        return rpoData;
    }

    /**
     * Sets the rpo data.
     *
     * @param rpoData the new rpo data
     */
    public void setRpoData(String rpoData) {
        this.rpoData = rpoData;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((rpoData == null) ? 0 : rpoData.hashCode());
        result = prime * result + ((vin == null) ? 0 : vin.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Options other = (Options) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (rpoData == null) {
            if (other.rpoData != null)
                return false;
        } else if (!rpoData.equals(other.rpoData))
            return false;
        if (vin == null) {
            if (other.vin != null)
                return false;
        } else if (!vin.equals(other.vin))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Options [id=" + id + ", rpoData=" + rpoData + ", vin=" + vin + "]";
    }

    /**
     * Mapto dto.
     *
     * @return the options DTO
     */
    public OptionsDTO maptoDto() {
        OptionsDTO optionsDTO = new OptionsDTO();
        optionsDTO.setId(this.getId());
        optionsDTO.setRpoData(this.getRpoData());
        optionsDTO.setVin(this.getVin());
        return optionsDTO;
    }

}
