/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.constant;

/**
 * enum for Translation states.
 *
 * @author E566559
 */
public enum TranslationState {

    /** The ko trsnslation. */
    KO_TRSNSLATION("KOTR"),

    /** The translated done. */
    TRANSLATED_DONE("TRDN"),

    /** The created. */
    CREATED("CRTD"),

    /** The translated on progress. */
    TRANSLATED_ON_PROGRESS("ONPR"),

    /** The sent to corvet. */
    SENT_TO_CORVET("STCR"),

    /** The ko to retranslate. */
    KO_TO_RETRANSLATE("RETR"),

    /** The cancelled. */
    CANCELLED("CNLD"),

    INIT("INIT"),

    IGNORE("IGNR"),

    REIN("REIN");

    /** The const value. */
    String constValue;

    /**
     * Instantiates a new translation state.
     *
     * @param constValue the const value
     */
    TranslationState(String constValue) {
        this.constValue = constValue;
    }

    /**
     * Gets the const value.
     *
     * @return the const value
     */
    public String getConstValue() {
        return constValue;
    }

}
