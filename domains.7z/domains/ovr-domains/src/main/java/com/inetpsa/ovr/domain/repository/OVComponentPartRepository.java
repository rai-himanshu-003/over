/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.OVComponentPart;

/**
 * The Interface FlowStaticMetadataRepository.
 */
public interface OVComponentPartRepository extends Repository<OVComponentPart, Long> {
}
