package com.inetpsa.ovr.interfaces.mapper;

import java.util.ArrayList;
import java.util.List;

import com.inetpsa.ovr.domain.model.Flow;
import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.model.InterfaceRule;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.interfaces.dto.FlowDto;
import com.inetpsa.ovr.interfaces.dto.InterfaceDto;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;
import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;
import com.inetpsa.ovr.interfaces.dto.OptionsDTO;
import com.inetpsa.ovr.interfaces.dto.OvPsaMappingDTO;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;
import com.inetpsa.ovr.interfaces.dto.VehicleChildDTO;
import com.inetpsa.ovr.interfaces.dto.VehicleDTO;

/*
 * Creation : 22 oct 2019
 */

/**
 * The Class DataMapper.
 */
public final class DataMapper {

    /**
     * Instantiates a new data mapper.
     */
    private DataMapper() {

    }

    /**
     * Interface rulemap to dto.
     *
     * @param interfaceRule the interface rule
     * @return the interface rules dto
     */
    public static InterfaceRulesDto interfaceRulemapToDto(InterfaceRule interfaceRule) {
        InterfaceRulesDto interfaceRulesDto = new InterfaceRulesDto();
        interfaceRulesDto.setId(interfaceRule.getId());
        interfaceRulesDto.setInterfaceId(interfaceRule.getIntId());
        interfaceRulesDto.setPriority(interfaceRule.getPriority());
        interfaceRulesDto.setTypeOfFilter(interfaceRule.getFilterType());
        interfaceRulesDto.setProductionCentre(interfaceRule.getProductionCentre());
        interfaceRulesDto.setCountry(interfaceRule.getCountry());
        interfaceRulesDto.setFamilyOfVehicle(interfaceRule.getVehicleFamily());
        interfaceRulesDto.setMaxEcomDate((interfaceRule.getMaxEcom()));
        interfaceRulesDto.setMinEcomDate((interfaceRule.getMinEcom()));
        interfaceRulesDto.setVersion(interfaceRule.getVersion());
        interfaceRulesDto.setDateCreation((interfaceRule.getDateCreation()));
        interfaceRulesDto.setVin((interfaceRule.getVin()));
        return interfaceRulesDto;
    }

    /**
     * Interface rulemap to dto.
     *
     * @param interfce the interfce
     * @return the interface dto
     */
    public static InterfaceDto interfacemapToDto(Interface interfce) {
        InterfaceDto interfaceDto = new InterfaceDto();
        interfaceDto.setId(interfce.getId().toString());
        interfaceDto.setInterfaceName(interfce.getInterfaceName());
        return interfaceDto;
    }

    /**
     * Map tomodel.
     *
     * @param interfaceRulesDto the interface rules dto
     * @param interfaceRule the interface rule
     * @return the interface rule
     */
    public static InterfaceRule mapTomodel(InterfaceRulesDto interfaceRulesDto, InterfaceRule interfaceRule) {

        interfaceRule.setIntId(interfaceRulesDto.getInterfaceId());
        interfaceRule.setPriority(interfaceRulesDto.getPriority());
        interfaceRule.setFilterType(interfaceRulesDto.getTypeOfFilter());
        interfaceRule.setVehicleFamily(interfaceRulesDto.getFamilyOfVehicle());
        interfaceRule.setProductionCentre(interfaceRulesDto.getProductionCentre());
        interfaceRule.setCountry(interfaceRulesDto.getCountry());
        interfaceRule.setMaxEcom((interfaceRulesDto.getMaxEcomDate()));
        interfaceRule.setMinEcom((interfaceRulesDto.getMinEcomDate()));
        interfaceRule.setVin(interfaceRulesDto.getVin());
        return interfaceRule;
    }

    /**
     * Vehiclemap to dto.
     *
     * @param vehicle the vehicle
     * @param vehicleChildDTO the vehicle child DTO
     * @return the vehicle DTO
     */
    public static VehicleDTO vehiclemapToDto(Vehicle vehicle, VehicleChildDTO vehicleChildDTO) {
        VehicleDTO vehicleDTO = new VehicleDTO();
        vehicleDTO.setVinNo(vehicle.getVinNo());
        vehicleDTO.setCcp(vehicle.getCcp());
        vehicleDTO.setVeh(vehicle.getVeh());
        vehicleDTO.setDateExtension(vehicle.getDateExtension());
        vehicleDTO.setDateEcom(vehicle.getDateEcom());
        vehicleDTO.setDateEmon(vehicle.getDateEmon());
        vehicleDTO.setCurrentState((vehicle.getCurrentState()));
        vehicleDTO.setLcdv24((vehicle.getLcdv24()));
        vehicleDTO.setModel(vehicle.getModel());
        vehicleDTO.setModelYear(vehicle.getModelYear());
        vehicleDTO.setApvpr(vehicle.getApvpr());
        vehicleDTO.setNre(vehicle.getNre());
        vehicleDTO.setOa((vehicle.getOa()));
        vehicleDTO.setOf((vehicle.getOf()));
        vehicleDTO.setTvv(vehicle.getTvv());
        vehicleDTO.setUp(vehicle.getUp());
        if (vehicleChildDTO.isOptions()) {
            List<OptionsDTO> optionsDTOs = new ArrayList();
            if (vehicle.getOptions() != null) {
                for (Options options : vehicle.getOptions()) {
                    OptionsDTO optionsDTO = vehicleoptionsToDto(options);
                    optionsDTOs.add(optionsDTO);
                }
            }
            vehicleDTO.setOptions(optionsDTOs);
        }
        return vehicleDTO;
    }

    /**
     * Vehicleoptions to dto.
     *
     * @param options the options
     * @return the options DTO
     */
    private static OptionsDTO vehicleoptionsToDto(Options options) {
        OptionsDTO optionsDTO = new OptionsDTO();
        optionsDTO.setRpoData(options.getRpoData());
        optionsDTO.setVin(options.getVin());
        return optionsDTO;

    }

    /**
     * Interface rulemap to dto.
     *
     * @param psaKeyMapping the psa key mapping
     * @return the ov psa mapping DTO
     */
    public static OvPsaMappingDTO psaKeyMappingMapToDto(PsaKeyMapping psaKeyMapping) {
        OvPsaMappingDTO ovPsaMappingDTO = new OvPsaMappingDTO();
        ovPsaMappingDTO.setId(psaKeyMapping.getId());
        ovPsaMappingDTO.setPsaType(psaKeyMapping.getPsaDatatype());
        ovPsaMappingDTO.setPsaKey(psaKeyMapping.getPsaKey());
        ovPsaMappingDTO.setOvStandard(psaKeyMapping.getOvStandard());
        ovPsaMappingDTO.setOvKey(psaKeyMapping.getOvKey());
        ovPsaMappingDTO.setDescription(psaKeyMapping.getDescription());
        ovPsaMappingDTO.setVersion(psaKeyMapping.getVersion());
        return ovPsaMappingDTO;
    }

    /**
     * Ov psa mapping DTO map tomodel.
     *
     * @param ovPsaMappingDTO the ov psa mapping DTO
     * @param psaKeyMapping the psa key mapping
     * @return the psa key mapping
     */
    public static PsaKeyMapping ovPsaMappingDTOMapTomodel(OvPsaMappingDTO ovPsaMappingDTO, PsaKeyMapping psaKeyMapping) {

        psaKeyMapping.setPsaDatatype(ovPsaMappingDTO.getPsaType());
        psaKeyMapping.setPsaKey(ovPsaMappingDTO.getPsaKey());
        psaKeyMapping.setOvStandard(ovPsaMappingDTO.getOvStandard());
        psaKeyMapping.setOvKey(ovPsaMappingDTO.getOvKey());
        psaKeyMapping.setDescription(ovPsaMappingDTO.getDescription());
        return psaKeyMapping;
    }

    /**
     * Flowmap to dto.
     *
     * @param flow the flow
     * @return the flow dto
     */
    public static FlowDto flowmapToDto(Flow flow) {
        FlowDto flowDto = new FlowDto();
        flowDto.setId(flow.getId().toString());
        flowDto.setFlowName(flow.getFlowName());
        return flowDto;
    }

    /**
     * Gets the flow dto from resend to OTT dto.
     *
     * @param resendToOTTDto the resend to OTT dto
     * @return the flow dto from resend to OTT dto
     */
    public static MultipleFlowStatusDTO getFlowDtoFromResendToOTTDto(ResendToOTTDto resendToOTTDto) {
        MultipleFlowStatusDTO flowDto = new MultipleFlowStatusDTO();
        flowDto.setVin(resendToOTTDto.getVin());
        flowDto.setStatus(resendToOTTDto.getCurrentState());
        flowDto.setFlow(resendToOTTDto.getFlowName());
        flowDto.setVersion(resendToOTTDto.getVersion());
        return flowDto;
    }

}
