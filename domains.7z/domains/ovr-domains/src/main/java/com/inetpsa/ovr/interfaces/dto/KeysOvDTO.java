/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.KeysOv;

/**
 * The Class KeysOvDTO.
 */
public class KeysOvDTO {

    /** The id. */
    private Long idKeyDto;

    /** The data. */
    private String dataKeyDto;

    /** The vin. */
    private String vinKeyDto;

    /** The eid. */
    private String eidKeyDto;

    /** The label. */
    private String labelKeyDto;

    /** The standard. */
    private String standardKeyDto;

    /**
     * Gets the eid.
     *
     * @return the eid
     */
    public String getEid() {
        return eidKeyDto;
    }

    /**
     * Sets the eid.
     *
     * @param eid the new eid
     */
    public void setEid(String eid) {
        this.eidKeyDto = eid;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return labelKeyDto;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.labelKeyDto = label;
    }

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public String getStandard() {
        return standardKeyDto;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(String standard) {
        this.standardKeyDto = standard;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return idKeyDto;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.idKeyDto = id;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return dataKeyDto;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.dataKeyDto = data;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vinKeyDto;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vinKeyDto = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "KeysOv [id=" + idKeyDto + ", data=" + dataKeyDto + ", vin=" + vinKeyDto + ", eid=" + eidKeyDto + ", label=" + labelKeyDto + ", standard=" + standardKeyDto + "]";
    }

    /**
     * Map tomodel.
     *
     * @return the keys ov
     */
    public KeysOv mapTomodel() {
        KeysOv keysOv = new KeysOv();
        keysOv.setData(this.getData());
        keysOv.setEid(this.getEid());
        keysOv.setId(this.getId());
        keysOv.setLabel(this.getLabel());
        keysOv.setStandard(this.getStandard());
        keysOv.setVin(this.getVin());
        return keysOv;
    }

}
