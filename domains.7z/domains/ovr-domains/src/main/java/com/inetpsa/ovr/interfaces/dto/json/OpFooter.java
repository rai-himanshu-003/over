/*
 * Creation : 17 Apr 2020
 */
package com.inetpsa.ovr.interfaces.dto.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class OpFooter.
 */
public class OpFooter {

    /** The sender. */
    @SerializedName("SENDER")
    @Expose
    private String sender;

    /** The client. */
    @SerializedName("CLIENT")
    @Expose
    private String client;

    /** The number of records. */
    @SerializedName("NUMBER_OF_RECORDS")
    @Expose
    private String numberOfRecords;

    /**
     * Gets the sender.
     *
     * @return the sender
     */
    public String getSender() {
        return sender;
    }

    /**
     * Sets the sender.
     *
     * @param sender the new sender
     */
    public void setSender(String sender) {
        this.sender = sender;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Gets the number of records.
     *
     * @return the number of records
     */
    public String getNumberOfRecords() {
        return numberOfRecords;
    }

    /**
     * Sets the number of records.
     *
     * @param numberOfRecords the new number of records
     */
    public void setNumberOfRecords(String numberOfRecords) {
        this.numberOfRecords = numberOfRecords;
    }

}