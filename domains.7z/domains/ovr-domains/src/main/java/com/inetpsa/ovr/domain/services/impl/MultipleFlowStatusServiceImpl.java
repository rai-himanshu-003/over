/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.Flow;
import com.inetpsa.ovr.domain.model.MultipleFlowStatus;
import com.inetpsa.ovr.domain.repository.FlowNameRepository;
import com.inetpsa.ovr.domain.repository.MultipleFlowStatusRepository;
import com.inetpsa.ovr.domain.services.MultipleFlowStatusService;
import com.inetpsa.ovr.interfaces.dto.FlowDto;
import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;
import com.inetpsa.ovr.interfaces.mapper.DataMapper;

/**
 * The Class MultipleFlowStatusServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class MultipleFlowStatusServiceImpl implements MultipleFlowStatusService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(MultipleFlowStatusServiceImpl.class);

    /** The multiple flow status repository. */
    @Inject
    private MultipleFlowStatusRepository multipleFlowStatusRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    @Inject
    private FlowNameRepository flowNameRepository;

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.MultipleFlowStatusService#saveorupdateflowstate(com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO)
     */
    @Override
    public boolean saveorupdateflowstate(MultipleFlowStatusDTO multipleFlowStatusDTO) {

        logger.info("Inside saveorupdateflowstate method: {} ", multipleFlowStatusDTO);

        if (multipleFlowStatusDTO != null) {

            if (multipleFlowStatusDTO.getId() != null)
                multipleFlowStatusRepository.update(multipleFlowStatusDTO.mapToModel());
            else
                multipleFlowStatusRepository.add(multipleFlowStatusDTO.mapToModel());

            return true;
        }

        return false;
    }

    @Override
    public boolean saveorupdateflowstate(MultipleFlowStatus multipleFlowStatus) {

        logger.info("Inside saveorupdateflowstate method: {} ", multipleFlowStatus);

        if (multipleFlowStatus != null) {

            if (multipleFlowStatus.getId() != null)
                multipleFlowStatusRepository.update(multipleFlowStatus);
            else
                multipleFlowStatusRepository.add(multipleFlowStatus);

            return true;
        }

        return false;
    }

    @Override
    public boolean saveflowstate(MultipleFlowStatusDTO multipleFlowStatusDTO) {

        logger.info("Inside saveflowstate method: {} ", multipleFlowStatusDTO);

        if (multipleFlowStatusDTO != null) {
            multipleFlowStatusRepository.add(multipleFlowStatusDTO.mapToModel());
            return true;
        }
        return false;

    }

    @Override
    public boolean updateflowstate(MultipleFlowStatusDTO multipleFlowStatusDTO) {

        if (multipleFlowStatusDTO != null) {
            Optional<MultipleFlowStatus> aggr = multipleFlowStatusRepository.get(multipleFlowStatusDTO.getId());

            if (aggr.isPresent()) {
                aggr.get().setFlow(multipleFlowStatusDTO.getFlow());
                aggr.get().setStatus(multipleFlowStatusDTO.getStatus());
                multipleFlowStatusRepository.update(aggr.get());
            }

            return true;
        }

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.MultipleFlowStatusService#getByVinFlowState(com.inetpsa.ovr.domain.model.MultipleFlowStatus)
     */
    @Override
    public MultipleFlowStatus getByVinFlowState(MultipleFlowStatusDTO multipleFlowStatusDTO) {

        if (multipleFlowStatusDTO != null) {
            MultipleFlowStatus multipleFlowStatus = multipleFlowStatusDTO.mapToModel();

            Specification<MultipleFlowStatus> spec = specificationBuilder.of(MultipleFlowStatus.class).property("vin")
                    .equalTo(multipleFlowStatus.getVin()).and().property("status").equalTo(multipleFlowStatus.getStatus()).and().property("flow")
                    .equalTo(multipleFlowStatus.getFlow()).build();
            List<MultipleFlowStatus> list = multipleFlowStatusRepository.get(spec).collect(Collectors.toList());
            if (list.isEmpty())
                return null;
            return list.get(0);
        }
        return null;
    }

    @Override
    public List<MultipleFlowStatus> getByVin(String vin) {
        Specification<MultipleFlowStatus> spec = specificationBuilder.of(MultipleFlowStatus.class).property("vin").equalTo(vin).build();
        return multipleFlowStatusRepository.get(spec).collect(Collectors.toList());
    }

    @Override
    public Optional<MultipleFlowStatus> getByID(long id) {
        return multipleFlowStatusRepository.get(id);
    }

    @Override
    public List<FlowDto> getFlowList() {
        List<FlowDto> flownames = new ArrayList<>();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        Specification<Flow> spec = specificationBuilder.of(Flow.class).property("flowName").not().equalTo(null).build();
        List<Flow> flows = (flowNameRepository.get(spec, opt)).collect(Collectors.toList());
        for (Flow flow : flows) {
            FlowDto flowDto = DataMapper.flowmapToDto(flow);
            flownames.add(flowDto);
        }
        return flownames;
    }

    @Override
    public boolean updateflowstate(List<String> multipleFlowStatusDTO, String statuscode) {

        StringBuilder idString = new StringBuilder();
        List<String> listOfIds = new ArrayList<>();
        int index = 0;

        if (multipleFlowStatusDTO != null && !multipleFlowStatusDTO.isEmpty()) {
            for (String id : multipleFlowStatusDTO) {
                idString.append("'" + id + "',");

                if ((index % 1000 == 999) || (index == (multipleFlowStatusDTO.size() - 1))) {
                    listOfIds.add(idString.toString().substring(0, idString.length() - 1));
                    idString.setLength(0);
                }

                index++;
            }

            if (listOfIds != null && !listOfIds.isEmpty()) {

                StringBuilder idInClouse = new StringBuilder();
                index = 0;
                for (String listId : listOfIds) {
                    idInClouse.append(" mfs.id in (" + listId + ")  ");

                    if (listOfIds.size() - 1 != index)
                        idInClouse.append(" OR ");

                    index++;
                }

                String queryForMfs = "update MultipleFlowStatus mfs set mfs.status = '" + statuscode
                        + "' , mfs.dateModif = sysdate ,  mfs.version = mfs.version + 1 where " + idInClouse;

                int numberOfRecordsUpdated = this.entityManager.createQuery(queryForMfs).executeUpdate();

                logger.info("Multiple flow status query : {} ", queryForMfs);
                logger.info("Number of records updated : {} ", numberOfRecordsUpdated);

                return true;

            }

        }

        return false;
    }
}
