package com.inetpsa.ovr.domain.services;

import org.seedstack.business.Service;

/**
 * The Interface SDIService.
 */
@Service
public interface SDIService {

    /**
     * Rasie SDI incident.
     *
     * @param type the type
     * @param sdiShortName the sdi short name
     * @param sdiLongDescription the sdi long description
     * @return true, if successful
     */
    boolean rasieSDIIncident(String type, String sdiShortName, String sdiLongDescription);

}
