/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.LcdvOttRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.VehicleLcdvOttService;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

/**
 * The Class VehicleLcdvOttServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class VehicleLcdvOttServiceImpl implements VehicleLcdvOttService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(VehicleLcdvOttServiceImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The specification builder. */
    @Inject
    private LcdvOttRepository lcdvOttRepository;

    /** The vehicle repo. */
    @Inject
    private VehicleRepository vehicleRepo;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#getLcdvOttByVin(java.lang.String)
     */
    @Override
    public List<LcdvOtt> getLcdvOttByVin(String vin) {

        Specification<LcdvOtt> spec = specificationBuilder.of(LcdvOtt.class).property("vin").equalTo(vin).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        return lcdvOttRepository.get(spec, opt).collect(Collectors.toList());

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#deleteLcdvOttById(com.inetpsa.ovr.domain.model.LcdvOtt)
     */
    @Override
    public boolean deleteLcdvOttById(Long lcdvOtt) {

        Optional<LcdvOtt> tobedeleted = lcdvOttRepository.get(lcdvOtt);

        if (tobedeleted.isPresent()) {
            lcdvOttRepository.remove(tobedeleted.get());
            logger.info("LCDV {} : has been deleted successfully!", lcdvOtt);

            Optional<Vehicle> optVehicle = vehicleRepo.get(tobedeleted.get().getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }
            return true;
        }
        logger.info("LCDV {} : is not present in DB", lcdvOtt);

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#addOrUpdateLcdvOtt(com.inetpsa.ovr.domain.model.LcdvOtt)
     */
    @Override
    public ResponseDto addOrUpdateLcdvOtt(LcdvOtt lcdvOtt) {
        ResponseDto responseDto = new ResponseDto();
        boolean flag = false;
        try {

            if (lcdvOtt.getId() != null) {
                responseDto.setId(lcdvOtt.getId().toString());
                lcdvOttRepository.update(lcdvOtt);

                flag = true;
            } else {

                List<BigDecimal> seqNumber = getSequenceCount(OVERConstants.MAGICNUMBER1);
                if (seqNumber != null) {
                    lcdvOtt.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).longValue());
                    responseDto.setId(seqNumber.get(OVERConstants.MAGICNUMBER0).toString());
                    lcdvOttRepository.add(lcdvOtt);
                    flag = true;
                } else {
                    logger.error("Sequence Number is {} Empty from DB : {}", seqNumber, lcdvOtt);

                }
            }
            Optional<Vehicle> optVehicle = vehicleRepo.get(lcdvOtt.getVin());

            if (optVehicle.isPresent()) {
                Vehicle vehicle = optVehicle.get();
                vehicle.preUpdate();
                vehicleRepo.update(vehicle);
            }

            responseDto.setMsg(flag);
            return responseDto;
        } catch (Exception e) {
            logger.error("Error while adding/updating LCDV {} : {}", lcdvOtt, e.getMessage());
            responseDto.setMsg(flag);
            return responseDto;
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.VehicleLcdvOttService#getSequenceCount(int)
     */
    @Override
    public List<BigDecimal> getSequenceCount(int numberOfSeq) {
        return lcdvOttRepository.getSequenceCount(numberOfSeq);
    }
}
