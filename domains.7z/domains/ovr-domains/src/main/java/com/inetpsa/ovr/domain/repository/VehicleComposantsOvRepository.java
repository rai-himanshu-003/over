/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.math.BigDecimal;
import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.PsaKeyMapping;
import com.inetpsa.ovr.interfaces.dto.ws.Criteria;

/**
 * The Interface VehicleComposantsOvRepository.
 */
public interface VehicleComposantsOvRepository extends Repository<ComposantsOv, Long> {

    /**
     * Gets the composants.
     *
     * @param psaKeyMappings the psa key mappings
     * @param vin the vin
     * @return the composants
     */
    List<ComposantsOv> getComposants(List<PsaKeyMapping> psaKeyMappings, String vin);

    /**
     * Gets the composants fr ws.
     *
     * @param psaKeyMappings the psa key mappings
     * @param criteriaList the criteria list
     * @return the composants fr ws
     */
    List<ComposantsOv> getComposantsFrWs(List<PsaKeyMapping> psaKeyMappings, List<Criteria> criteriaList);

    /**
     * Gets the sequence count.
     *
     * @param size the size
     * @return the sequence count
     */
    List<BigDecimal> getSequenceCount(long size);

}
