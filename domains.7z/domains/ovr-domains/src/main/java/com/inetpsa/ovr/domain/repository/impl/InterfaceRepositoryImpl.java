/*
 * Creation : 18 Nov 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.Interface;
import com.inetpsa.ovr.domain.repository.InterfaceRepository;

/**
 * The Class InterfaceRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class InterfaceRepositoryImpl extends BaseJpaRepository<Interface, Long> implements InterfaceRepository {

}
