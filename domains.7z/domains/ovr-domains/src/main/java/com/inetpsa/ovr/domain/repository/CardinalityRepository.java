/*
 * Creation : 16 Jan 2020
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.Cardinality;
import com.inetpsa.ovr.domain.model.CardinalityPk;

/**
 * The Interface CardinalityRepository.
 */
public interface CardinalityRepository extends Repository<Cardinality, CardinalityPk> {

}
