/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import com.inetpsa.ovr.domain.model.Composants;

/**
 * The Class ComposantsDTO added.
 */

public class ComposantsDTO {

    /** The id. */

    private Long compId;

    /** The data. */
    private String compData;

    /** The vin. */
    private String comVin;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return compId;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.compId = id;
    }

    /**
     * Gets the data.
     *
     * @return the data
     */
    public String getData() {
        return compData;
    }

    /**
     * Sets the data.
     *
     * @param data the new data
     */
    public void setData(String data) {
        this.compData = data;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return comVin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.comVin = vin;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Composants [id=" + compId + ", data=" + compData + ", vin=" + comVin + "]";
    }

    /**
     * Map tomodel.
     *
     * @return the composants
     */
    public Composants mapTomodel() {
        Composants composants = new Composants();
        composants.setData(this.getData());
        composants.setId(this.getId());
        composants.setVin(this.getVin());
        return composants;
    }

}
