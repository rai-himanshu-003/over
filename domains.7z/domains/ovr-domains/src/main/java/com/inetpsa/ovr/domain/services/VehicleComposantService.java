/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.math.BigDecimal;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.Composants;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

/**
 * The Interface VehicleComposantService.
 */
@Service
public interface VehicleComposantService {

    /**
     * Gets the composants by vin.
     *
     * @param vin the vin
     * @return the composants by vin
     */
    List<Composants> getComposantsByVin(String vin);

    /**
     * Delete composants by id.
     *
     * @param composants the composants
     * @return true, if successful
     */
    boolean deleteComposantsById(Long composants);

    /**
     * Adds the or update composants.
     *
     * @param composants the composants
     * @return true, if successful
     */
    ResponseDto addOrUpdateComposants(Composants composants);

    /**
     * Gets the sequence count.
     *
     * @param numberOfSeq the number of seq
     * @return the sequence count
     */
    List<BigDecimal> getSequenceCount(int numberOfSeq);

}
