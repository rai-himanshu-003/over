/*
 * Creation : 2 mai 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.util.List;

/**
 * The Class PaginationDto.
 *
 * @param <T> the generic type
 */
public class PaginationDto<T> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -4527943607165453814L;

    /** The response list. */
    private transient List<T> responseList;

    /** The page number. */
    private long pageNumber;

    /** The page size. */
    private long pageSize;

    /** The total records. */
    private long totalRecords;

    /**
     * Gets the response list.
     *
     * @return the response list
     */
    public List<T> getResponseList() {
        return responseList;
    }

    /**
     * Sets the response list.
     *
     * @param responseList the new response list
     */
    public void setResponseList(List<T> responseList) {
        this.responseList = responseList;
    }

    /**
     * Gets the page number.
     *
     * @return the page number
     */
    public long getPageNumber() {
        return pageNumber;
    }

    /**
     * Sets the page number.
     *
     * @param pageNumber the new page number
     */
    public void setPageNumber(long pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * Gets the page size.
     *
     * @return the page size
     */
    public long getPageSize() {
        return pageSize;
    }

    /**
     * Sets the page size.
     *
     * @param pageSize the new page size
     */
    public void setPageSize(long pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * Gets the total records.
     *
     * @return the total records
     */
    public long getTotalRecords() {
        return totalRecords;
    }

    /**
     * Sets the total records.
     *
     * @param totalRecords the new total records
     */
    public void setTotalRecords(long totalRecords) {
        this.totalRecords = totalRecords;
    }

}
