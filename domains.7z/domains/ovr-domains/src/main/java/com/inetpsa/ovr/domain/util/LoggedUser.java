/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.ovr.domain.util;

/**
 * The Class LoggedUser.
 */
public final class LoggedUser {

    /**
     * Instantiates a new logged user.
     */
    private LoggedUser() {
    }

    /** The Constant userHolder. */
    private static final ThreadLocal<String> userHolder = new ThreadLocal<>();

    /**
     * Log in.
     *
     * @param user the user
     */
    public static void logIn(String user) {

        userHolder.set(user);
    }

    /**
     * Log out.
     */
    public static void logOut() {
        userHolder.remove();
    }

    /**
     * Gets the.
     *
     * @return the string
     */
    public static String get() {
        return userHolder.get();
    }

}
