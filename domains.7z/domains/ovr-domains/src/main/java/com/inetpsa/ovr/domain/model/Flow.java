/*
 * Creation : 18 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

/**
 * The Class Interface.
 */
@Entity
@Table(name = "OVRQTFLOW")
public class Flow extends BaseAggregateRoot<Long> {
    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    private Long id;

    /** The interface name. */
    @Column(name = "FLOWNAME")
    @NotNull
    private String flowName;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the flow name.
     *
     * @return the flow name
     */
    public String getFlowName() {
        return flowName;
    }

    /**
     * Sets the flow name.
     *
     * @param flowName the new flow name
     */
    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Flow [id=" + id + ", flowName=" + flowName + "]";
    }

}
