/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.interfaces.dto.FlowVhlMetadataDTO;
import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentDTO;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;

/**
 * The Class OutputFlowDetails.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTOPFL")
public class OutputFlowDetails extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTOPFL_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The flow. */
    @Column(name = "FLOWNAME")
    private String flow;

    /** The lable. */
    @Column(name = "DESCRIPTION")
    private String description;

    /** The value. */
    @Column(name = "FILE_FORMAT_ID")
    private Long format;

    /** The lable. */
    @Column(name = "FREQUENCY")
    private String frequency;

    /** The folder. */
    @Column(name = "FOLDER_LOCATION")
    private String folder;

    /** The value. */
    @Column(name = "fileName")
    private String fileName;

    /** The value. */
    @Column(name = "ACTION")
    private Long action;

    /** The is deleted. */
    @Column(name = "IS_DELETED")
    private String isDeleted;

    /** The date modif. */
    @Column(name = "LAST_RUN")
    private LocalDateTime lastRun;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private LocalDateTime dateCreation;

    /** The date modif. */
    @Column(name = "DATE_MODIF")
    private LocalDateTime dateModif;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The user modif. */
    @Column(name = "USER_MODIF")
    private String userModif;

    /** The version. */
    @Version
    @Column(name = "VERSION")
    private Integer version;

    /** The flow vhl metadatas. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "FLOW_ID")
    private Set<FlowVhlMetadata> flowVhlMetadatas;

    /** The generic collections. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "FLOW_ID")
    private Set<GenericCollection> genericCollections;

    /** The ov components. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "FLOW_ID")
    private Set<OVComponent> ovComponents;

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        dateCreation = LocalDateTime.now();
        userCreation = LoggedUser.get();
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();
    }

    /**
     * Pre update.
     */
    @PreUpdate
    public void preUpdate() {
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();

    }

    /**
     * Gets the last run.
     *
     * @return the last run
     */
    public LocalDateTime getLastRun() {
        return lastRun;
    }

    /**
     * Sets the last run.
     *
     * @param lastRun the new last run
     */
    public void setLastRun(LocalDateTime lastRun) {
        this.lastRun = lastRun;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the new file name
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Gets the checks if is deleted.
     *
     * @return the checks if is deleted
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the checks if is deleted.
     *
     * @param isDeleted the new checks if is deleted
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the flow.
     *
     * @return the flow
     */
    public String getFlow() {
        return flow;
    }

    /**
     * Sets the flow.
     *
     * @param flow the new flow
     */
    public void setFlow(String flow) {
        this.flow = flow;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the format.
     *
     * @return the format
     */
    public Long getFormat() {
        return format;
    }

    /**
     * Sets the format.
     *
     * @param format the new format
     */
    public void setFormat(Long format) {
        this.format = format;
    }

    /**
     * Gets the frequency.
     *
     * @return the frequency
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Sets the frequency.
     *
     * @param frequency the new frequency
     */
    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    /**
     * Gets the folder.
     *
     * @return the folder
     */
    public String getFolder() {
        return folder;
    }

    /**
     * Sets the folder.
     *
     * @param folder the new folder
     */
    public void setFolder(String folder) {
        this.folder = folder;
    }

    /**
     * /** Gets the date creation.
     *
     * @return the date creation
     */
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    /**
     * Gets the action.
     *
     * @return the action
     */
    public Long getAction() {
        return action;
    }

    /**
     * Sets the action.
     *
     * @param action the new action
     */
    public void setAction(Long action) {
        this.action = action;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public LocalDateTime getDateModif() {
        return dateModif;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Gets the flow vhl metadatas.
     *
     * @return the flow vhl metadatas
     */
    public Set<FlowVhlMetadata> getFlowVhlMetadatas() {
        return flowVhlMetadatas;
    }

    /**
     * Sets the flow vhl metadatas.
     *
     * @param flowVhlMetadatas the new flow vhl metadatas
     */
    public void setFlowVhlMetadatas(Set<FlowVhlMetadata> flowVhlMetadatas) {
        this.flowVhlMetadatas = flowVhlMetadatas;
    }

    /**
     * Gets the generic collections.
     *
     * @return the generic collections
     */
    public Set<GenericCollection> getGenericCollections() {
        return genericCollections;
    }

    /**
     * Sets the generic collections.
     *
     * @param genericCollections the new generic collections
     */
    public void setGenericCollections(Set<GenericCollection> genericCollections) {
        this.genericCollections = genericCollections;
    }

    /**
     * Gets the ov components.
     *
     * @return the ov components
     */
    public Set<OVComponent> getOvComponents() {
        return ovComponents;
    }

    /**
     * Sets the ov components.
     *
     * @param ovComponents the new ov components
     */
    public void setOvComponents(Set<OVComponent> ovComponents) {
        this.ovComponents = ovComponents;
    }

    /**
     * Mapto dto.
     *
     * @return the output flow details DTO
     */
    public OutputFlowDetailsDTO maptoDto() {
        OutputFlowDetailsDTO outputFlowDetailsDTO = new OutputFlowDetailsDTO();
        outputFlowDetailsDTO.setFlow(this.getFlow());
        outputFlowDetailsDTO.setId(this.getId());
        outputFlowDetailsDTO.setDescription(this.getDescription());
        outputFlowDetailsDTO.setFileFormatId(this.getFormat());
        outputFlowDetailsDTO.setFrequency(this.getFrequency());
        outputFlowDetailsDTO.setAction(this.getAction());
        outputFlowDetailsDTO.setFolderLocation(this.getFolder());
        outputFlowDetailsDTO.setFileName(this.getFileName());
        outputFlowDetailsDTO.setVersion(this.getVersion());

        return outputFlowDetailsDTO;

    }

    /**
     * Instantiates a new output flow details.
     */
    public OutputFlowDetails() {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "OutputFlowDetails [id=" + id + ", flow=" + flow + ", description=" + description + ", format=" + format + ", frequency=" + frequency
                + ", folder=" + folder + ", fileName=" + fileName + ", action=" + action + ", isDeleted=" + isDeleted + ", lastRun=" + lastRun
                + ", dateCreation=" + dateCreation + ", dateModif=" + dateModif + ", userCreation=" + userCreation + ", userModif=" + userModif
                + ", version=" + version + ", flowVhlMetadatas=" + flowVhlMetadatas + ", genericCollections=" + genericCollections + ", ovComponents="
                + ovComponents + "]";
    }

    /**
     * Mapto dto for FMGT.
     *
     * @return the output flow details DTO
     */
    public OutputFlowDetailsDTO maptoDtoForFMGT() {
        OutputFlowDetailsDTO outputFlowDetailsDTO = new OutputFlowDetailsDTO();
        outputFlowDetailsDTO.setFlow(this.getFlow());
        outputFlowDetailsDTO.setId(this.getId());
        outputFlowDetailsDTO.setDescription(this.getDescription());
        outputFlowDetailsDTO.setFileFormatId(this.getFormat());
        outputFlowDetailsDTO.setFrequency(this.getFrequency());
        outputFlowDetailsDTO.setAction(this.getAction());
        outputFlowDetailsDTO.setFolderLocation(this.getFolder());
        outputFlowDetailsDTO.setFileName(this.getFileName());
        outputFlowDetailsDTO.setVersion(this.getVersion());
        Set<FlowVhlMetadataDTO> flowVhlMetadataDTOs = new HashSet();
        Set<GenericCollectionDTO> genericCollectionDTOs = new HashSet();
        Set<OVComponentDTO> ovComponentDTOs = new HashSet();

        if (this.getFlowVhlMetadatas() != null && !this.getFlowVhlMetadatas().isEmpty()) {
            for (FlowVhlMetadata flowVhlMetadata : this.getFlowVhlMetadatas()) {
                FlowVhlMetadataDTO flowVhlMetadataDTO = flowVhlMetadata.maptoDto();
                flowVhlMetadataDTOs.add(flowVhlMetadataDTO);
            }
            outputFlowDetailsDTO.setFlowVhlMetadataDTOs(flowVhlMetadataDTOs);
        }

        if (this.getGenericCollections() != null && !this.getGenericCollections().isEmpty()) {
            for (GenericCollection genericCollection : this.getGenericCollections()) {
                GenericCollectionDTO genericCollectionDTO = genericCollection.maptoDto();
                genericCollectionDTOs.add(genericCollectionDTO);
            }
            outputFlowDetailsDTO.setCollectionDTOs(genericCollectionDTOs);
        }
        if (this.getOvComponents() != null && !this.getOvComponents().isEmpty()) {
            for (OVComponent ovComponent : this.getOvComponents()) {
                OVComponentDTO ovComponentDTO = ovComponent.maptoDto();
                ovComponentDTOs.add(ovComponentDTO);
            }
            outputFlowDetailsDTO.setOvComponentDTOs(ovComponentDTOs);
        }

        return outputFlowDetailsDTO;

    }

}
