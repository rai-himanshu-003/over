/*
 * Creation : 2 Jul 2019
 */
package com.inetpsa.ovr.domain.constant;

/**
 * common constants enum.
 *
 * @author E566559
 */
public enum CommonConstant {

    /** The interface over. */
    INTERFACE_OVER("OVER_TO_OTT"),

    INTERFACE_OVER_REVOTT("OVER_TO_REVOTT"),

    INTERFACE_REVOTT_OVER("REVOTT_TO_OVER"),

    INTERFACE_OVER_THUB("OVER_TO_THUB"),

    INTERFACE_THUB_OVER("THUB_TO_OVER"),

    /** The interface ott. */
    INTERFACE_OTT("OTT_TO_OVER"),

    /** The user mod ovr ott resp. */
    USER_MOD_OVR_OTT_RESP("OTT"),

    /** The user mod ovr ott resp. */
    USER_MOD_OVR_REVOTT_RESP("REVOTT"),

    USER_MOD_OVR_THUB_RESP("THUB"),

    USER_MOD_OVR_INPUT("OV_INPUT"),

    USER_MOD_PSA_INPUT("PSA_INPUT"),

    GEPICS_INTERFACE("GEPICS"),

    OV_INPUT("OV_INPUT"),

    /** The date format. */
    DATE_FORMAT("dd/MM/yyyy HH:mm:ss"),

    /** The negative magic number. */
    NEGATIVE_MAGIC_NUMBER(-1),

    /** The random number sdi. */
    RANDOM_NUMBER_SDI(1000),

    /** The interface name. */
    INTERFACE_NAME("interfaceName"),

    /** The audit datecreation. */
    AUDIT_DATECREATION("auditPk.dateCreation"),

    /** The user creation. */
    USER_CREATION("userCreation"),

    /** The audit filename. */
    AUDIT_FILENAME("auditPk.fileName"),

    /** The error count. */
    ERROR_COUNT("errorCount"),

    /** The success count. */
    SUCCESS_COUNT("successCount"),

    /** The Err sdi type. */
    SDI_TYPE_ERR("ERR"),

    LIMIT(1000),

    PSA_ORGAN("PSA_ORGAN"),

    PSA_KEY("10"), EXCLUSIVE(2), INCLUSIVE(1), MINECOM("01-Jan-1900"),

    MAXECOM("01-Jan-9999"),

    SEND_RULES_CONSTANT("SEND_RULES_TO_CORVET"),

    PARAMETER_OK("OK"), STD_OTHERS("OTHER"), STD_GMW15862("GMW15862"), YES("Y"), NO("N"),

    INTERFACE_CRONOS("CRONOS"),

    JSON_FORMAT("3"),

    XML_FORMAT("2"),

    FLAT_FORMAT("1"),

    SEPERATOR_DOT("."),

    APPLICATION_OVER("OVER"),

    CONSTANT_1000(1000),

    CONSTANT_0(0),

    CONSTANT_1(1),

    CONSTANT_2(2),

    CONSTANT_3(3),

    CONSTANT_4(4),

    CONSTANT_5(5),

    CONSTANT_6(6),

    CONSTANT_7(7),

    CONSTANT_999(999),

    CONSTANT_C("C"),

    CONSTANT_M("M"),

    CONSTANT_S("S"),

    CONSTANT_CE("CE"),

    TYPE_DATA(
            "RPO,COMPOSANTS_OV,ART_LCDV,CCP,UP,LCDV24,DATE_ECOM,DATE_EMON,DATE_EXTENSION,VEH,V_MODEL,APVPR,NRE,TVV,MODELYEAR,OV_INPUT,OTT,THUB,REVOTT,CORVET"),

    METADATA("CCP,UP,LCDV24,DATE_ECOM,DATE_EMON,DATE_EXTENSION,VEH,V_MODEL,APVPR,NRE,TVV,MODELYEAR"),

    ALLOWED_FLOWS("OV_INPUT,OTT,THUB,REVOTT,CORVET"),

    METADATA_CONSTANT_1("KO -Error MMO-011 : Creation Impossible : METADATA "),

    METADATA_CONSTANT_2(" exists for this vehicle or not in a valid format"),

    METADATA_CONSTANT_3("KO -Error MMO-012 : Modification Impossible : METADATA "),

    METADATA_CONSTANT_4(" don’t exists for this vehicle or not in a valid format"),

    METADATA_CONSTANT_5("KO -Error MMO-013 : Deletion Impossible : Unknown METADATA "),

    METADATA_CONSTANT_6("KO -Error MMO-006 :  ACTION_TYPE "),

    METADATA_CONSTANT_7(" not authorized for METADATA"),

    METADATA_CONSTANT_8("KO -Error MMO-011 : Creation Impossible : METADATA "),

    METADATA_CONSTANT_9(" exists for this vehicle or not in a valid format"),

    OTT_FLOW("OTT"), CORVET_FLOW("CORVET"), REV_OTT_FLOW("REVOTT"), TRANSFORMATION_HUB_FLOW("THUB"), OUTPUT_FLOW("OUTPUT");
    /** The const value. */
    String constValue;

    /**
     * Instantiates a new common constant.
     *
     * @param constValueInt the const value int
     */
    CommonConstant(int constValueInt) {
        this.constValueInt = constValueInt;
    }

    /** The const value int. */
    int constValueInt;

    /**
     * Gets the const value int.
     *
     * @return the const value int
     */
    public int getConstValueInt() {
        return constValueInt;
    }

    /**
     * Instantiates a new common constant.
     *
     * @param constValue the const value
     */
    CommonConstant(String constValue) {
        this.constValue = constValue;
    }

    /**
     * Gets the const value.
     *
     * @return the const value
     */
    public String getConstValue() {
        return constValue;
    }

}
