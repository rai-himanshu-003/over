/*
 * Creation : 27 May 2021
 */
package com.inetpsa.ovr.domain.repository;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.TrackChanges;

public interface TrackChangesRepository extends Repository<TrackChanges, Long> {

    Long generateSequence();

}
