/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.math.BigDecimal;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.LcdvOtt;
import com.inetpsa.ovr.interfaces.dto.ResponseDto;

/**
 * The Interface VehicleLcdvOttService.
 */
@Service
public interface VehicleLcdvOttService {

    /**
     * Gets the lcdv ott by vin.
     *
     * @param vin the vin
     * @return the lcdv ott by vin
     */
    List<LcdvOtt> getLcdvOttByVin(String vin);

    /**
     * Delete lcdv ott by id.
     *
     * @param lcdvOtt the lcdv ott
     * @return true, if successful
     */
    boolean deleteLcdvOttById(Long lcdvOtt);

    /**
     * Adds the or update lcdv ott.
     *
     * @param lcdvOtt the lcdv ott
     * @return true, if successful
     */
    ResponseDto addOrUpdateLcdvOtt(LcdvOtt lcdvOtt);

    /**
     * Gets the sequence count.
     *
     * @param numberOfSeq the number of seq
     * @return the sequence count
     */
    List<BigDecimal> getSequenceCount(int numberOfSeq);

}
