/*
 * Creation : 3 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

/**
 * The Class FIleSequence.
 */
@Entity
@Table(name = "OVRQTOTH")
public class FIleSequence extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    private Long id;

}
