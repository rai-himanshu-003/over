/*
 * Creation : 18 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

/**
 * The Class Interface.
 */
@Entity
@Table(name = "OVRQTINT")
public class Interface extends BaseAggregateRoot<Long> {
    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    private Long id;

    /** The interface name. */
    @Column(name = "INTERFACENAME")
    @NotNull
    private String interfaceName;

    /** The interface rules. */
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "INT_ID")
    private List<InterfaceRule> interfaceRules;

    /**
     * Gets the interface rules.
     *
     * @return the interface rules
     */
    public List<InterfaceRule> getInterfaceRules() {
        return interfaceRules;
    }

    /**
     * Sets the interface rules.
     *
     * @param interfaceRules the new interface rules
     */
    public void setInterfaceRules(List<InterfaceRule> interfaceRules) {
        this.interfaceRules = interfaceRules;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the interface name.
     *
     * @return the interface name
     */
    public String getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the interface name.
     *
     * @param interfaceName the new interface name
     */
    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Interface [id=" + id + ", interfaceName=" + interfaceName + "]";
    }

}
