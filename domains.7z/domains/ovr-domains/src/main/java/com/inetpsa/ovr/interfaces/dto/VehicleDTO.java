/*
 * Creation : 2 Jul 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * The Class VehicleDTO.
 */

public class VehicleDTO {

    /** The vin no. */

    private String vinNo;

    /** The current state. */
    private String currentState;

    /** The ccp. */
    private String ccp;

    /** The veh. */
    private String veh;

    /** The xml ov. */
    private String xmlOv;

    /** The date extension. */
    private Date dateExtension;

    /** The lcdv ott. */
    private String lcdvOtt;

    /** The lcdv 24. */
    private String lcdv24;

    /** The oa. */
    private String oa;

    /** The nrv. */
    private String nre;

    /** The tvv. */
    private String tvv;

    /** The model. */
    private String model;

    /** The model year. */
    private String modelYear;

    /** The apvpr. */
    private String apvpr;

    /** The up. */
    private String up;

    /** The of. */
    private String of;

    /** The date ecom. */
    private Date dateEcom;

    /** The date emon. */
    private Date dateEmon;

    /** The date creation. */
    private LocalDateTime dateCreation;

    /** The user creation. */
    private String userCreation;

    /** The date modif. */
    private LocalDateTime dateModif;

    /** The user modif. */
    private String userModif;

    /** The version. */
    private Integer version;

    /** The user modif. */
    private String isIgnored;

    // Relationships STARTS----->

    /** The composants. */

    private List<ComposantsDTO> composants;

    /** The references electroniques. */

    private List<ReferencesElectroniquesDTO> referencesElectroniques;

    /** The composants ov. */

    private List<ComposantsOvDTO> composantsOv;

    /** The options. */

    private List<OptionsDTO> options;

    /** The keys ov. */

    private List<KeysOvDTO> keysOv;

    /** The lcdv ott ov. */

    private List<LcdvOttDTO> lcdvOttOv;

    // Relationships ENDS----->

    /**
     * Gets the composants.
     *
     * @return the composants
     */
    public List<ComposantsDTO> getComposants() {
        return composants;
    }

    /**
     * Sets the composants.
     *
     * @param composants the new composants
     */
    public void setComposants(List<ComposantsDTO> composants) {
        this.composants = composants;
    }

    /**
     * Gets the references electroniques.
     *
     * @return the references electroniques
     */
    public List<ReferencesElectroniquesDTO> getReferencesElectroniques() {
        return referencesElectroniques;
    }

    /**
     * Sets the references electroniques.
     *
     * @param referencesElectroniques the new references electroniques
     */
    public void setReferencesElectroniques(List<ReferencesElectroniquesDTO> referencesElectroniques) {
        this.referencesElectroniques = referencesElectroniques;
    }

    /**
     * Gets the composants ov.
     *
     * @return the composants ov
     */
    public List<ComposantsOvDTO> getComposantsOv() {
        return composantsOv;
    }

    /**
     * Sets the composants ov.
     *
     * @param composantsOv the new composants ov
     */
    public void setComposantsOv(List<ComposantsOvDTO> composantsOv) {
        this.composantsOv = composantsOv;
    }

    /**
     * Gets the options.
     *
     * @return the options
     */
    public List<OptionsDTO> getOptions() {
        return options;
    }

    /**
     * Sets the options.
     *
     * @param options the new options
     */
    public void setOptions(List<OptionsDTO> options) {
        this.options = options;
    }

    /**
     * Gets the keys ov.
     *
     * @return the keys ov
     */
    public List<KeysOvDTO> getKeysOv() {
        return keysOv;
    }

    /**
     * Sets the keys ov.
     *
     * @param keysOv the new keys ov
     */
    public void setKeysOv(List<KeysOvDTO> keysOv) {
        this.keysOv = keysOv;
    }

    /**
     * Gets the lcdv ott ov.
     *
     * @return the lcdv ott ov
     */
    public List<LcdvOttDTO> getLcdvOttOv() {
        return lcdvOttOv;
    }

    /**
     * Sets the lcdv ott ov.
     *
     * @param lcdvOttOv the new lcdv ott ov
     */
    public void setLcdvOttOv(List<LcdvOttDTO> lcdvOttOv) {
        this.lcdvOttOv = lcdvOttOv;
    }

    /**
     * Gets the lcdv 24.
     *
     * @return the lcdv 24
     */
    public String getLcdv24() {
        return lcdv24;
    }

    /**
     * Sets the lcdv 24.
     *
     * @param lcdv24 the new lcdv 24
     */
    public void setLcdv24(String lcdv24) {
        this.lcdv24 = lcdv24;
    }

    /**
     * Gets the oa.
     *
     * @return the oa
     */
    public String getOa() {
        return oa;
    }

    /**
     * Sets the oa.
     *
     * @param oa the new oa
     */
    public void setOa(String oa) {
        this.oa = oa;
    }

    /**
     * Gets the nre.
     *
     * @return the nre
     */
    public String getNre() {
        return nre;
    }

    /**
     * Sets the nre.
     *
     * @param nre the new nre
     */
    public void setNre(String nre) {
        this.nre = nre;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Sets the tvv.
     *
     * @param tvv the new tvv
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * Gets the model.
     *
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model.
     *
     * @param model the new model
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Gets the model year.
     *
     * @return the model year
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the model year.
     *
     * @param modelYear the new model year
     */
    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    /**
     * Gets the apvpr.
     *
     * @return the apvpr
     */
    public String getApvpr() {
        return apvpr;
    }

    /**
     * Sets the apvpr.
     *
     * @param apvpr the new apvpr
     */
    public void setApvpr(String apvpr) {
        this.apvpr = apvpr;
    }

    /**
     * Gets the up.
     *
     * @return the up
     */
    public String getUp() {
        return up;
    }

    /**
     * Sets the up.
     *
     * @param up the new up
     */
    public void setUp(String up) {
        this.up = up;
    }

    /**
     * Gets the of.
     *
     * @return the of
     */
    public String getOf() {
        return of;
    }

    /**
     * Sets the of.
     *
     * @param of the new of
     */
    public void setOf(String of) {
        this.of = of;
    }

    /**
     * Gets the date ecom.
     *
     * @return the date ecom
     */
    public Date getDateEcom() {
        return dateEcom;
    }

    /**
     * Sets the date ecom.
     *
     * @param dateEcom the new date ecom
     */
    public void setDateEcom(Date dateEcom) {
        this.dateEcom = dateEcom;
    }

    /**
     * Gets the date emon.
     *
     * @return the date emon
     */
    public Date getDateEmon() {
        return dateEmon;
    }

    /**
     * Sets the date emon.
     *
     * @param dateEmon the new date emon
     */
    public void setDateEmon(Date dateEmon) {
        this.dateEmon = dateEmon;
    }

    /**
     * Gets the vin no.
     *
     * @return the vin no
     */
    public String getVinNo() {
        return vinNo;
    }

    /**
     * Sets the vin no.
     *
     * @param vinNo the new vin no
     */
    public void setVinNo(String vinNo) {
        this.vinNo = vinNo;
    }

    /**
     * Gets the current state.
     *
     * @return the current state
     */
    public String getCurrentState() {
        return currentState;
    }

    /**
     * Sets the current state.
     *
     * @param currentState the new current state
     */
    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    /**
     * Gets the xml ov.
     *
     * @return the xml ov
     */
    public String getXmlOv() {
        return xmlOv;
    }

    /**
     * Sets the xml ov.
     *
     * @param xmlOv the new xml ov
     */
    public void setXmlOv(String xmlOv) {
        this.xmlOv = xmlOv;
    }

    /**
     * Gets the date extension.
     *
     * @return the date extension
     */
    public Date getDateExtension() {
        return dateExtension;
    }

    /**
     * Sets the date extension.
     *
     * @param dateExtension the new date extension
     */
    public void setDateExtension(Date dateExtension) {
        this.dateExtension = dateExtension;
    }

    /**
     * Gets the lcdv ott.
     *
     * @return the lcdv ott
     */
    public String getLcdvOtt() {
        return lcdvOtt;
    }

    /**
     * Sets the lcdv ott.
     *
     * @param lcdvOtt the new lcdv ott
     */
    public void setLcdvOtt(String lcdvOtt) {
        this.lcdvOtt = lcdvOtt;
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public LocalDateTime getDateModif() {
        return dateModif;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Gets the ccp.
     *
     * @return the ccp
     */
    public String getCcp() {
        return ccp;
    }

    /**
     * Sets the ccp.
     *
     * @param ccp the new ccp
     */
    public void setCcp(String ccp) {
        this.ccp = ccp;
    }

    /**
     * Gets the veh.
     *
     * @return the veh
     */
    public String getVeh() {
        return veh;
    }

    /**
     * Sets the veh.
     *
     * @param veh the new veh
     */
    public void setVeh(String veh) {
        this.veh = veh;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * sets the version.
     *
     * @param version the version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the checks if is ignored.
     *
     * @return the checks if is ignored
     */
    public String getIsIgnored() {
        return isIgnored;
    }

    /**
     * Sets the checks if is ignored.
     *
     * @param isIgnored the new checks if is ignored
     */
    public void setIsIgnored(String isIgnored) {
        this.isIgnored = isIgnored;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Vehicle [vinNo=" + vinNo + ", currentState=" + currentState + ", ccp=" + ccp + ", veh=" + veh + ", xmlOv=" + xmlOv
                + ", dateExtension=" + dateExtension + ", lcdvOtt=" + lcdvOtt + ", dateCreation=" + dateCreation + ", userCreation=" + userCreation
                + ", dateModif=" + dateModif + ", userModif=" + userModif + "]";
    }

}
