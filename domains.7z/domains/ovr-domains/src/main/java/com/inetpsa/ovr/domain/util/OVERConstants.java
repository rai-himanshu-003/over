/*
 * Creation : 3 Jul 2019
 */
package com.inetpsa.ovr.domain.util;

/**
 * The Class OVERConstants.
 */
// change to OVERConstants, check with interface too
public final class OVERConstants {

    /**
     * Instantiates a new OVER constants.
     */
    // private constructor
    private OVERConstants() {
    }

    /** The Constant KO. */
    // Constants for OVRQTPAR Table for OTT_FLOW_STATE static values
    public static final String KO = "KO";

    /** The Constant OK. */
    public static final String OK = "OK";

    /** The Constant OTT_FLOW_STATE. */
    public static final String OTT_FLOW_STATE = "OTT_FLOW_STATE";

    /** The Constant OTT_FREQUENCY. */
    public static final String OTT_FREQUENCY = "OTT_FREQUENCY";

    /** The Constant OTT_MAX_WAITING. */
    public static final String OTT_MAX_WAITING = "OTT_MAX_WAITING";

    /** The Constant INTERFACE_NAME. */
    public static final String INTERFACE_NAME = "OVER_TO_OTT";

    /** The Constant WAITING. */
    // Constants for OVRQTSTS Table for OVER_TO_OTT Interface
    public static final String WAITING = "WAITING";

    /** The Constant STOPPED. */
    public static final String STOPPED = "STOPPED";

    /** The Constant ACTIVE. */
    public static final String ACTIVE = "ACTIVE";

    /** The Constant USER_NAME. */
    // batch user name
    public static final String USER_NAME = "OTT_REQUEST";

    /** The Constant BATCH_NAME. */
    public static final String BATCH_NAME = "OTT_REQUEST";

    /** The Constant CREATED. */
    // CURRENT STATUS STATIC DATA
    public static final String CREATED = "CRTD";

    /** The Constant TRANSLATED_ON_PROGRESS. */
    public static final String TRANSLATED_ON_PROGRESS = "ONPR";

    /** The Constant TRANSLATED_DONE. */
    public static final String TRANSLATED_DONE = "TRDN";

    /** The Constant SENT_TO_CORVET. */
    public static final String SENT_TO_CORVET = "ONPR";

    /** The Constant KO_TRSNSLATION. */
    public static final String KO_TRSNSLATION = "STCR";

    /** The Constant KO_TO_RETRANSLATE. */
    public static final String KO_TO_RETRANSLATE = "RETR";

    /** The Constant CANCELLED. */
    public static final String CANCELLED = "CNLD";

    /** The Constant FOOTER. */
    // TO_OTT request file footer value
    public static final String FOOTER = "F000";

    /** The Constant TIMER1000. */
    public static final int TIMER1000 = 1000;

    /** The Constant TIMER60. */
    public static final int TIMER60 = 60;

    /** The Constant MAGICNUMBER0. */
    public static final int MAGICNUMBER0 = 0;

    /** The Constant MAGICNUMBER1. */
    public static final int MAGICNUMBER1 = 1;

    /** The Constant MAGICNUMBER2. */
    public static final int MAGICNUMBER2 = 2;

    /** The Constant MAGICNUMBER3. */
    public static final int MAGICNUMBER3 = 3;

    /** The Constant MAGICNUMBER4. */
    public static final int MAGICNUMBER4 = 4;

    /** The Constant MAGICNUMBER5. */
    public static final int MAGICNUMBER5 = 5;

    /** The Constant MAGICNUMBER6. */
    public static final int MAGICNUMBER6 = 6;

    /** The Constant MAGICNUMBER7. */
    public static final int MAGICNUMBER7 = 7;

    /** The Constant MAGICNUMBER8. */
    public static final int MAGICNUMBER8 = 8;

    /** The Constant MAGICNUMBER8. */
    public static final int MAGICNUMBER9 = 9;

    /** The Constant MAGICNUMBER10. */
    public static final int MAGICNUMBER10 = 10;

    /** The Constant MAGICNUMBER16. */
    public static final int MAGICNUMBER16 = 16;

}
