/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.MultipleFlowStatus;
import com.inetpsa.ovr.interfaces.dto.FlowDto;
import com.inetpsa.ovr.interfaces.dto.MultipleFlowStatusDTO;

/**
 * The Interface PsaKeyMappingService.
 */
@Service
public interface MultipleFlowStatusService {

    /**
     * Saveorupdateflowstate.
     *
     * @param multipleFlowStatusDTO the multiple flow status DTO
     * @return true, if successful
     */
    boolean saveorupdateflowstate(MultipleFlowStatusDTO multipleFlowStatusDTO);

    /**
     * Gets the by vin flow state.
     *
     * @param multipleFlowStatusDTO the multiple flow status DTO
     * @return the by vin flow state
     */
    MultipleFlowStatus getByVinFlowState(MultipleFlowStatusDTO multipleFlowStatusDTO);

    /**
     * Gets the by vin.
     *
     * @param vin the vin
     * @return the by vin
     */
    List<MultipleFlowStatus> getByVin(String vin);

    /**
     * Gets the by ID.
     *
     * @param id the id
     * @return the by ID
     */
    Optional<MultipleFlowStatus> getByID(long id);

    /**
     * Saveflowstate.
     *
     * @param multipleFlowStatusDTO the multiple flow status DTO
     * @return true, if successful
     */
    boolean saveflowstate(MultipleFlowStatusDTO multipleFlowStatusDTO);

    /**
     * Updateflowstate.
     *
     * @param multipleFlowStatusDTO the multiple flow status DTO
     * @return true, if successful
     */
    boolean updateflowstate(MultipleFlowStatusDTO multipleFlowStatusDTO);

    List<FlowDto> getFlowList();

    /**
     * Updateflowstate.
     *
     * @param multipleFlowStatusDTO the multiple flow status DTO
     * @return true, if successful
     */
    boolean updateflowstate(List<String> multipleFlowStatusDTO, String statusCode);

    boolean saveorupdateflowstate(MultipleFlowStatus multipleFlowStatus);

}
