package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;

import com.inetpsa.ovr.domain.model.GenericCollection;

/**
 * The Class GenericCollectionDTO.
 */
public class GenericCollectionDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The id. */
    private Long id;

    /** The flow id. */
    private Long flowId;

    /** The seq. */
    private Long seq;

    /** The value. */
    private Long value;

    /** The filter. */
    private String filter;

    /** The separator. */
    private String separator;

    /** The int separator. */
    private String intSeparator;

    /** The alignment. */
    private Long alignment;

    /** The max occ. */
    private Long maxOcc;

    @Override
    public String toString() {
        return "GenericCollectionDTO [id=" + id + ", flowId=" + flowId + ", seq=" + seq + ", value=" + value + ", filter=" + filter + ", separator="
                + separator + ", intSeparator=" + intSeparator + ", alignment=" + alignment + ", maxOcc=" + maxOcc + "]";
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the seq.
     *
     * @return the seq
     */
    public Long getSeq() {
        return seq;
    }

    /**
     * Sets the seq.
     *
     * @param seq the new seq
     */
    public void setSeq(Long seq) {
        this.seq = seq;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * Gets the separator.
     *
     * @return the separator
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * Sets the separator.
     *
     * @param separator the new separator
     */
    public void setSeparator(String separator) {
        this.separator = separator;
    }

    /**
     * Gets the flow id.
     *
     * @return the flow id
     */
    public Long getFlowId() {
        return flowId;
    }

    /**
     * Sets the flow id.
     *
     * @param flowId the new flow id
     */
    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    /**
     * Gets the int separator.
     *
     * @return the int separator
     */
    public String getIntSeparator() {
        return intSeparator;
    }

    /**
     * Sets the int separator.
     *
     * @param intSeparator the new int separator
     */
    public void setIntSeparator(String intSeparator) {
        this.intSeparator = intSeparator;
    }

    /**
     * Gets the alignment.
     *
     * @return the alignment
     */
    public Long getAlignment() {
        return alignment;
    }

    /**
     * Sets the alignment.
     *
     * @param alignment the new alignment
     */
    public void setAlignment(Long alignment) {
        this.alignment = alignment;
    }

    /**
     * Gets the max occ.
     *
     * @return the max occ
     */
    public Long getMaxOcc() {
        return maxOcc;
    }

    /**
     * Sets the max occ.
     *
     * @param maxOcc the new max occ
     */
    public void setMaxOcc(Long maxOcc) {
        this.maxOcc = maxOcc;
    }

    /**
     * Map tomodel.
     *
     * @return the output flow details
     */
    public GenericCollection mapTomodel() {

        GenericCollection genericCollection = new GenericCollection();
        genericCollection.setFlowId(this.getFlowId());// need to change
        genericCollection.setSeq(this.getSeq());
        genericCollection.setSeparator(this.getSeparator());
        genericCollection.setIntSeparator(this.getIntSeparator());
        genericCollection.setMaxOcc(this.getMaxOcc());
        genericCollection.setAlignment(this.getAlignment());
        genericCollection.setValue(this.getValue());
        genericCollection.setFilter(this.getFilter());
        return genericCollection;
    }

}
