/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.model.Composants;
import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.Options2;
import com.inetpsa.ovr.domain.model.ReferencesElectroniques;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.model.VehicleError;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;
import com.inetpsa.ovr.interfaces.dto.ws.RequestObj;
import com.inetpsa.ovr.interfaces.dto.ws.ResponseObj;

/**
 * The Interface VehicleService.
 *
 * @author E567673
 */

@Service
public interface VehicleService {

    /**
     * Update vehicles.
     *
     * @param vehicles the vehicles
     * @param flowname the flowname
     * @param multipleFlowStatusList the multiple flow status list
     * @param statusCode the status code
     */
    void updateVehicles(List<Vehicle> vehicles, String flowname, List<String> multipleFlowStatusList, String statusCode);

    /**
     * Adds the vehicle error.
     *
     * @param vehicleError the vehicle error
     */
    void addVehicleError(VehicleError vehicleError);

    /**
     * Add new vehicle.
     *
     * @param vehicles the vehicle
     * @param flowname the flowname
     */
    void addVehicles(List<Vehicle> vehicles, String flowname);

    /**
     * Update vehicle.
     *
     * @param vehicle the vehicle
     * @param flowname the flowname
     */
    void updateVehicle(Vehicle vehicle, String flowname);

    /**
     * This method get details of vin with given filter criteria.
     *
     * @param resendToOTTDto of type {@link ResendToOTTDto} represents the code attribute
     * @param offsetPositionToStartFrom of type {@literal int} represent the start position of the range
     * @param rowsPerPage of type {@literal int} represent the number of elements to get.
     * @param toIgnore of type {@literal boolean} represent if toIgnore vehicles to fetch.
     * @return a {@link List} of {@link ResendToOTTDto}
     */
    List<ResendToOTTDto> getErrList(ResendToOTTDto resendToOTTDto, int offsetPositionToStartFrom, int rowsPerPage, boolean toIgnore);

    /**
     * Update status.
     *
     * @param resendToOTTDto the resend to OTT dto
     * @param status the status
     * @return the boolean
     */
    boolean updateStatus(ResendToOTTDto resendToOTTDto, String status);

    /**
     * This method get the total of records.
     *
     * @param resendToOTTDto of type {@link ResendToOTTDto} represents the code attribute
     * @param toIgnore the to ignore
     * @return a number of type {@link Long}
     */
    long getTotalErrRecords(ResendToOTTDto resendToOTTDto, boolean toIgnore);

    /**
     * This method get vehicle details of given vin.
     *
     * @param vinNo of type {@link String} represents the code attribute
     * @return a details of type {@link Vehicle}
     */
    Vehicle getVehicleDetails(String vinNo);

    /**
     * This method get vehicle details of given vin.
     * 
     * @param vinNo the vinnumber passed
     * @return the vehicle details
     */
    Optional<Vehicle> getOvVehicleDetails(String vinNo);

    /**
     * Gets the veh err hist list.
     *
     * @param vin the vin
     * @return the veh err hist list
     */
    List<VehicleDetailsDto> getVehErrHistList(String vin);

    /**
     * Gets the veh hist list.
     *
     * @param vin the vin
     * @return the veh hist list
     */
    List<VehicleDetailsDto> getVehHistList(String vin);

    /**
     * Gets the veh err hist list count.
     *
     * @param vin the vin
     * @return the veh err hist list count
     */
    long getVehErrHistListCount(String vin);

    /**
     * Gets the veh hist list count.
     *
     * @param vin the vin
     * @return the veh hist list count
     */
    long getVehHistListCount(String vin);

    /**
     * Update vehicle details.
     *
     * @param vehicle the vehicle
     * @param flowname the flowname
     * @return the boolean
     */
    Boolean updateVehicleDetails(VehicleDetailsDto vehicle, String flowname);

    /**
     * Gets the vehicles details.
     *
     * @param vehicleSearchDto the vehicle search dto
     * @param offsetPositionToStartFrom the offset position to start from
     * @param rowsPerPage the rows per page
     * @return the vehicles details
     */
    List<ResendToOTTDto> getVehiclesDetails(ResendToOTTDto vehicleSearchDto, int offsetPositionToStartFrom, int rowsPerPage);

    /**
     * Gets the total vehicle count.
     *
     * @param vehicleSearchDto the vehicle search dto
     * @return the total vehicle count
     */
    /**
     * @param vehicleSearchDto
     * @return
     */
    long getTotalVehicleCount(ResendToOTTDto vehicleSearchDto);

    /**
     * Update vehicles and lcdv.
     *
     * @param vehicles the vehicles
     * @param lcdvTokenList the lcdv token list
     * @param flowname the flowname
     * @param multipleFlowStatusList the multiple flow status list
     * @param statusCode the status code
     * @param count the count
     */
    void updateVehiclesAndLcdv(List<Vehicle> vehicles, List<String[]> lcdvTokenList, String flowname, List<String> multipleFlowStatusList,
            String statusCode, long count);

    /**
     * Add vehicles and lcdv.
     *
     * @param vehicles the vehicles
     * @param lcdvTokenList the lcdv token list
     * @param flowname the flowname
     * @param count the count
     */
    void addVehiclesAndLcdv(List<Vehicle> vehicles, List<String[]> lcdvTokenList, String flowname, long count);

    /**
     * Gets the vehicle information ws.
     *
     * @param requestObj the request obj
     * @return the vehicle information ws
     */
    ResponseObj getVehicleInformationWs(RequestObj requestObj);

    /**
     * Fetch cardinality by ov std.
     *
     * @param ovStd the ov std
     * @param ovKey the ov key
     * @return the int
     */
    int fetchCardinalityByOvStd(String ovStd, String ovKey);

    /**
     * Find cardinality.
     *
     * @param psaType the psa type
     * @param psaKey the psa key
     * @return the int
     */
    int findCardinality(String psaType, String psaKey);

    /**
     * Adds the vehiclesand rpo.
     *
     * @param vehicles the vehicles
     * @param rpoTokenList the rpo token list
     * @param flowname the flowname
     * @param multipleFlowStatusList the multiple flow status list
     * @param statusCode the status code
     * @param count the count
     */
    void addVehiclesandRpo(List<Vehicle> vehicles, List<String[]> rpoTokenList, String flowname, List<String> multipleFlowStatusList,
            String statusCode, long count);

    /**
     * Update vehicles and art lcdv.
     *
     * @param vehicles the vehicles
     * @param lcdvs the lcdvs
     * @param flowname the flowname
     * @param multipleFlowStatusList the multiple flow status list
     * @param statusCode the status code
     * @param count the count
     */
    void updateVehiclesAndArtLcdv(List<Vehicle> vehicles, Map<String, List<ArtLcdvOtt>> lcdvs, String flowname, List<String> multipleFlowStatusList,
            String statusCode, long count);

    /**
     * Adds the all comp data.
     *
     * @param vehOptions the veh options
     * @param comp the comp
     * @param ref the ref
     * @param compOv the comp ov
     * @param optCount the opt count
     * @param compCount the comp count
     * @param compovCount the compov count
     * @param refECount the ref E count
     */
    void addAllCompData(Set<Options> vehOptions, Set<Composants> comp, Set<ReferencesElectroniques> ref, Set<ComposantsOv> compOv, long optCount,
            long compCount, long compovCount, long refECount);

    /**
     * Gets the vehicle details fr ott resp.
     *
     * @param vinNo the vin no
     * @return the vehicle details fr ott resp
     */
    Vehicle getVehicleDetailsFrOttResp(String vinNo);

    /**
     * Gets the vehicle details to ott req.
     *
     * @param vinNo the vin no
     * @return the vehicle details to ott req
     */
    Vehicle getVehicleDetailsToOttReq(String vinNo);

    /**
     * Gets the vehicle details to rev ott req.
     *
     * @param vinNo the vin no
     * @return the vehicle details to rev ott req
     */
    Vehicle getVehicleDetailsToRevOttReq(String vinNo);

    /**
     * Gets the vehicle details to corvet.
     *
     * @param vinNo the vin no
     * @return the vehicle details to corvet
     */
    Vehicle getVehicleDetailsToCorvet(String vinNo);

    /**
     * Gets the vehicle list.
     *
     * @param vinList the vin list
     * @return the vehicle list
     */
    List<Vehicle> getVehicleList(List<String> vinList);

    /**
     * Gets the vehicle details to thub req.
     *
     * @param vinList the vin list
     * @return the vehicle details to thub req
     */
    Map<String, Vehicle> getVehicleDetailsToThubReq(List<String> vinList);

    /**
     * Save gepics data.
     *
     * @param vehicles the vehicles
     * @param flowname the flowname
     * @param vehOptions the veh options
     * @param comp the comp
     * @param ref the ref
     * @param compOv the comp ov
     * @param optCount the opt count
     * @param compCount the comp count
     * @param compovCount the compov count
     * @param refECount the ref E count
     */
    void saveGepicsData(List<Vehicle> vehicles, String flowname, Set<Options> vehOptions, Set<Composants> comp, Set<ReferencesElectroniques> ref,
            Set<ComposantsOv> compOv, long optCount, long compCount, long compovCount, long refECount);

    /**
     * Save gepics rpo.
     *
     * @param vehicles the vehicles
     * @param flowname the flowname
     * @param vehOptions the veh options
     * @param optCount the opt count
     */
    void saveGepicsRpo(List<Vehicle> vehicles, String flowname, Set<Options> vehOptions, long optCount);

    /**
     * Save gepics data rpo 2.
     *
     * @param vehicles the vehicles
     * @param flowname the flowname
     * @param vehOptions2 the veh options 2
     * @param comp the comp
     * @param ref the ref
     * @param compOv the comp ov
     * @param optCount the opt count
     * @param compCount the comp count
     * @param compovCount the compov count
     * @param refECount the ref E count
     */
    void saveGepicsDataRpo2(List<Vehicle> vehicles, String flowname, Set<Options2> vehOptions2, Set<Composants> comp,
            Set<ReferencesElectroniques> ref, Set<ComposantsOv> compOv, long optCount, long compCount, long compovCount, long refECount);

    /**
     * Adds the or update vehicle.
     *
     * @param vehicle the vehicle
     * @return true, if successful
     */
    boolean addOrUpdateVehicle(Vehicle vehicle);

    /**
     * Gets the vehicle history list.
     *
     * @param vin the vin
     * @return the vehicle history list
     */
    List<VehicleDetailsDto> getMMVehicleHistoryList(String vin);
}
