/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.TechnicalParameter;
import com.inetpsa.ovr.domain.repository.TechnicalParameterRepository;

/**
 * The Class TechnicalParameterRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class TechnicalParameterRepositoryImpl extends BaseJpaRepository<TechnicalParameter, String> implements TechnicalParameterRepository {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(TechnicalParameterRepositoryImpl.class);

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.TechnicalParameterRepository#getAllTechParam()
     */
    @Override
    public List<TechnicalParameter> getAllTechParam() {

        logger.info("Entering getParamList of TechParamJPAImpl");
        CriteriaBuilder criteriaBuilder = super.getEntityManager().getCriteriaBuilder();
        CriteriaQuery<TechnicalParameter> criteriaQuery = criteriaBuilder.createQuery(TechnicalParameter.class);
        Root<TechnicalParameter> root = criteriaQuery.from(TechnicalParameter.class);
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get("code")));
        TypedQuery<TechnicalParameter> typedQuery = super.getEntityManager().createQuery(criteriaQuery.select(root));
        logger.info("Exiting getParamList of TechParamJPAImpl");
        return typedQuery.getResultList();

    }

}
