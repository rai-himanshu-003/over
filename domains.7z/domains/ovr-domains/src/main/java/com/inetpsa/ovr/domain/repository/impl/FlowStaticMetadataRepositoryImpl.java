/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.FlowStaticMetadata;
import com.inetpsa.ovr.domain.repository.FlowStaticMetadataRepository;

/**
 * The Class FlowStaticMetadataRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class FlowStaticMetadataRepositoryImpl extends BaseJpaRepository<FlowStaticMetadata, Long> implements FlowStaticMetadataRepository {

}