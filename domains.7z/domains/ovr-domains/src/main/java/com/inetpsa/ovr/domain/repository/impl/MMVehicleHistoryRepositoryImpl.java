/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.ovr.domain.model.MMVehicleHistory;
import com.inetpsa.ovr.domain.repository.MMVehicleHistoryRepository;

/**
 * The Class VehicleHistoryRepositoryImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class MMVehicleHistoryRepositoryImpl extends BaseJpaRepository<MMVehicleHistory, Long> implements MMVehicleHistoryRepository {

}
