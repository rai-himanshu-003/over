/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.google.gson.Gson;
import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.constant.FormatManagementConstant;
import com.inetpsa.ovr.domain.constant.TranslationState;
import com.inetpsa.ovr.domain.model.ArtLcdvOtt;
import com.inetpsa.ovr.domain.model.Audit;
import com.inetpsa.ovr.domain.model.AuditPk;
import com.inetpsa.ovr.domain.model.ComposantsOv;
import com.inetpsa.ovr.domain.model.FlowStaticMetadata;
import com.inetpsa.ovr.domain.model.FlowVhlMetadata;
import com.inetpsa.ovr.domain.model.GenericCollection;
import com.inetpsa.ovr.domain.model.OVComponent;
import com.inetpsa.ovr.domain.model.OVComponentPart;
import com.inetpsa.ovr.domain.model.Options;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.AuditRepository;
import com.inetpsa.ovr.domain.repository.FlowManagementDetailsRepository;
import com.inetpsa.ovr.domain.repository.FlowStaticMetadataRepository;
import com.inetpsa.ovr.domain.repository.FlowVhlMetadataRepository;
import com.inetpsa.ovr.domain.repository.GenericCollectionRepository;
import com.inetpsa.ovr.domain.repository.OVComponentPartRepository;
import com.inetpsa.ovr.domain.repository.OVComponentRepository;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.services.FlatFileService;
import com.inetpsa.ovr.domain.services.FormatManagementService;
import com.inetpsa.ovr.interfaces.dto.FlowVhlMetadataDTO;
import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentDTO;
import com.inetpsa.ovr.interfaces.dto.OVComponentPartDTO;
import com.inetpsa.ovr.interfaces.dto.OutputFlowDetailsDTO;
import com.inetpsa.ovr.interfaces.dto.json.OpFlJson;
import com.inetpsa.ovr.interfaces.dto.json.OpFooter;
import com.inetpsa.ovr.interfaces.dto.json.OpHeader;
import com.inetpsa.ovr.interfaces.dto.json.OpVehicule;
import com.inetpsa.ovr.interfaces.dto.json.OpVehiculeData;
import com.inetpsa.ovr.interfaces.dto.ws.ComponentsOv;
import com.inetpsa.ovr.interfaces.dto.xml.FORMAT;
import com.inetpsa.ovr.interfaces.dto.xml.ObjectFactory;

/**
 * The Class FormatManagementServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class FormatManagementServiceImpl implements FormatManagementService {

    /** The Constant logger. */
    public static final Logger logger = LoggerFactory.getLogger(FormatManagementServiceImpl.class);

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /** The Constant FILE_FORMAT_DATE. */
    private static final String FILE_FORMAT_DATE = "yyyyMMddHHmmss";

    /** The specification builder. */
    @Inject
    private FlowManagementDetailsRepository flowManagementDetailsRepository;

    /** The flow vhl metadata repository. */
    @Inject
    private FlowVhlMetadataRepository flowVhlMetadataRepository;

    /** The generic collection repository. */
    @Inject
    private GenericCollectionRepository genericCollectionRepository;

    /** The ov component repository. */
    @Inject
    private OVComponentRepository ovComponentRepository;

    /** The ov component part repository. */
    @Inject
    private OVComponentPartRepository ovComponentPartRepository;

    /** The flow static metadata repository. */
    @Inject
    private FlowStaticMetadataRepository flowStaticMetadataRepository;

    /** The vehicle repository. */
    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    FlatFileService flatFileService;

    @Inject
    private AuditRepository auditRepository;

    public void setAuditRepository(AuditRepository auditRepository) {
        this.auditRepository = auditRepository;
    }

    private StringBuilder lcdvWhereClause;
    private StringBuilder rpoWhereClause;
    private StringBuilder compOvWhereClause;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.FormatManagementService#getFlowStaticMetadata()
     */
    @Override
    public List<FlowStaticMetadata> getFlowStaticMetadata() {

        Specification<FlowStaticMetadata> spec = specificationBuilder.of(FlowStaticMetadata.class).property("id").not().equalTo(null).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        return flowStaticMetadataRepository.get(spec, opt).collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.FormatManagementService#getflowDetailsById(java.lang.Long)
     */
    @Override
    public OutputFlowDetailsDTO getflowDetailsById(Long flowId) {
        Specification<OutputFlowDetails> spec = specificationBuilder.of(OutputFlowDetails.class).property("id").equalTo(flowId).and()
                .property("isDeleted").not().equalTo(CommonConstant.YES.getConstValue()).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        Optional<OutputFlowDetails> outputFlowDetails = flowManagementDetailsRepository.get(spec, opt).findFirst();

        if (outputFlowDetails.isPresent()) {
            OutputFlowDetails opFlowDetails = outputFlowDetails.get();
            return opFlowDetails.maptoDtoForFMGT();
        }
        return null;
    }

    @Override
    public OutputFlowDetails getflowDetailsByName(String flowname) {
        Specification<OutputFlowDetails> spec = specificationBuilder.of(OutputFlowDetails.class).property("flow").equalTo(flowname).and()
                .property("isDeleted").not().equalTo(CommonConstant.YES.getConstValue()).build();
        SortOption opt = new SortOption();
        opt.add("id", Direction.ASCENDING);
        Optional<OutputFlowDetails> outputFlowDetails = flowManagementDetailsRepository.get(spec, opt).findFirst();

        return (outputFlowDetails.isPresent()) ? outputFlowDetails.get() : null;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.FormatManagementService#addOrUpdateFormatDetails(com.inetpsa.ovr.domain.model.OutputFlowDetails)
     */
    @Override
    public boolean addOrUpdateFormatDetails(OutputFlowDetailsDTO outputFlowDetailsDTO) {

        try {
            Optional<OutputFlowDetails> outputFlowDetails = flowManagementDetailsRepository.get(outputFlowDetailsDTO.getId());
            if (outputFlowDetails.isPresent()) {
                boolean flag = this.outputFlowDetailsValidator(outputFlowDetailsDTO);

                if (flag) {
                    OutputFlowDetails aggregate = outputFlowDetailsDTO.mapTomodelForFMGMT(outputFlowDetails.get());
                    flowManagementDetailsRepository.addOrUpdate(aggregate);
                } else {
                    return flag;
                }

            }
            return true;
        } catch (Exception e) {
            logger.error("Error occured while updating Output Flow details for flow {} detailed exception :{}", outputFlowDetailsDTO.getFlow(),
                    e.getMessage());

            return false;
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.FormatManagementService#generateFileFrFormat(java.lang.String, java.lang.String, java.lang.String,
     *      com.inetpsa.ovr.domain.model.OutputFlowDetails)
     */
    @Override
    public File generateFileFrFormat(String path, String fileName, String extension, OutputFlowDetails flowDetails, Boolean isExport) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String fileDate = format.format(new Date());
        fileName = fileName + fileDate;

        logger.info("{} : Entering generateFileFrFormat", flowDetails.getFlow());
        if (flowDetails.getFormat().toString().equals(CommonConstant.JSON_FORMAT.getConstValue())) {
            List<Vehicle> vehicles = this.fetchFilteredData(flowDetails);

            if (vehicles != null && !vehicles.isEmpty()) {
                String returnJson = returnJsonFormat(vehicles, flowDetails);
                List<StringBuilder> jsonList = new ArrayList<>();
                jsonList.add(new StringBuilder(returnJson));
                return this.generateFileAtFolder(path, fileName + extension.toLowerCase(), jsonList, isExport, vehicles.size(),
                        flowDetails.getFlow());

            }
        }

        else if (flowDetails.getFormat().toString().equals(CommonConstant.FLAT_FORMAT.getConstValue())) {
            List<Vehicle> vehicles = this.fetchFilteredData(flowDetails);
            if (vehicles != null && !vehicles.isEmpty()) {

                return this.generateFileAtFolder(path, fileName + extension.toLowerCase(), flatFileService.returnFlatFormat(vehicles, flowDetails),
                        isExport, vehicles.size(), flowDetails.getFlow());
            }
        }

        else if (flowDetails.getFormat().toString().equals(CommonConstant.XML_FORMAT.getConstValue())) {
            List<Vehicle> vehicles = this.fetchFilteredData(flowDetails);
            if (vehicles != null && !vehicles.isEmpty()) {
                String returnXml = returnXmlFormat(vehicles, flowDetails);
                List<StringBuilder> xmlList = new ArrayList<>();
                xmlList.add(new StringBuilder(returnXml));
                return this.generateFileAtFolder(path, fileName + extension.toLowerCase(), xmlList, isExport, vehicles.size(), flowDetails.getFlow());
            }
        }

        else {
            logger.info("{} : Invalid file format", flowDetails.getFlow());
        }

        return null;
    }

    @Override
    public List<Vehicle> fetchFilteredData(OutputFlowDetails opflow) {

        List<Vehicle> vehicleList = new LinkedList<>();
        lcdvWhereClause = new StringBuilder();
        rpoWhereClause = new StringBuilder();
        compOvWhereClause = new StringBuilder();
        Map<String, Set<ArtLcdvOtt>> artLcdvOttMap = new HashMap<>();
        Map<String, Set<Options>> rpoMap = new HashMap<>();
        Map<String, Set<ComposantsOv>> compOvMap = new HashMap<>();

        try {
            logger.info("{} : Entering into FormatManagementServiceImpl > fetchFilteredData ", opflow.getFlow());

            String startQuery = "SELECT distinct vhl FROM Vehicle vhl where 1=1 ";

            StringBuilder whereClouse = new StringBuilder();
            StringBuilder selectAndFrom = new StringBuilder(startQuery);

            whereClouse = setupWhereClauseandExecute(opflow);

            if (whereClouse.length() == 0)
                whereClouse.append(" AND vhl.vinNo in (select distinct mfs.vin from MultipleFlowStatus mfs where mfs.flow='" + opflow.getFlow()
                        + "' and mfs.status ='" + TranslationState.INIT.getConstValue() + "' ) ");

            Query finalQuery = this.entityManager.createQuery(selectAndFrom.toString() + whereClouse.toString());

            String loggerInfo = selectAndFrom.toString() + whereClouse.toString();
            logger.info("{} : Query with filters to fetch VIN : {} ", opflow.getFlow(), loggerInfo);

            vehicleList = finalQuery.getResultList();

            StringBuilder vinString = new StringBuilder();
            List<String> listOfVin = new ArrayList<>();
            int index = 0;

            if (vehicleList != null && !vehicleList.isEmpty()) {
                for (Vehicle vhl : vehicleList) {
                    vinString.append("'" + vhl.getVinNo() + "',");

                    if ((index % CommonConstant.CONSTANT_1000.getConstValueInt() == CommonConstant.CONSTANT_999.getConstValueInt())
                            || (index == (vehicleList.size() - 1))) {
                        listOfVin.add(vinString.toString().substring(0, vinString.length() - 1));
                        vinString.setLength(0);
                    }

                    index++;
                }

                logger.info("{} : Selected VIN List : {} ", opflow.getFlow(), vinString);
                logger.info("{} : Where Clause on LCDV : {} ", opflow.getFlow(), lcdvWhereClause);
                logger.info("{} : Where Clause on RPO : {} ", opflow.getFlow(), rpoWhereClause);
                logger.info("{} : Where Clause on COMP OV : {} ", opflow.getFlow(), compOvWhereClause);

                if (listOfVin != null && !listOfVin.isEmpty()) {

                    logger.info("{} : START <Fetch LCDV and prepare map>", opflow.getFlow());

                    List<ArtLcdvOtt> artLcdvOttList = new LinkedList<>();

                    StringBuilder vinInClouse = new StringBuilder();
                    index = 0;
                    for (String listVin : listOfVin) {
                        vinInClouse.append(" upper(lcdv.vin) in (" + listVin + ")  ");

                        if (listOfVin.size() - 1 != index)
                            vinInClouse.append(" OR ");

                        index++;
                    }
                    // Changes done in lot 5 for ARTLCDV
                    String queryForLcdvOtt = "SELECT lcdv  FROM ArtLcdvOtt lcdv where " + vinInClouse + lcdvWhereClause;

                    logger.info("{} : Query for LCDV : {} ", opflow.getFlow(), queryForLcdvOtt);

                    artLcdvOttList = this.entityManager.createQuery(queryForLcdvOtt).getResultList();

                    if (artLcdvOttList != null && !artLcdvOttList.isEmpty()) {
                        for (ArtLcdvOtt lcdvOtt : artLcdvOttList) {

                            if (artLcdvOttMap.get(lcdvOtt.getVin()) != null) {
                                Set<ArtLcdvOtt> lcdvList = artLcdvOttMap.get(lcdvOtt.getVin());
                                lcdvList.add(lcdvOtt);
                                artLcdvOttMap.put(lcdvOtt.getVin(), lcdvList);
                            } else {
                                Set<ArtLcdvOtt> lcdvList = new HashSet<>();
                                lcdvList.add(lcdvOtt);
                                artLcdvOttMap.put(lcdvOtt.getVin(), lcdvList);
                            }
                        }

                    }

                    logger.info("{} : END <Fetch LCDV and prepare map> {} ", opflow.getFlow(), artLcdvOttList.size());

                    logger.info("{} : START <Fetch RPO and prepare map>", opflow.getFlow());

                    List<Options> rpoList = new LinkedList<>();
                    vinInClouse.setLength(0);
                    index = 0;
                    for (String listVin : listOfVin) {
                        vinInClouse.append(" upper(rpo.vin) in (" + listVin + ")  ");

                        if (listOfVin.size() - 1 != index)
                            vinInClouse.append(" OR ");

                        index++;
                    }

                    String queryForRpo = "SELECT rpo  FROM Options rpo where " + vinInClouse + rpoWhereClause;

                    logger.info("{} : Query for RPO  : {} ", opflow.getFlow(), queryForRpo);

                    rpoList = this.entityManager.createQuery(queryForRpo).getResultList();

                    if (rpoList != null && !rpoList.isEmpty()) {
                        for (Options rpo : rpoList) {

                            if (rpoMap.get(rpo.getVin()) != null) {
                                Set<Options> rpoDataList = rpoMap.get(rpo.getVin());
                                rpoDataList.add(rpo);
                                rpoMap.put(rpo.getVin(), rpoDataList);
                            } else {
                                Set<Options> rpoDataList = new HashSet<>();
                                rpoDataList.add(rpo);
                                rpoMap.put(rpo.getVin(), rpoDataList);
                            }
                        }

                    }

                    logger.info("{} : END <Fetch RPO and prepare map> {} ", opflow.getFlow(), rpoList.size());

                    logger.info("{} : START <Fetch Comp Ov and prepare map>", opflow.getFlow());

                    List<ComposantsOv> compOvList = new LinkedList<>();
                    vinInClouse.setLength(0);
                    index = 0;
                    for (String listVin : listOfVin) {
                        vinInClouse.append(" upper(compov.vin) in (" + listVin + ")  ");

                        if (listOfVin.size() - 1 != index)
                            vinInClouse.append(" OR ");

                        index++;
                    }

                    String queryForCompOv = "SELECT compov  FROM ComposantsOv compov where  " + vinInClouse + compOvWhereClause;

                    logger.info("{} : Query for Comp Ov  : {} ", opflow.getFlow(), queryForCompOv);

                    compOvList = this.entityManager.createQuery(queryForCompOv).getResultList();

                    if (compOvList != null && !compOvList.isEmpty()) {
                        for (ComposantsOv compOv : compOvList) {

                            if (compOvMap.get(compOv.getVin()) != null) {
                                Set<ComposantsOv> compOvDataList = compOvMap.get(compOv.getVin());
                                compOvDataList.add(compOv);
                                compOvMap.put(compOv.getVin(), compOvDataList);
                            } else {
                                Set<ComposantsOv> compOvDataList = new HashSet<>();
                                compOvDataList.add(compOv);
                                compOvMap.put(compOv.getVin(), compOvDataList);
                            }
                        }

                    }

                    if (compOvList != null)
                        logger.info("{} : END <Fetch Comp Ov and prepare map> {} ", opflow.getFlow(), compOvList.size());

                } // if vin list is not null

                // Setting up Vehicle Final Entity
                logger.info("{} : START <Setting up Vehicle entity with lcdv, rpo and compOv>", opflow.getFlow());

                List<Vehicle> detachedVehicleList = new LinkedList<>();
                for (Vehicle vhl : vehicleList) {

                    Vehicle detached = new Vehicle();

                    detached.createShallowCopy(vhl);
                    detached.setArtLcdvOtt(artLcdvOttMap.get(detached.getVinNo()));
                    detached.setComposantsOv(compOvMap.get(detached.getVinNo()));
                    detached.setOptions(rpoMap.get(detached.getVinNo()));

                    detachedVehicleList.add(detached);

                }
                logger.info("{} : END <Setting up Vehicle entity with lcdv, rpo and compOv>", opflow.getFlow());

                return detachedVehicleList;

            } // if vin list is null

        } catch (Exception e) {
            logger.error("{} : ERROR into FormatManagementServiceImpl > fetchFilteredData {} ", opflow.getFlow(), e);
        }

        logger.info("{} : Existing from FormatManagementServiceImpl > fetchFilteredData ", opflow.getFlow());

        return vehicleList;

    }

    private StringBuilder setupWhereClauseandExecute(OutputFlowDetails opflow) {

        logger.info("{} : Inside setupWhereClauseandExecute : {} ", opflow.getFlow(), opflow);

        StringBuilder query = new StringBuilder();
        StringBuilder vinQuery = new StringBuilder();
        if (opflow != null) {

            if (opflow.getFlowVhlMetadatas() != null && !opflow.getFlowVhlMetadatas().isEmpty()) {

                for (FlowVhlMetadata flowVhlMetadata : opflow.getFlowVhlMetadatas()) {
                    String filter = flowVhlMetadata.getFilter();

                    if (flowVhlMetadata.getValue() != null && flowVhlMetadata.getValue().toString().equals("7")
                            && (filter != null && filter.trim().length() != 0 && (((filter.replaceAll("\\s+", "")).trim().split(",")).length != 0))) {

                        String[] vinList = filter.split(",");

                        StringBuilder vinString = new StringBuilder();
                        int index = 0;
                        for (String str : vinList) {
                            vinString.append("'" + str.toUpperCase() + "'");

                            if (index != (vinList.length - 1))
                                vinString.append(",");

                            index++;
                        }

                        vinQuery.append(" AND upper(vhl.vinNo) in (" + vinString.toString() + ")");

                    }
                }
            }

            if (opflow.getGenericCollections() != null && !opflow.getGenericCollections().isEmpty()) {
                for (GenericCollection genericCollection : opflow.getGenericCollections()) {

                    String filter = genericCollection.getFilter();
                    if (filter != null && filter.trim().length() != 0 && (((filter.replaceAll("\\s+", "")).trim().split(",")).length != 0)) {

                        if (genericCollection.getValue().toString().equals("19")) {
                            query.append(FormatManagementConstant.AND.getConstValue()
                                    + splitFilter(filter, " upper(concat(lcdv.family,lcdv.code,lcdv.value)) like "));

                            lcdvWhereClause.append(FormatManagementConstant.AND.getConstValue()
                                    + splitFilter(filter, " upper(concat(lcdv.family,lcdv.code,lcdv.value)) like "));
                        }

                        if (genericCollection.getValue().toString().equals("20")) {
                            query.append(FormatManagementConstant.AND.getConstValue() + splitFilter(filter, " upper(rpo.rpoData) like "));
                            rpoWhereClause.append(FormatManagementConstant.AND.getConstValue() + splitFilter(filter, " upper(rpo.rpoData) like "));
                        }
                    }
                }

            }

            if (opflow.getOvComponents() != null && !opflow.getOvComponents().isEmpty()) {
                for (OVComponent ovComponent : opflow.getOvComponents()) {
                    if (ovComponent.getOvComponentParts() != null && !ovComponent.getOvComponentParts().isEmpty()) {

                        List<OVComponentPart> std22 = new ArrayList<>();
                        List<OVComponentPart> std23 = new ArrayList<>();
                        List<OVComponentPart> std24 = new ArrayList<>();

                        for (OVComponentPart ovComponentParts : ovComponent.getOvComponentParts()) {
                            if (ovComponentParts.getStandard().toString().equals("22"))
                                std22.add(ovComponentParts);
                            if (ovComponentParts.getStandard().toString().equals("23"))
                                std23.add(ovComponentParts);
                            if (ovComponentParts.getStandard().toString().equals("24"))
                                std24.add(ovComponentParts);
                        }

                        int firstOrDone = 0;
                        StringBuilder comovBuilderFinal = new StringBuilder();

                        if (!std22.isEmpty()) {
                            StringBuilder comovBuilder = new StringBuilder();
                            comovBuilder = splitForComOVPart(std22, FormatManagementConstant.GM1737.getConstValue());
                            if (comovBuilder != null) {

                                if (firstOrDone != 0)
                                    comovBuilderFinal.append(" OR ");

                                comovBuilderFinal.append(comovBuilder.toString());
                                firstOrDone = 1;

                            }

                        }

                        if (!std23.isEmpty()) {
                            StringBuilder comovBuilder = new StringBuilder();
                            comovBuilder = splitForComOVPart(std23, FormatManagementConstant.GMW15862.getConstValue());
                            if (comovBuilder != null) {

                                if (firstOrDone != 0)
                                    comovBuilderFinal.append(" OR ");

                                comovBuilderFinal.append(comovBuilder.toString());
                                firstOrDone = 1;
                            }
                        }

                        if (!std24.isEmpty()) {
                            StringBuilder comovBuilder = new StringBuilder();
                            comovBuilder = splitForComOVPart(std24, FormatManagementConstant.OTHER.getConstValue());
                            if (comovBuilder != null) {

                                if (firstOrDone != 0)
                                    comovBuilderFinal.append(" OR ");

                                comovBuilderFinal.append(comovBuilder.toString());
                                firstOrDone = 1;

                            }

                        }

                        if (firstOrDone == 1) {
                            query.append(" AND ( " + comovBuilderFinal.toString() + " ) ");
                            compOvWhereClause.append(" AND ( " + comovBuilderFinal.toString() + " ) ");
                        }

                    }
                }
            }

        } // if condition of opflow is not null

        return vinQuery;
    }

    public StringBuilder splitForComOVPart(List<OVComponentPart> std22, String std) {

        if (!std22.isEmpty()) {
            int index = 0;
            StringBuilder strBuiider = new StringBuilder();
            StringBuilder standardBuiider = new StringBuilder();
            int selectionFlag = 0;
            standardBuiider.append("( compov.standard like '" + std + "' ");

            List<OVComponentPart> std22Filtered = new ArrayList<>();

            for (OVComponentPart ovComponentParts1 : std22) {
                String filter = ovComponentParts1.getFilter();
                if (filter != null && filter.trim().length() != 0 && (((filter.replaceAll("\\s+", "")).trim().split(",")).length != 0))
                    std22Filtered.add(ovComponentParts1);
            }

            for (OVComponentPart ovComponentParts : std22Filtered) {

                String filter = ovComponentParts.getFilter();
                if (filter != null && filter.trim().length() != 0 && (((filter.replaceAll("\\s+", "")).trim().split(",")).length != 0)) {

                    if (ovComponentParts.getValue().toString().equals("25"))
                        strBuiider.append(splitFilter(filter, " upper(compov.eid) like "));

                    if (ovComponentParts.getValue().toString().equals("26"))
                        strBuiider.append(splitFilter(filter, " upper(compov.part) like "));

                    if (ovComponentParts.getValue().toString().equals("27"))
                        strBuiider.append(splitFilter(filter, " upper(compov.supplier) like "));

                    if (ovComponentParts.getValue().toString().equals("28"))
                        strBuiider.append(splitFilter(filter, " upper(compov.data) like "));

                    if (index != (std22Filtered.size() - 1))
                        strBuiider.append(" AND ");

                    selectionFlag = 1;
                }

                index++;
            }
            strBuiider.append(" ) ");

            if (selectionFlag == 1)
                return new StringBuilder(standardBuiider.toString() + " AND " + strBuiider.toString());

            return new StringBuilder(standardBuiider.toString() + " ) ");
        }
        return null;
    }

    public StringBuilder splitFilter(String str, String preStr) {

        StringBuilder finalFilter = new StringBuilder();

        if (str.length() != 0) {
            String[] split = str.trim().split(",");
            if (split.length != 0) {
                int index = 0;
                finalFilter.append("( ");
                for (String value : split) {
                    if (value != null && value.trim().length() != 0) {
                        finalFilter.append(preStr + " '" + value.toUpperCase() + "'");

                        if (index != (split.length - 1))
                            finalFilter.append(" OR ");
                    }
                    index++;
                }
                finalFilter.append(" )");
            }
        }

        return finalFilter;
    }

    /**
     * Return json format.
     *
     * @param vehicles the vehicles
     * @param flowDetails the flow details
     * @return the string
     */
    public String returnJsonFormat(List<Vehicle> vehicles, OutputFlowDetails flowDetails) {
        try {
            String flowName = flowDetails.getFlow();
            OpFlJson opFlJson = new OpFlJson();
            OpHeader opHeader = new OpHeader();
            opHeader.setSender(CommonConstant.APPLICATION_OVER.getConstValue());
            opHeader.setClient(flowName.toUpperCase());
            opHeader.setSendingDate(new SimpleDateFormat(FILE_FORMAT_DATE).format(new java.util.Date()));

            OpFooter opFooter = new OpFooter();
            opFooter.setClient(flowName.toUpperCase());
            opFooter.setSender(CommonConstant.APPLICATION_OVER.getConstValue());
            opFooter.setNumberOfRecords(Integer.toString(vehicles.size()));
            List<OpVehicule> opVehicules = new ArrayList<>();
            logger.info("{} : Generating json format", flowDetails.getFlow());
            Set<FlowVhlMetadata> flowVhlMetadatas = flowDetails.getFlowVhlMetadatas();

            Set<GenericCollection> genericCollections = flowDetails.getGenericCollections();

            Set<OVComponent> ovComponents = flowDetails.getOvComponents();

            ArrayList<Long> mtdtValues = new ArrayList<>();

            Map<Long, String> formatMap = new HashMap<>();
            if (flowVhlMetadatas != null && !flowVhlMetadatas.isEmpty()) {
                for (FlowVhlMetadata flowVhlMetadata : flowVhlMetadatas) {
                    mtdtValues.add(flowVhlMetadata.getValue());
                    formatMap.put(flowVhlMetadata.getValue(), flowVhlMetadata.getFilter());
                }
            }
            if (genericCollections != null && !genericCollections.isEmpty()) {
                for (GenericCollection genericCollection : genericCollections) {
                    mtdtValues.add(genericCollection.getValue());
                }
            }
            if (ovComponents != null && !ovComponents.isEmpty()) {
                for (OVComponent ovComponent : ovComponents) {
                    mtdtValues.add(ovComponent.getValue());
                    for (OVComponentPart ovComponentPart : ovComponent.getOvComponentParts()) {
                        if (!mtdtValues.contains(ovComponentPart.getStandard())) {
                            mtdtValues.add(ovComponentPart.getStandard());
                        }
                        String value = Long.toString(ovComponentPart.getStandard()) + Long.toString(ovComponentPart.getValue());
                        mtdtValues.add(Long.valueOf(value));
                    }
                }
            }
            logger.info("{} : mtdt values :  {} ", flowDetails.getFlow(), mtdtValues);
            for (Vehicle vehicle : vehicles) {
                OpVehiculeData opVehiculeData = new OpVehiculeData();
                OpVehicule opVehicule = new OpVehicule();
                List<ComponentsOv> componentsOvs = new ArrayList<>();
                if (mtdtValues.contains(FormatManagementConstant.LENGTH7.getConstValueInt())) {
                    if (null != vehicle.getVinNo())
                        opVehiculeData.setVin(vehicle.getVinNo());
                    else
                        opVehiculeData.setVin("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH8.getConstValueInt())) {
                    if (null != vehicle.getCcp())
                        opVehiculeData.setCcp(vehicle.getCcp());
                    else
                        opVehiculeData.setCcp("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH9.getConstValueInt()) && null != vehicle.getVeh()) {
                    if (null != vehicle.getVeh())
                        opVehiculeData.setVeh(vehicle.getVeh());
                    else
                        opVehiculeData.setVeh("");
                }

                if (mtdtValues.contains(FormatManagementConstant.LENGTH10.getConstValueInt())) {
                    if (null != vehicle.getUp())
                        opVehiculeData.setUp(vehicle.getUp());
                    else
                        opVehiculeData.setUp("");
                }

                if (mtdtValues.contains(FormatManagementConstant.LENGTH11.getConstValueInt())) {
                    if (null != vehicle.getOf())
                        opVehiculeData.setOf(vehicle.getOf());
                    else
                        opVehiculeData.setOf("");

                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH12.getConstValueInt())) {
                    if (null != vehicle.getLcdv24())
                        opVehiculeData.setLcdv24(vehicle.getLcdv24());
                    else
                        opVehiculeData.setLcdv24("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH13.getConstValueInt())
                        && formatMap.containsKey(FormatManagementConstant.LENGTH13.getConstValueInt())) {
                    if (null != vehicle.getDateEmon()) {
                        String format = formatMap.get(FormatManagementConstant.LENGTH13.getConstValueInt());

                        if (format != null && format.length() > 0) {
                            try {
                                opVehiculeData.setDateEmon(new SimpleDateFormat(format).format(vehicle.getDateEmon()));
                            } catch (IllegalArgumentException ie) {
                                logger.error("Error while formatting date emon {}, swtiching to default date format {} ", ie.getMessage(), format);
                                opVehiculeData.setDateEmon(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEmon()));
                            }

                        } else {
                            opVehiculeData.setDateEmon(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEmon()));
                        }
                    } else {
                        opVehiculeData.setDateEmon("");
                    }
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH14.getConstValueInt())
                        && formatMap.containsKey(FormatManagementConstant.LENGTH14.getConstValueInt())) {
                    if (null != vehicle.getDateEcom()) {
                        String format = formatMap.get(FormatManagementConstant.LENGTH14.getConstValueInt());

                        if (format != null && format.length() > 0) {
                            try {

                                opVehiculeData.setDateEcom(new SimpleDateFormat(format).format(vehicle.getDateEcom()));
                            } catch (IllegalArgumentException ie) {
                                logger.error("Error while formatting date ecom {}, swtiching to default date format {} ", ie.getMessage(), format);
                                opVehiculeData.setDateEcom(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEcom()));
                            }

                        } else {

                            opVehiculeData.setDateEcom(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEcom()));
                        }
                    } else {
                        opVehiculeData.setDateEcom("");
                    }

                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH15.getConstValueInt())) {
                    if (null != vehicle.getOa())
                        opVehiculeData.setOa(vehicle.getOa());
                    else
                        opVehiculeData.setOa("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH16.getConstValueInt())) {
                    if (null != vehicle.getApvpr())
                        opVehiculeData.setApvpr(vehicle.getApvpr());
                    else
                        opVehiculeData.setApvpr("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH17.getConstValueInt())) {
                    if (null != vehicle.getModel())
                        opVehiculeData.setModel(vehicle.getModel());
                    else
                        opVehiculeData.setModel("");

                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH18.getConstValueInt())) {
                    if (null != vehicle.getModelYear())
                        opVehiculeData.setModelYear(vehicle.getModelYear());
                    else
                        opVehiculeData.setModelYear("");

                }

                if (mtdtValues.contains(FormatManagementConstant.LENGTH19.getConstValueInt())) {
                    Set<ArtLcdvOtt> lcdvOtts = vehicle.getArtLcdvOtt();
                    if (lcdvOtts != null && !lcdvOtts.isEmpty()) {
                        List<String> artLcdv = new ArrayList<>();
                        for (ArtLcdvOtt lcdvOtt : lcdvOtts) {
                            artLcdv.add(lcdvOtt.getFamily() + lcdvOtt.getCode() + lcdvOtt.getValue());
                        }
                        opVehicule.setArtLcdv(artLcdv);
                    } else {
                        opVehicule.setArtLcdv(Collections.emptyList());
                    }

                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH20.getConstValueInt())) {

                    Set<Options> rpos = vehicle.getOptions();
                    if (rpos != null && !rpos.isEmpty()) {
                        List<String> rpoList = new ArrayList<>();
                        for (Options options : rpos) {
                            rpoList.add(options.getRpoData());
                        }
                        opVehicule.setRpo(rpoList);
                    } else {
                        opVehicule.setRpo(Collections.emptyList());
                    }
                }
                Set<ComposantsOv> compOvSet = vehicle.getComposantsOv();
                if (mtdtValues.contains(FormatManagementConstant.LENGTH21.getConstValueInt())) {
                    if (null != compOvSet && !compOvSet.isEmpty()) {
                        for (ComposantsOv composantsOv : compOvSet) {
                            ComponentsOv componentsOv = new ComponentsOv();

                            if (mtdtValues.contains(FormatManagementConstant.STD22.getConstValueInt())
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (composantsOv.getStandard() != null)
                                    componentsOv.setStandard(composantsOv.getStandard());
                                else
                                    componentsOv.setStandard("");
                            }
                            if (mtdtValues.contains(FormatManagementConstant.STD23.getConstValueInt())
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (composantsOv.getStandard() != null)
                                    componentsOv.setStandard(composantsOv.getStandard());
                                else
                                    componentsOv.setStandard("");
                            }
                            if (mtdtValues.contains(FormatManagementConstant.STD24.getConstValueInt())
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (composantsOv.getStandard() != null)
                                    componentsOv.setStandard(composantsOv.getStandard());
                                else
                                    componentsOv.setStandard("");
                            }
                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_ID.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (composantsOv.getEid() != null)
                                    componentsOv.setId(composantsOv.getEid());
                                else
                                    componentsOv.setId("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_ID.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (composantsOv.getEid() != null)
                                    componentsOv.setId(composantsOv.getEid());
                                else
                                    componentsOv.setId("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_ID.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (composantsOv.getEid() != null)
                                    componentsOv.setId(composantsOv.getEid());
                                else
                                    componentsOv.setId("");
                            } else {
                                logger.info("No matching format present");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_PART.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (composantsOv.getPart() != null)
                                    componentsOv.setPart(composantsOv.getPart());
                                else
                                    componentsOv.setPart("");

                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_PART.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())
                                    && composantsOv.getPart() != null) {
                                if (composantsOv.getPart() != null)
                                    componentsOv.setPart(composantsOv.getPart());
                                else
                                    componentsOv.setPart("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_PART.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (composantsOv.getPart() != null)
                                    componentsOv.setPart(composantsOv.getPart());
                                else
                                    componentsOv.setPart("");
                            } else {
                                logger.info("No matching format present");
                            }
                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_SUPPLIER.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (composantsOv.getSupplier() != null)
                                    componentsOv.setSupplier(composantsOv.getSupplier());
                                else
                                    componentsOv.setSupplier("");

                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_SUPPLIER.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())
                                    && composantsOv.getSupplier() != null) {
                                if (composantsOv.getSupplier() != null)
                                    componentsOv.setSupplier(composantsOv.getSupplier());
                                else
                                    componentsOv.setSupplier("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_SUPPLIER.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (composantsOv.getSupplier() != null)
                                    componentsOv.setSupplier(composantsOv.getSupplier());
                                else
                                    componentsOv.setSupplier("");
                            } else {
                                logger.info("No matching format present");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_DATA.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (composantsOv.getData() != null)
                                    componentsOv.setData(composantsOv.getData());
                                else
                                    componentsOv.setData("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_DATA.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (composantsOv.getData() != null)
                                    componentsOv.setData(composantsOv.getData());
                                else
                                    componentsOv.setData("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_DATA.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (composantsOv.getData() != null)
                                    componentsOv.setData(composantsOv.getData());
                                else
                                    componentsOv.setData("");
                            } else {
                                logger.info("No matching format present");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_LABEL.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (composantsOv.getLabel() != null)
                                    componentsOv.setLabel(composantsOv.getLabel());
                                else
                                    componentsOv.setLabel("");

                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_LABEL.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (composantsOv.getLabel() != null)
                                    componentsOv.setLabel(composantsOv.getLabel());
                                else
                                    componentsOv.setLabel("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_LABEL.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (composantsOv.getLabel() != null)
                                    componentsOv.setLabel(composantsOv.getLabel());
                                else
                                    componentsOv.setLabel("");
                            } else {
                                logger.info("No matching format present");
                            }
                            if (componentsOv.getStandard() != null) {
                                componentsOvs.add(componentsOv);
                            }
                        }

                        opVehicule.setComponentsOv(componentsOvs);
                    } else {
                        opVehicule.setComponentsOv(Collections.emptyList());
                    }
                }

                opVehicule.setVehiculeData(opVehiculeData);
                opVehicules.add(opVehicule);
            }

            opFlJson.setFooter(opFooter);
            opFlJson.setHeader(opHeader);
            opFlJson.setVehicules(opVehicules);
            return new Gson().toJson(opFlJson);
        } catch (

        Exception e) {
            logger.error("Exception {}", e);
        }
        return null;
    }

    /**
     * Generate file at folder.
     *
     * @param directory the directory
     * @param fileName the file name
     * @param data the data
     */
    public File generateFileAtFolder(String directory, String fileName, List<StringBuilder> data, Boolean isExport, int size, String flowName) {

        logger.info("Creating file : {} at directory : {}", fileName, directory);
        File dir = new File(directory);
        File file = new File(directory + fileName);
        if (dir.exists()) {
            try (BufferedWriter buffer = new BufferedWriter(new FileWriter(file))) {
                int index = 0;
                for (StringBuilder string : data) {
                    buffer.append(string);

                    if (index != (data.size() - 1))
                        buffer.newLine();

                    index++;
                }

            } catch (IOException exception) {
                logger.error("Exception occured in file creation {}", exception);
                return null;
            }
            if (!isExport) {
                logger.info("Adding Entry into Audit table");
                Audit audit = new Audit();
                AuditPk auditPk = new AuditPk();
                auditPk.setFileName(fileName);
                audit.setAuditModelPk(auditPk);
                audit.setErrorCount(0);
                audit.setSuccessCount(size);
                audit.setInterfaceName(flowName);
                auditRepository.add(audit);
            }
            return file;
        }
        return null;
    }

    @Override
    public boolean outputFlowDetailsValidator(OutputFlowDetailsDTO opflow) {

        List<Long> overAllSeq = new ArrayList<>();
        List<String> flowIdValue = new ArrayList<>();
        List<String> ovCompPartList = new ArrayList<>();
        List<String> overAllCmpSeq = new ArrayList<>();

        logger.info("Entering into FormatManagementServiceImpl > outputFlowDetailsValidator {} ", opflow);
        try {

            if (opflow != null) {

                Set<FlowVhlMetadataDTO> flowVhlMetadataSet = opflow.getFlowVhlMetadataDTOs();
                if (flowVhlMetadataSet != null && !flowVhlMetadataSet.isEmpty())
                    for (FlowVhlMetadataDTO flowVhlMtdt : flowVhlMetadataSet) {

                        if (flowVhlMtdt.getSeq() != null) {
                            if (overAllSeq.contains(flowVhlMtdt.getSeq())) {
                                logger.info("Vehicle metadata sequence validation failed ,Seq : {} already present", flowVhlMtdt.getSeq());
                                return false;
                            }
                            overAllSeq.add(flowVhlMtdt.getSeq());
                        }

                        if (flowVhlMtdt.getFlowId() != null && flowVhlMtdt.getValue() != null && flowVhlMtdt.getValue() != 32l) {
                            if (flowIdValue.contains(flowVhlMtdt.getFlowId() + "." + flowVhlMtdt.getValue())) {
                                logger.info(" Metadata validation failed ,Metadata : {} already present for flow :{}", flowVhlMtdt.getValue(),
                                        flowVhlMtdt.getFlowId());
                                return false;
                            }
                            flowIdValue.add(flowVhlMtdt.getFlowId() + "." + flowVhlMtdt.getValue());
                        }

                    }

                Set<GenericCollectionDTO> genericCollection = opflow.getCollectionDTOs();
                if (genericCollection != null && !genericCollection.isEmpty())
                    for (GenericCollectionDTO genflow : genericCollection) {

                        if (genflow.getSeq() != null) {
                            if (overAllSeq.contains(genflow.getSeq())) {
                                logger.info("Generic collection sequence validation failed ,Seq : {} already present", genflow.getSeq());
                                return false;
                            }
                            overAllSeq.add(genflow.getSeq());
                        }

                        if (genflow.getFlowId() != null && genflow.getValue() != null) {
                            if (flowIdValue.contains(genflow.getFlowId() + "." + genflow.getValue())) {
                                logger.info(" Generic collection validation failed ,Generic collection : {} already present for flow :{}",
                                        genflow.getValue(), genflow.getFlowId());
                                return false;
                            }
                            flowIdValue.add(genflow.getFlowId() + "." + genflow.getValue());
                        }

                    }

                Set<OVComponentDTO> oVComponent = opflow.getOvComponentDTOs();
                if (oVComponent != null && !oVComponent.isEmpty())
                    for (OVComponentDTO ovcomp : oVComponent) {

                        if (ovcomp.getSeq() != null) {
                            if (overAllSeq.contains(ovcomp.getSeq())) {
                                logger.info("OV component sequence validation failed ,Seq : {} already present", ovcomp.getSeq());

                                return false;

                            }
                            overAllSeq.add(ovcomp.getSeq());
                        }

                        if (ovcomp.getFlowId() != null && ovcomp.getValue() != null) {
                            if (flowIdValue.contains(ovcomp.getFlowId() + "." + ovcomp.getValue())) {
                                logger.info("OV component validation failed ,OV component : {} already present for flow :{}", ovcomp.getValue(),
                                        ovcomp.getFlowId());
                                return false;
                            }
                            flowIdValue.add(ovcomp.getFlowId() + "." + ovcomp.getValue());
                        }

                        Set<OVComponentPartDTO> oVComponentParts = ovcomp.getOvComponentPartDTOs();
                        if (oVComponentParts != null && !oVComponentParts.isEmpty())
                            for (OVComponentPartDTO ovcompPart : oVComponentParts) {

                                if (ovcompPart.getStandard() != null && ovcompPart.getValue() != null) {
                                    if (ovCompPartList.contains(ovcompPart.getStandard() + "." + ovcompPart.getValue())) {
                                        logger.info(" Ov Component validation failed ,Ov component  : {} already present for Standard :{}",
                                                ovcompPart.getValue(), ovcompPart.getStandard());
                                        return false;
                                    }
                                    ovCompPartList.add(ovcompPart.getStandard() + "." + ovcompPart.getValue());
                                }

                                if (ovcompPart.getIntSeq() != null) {
                                    if (overAllCmpSeq.contains(ovcompPart.getIntSeq())) {
                                        logger.info("Ov Component sequence validation failed ,Seq : {} already present", ovcompPart.getIntSeq());
                                        return false;
                                    }
                                    overAllCmpSeq.add(ovcompPart.getIntSeq());
                                }

                            }
                    }
            }

        } catch (Exception e) {
            logger.error("Error into FormatManagementServiceImpl > outputFlowDetailsValidator {} ", e);
            return false;
        }

        logger.error("Exiting from FormatManagementServiceImpl > outputFlowDetailsValidator ");
        return true;
    }

    public String returnXmlFormat(List<Vehicle> vehicles, OutputFlowDetails flowDetails) {
        ObjectFactory factory = new ObjectFactory();
        try {
            String flowName = flowDetails.getFlow();
            FORMAT format = factory.createFORMAT();
            FORMAT.FOOTER footer = factory.createFORMATFOOTER();
            FORMAT.HEADER header = factory.createFORMATHEADER();

            footer.setCLIENT(flowName.toUpperCase());
            footer.setNUMBEROFRECORDS(Integer.toString(vehicles.size()));
            footer.setSENDER(CommonConstant.APPLICATION_OVER.getConstValue());

            header.setCLIENT(flowName.toUpperCase());
            header.setSENDER(CommonConstant.APPLICATION_OVER.getConstValue());
            header.setSENDINGDATE(new SimpleDateFormat(FILE_FORMAT_DATE).format(new java.util.Date()));

            format.setFOOTER(footer);
            format.setHEADER(header);

            logger.info("{} : Generating xml format", flowDetails.getFlow());
            Set<FlowVhlMetadata> flowVhlMetadatas = flowDetails.getFlowVhlMetadatas();

            Set<GenericCollection> genericCollections = flowDetails.getGenericCollections();

            Set<OVComponent> ovComponents = flowDetails.getOvComponents();

            ArrayList<Long> mtdtValues = new ArrayList<>();
            Map<Long, String> formatMap = new HashMap<>();

            if (flowVhlMetadatas != null && !flowVhlMetadatas.isEmpty()) {
                for (FlowVhlMetadata flowVhlMetadata : flowVhlMetadatas) {
                    mtdtValues.add(flowVhlMetadata.getValue());
                    formatMap.put(flowVhlMetadata.getValue(), flowVhlMetadata.getFilter());

                }
            }
            if (genericCollections != null && !genericCollections.isEmpty()) {
                for (GenericCollection genericCollection : genericCollections) {
                    mtdtValues.add(genericCollection.getValue());
                }
            }
            if (ovComponents != null && !ovComponents.isEmpty()) {
                for (OVComponent ovComponent : ovComponents) {
                    mtdtValues.add(ovComponent.getValue());
                    for (OVComponentPart ovComponentPart : ovComponent.getOvComponentParts()) {
                        if (!mtdtValues.contains(ovComponentPart.getStandard())) {
                            mtdtValues.add(ovComponentPart.getStandard());
                        }

                        String value = Long.toString(ovComponentPart.getStandard()) + Long.toString(ovComponentPart.getValue());
                        mtdtValues.add(Long.valueOf(value));
                    }
                }
            }
            logger.info("mtdt values {}", mtdtValues);
            for (Vehicle vehicle : vehicles) {

                FORMAT.VEHICULES vehicules = factory.createFORMATVEHICULES();
                FORMAT.VEHICULES.LISTCOMPONENTSOV compsOv = factory.createFORMATVEHICULESLISTCOMPONENTSOV();
                FORMAT.VEHICULES.VEHICLEDATAS vdatas = factory.createFORMATVEHICULESVEHICLEDATAS();
                FORMAT.VEHICULES.LISTARTLCDV lcdv = factory.createFORMATVEHICULESLISTARTLCDV();
                FORMAT.VEHICULES.LISTRPO option = factory.createFORMATVEHICULESLISTRPO();

                if (mtdtValues.contains(FormatManagementConstant.LENGTH7.getConstValueInt())) {
                    if (null != vehicle.getVinNo())
                        vdatas.setVIN(vehicle.getVinNo());
                    else
                        vdatas.setVIN("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH8.getConstValueInt())) {
                    if (null != vehicle.getCcp())
                        vdatas.setCCP(vehicle.getCcp());
                    else
                        vdatas.setCCP("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH9.getConstValueInt())) {
                    if (null != vehicle.getVeh())
                        vdatas.setVEH(vehicle.getVeh());
                    else
                        vdatas.setVEH("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH10.getConstValueInt())) {
                    if (null != vehicle.getUp())
                        vdatas.setUP(vehicle.getUp());
                    else
                        vdatas.setUP("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH11.getConstValueInt())) {
                    if (null != vehicle.getOf())
                        vdatas.setOF(vehicle.getOf());
                    else
                        vdatas.setOF("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH12.getConstValueInt())) {
                    if (null != vehicle.getLcdv24())
                        vdatas.setLCDV24(vehicle.getLcdv24());
                    else
                        vdatas.setLCDV24("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH13.getConstValueInt())
                        && formatMap.containsKey(FormatManagementConstant.LENGTH13.getConstValueInt())) {
                    if (null != vehicle.getDateEmon()) {
                        String filter = formatMap.get(FormatManagementConstant.LENGTH13.getConstValueInt());
                        if (filter != null && filter.length() > 0) {
                            try {
                                vdatas.setDATEEMON(new SimpleDateFormat(filter).format(vehicle.getDateEmon()));
                            } catch (IllegalArgumentException ie) {
                                logger.error("Error while formatting date emon {}, swtiching to default date format {} ", ie.getMessage(), filter);
                                vdatas.setDATEEMON(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEmon()));
                            }

                        } else {
                            vdatas.setDATEEMON(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEmon()));
                        }
                    } else {
                        vdatas.setDATEEMON("");
                    }
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH14.getConstValueInt())
                        && formatMap.containsKey(FormatManagementConstant.LENGTH14.getConstValueInt())) {
                    if (null != vehicle.getDateEcom()) {
                        String filter = formatMap.get(FormatManagementConstant.LENGTH14.getConstValueInt());
                        if (filter != null && filter.length() > 0) {
                            try {
                                vdatas.setDATEECOM(new SimpleDateFormat(filter).format(vehicle.getDateEcom()));
                            } catch (IllegalArgumentException ie) {
                                logger.error("Error while formatting date ecom {}, swtiching to default date format {} ", ie.getMessage(), filter);
                                vdatas.setDATEECOM(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEcom()));
                            }

                        } else {
                            vdatas.setDATEECOM(new SimpleDateFormat(FILE_FORMAT_DATE).format(vehicle.getDateEcom()));
                        }
                    } else {
                        vdatas.setDATEECOM("");
                    }

                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH15.getConstValueInt())) {
                    if (null != vehicle.getOa())
                        vdatas.setOA(vehicle.getOa());
                    else
                        vdatas.setOA("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH16.getConstValueInt())) {
                    if (null != vehicle.getApvpr())
                        vdatas.setAPVPR(vehicle.getApvpr());
                    else
                        vdatas.setAPVPR("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH17.getConstValueInt())) {
                    if (null != vehicle.getModel())
                        vdatas.setMODEL(vehicle.getModel());
                    else
                        vdatas.setMODEL("");
                }
                if (mtdtValues.contains(FormatManagementConstant.LENGTH18.getConstValueInt())) {
                    if (null != vehicle.getModelYear())
                        vdatas.setMODELYEAR(vehicle.getModelYear());
                    else
                        vdatas.setMODELYEAR("");
                }
                // Changes done for ARTLCDV in lot 5
                List<String> artLcdv = new ArrayList<>();
                if (mtdtValues.contains(FormatManagementConstant.LENGTH19.getConstValueInt())) {
                    Set<ArtLcdvOtt> lcdvOtts = vehicle.getArtLcdvOtt();
                    if (lcdvOtts != null && !lcdvOtts.isEmpty()) {
                        for (ArtLcdvOtt lcdvOtt : lcdvOtts) {
                            artLcdv.add(lcdvOtt.getFamily() + lcdvOtt.getCode() + lcdvOtt.getValue());
                        }

                    }
                }
                List<String> rpoList = new ArrayList<>();
                if (mtdtValues.contains(FormatManagementConstant.LENGTH20.getConstValueInt())) {

                    Set<Options> rpos = vehicle.getOptions();
                    if (rpos != null && !rpos.isEmpty()) {

                        for (Options options : rpos) {
                            rpoList.add(options.getRpoData());
                        }

                    }
                }
                List<FORMAT.VEHICULES.LISTCOMPONENTSOV.COMPONENTSOV> compsOvList = new ArrayList<>();
                if (mtdtValues.contains(FormatManagementConstant.LENGTH21.getConstValueInt())) {
                    Set<ComposantsOv> compOvSet = vehicle.getComposantsOv();
                    if (null != compOvSet && !compOvSet.isEmpty()) {
                        for (ComposantsOv composantsOv : compOvSet) {
                            FORMAT.VEHICULES.LISTCOMPONENTSOV.COMPONENTSOV compValue = factory.createFORMATVEHICULESLISTCOMPONENTSOVCOMPONENTSOV();
                            if (mtdtValues.contains(FormatManagementConstant.STD22.getConstValueInt())
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (null != composantsOv.getStandard())
                                    compValue.setSTANDARD(composantsOv.getStandard());
                                else
                                    compValue.setSTANDARD("");
                            }
                            if (mtdtValues.contains(FormatManagementConstant.STD23.getConstValueInt())
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (null != composantsOv.getStandard())
                                    compValue.setSTANDARD(composantsOv.getStandard());
                                else
                                    compValue.setSTANDARD("");
                            }
                            if (mtdtValues.contains(FormatManagementConstant.STD24.getConstValueInt())
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (null != composantsOv.getStandard())
                                    compValue.setSTANDARD(composantsOv.getStandard());
                                else
                                    compValue.setSTANDARD("");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_ID.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (null != composantsOv.getEid())
                                    compValue.setID(composantsOv.getEid());
                                else
                                    compValue.setID("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_ID.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (null != composantsOv.getEid())
                                    compValue.setID(composantsOv.getEid());
                                else
                                    compValue.setID("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_ID.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (null != composantsOv.getEid())
                                    compValue.setID(composantsOv.getEid());
                                else
                                    compValue.setID("");
                            } else {
                                logger.info("No matching format present");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_PART.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (null != composantsOv.getPart())
                                    compValue.setPART(composantsOv.getPart());
                                else
                                    compValue.setPART("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_PART.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (null != composantsOv.getPart())
                                    compValue.setPART(composantsOv.getPart());
                                else
                                    compValue.setPART("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_PART.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (null != composantsOv.getPart())
                                    compValue.setPART(composantsOv.getPart());
                                else
                                    compValue.setPART("");
                            } else {
                                logger.info("No matching format present");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_SUPPLIER.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (null != composantsOv.getSupplier())
                                    compValue.setSUPPLIER(composantsOv.getSupplier());
                                else
                                    compValue.setSUPPLIER("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_SUPPLIER.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (null != composantsOv.getSupplier())
                                    compValue.setSUPPLIER(composantsOv.getSupplier());
                                else
                                    compValue.setSUPPLIER("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_SUPPLIER.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (null != composantsOv.getSupplier())
                                    compValue.setSUPPLIER(composantsOv.getSupplier());
                                else
                                    compValue.setSUPPLIER("");
                            } else {
                                logger.info("No matching format present");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_DATA.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (composantsOv.getData() != null)
                                    compValue.setDATA(composantsOv.getData());
                                else
                                    compValue.setDATA("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_DATA.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (composantsOv.getData() != null)
                                    compValue.setDATA(composantsOv.getData());
                                else
                                    compValue.setDATA("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_DATA.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (composantsOv.getData() != null)
                                    compValue.setDATA(composantsOv.getData());
                                else
                                    compValue.setDATA("");
                            } else {
                                logger.info("No matching format present");
                            }

                            if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD22.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_LABEL.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GM1737.getConstValue())) {
                                if (null != composantsOv.getLabel())
                                    compValue.setLABEL(composantsOv.getLabel());
                                else
                                    compValue.setLABEL("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD23.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_LABEL.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.GMW15862.getConstValue())) {
                                if (null != composantsOv.getLabel())
                                    compValue.setLABEL(composantsOv.getLabel());
                                else
                                    compValue.setLABEL("");
                            }

                            else if (mtdtValues
                                    .contains(Long.valueOf(Long.toString(FormatManagementConstant.STD24.getConstValueInt())
                                            + Long.toString(FormatManagementConstant.STD_LABEL.getConstValueInt())))
                                    && composantsOv.getStandard().equals(FormatManagementConstant.OTHER.getConstValue())) {
                                if (null != composantsOv.getLabel())
                                    compValue.setLABEL(composantsOv.getLabel());
                                else
                                    compValue.setLABEL("");
                            } else {
                                logger.info("No matching format present");
                            }
                            if (compValue.getSTANDARD() != null) {
                                compsOvList.add(compValue);
                            }

                        }
                    }
                }

                lcdv.getARTLCDV().addAll(artLcdv);
                option.getRPO().addAll(rpoList);
                compsOv.getCOMPONENTSOV().addAll(compsOvList);

                if (!lcdv.getARTLCDV().isEmpty() || mtdtValues.contains(FormatManagementConstant.LENGTH19.getConstValueInt())) {
                    vehicules.setLISTARTLCDV(lcdv);
                }
                if (!option.getRPO().isEmpty() || mtdtValues.contains(FormatManagementConstant.LENGTH20.getConstValueInt())) {
                    vehicules.setLISTRPO(option);
                }
                if (!compsOv.getCOMPONENTSOV().isEmpty() || mtdtValues.contains(FormatManagementConstant.LENGTH21.getConstValueInt())) {
                    vehicules.setLISTCOMPONENTSOV(compsOv);
                }

                vehicules.setVEHICLEDATAS(vdatas);
                format.getVEHICULES().add(vehicules);
            }

            Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
            marshaller.setContextPath("com.inetpsa.ovr.interfaces.dto.xml");
            StringWriter sw = new StringWriter();
            Result result1 = new StreamResult(sw);
            marshaller.marshal(format, result1);
            return sw.toString();
        } catch (

        Exception e) {
            logger.error("Exception {}", e);
        }
        return null;
    }

    @Override
    public void updateLastRun(OutputFlowDetails details) {
        details.setLastRun(LocalDateTime.now());
        logger.info("Updating last run {}", details.getLastRun());
        flowManagementDetailsRepository.update(details);
    }

}
