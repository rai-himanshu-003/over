package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;

import com.inetpsa.ovr.domain.model.OVComponentPart;

/**
 * The Class OVComponentPartDTO.
 */
public class OVComponentPartDTO implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The id. */
    private Long id;

    /** The flow id. */
    private Long ovCompId;

    /** The seq. */
    private Long standard;

    /** The value. */
    private Long value;

    /** The filter. */
    private String filter;

    /** The selected. */
    private String intSeq;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the ov comp id.
     *
     * @return the ov comp id
     */
    public Long getOvCompId() {
        return ovCompId;
    }

    /**
     * Sets the ov comp id.
     *
     * @param ovCompId the new ov comp id
     */
    public void setOvCompId(Long ovCompId) {
        this.ovCompId = ovCompId;
    }

    /**
     * Gets the standard.
     *
     * @return the standard
     */
    public Long getStandard() {
        return standard;
    }

    /**
     * Sets the standard.
     *
     * @param standard the new standard
     */
    public void setStandard(Long standard) {
        this.standard = standard;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    public String getIntSeq() {
        return intSeq;
    }

    public void setIntSeq(String intSeq) {
        this.intSeq = intSeq;
    }

    /**
     * Map tomodel.
     *
     * @return the output flow details
     */
    public OVComponentPart mapTomodel() {

        OVComponentPart ovComponentPart = new OVComponentPart();
        ovComponentPart.setStandard(this.getStandard());
        ovComponentPart.setIntSeq(this.getIntSeq());
        ovComponentPart.setFilter(this.getFilter());
        ovComponentPart.setValue(this.getValue());
        return ovComponentPart;
    }

}
