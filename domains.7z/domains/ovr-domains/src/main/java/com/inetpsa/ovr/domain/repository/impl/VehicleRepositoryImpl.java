/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.constant.CommonConstant;
import com.inetpsa.ovr.domain.constant.TranslationState;
import com.inetpsa.ovr.domain.model.OutputFlowDetails;
import com.inetpsa.ovr.domain.model.Vehicle;
import com.inetpsa.ovr.domain.repository.VehicleRepository;
import com.inetpsa.ovr.domain.util.LoggedUser;
import com.inetpsa.ovr.domain.util.OVERConstants;
import com.inetpsa.ovr.interfaces.dto.IRMRequestDTO;
import com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto;
import com.inetpsa.ovr.interfaces.dto.PreviousFlowDetailsDTO;
import com.inetpsa.ovr.interfaces.dto.ResendToOTTDto;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;

/**
 * The Class VehicleRepositoryImpl.
 */
public class VehicleRepositoryImpl extends BaseJpaRepository<Vehicle, String> implements VehicleRepository {

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(VehicleRepositoryImpl.class);

    /** The Constant DATEEXT. */
    private static final String DATEEXT = "dateEcom";

    /** The Constant VINNO. */
    private static final String VINNO = "vinNo";

    /** The Constant STATUS. */
    private static final String STATUS = "status";

    /** The formatter. */
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

    /** The Constant CONST23. */
    private static final int CONST23 = 23;

    /** The Constant CONST59. */
    private static final int CONST59 = 59;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleRepository#getVehicleDetails(java.lang.String)
     */
    public Vehicle getVehicleDetails(String vinNo) {
        Vehicle oldVehicleData = null;
        try {

            CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
            CriteriaQuery<Vehicle> criteria = builder.createQuery(Vehicle.class);
            Root<Vehicle> c = criteria.from(Vehicle.class);
            criteria.select(c);
            criteria.where(builder.equal(c.get(VINNO), vinNo));
            TypedQuery<Vehicle> typed = this.entityManager.createQuery(criteria);

            oldVehicleData = typed.getSingleResult();

        } catch (Exception e) {
            logger.error("Exception occurred in retriving data from database  {}", e.getMessage());
        }

        return oldVehicleData;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleRepository#getVehiclesDetails(com.inetpsa.ovr.interfaces.rest.dto.ResendToOTTDto, int, int)
     */
    @Override
    public List<ResendToOTTDto> getVehiclesDetails(ResendToOTTDto vehicleSearchDto, int offsetPositionToStartFrom, int rowsPerPage) {
        List<ResendToOTTDto> vehicleDtoTests = null;
        try {
            logger.info("Entering into VehicleRepositoryImpl > getVehiclesDetails ");
            CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
            CriteriaQuery<ResendToOTTDto> criteria = builder.createQuery(ResendToOTTDto.class);
            Root<Vehicle> c = criteria.from(Vehicle.class);
            Join<Object, Object> ottFlow = (Join<Object, Object>) c.join("multipleFlowStatus", JoinType.INNER);
            // Join<Object, Object> revFlow = (Join<Object, Object>) c.join("multipleFlowStatus", JoinType.INNER);
            // Join<Object, Object> corvetFlow = (Join<Object, Object>) c.join("multipleFlowStatus", JoinType.INNER);
            // Join<Object, Object> thubFlow = (Join<Object, Object>) c.join("multipleFlowStatus", JoinType.INNER);
            criteria.multiselect(c.get(VINNO), c.get("ccp"), c.get("up"), c.get("veh"), c.get("model"), c.get(DATEEXT), ottFlow.get(STATUS),
                    ottFlow.get("flow"));

            setWhereClause(criteria, builder, c, ottFlow, vehicleSearchDto);
            setOrderByClause(criteria, builder, c, ottFlow, vehicleSearchDto);
            final TypedQuery<ResendToOTTDto> typed = this.entityManager.createQuery(criteria);

            if (rowsPerPage != CommonConstant.NEGATIVE_MAGIC_NUMBER.getConstValueInt()) {
                typed.setFirstResult(offsetPositionToStartFrom);
                typed.setMaxResults(rowsPerPage);
            }
            logger.info("Domain commented > offsetPositionToStartFrom {} and rowsPerPage {} ", typed.getFirstResult(), typed.getMaxResults());
            vehicleDtoTests = typed.getResultList();
            System.out.println("size-----------" + vehicleDtoTests.size());
            logger.info("Exiting from VehicleRepositoryImpl  getVehiclesDetails {}", vehicleDtoTests.size());
        } catch (Exception e) {
            logger.error("Error occured in getVehiclesDetails {}", e.getMessage());
        }

        return vehicleDtoTests;

    }

    public List<ResendToOTTDto> getVehiclesDetailsTest(ResendToOTTDto vehicleSearchDto, int offsetPositionToStartFrom, int rowsPerPage) {
        List<ResendToOTTDto> vehicleDtoTests = new ArrayList<>();
        try {
            List list = null;
            logger.info("Entering into VehicleRepositoryImpl > getVehiclesDetails ");
            String query = "SELECT  /*+ PARALLEL(8) */ vhl.vin ,vhl.ccp,up,veh,v_model,vhl.date_ecom,ott.status ott_status, revott.status revott_status,thub.status thub_status, corvet.status corvet_status , vhl.user_creation "
                    + "FROM  ovrqtvhl vhl, ovrqtvsts ott,    ovrqtvsts revott,ovrqtvsts thub,   ovrqtvsts corvet where vhl.vin = ott.vin (+) AND ott.flow (+) = 'OTT'    AND vhl.vin = revott.vin (+) AND revott.flow (+) = 'REVOTT'"
                    + "  AND vhl.vin = thub.vin (+) AND thub.flow (+) = 'THUB'  AND vhl.vin = corvet.vin (+) AND corvet.flow (+) = 'CORVET'";
            Query hql = filterCriteriaTest(vehicleSearchDto, query, true);
            hql.setFirstResult(offsetPositionToStartFrom);
            if (rowsPerPage != OVERConstants.MAGICNUMBER0)
                hql.setMaxResults(rowsPerPage);
            logger.info("Domain commented > offsetPositionToStartFrom {} and rowsPerPage {} ", offsetPositionToStartFrom, rowsPerPage);
            list = hql.getResultList();

            logger.info("Exiting from VehicleRepositoryImpl  getVehiclesDetails test {}", vehicleDtoTests.size());
            vehicleDtoTests = generateResponse(list, vehicleDtoTests);
            logger.info("Exiting from VehicleRepositoryImpl  getVehiclesDetails {}", vehicleDtoTests.size());

        } catch (Exception e) {
            logger.error("Error occured in getVehiclesDetails {}", e);
        }

        return vehicleDtoTests;

    }

    private List<ResendToOTTDto> generateResponse(List arrayList, List<ResendToOTTDto> resendToOTTDtoList) {
        Iterator itr = arrayList.iterator();
        while (itr.hasNext()) {
            Object[] obj = (Object[]) (itr.next());
            String ccp = Optional.ofNullable(obj[OVERConstants.MAGICNUMBER1]).orElse("").toString();
            String up = Optional.ofNullable(obj[OVERConstants.MAGICNUMBER2]).orElse("").toString();
            String veh = Optional.ofNullable(obj[OVERConstants.MAGICNUMBER3]).orElse("").toString();
            String model = Optional.ofNullable(obj[OVERConstants.MAGICNUMBER4]).orElse("").toString();
            ccp = ccp != null ? ccp : "";
            up = up != null ? up : "";
            veh = veh != null ? veh : "";
            model = model != null ? model : "";

            ResendToOTTDto resendToOTTDtoObj = new ResendToOTTDto();
            resendToOTTDtoObj.setVin(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER0]).orElse("").toString());
            resendToOTTDtoObj.setCcp(ccp + "/" + up);
            resendToOTTDtoObj.setVeh(veh + "/" + model);
            if (obj[OVERConstants.MAGICNUMBER5] != null)
                resendToOTTDtoObj.setExtFromDate(obj[OVERConstants.MAGICNUMBER5].toString());
            resendToOTTDtoObj.setOttFlow(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER6]).orElse("").toString());
            resendToOTTDtoObj.setRevottFlow(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER7]).orElse("").toString());
            resendToOTTDtoObj.setThubFlow(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER8]).orElse("").toString());
            resendToOTTDtoObj.setCorvetFlow(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER9]).orElse("").toString());
            resendToOTTDtoObj.setUserCreation(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER10]).orElse("").toString());
            resendToOTTDtoList.add(resendToOTTDtoObj);
        }
        return resendToOTTDtoList;

    }

    public Query filterCriteriaTest(ResendToOTTDto vehicleSearchDto, String query, Boolean callFrom) {
        StringBuilder whereclause = new StringBuilder();
        StringBuilder orderBy = new StringBuilder();
        String finalQuery = null;
        String vinJoinClause = null;
        String linkToProgramClause = null;
        LocalDate extFromDate = null;
        LocalDate extToDate = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        String cons = null;
        if (vehicleSearchDto != null) {
            if (!(vehicleSearchDto.getExtFromDate() == null || vehicleSearchDto.getExtFromDate().equals("null"))) {
                extFromDate = LocalDate.parse(vehicleSearchDto.getExtFromDate(), formatter);
            }

            if (!(vehicleSearchDto.getExtToDate() == null || vehicleSearchDto.getExtToDate().equals("null"))) {
                extToDate = LocalDate.parse(vehicleSearchDto.getExtToDate(), formatter);
            }

            if (vehicleSearchDto.getVin() != null && vehicleSearchDto.getVin().trim().length() != 0) {
                whereclause.append(" AND (vhl.vin) like :vin ");
            }
            if (vehicleSearchDto.getCcp() != null && vehicleSearchDto.getCcp().trim().length() != 0) {
                whereclause.append(" AND (ccp||up)  like :ccp ");
            }
            if (vehicleSearchDto.getVeh() != null && vehicleSearchDto.getVeh().trim().length() != 0) {
                whereclause.append(" AND (veh||v_model)  like :veh ");
            }
            if (vehicleSearchDto.getUserCreation() != null && vehicleSearchDto.getUserCreation().trim().length() != 0) {
                whereclause.append(" AND (vhl.user_creation)  like :userCreation ");

            }
            if (vehicleSearchDto.getOttFlow() != null && vehicleSearchDto.getOttFlow().trim().length() != 0) {
                whereclause.append(" AND (ott.status) in (:ottFlow )");
            }
            if (vehicleSearchDto.getRevottFlow() != null && vehicleSearchDto.getRevottFlow().trim().length() != 0) {
                whereclause.append(" AND (revott.status) in (:revOttFlow )");
            }
            if (vehicleSearchDto.getThubFlow() != null && vehicleSearchDto.getThubFlow().trim().length() != 0) {
                whereclause.append(" AND (thub.status) in (:thubFlow) ");
            }
            if (vehicleSearchDto.getCorvetFlow() != null && vehicleSearchDto.getCorvetFlow().trim().length() != 0) {
                whereclause.append(" AND (corvet.status) in (:corvetFlow) ");
            }
            if (vehicleSearchDto.getExtFromDate() != null) {
                whereclause.append(" AND trunc(vhl.date_ecom) >=:fromDate ");
            }

            if (vehicleSearchDto.getExtToDate() != null) {
                whereclause.append(" AND trunc(vhl.date_ecom) <=:toDate ");
            }

            if (callFrom) {
                orderBy.append("Order").append(" by");
                cons = orderBy.toString();
                if (vehicleSearchDto.getVinOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append("  vhl.vin ").append(vehicleSearchDto.getVinOrder());

                }
                if (vehicleSearchDto.getCcpOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" ccp||up ").append(vehicleSearchDto.getCcpOrder());

                }
                if (vehicleSearchDto.getVehOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" veh||v_model ").append(vehicleSearchDto.getVehOrder());

                }
                if (vehicleSearchDto.getOttFlowOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" ott_status ").append(vehicleSearchDto.getOttFlowOrder());

                }
                if (vehicleSearchDto.getRevottFlowOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" revott_status ").append(vehicleSearchDto.getRevottFlowOrder());

                }
                if (vehicleSearchDto.getThubFlowOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" thub_status ").append(vehicleSearchDto.getThubFlowOrder());

                }
                if (vehicleSearchDto.getCorvetFlowOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" corvet_status ").append(vehicleSearchDto.getCorvetFlowOrder());

                }

                if (vehicleSearchDto.getUserCreationOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" vhl.user_creation ").append(vehicleSearchDto.getUserCreationOrder());

                }
                if (vehicleSearchDto.getExtDateOrder() != null) {
                    if (!orderBy.toString().equals(cons)) {
                        orderBy.append(",");
                    }
                    orderBy.append(" vhl.date_ecom ").append(vehicleSearchDto.getExtDateOrder());

                }

            }
        }
        if (callFrom) {

            if (orderBy.toString().equals(cons))
                orderBy.append(" vhl.date_ecom desc ");
            finalQuery = query + whereclause.append(orderBy).toString();

        } else
            finalQuery = query + whereclause;

        Query hql = this.entityManager.createNativeQuery(finalQuery);

        if (vehicleSearchDto != null) {

            if (vehicleSearchDto.getVin() != null && vehicleSearchDto.getVin().trim().length() != 0)
                hql.setParameter("vin", "%" + vehicleSearchDto.getVin().replace("_", "\\_").trim().toUpperCase() + "%");

            if (vehicleSearchDto.getCcp() != null && vehicleSearchDto.getCcp().trim().length() != 0)
                hql.setParameter("ccp", "%" + vehicleSearchDto.getCcp() + "%");

            if (vehicleSearchDto.getVeh() != null && vehicleSearchDto.getVeh().trim().length() != 0)
                hql.setParameter("veh", "%" + vehicleSearchDto.getVeh() + "%");

            if (vehicleSearchDto.getUserCreation() != null && vehicleSearchDto.getUserCreation().trim().length() != 0)
                hql.setParameter("userCreation", "%" + vehicleSearchDto.getUserCreation() + "%");

            if (vehicleSearchDto.getOttFlow() != null && vehicleSearchDto.getOttFlow().trim().length() != 0) {
                List<String> ottStatusList = Arrays.asList(vehicleSearchDto.getOttFlow().toUpperCase().split(","));
                hql.setParameter("ottFlow", ottStatusList);
            }

            if (vehicleSearchDto.getRevottFlow() != null && vehicleSearchDto.getRevottFlow().trim().length() != 0) {
                List<String> revottStatusList = Arrays.asList(vehicleSearchDto.getRevottFlow().toUpperCase().split(","));
                hql.setParameter("revOttFlow", revottStatusList);
            }
            if (vehicleSearchDto.getThubFlow() != null && vehicleSearchDto.getThubFlow().trim().length() != 0) {
                List<String> thubStatusList = Arrays.asList(vehicleSearchDto.getThubFlow().toUpperCase().split(","));
                hql.setParameter("thubFlow", thubStatusList);
            }
            if (vehicleSearchDto.getCorvetFlow() != null && vehicleSearchDto.getCorvetFlow().trim().length() != 0) {
                List<String> corvetStatusList = Arrays.asList(vehicleSearchDto.getCorvetFlow().toUpperCase().split(","));
                hql.setParameter("corvetFlow", corvetStatusList);
            }
            if (vehicleSearchDto.getExtFromDate() != null)
                hql.setParameter("fromDate", extFromDate);

            if (vehicleSearchDto.getExtToDate() != null)
                hql.setParameter("toDate", extToDate);

        }

        return hql;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleRepository#getVehiclesDetailsCount(com.inetpsa.ovr.interfaces.dto.ResendToOTTDto)
     */
    @Override
    public Long getVehiclesDetailsCount(ResendToOTTDto vehicleSearchDto) {
        Long count = 0L;
        try {
            logger.info("Entering into VehicleRepositoryImpl > getVehiclesDetailsCount ");
            String query = "SELECT  /*+ PARALLEL(8) */ count (vhl.vin) FROM  ovrqtvhl vhl, ovrqtvsts ott,    ovrqtvsts revott,ovrqtvsts thub,   ovrqtvsts corvet where vhl.vin = ott.vin (+) AND ott.flow (+) = 'OTT'    AND vhl.vin = revott.vin (+) AND revott.flow (+) = 'REVOTT'"
                    + "  AND vhl.vin = thub.vin (+) AND thub.flow (+) = 'THUB'  AND vhl.vin = corvet.vin (+) AND corvet.flow (+) = 'CORVET'";
            Query hql = filterCriteriaTest(vehicleSearchDto, query, false);

            count = ((BigDecimal) hql.getSingleResult()).longValue();
            logger.info("Exiting from VehicleRepositoryImpl > getVehiclesDetailsCount {}", count);
        } catch (Exception e) {
            logger.error("Error occured in getVehiclesDetails {}", e.getMessage());
        }

        return count;
    }

    /**
     * Sets the order by clause.
     *
     * @param criteria the criteria
     * @param builder the builder
     * @param c the c
     * @param cRoot the c root
     * @param vehicleSearchDto the vehicle search dto
     */
    private void setOrderByClause(CriteriaQuery<ResendToOTTDto> criteria, CriteriaBuilder builder, Root<Vehicle> c, Join<Object, Object> cRoot,
            ResendToOTTDto vehicleSearchDto) {
        boolean flag = true;
        List<Order> orderList = new ArrayList<>();

        try {

            logger.info("Entering into VehicleRepositoryImpl > setOrderByClause ");

            if (vehicleSearchDto.getVinOrder() != null) {
                if (vehicleSearchDto.getVinOrder().equalsIgnoreCase("asc"))
                    orderList.add(builder.asc(c.get(VINNO)));
                else if (vehicleSearchDto.getVinOrder().equalsIgnoreCase("desc"))
                    orderList.add(builder.desc(c.get(VINNO)));

                logger.info("Order by VIN {} ", vehicleSearchDto.getVinOrder());

                flag = false;
            }

            if (vehicleSearchDto.getCcpOrder() != null) {
                if (vehicleSearchDto.getCcpOrder().equalsIgnoreCase("asc"))
                    orderList.add(builder.asc(c.get("ccp")));
                else if (vehicleSearchDto.getCcpOrder().equalsIgnoreCase("desc"))
                    orderList.add(builder.desc(c.get("ccp")));

                logger.info("Order by CCP {} ", vehicleSearchDto.getCcpOrder());

                flag = false;
            }

            if (vehicleSearchDto.getVehOrder() != null) {
                if (vehicleSearchDto.getVehOrder().equalsIgnoreCase("asc"))
                    orderList.add(builder.asc(c.get("veh")));
                else if (vehicleSearchDto.getVehOrder().equalsIgnoreCase("desc"))
                    orderList.add(builder.desc(c.get("veh")));

                logger.info("Order by VEH {} ", vehicleSearchDto.getVehOrder());

                flag = false;
            }

            if (vehicleSearchDto.getExtDateOrder() != null) {
                if (vehicleSearchDto.getExtDateOrder().equalsIgnoreCase("asc"))
                    orderList.add(builder.asc(c.get(DATEEXT)));
                else if (vehicleSearchDto.getExtDateOrder().equalsIgnoreCase("desc"))
                    orderList.add(builder.desc(c.get(DATEEXT)));

                logger.info("Order by Date Extension {} ", vehicleSearchDto.getExtDateOrder());

                flag = false;
            }

            if (flag) {
                logger.info("No order by filter found, setting default order by dateEcom desc and VIN asc filter!!");
                orderList.add(builder.desc(c.get(DATEEXT)));
            }

            // This is by default sorting, because index based sorting is not available on VIN
            if (vehicleSearchDto.getVinOrder() == null)
                orderList.add(builder.asc(c.get(VINNO)));

            criteria.orderBy(orderList);
        } catch (Exception e) {
            logger.error("Error occured in order by clause {}", e.getMessage());
        }

        logger.info("Exiting from VehicleRepositoryImpl > setOrderByClause ");

    }

    /**
     * Sets the where clause.
     *
     * @param criteria the criteria
     * @param builder the builder
     * @param c the c
     * @param cRoot the c root
     * @param vehicleSearchDto the vehicle search dto
     */
    private void setWhereClause(CriteriaQuery<ResendToOTTDto> criteria, CriteriaBuilder builder, Root<Vehicle> c, Join<Object, Object> ottRoot,
            ResendToOTTDto vehicleSearchDto) {

        try {
            logger.info("Entering into VehicleRepositoryImpl > setWhereClause ");

            List<Predicate> predicates = new ArrayList<>();
            Date extFromDate = null;
            Date extToDate = null;

            if (vehicleSearchDto.getVin() != null)
                predicates.add(builder.like(c.get(VINNO), "%" + vehicleSearchDto.getVin() + "%"));

            if (vehicleSearchDto.getCcp() != null)
                predicates.add(builder.like(builder.concat(c.get("ccp"), c.get("up")), "%" + vehicleSearchDto.getCcp() + "%"));

            if (vehicleSearchDto.getVeh() != null)
                predicates.add(builder.like(builder.concat(c.get("veh"), c.get("model")), "%" + vehicleSearchDto.getVeh() + "%"));

            if (vehicleSearchDto.getFlowName() != null) {
                List<String> list = Arrays.asList(vehicleSearchDto.getFlowName().split(","));
                predicates.add(ottRoot.get("flow").in(list));
            }
            if (vehicleSearchDto.getExtFromDate() != null)
                extFromDate = formatter.parse(vehicleSearchDto.getExtFromDate());

            if (vehicleSearchDto.getExtToDate() != null) {
                extToDate = formatter.parse(vehicleSearchDto.getExtToDate());
                extToDate.setHours(CONST23);
                extToDate.setMinutes(CONST59);
                extToDate.setSeconds(CONST59);

            }
            if (extFromDate != null)
                predicates.add(builder.greaterThanOrEqualTo(c.get(DATEEXT), extFromDate));

            if (extToDate != null)
                predicates.add(builder.lessThanOrEqualTo(c.get(DATEEXT), extToDate));

            // predicates.add(builder.equal(ottRoot.get("flow"), "OTT"));
            // predicates.add(builder.equal(revottRoot.get("flow"), "REVOTT"));
            // predicates.add(builder.equal(thubRoot.get("flow"), "THUB"));
            // predicates.add(builder.equal(corvetRoot.get("flow"), "CORVET"));
            criteria.where(predicates.toArray(new Predicate[] {}));

        } catch (Exception e) {
            logger.error("Error in setWhereAndOrderByConditions() {} ", e.getMessage());
        }
        logger.info("Exiting from VehicleRepositoryImpl > setWhereClause ");
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleRepository#applyRulesAndInsertVehicles(com.inetpsa.ovr.interfaces.dto.InterfaceRulesDto,
     *      com.inetpsa.ovr.interfaces.dto.IRMRequestDTO, java.lang.String)
     */
    public boolean applyRulesAndInsertVehicles(InterfaceRulesDto interfaceRulesDto, IRMRequestDTO irmRequestDTO, String status, Boolean ignoreAll,
            List<String> vinList) {

        boolean vehsts = false;
        boolean vehhis = false;
        boolean veherr = false;
        boolean outputFlow = false;

        try {
            StringBuilder ottQuery;
            StringBuilder ottQueryForHistoryTable;
            StringBuilder ottQueryForErrorTable;

            outputFlow = CommonConstant.OUTPUT_FLOW.getConstValue()
                    .equalsIgnoreCase(irmRequestDTO.getPreviousFlowDetailsDTOs().get(0).getPreviousFlow());

            StringBuilder vinListForm = formInClause(vinList, " sts.vin in ( ");

            if (vinListForm == null)
                vinListForm = new StringBuilder(" ) ");

            ottQueryForHistoryTable = new StringBuilder(
                    "Insert into OVRQTHIS(VIN,FLOWNAME,STATE_ID,DATE_CREATION,USER_CREATION)  select  vhl.vin,:currentFlow,:status,sysdate,:creationUser from OVRQTVHL vhl join OVRQTVSTS sts on vhl.vin=sts.vin where   ( "
                            + vinListForm.toString());
            ottQueryForErrorTable = new StringBuilder(
                    "Insert into OVRQTERR(VIN,ERR_CODE,ERR_COMPLEMENT,ERR_DESCRIPTION,ERR_MESSAGE,FLOWNAME,DATE_CREATION,USER_CREATION)  select  vhl.vin,'IGNORED',null,'Ignored by rules',null,:currentFlow,sysdate,:creationUser from OVRQTVHL vhl join OVRQTVSTS sts on vhl.vin=sts.vin where  ( "
                            + vinListForm.toString());

            ottQuery = new StringBuilder(
                    "Insert into OVRQTVSTS(ID,FLOW,STATUS,DATE_CREATION,USER_CREATION,DATE_MODIF,USER_MODIF,VIN,VERSION)   select OVRQTVSTS_SEQ.NEXTVAL,:currentFlow ,:status,sysdate,:creationUser,sysdate,:creationUser,vhl.vin,0 from OVRQTVHL vhl join OVRQTVSTS sts on vhl.vin=sts.vin where ( "
                            + vinListForm.toString());
            if (!outputFlow)
                vehhis = filterCriteria(interfaceRulesDto, irmRequestDTO, status, ignoreAll, ottQueryForHistoryTable, false, vinList);

            if (status.equalsIgnoreCase(TranslationState.IGNORE.getConstValue()) && !outputFlow)
                veherr = filterCriteria(interfaceRulesDto, irmRequestDTO, status, ignoreAll, ottQueryForErrorTable, true, vinList);

            vehsts = filterCriteria(interfaceRulesDto, irmRequestDTO, status, ignoreAll, ottQuery, false, vinList);

            return (outputFlow) ? vehsts : (vehhis && vehsts);

        } catch (Exception e) {
            logger.error("ERROR in generic Component {} ", e.getMessage());
            vehsts = false;
        }

        return vehsts;
    }

    public StringBuilder formInClause(List<String> dataList, String innerequery) {

        StringBuilder idString = new StringBuilder();
        List<String> listOfIds = new ArrayList<>();
        int index = 0;

        if (dataList != null && !dataList.isEmpty()) {
            for (String id : dataList) {
                idString.append("'" + id + "',");

                if ((index % 1000 == 999) || (index == (dataList.size() - 1))) {
                    listOfIds.add(idString.toString().substring(0, idString.length() - 1));
                    idString.setLength(0);
                }

                index++;
            }
            if (listOfIds != null && !listOfIds.isEmpty()) {
                StringBuilder idInClouse = new StringBuilder();
                index = 0;
                for (String listId : listOfIds) {
                    idInClouse.append(innerequery + listId + ")  ");

                    if (listOfIds.size() - 1 != index)
                        idInClouse.append(" OR ");

                    index++;
                }
                idInClouse.append(" ) ");

                return idInClouse;

            }

        }

        return null;
    }

    /**
     * Filter criteria.
     *
     * @param interfaceRulesDto the interface rules dto
     * @param irmRequestDTO the irm request DTO
     * @param status the status
     * @param ignoreAll the ignore all
     * @param query the query
     * @return true, if successful
     */
    private boolean filterCriteria(InterfaceRulesDto interfaceRulesDto, IRMRequestDTO irmRequestDTO, String status, Boolean ignoreAll,
            StringBuilder query, boolean isErr, List<String> mainVinList) {
        String currentFlow = irmRequestDTO.getCurrentFlow();
        List<PreviousFlowDetailsDTO> previousFlowDetailsDTOs = irmRequestDTO.getPreviousFlowDetailsDTOs();

        Query hql = null;
        List<String> vehList = null;
        List<String> ccpList = null;
        List<String> countryList = null;
        List<String> vinList = null;
        List<String> prevFlowList = null;
        String familyOfVehArr = null;
        String creationUser = LoggedUser.get();
        boolean outputFlow = false;

        outputFlow = CommonConstant.OUTPUT_FLOW.getConstValue().equalsIgnoreCase(irmRequestDTO.getPreviousFlowDetailsDTOs().get(0).getPreviousFlow());

        logger.info("irmRequestDTO.getPreviousFlowDetailsDTOs().get(0).getPreviousFlow() : {} ",
                irmRequestDTO.getPreviousFlowDetailsDTOs().get(0).getPreviousFlow());
        logger.info("CommonConstant.OUTPUT_FLOW.getConstValue() : {} ", CommonConstant.OUTPUT_FLOW.getConstValue());
        logger.info("Is this oiutput flow : {} : ignoreall : {}", outputFlow, ignoreAll);

        try {
            if (ignoreAll) {
                if (interfaceRulesDto.getFamilyOfVehicle() != null) {
                    familyOfVehArr = "'^(" + interfaceRulesDto.getFamilyOfVehicle().toUpperCase().replaceAll(",", "|").concat(")'");
                    // vehList = Arrays.asList(familyOfVehArr);

                    if (currentFlow.equalsIgnoreCase(CommonConstant.OTT_FLOW.getConstValue())
                            || currentFlow.equalsIgnoreCase(CommonConstant.TRANSFORMATION_HUB_FLOW.getConstValue()) || outputFlow)
                        query.append(" AND REGEXP_LIKE ( vhl.V_MODEL, :veh )");
                    else if (currentFlow.equalsIgnoreCase(CommonConstant.CORVET_FLOW.getConstValue())
                            || currentFlow.equalsIgnoreCase(CommonConstant.REV_OTT_FLOW.getConstValue()))
                        query.append(" AND REGEXP_LIKE ((select substr(lcdv24,2,3) from ovrqtvhl vhl1 where vhl1.vin=vhl.vin ) , :veh)");
                }
                if (interfaceRulesDto.getProductionCentre() != null) {
                    String[] prodCentre = interfaceRulesDto.getProductionCentre().toUpperCase().split(",");
                    ccpList = Arrays.asList(prodCentre);
                    if (currentFlow.equalsIgnoreCase(CommonConstant.OTT_FLOW.getConstValue())
                            || currentFlow.equalsIgnoreCase(CommonConstant.TRANSFORMATION_HUB_FLOW.getConstValue()) || outputFlow)

                    {
                        StringBuilder inclause = formInClause(ccpList, " upper(vhl.up) in(");
                        query.append(" AND (");

                        query.append(inclause);

                    } else if (currentFlow.equalsIgnoreCase(CommonConstant.CORVET_FLOW.getConstValue())
                            || currentFlow.equalsIgnoreCase(CommonConstant.REV_OTT_FLOW.getConstValue())) {
                        StringBuilder inclause = formInClause(ccpList, " upper(vhl.ccp) in(");
                        query.append(" AND (");
                        query.append(inclause);
                    }
                }

                if (interfaceRulesDto.getCountry() != null) {

                    String[] countries = interfaceRulesDto.getCountry().toUpperCase().split(",");
                    countryList = Arrays.asList(countries);
                    StringBuilder inclause = null;
                    if (currentFlow.equalsIgnoreCase(CommonConstant.CORVET_FLOW.getConstValue())
                            || currentFlow.equalsIgnoreCase(CommonConstant.REV_OTT_FLOW.getConstValue()) || outputFlow) {
                        inclause = formInClause(countryList, "(select 1 from OVRQTVLCDV ol where  ol.vin=vhl.vin and characteristic || value in(");

                    } else if (currentFlow.equalsIgnoreCase(CommonConstant.OTT_FLOW.getConstValue())
                            || currentFlow.equalsIgnoreCase(CommonConstant.TRANSFORMATION_HUB_FLOW.getConstValue())) {
                        inclause = formInClause(countryList, "(select 1 from OVRQTVRPO rp where  rp.vin=vhl.vin and rp.rpo in(");

                    }
                    query.append(" AND  exists");
                    query.append(inclause);
                }
                if (interfaceRulesDto.getMinEcomDate() != null)
                    query.append(" AND trunc(vhl.date_ecom) >=:minEcomDate");
                if (interfaceRulesDto.getMaxEcomDate() != null)
                    query.append(" AND trunc(vhl.date_ecom) <=:maxEcomDate");
                if (interfaceRulesDto.getVin() != null) {
                    String[] vinArr = interfaceRulesDto.getVin().toUpperCase().split(",");
                    vinList = Arrays.asList(vinArr);
                    query.append(" AND upper(vhl.vin) in (:vin)");
                }
            }
            int i = 0;
            if (!outputFlow)
                for (PreviousFlowDetailsDTO previousFlowDetailsDTO : previousFlowDetailsDTOs) {

                    if (previousFlowDetailsDTO.getPreviousFlow() != null)
                        query.append(" AND (upper(sts.flow)  in (:prevFlow" + i + ")");

                    String statusList = String.join(",", previousFlowDetailsDTO.getStatus());

                    if (statusList != null) {

                        query.append(" AND sts.status in(:statusList" + i + ")");

                    }
                    query.append(")");
                    i++;

                }
            hql = super.getEntityManager().createNativeQuery(query.toString());
            i = 0;
            if (ignoreAll) {
                if (interfaceRulesDto.getFamilyOfVehicle() != null)
                    hql.setParameter("veh", familyOfVehArr);

                logger.info("veh  : {} ", familyOfVehArr);

                if (interfaceRulesDto.getMinEcomDate() != null)
                    hql.setParameter("minEcomDate", interfaceRulesDto.getMinEcomDate());

                logger.info("minEcomDate  : {} ", interfaceRulesDto.getMinEcomDate());

                if (interfaceRulesDto.getMaxEcomDate() != null)
                    hql.setParameter("maxEcomDate", interfaceRulesDto.getMaxEcomDate());

                logger.info("maxEcomDate  : {} ", interfaceRulesDto.getMaxEcomDate());

                if (interfaceRulesDto.getVin() != null)
                    hql.setParameter("vin", vinList);

                logger.info("vin  : {} ", vinList);

            }

            if (!outputFlow)
                for (PreviousFlowDetailsDTO previousFlowDetailsDTO : previousFlowDetailsDTOs) {
                    prevFlowList = null;
                    String[] prevFlow = previousFlowDetailsDTO.getPreviousFlow().split(",");
                    prevFlowList = Arrays.asList(prevFlow);
                    hql.setParameter("statusList" + i, previousFlowDetailsDTO.getStatus());
                    hql.setParameter("prevFlow" + i, prevFlowList);
                    i++;
                }

            hql.setParameter("currentFlow", currentFlow);
            logger.info("currentFlow  : {} ", currentFlow);
            if (!isErr)
                hql.setParameter(STATUS, status);

            logger.info("status  : {} ", status);

            hql.setParameter("creationUser", creationUser);
            logger.info("creationUser  : {} ", creationUser);

            // hql.setParameter("vinList", mainVinList);

            logger.info("*********** Final query : {}", query.toString());
            int count = hql.executeUpdate();
            logger.info("Fetching vehicle details completed for flow :{} total {} records inserted", irmRequestDTO.getCurrentFlow(), count);
            return true;
        } catch (

        Exception e) {
            logger.error("Error occured while fetching vehicle  for flow {} detailed exception :{}", irmRequestDTO.getCurrentFlow(), e.getMessage());
            logger.error("Error in query : {} ", query.toString());
            return false;
        }

    }

    /**
     * Sets the where clause count.
     *
     * @param criteria the criteria
     * @param builder the builder
     * @param c the c
     * @param cRoot the c root
     * @param vehicleSearchDto the vehicle search dto
     */
    private void setWhereClauseCount(CriteriaQuery<Long> criteria, CriteriaBuilder builder, Root<Vehicle> c, Join<Object, Object> cRoot,
            ResendToOTTDto vehicleSearchDto) {

        try {
            logger.info("Entering into VehicleRepositoryImpl > setWhereClause ");

            List<Predicate> predicates = new ArrayList<>();
            Date extFromDate = null;
            Date extToDate = null;
            if (vehicleSearchDto.getVin() != null)
                predicates.add(builder.like(c.get(VINNO), "%" + vehicleSearchDto.getVin() + "%"));

            if (vehicleSearchDto.getCcp() != null)
                predicates.add(builder.like(builder.concat(c.get("ccp"), c.get("up")), "%" + vehicleSearchDto.getCcp() + "%"));

            if (vehicleSearchDto.getVeh() != null)
                predicates.add(builder.like(builder.concat(c.get("veh"), c.get("model")), "%" + vehicleSearchDto.getVeh() + "%"));

            if (vehicleSearchDto.getFlowName() != null) {
                List<String> list = Arrays.asList(vehicleSearchDto.getFlowName().split(","));
                predicates.add(cRoot.get("flow").in(list));
            }
            if (vehicleSearchDto.getExtFromDate() != null)
                extFromDate = formatter.parse(vehicleSearchDto.getExtFromDate());

            if (vehicleSearchDto.getExtToDate() != null) {
                extToDate = formatter.parse(vehicleSearchDto.getExtToDate());
                extToDate.setHours(CONST23);
                extToDate.setMinutes(CONST59);
                extToDate.setSeconds(CONST59);

            }
            if (extFromDate != null && extToDate != null)
                predicates.add(builder.between(c.get(DATEEXT), extFromDate, extToDate));

            criteria.where(predicates.toArray(new Predicate[] {}));

        } catch (Exception e) {
            logger.error("Error in setWhereAndOrderByConditions() {} ", e.getMessage());
        }
        logger.info("Exiting from VehicleRepositoryImpl > setWhereClause ");
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.repository.VehicleRepository#deleteOTTRetriedRecs()
     */
    @Override
    public boolean deleteOTTRetriedRecs(String flow, String status) {
        try {
            logger.info("REIN records are getting deleted");
            StringBuilder query;

            query = new StringBuilder("Delete from OVRQTVSTS where flow=? and STATUS=?");
            int cnt = super.getEntityManager().createNativeQuery(query.toString()).setParameter(1, flow).setParameter(2, status).executeUpdate();
            logger.info("Total {} REIN records deleted for  flow:{}", cnt, flow);

            return true;
        } catch (Exception e) {
            logger.error("Error occured while deleting REIN records  for flow:{} detailed exception :{}", flow, e.getMessage());
            return false;
        }
    }

    @Override
    public List<VehicleDetailsDto> getVehList(List<String> previousFlow, List<String> previousStatus, String currentFlow) {

        logger.info("Entering getErrList of VehicleErrorRepositoryImpl");
        logger.info("previousFlow: {},  currentFLow: {} , previousStatus : {}", previousFlow, currentFlow, previousStatus);
        List<VehicleDetailsDto> vehicleError = null;
        List list = null;
        Query hql = null;
        try {

            logger.info("Entering  of VehicleErrorRepositoryImpl");

            if (currentFlow.equals(CommonConstant.REV_OTT_FLOW.getConstValue())) {
                hql = super.getEntityManager().createNativeQuery(
                        "select  vhl.vin,sts.status,sts.flow  from OVRQTVHL vhl join OVRQTVSTS sts on vhl.vin=sts.vin where  sts.vin not in (select vin  from OVRQTVSTS where  flow =:currentFLow ) and sts.flow in (:previousFlow) and sts.status in (:previousStatus)");
                logger.info("Current flow is {}, Null RPOs are allowed !!!", currentFlow);
            } else {
                hql = super.getEntityManager().createNativeQuery(
                        "select  distinct vhl.vin,sts.status,sts.flow  from OVRQTVHL vhl join OVRQTVSTS sts on vhl.vin=sts.vin join OVRQTVRPO rpo on vhl.vin = rpo.vin where  sts.vin not in (select vin  from OVRQTVSTS where  flow =:currentFLow ) and sts.flow in (:previousFlow) and sts.status in (:previousStatus)");
                logger.info("Current flow is {}, Null RPOs are NOT allowed !!!", currentFlow);
            }

            hql.setParameter("previousFlow", previousFlow);
            hql.setParameter("currentFLow", currentFlow);
            // hql.setParameter("previousStatus", previousStatus);

            hql.setParameter("previousStatus", previousStatus);

            list = hql.getResultList();
            logger.info(" getVehList list size  **** {}  ", list.size());
            vehicleError = this.generateHisList(list);

            return vehicleError;
        } catch (Exception e) {
            logger.error("Error occurred while fetching data {}", e.getMessage());
        }
        return vehicleError;
    }

    private List<VehicleDetailsDto> generateHisList(List arrayList) {
        try {
            List<VehicleDetailsDto> mainDTOList = new ArrayList<>();
            Iterator itr = arrayList.iterator();
            while (itr.hasNext()) {
                logger.info(" iteratore the list VehicleErrorRepositoryImpl");
                Object[] obj = (Object[]) (itr.next());
                VehicleDetailsDto vehicleDetailsDto = new VehicleDetailsDto();
                vehicleDetailsDto.setVin(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER0]).orElse("").toString());
                vehicleDetailsDto.setStateId(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER1]).orElse("").toString());
                vehicleDetailsDto.setFlowName(Optional.ofNullable(obj[OVERConstants.MAGICNUMBER2]).orElse("").toString());
                mainDTOList.add(vehicleDetailsDto);
            }
            logger.info("Exiting  of VehicleErrorRepositoryImpl" + mainDTOList.size());
            return mainDTOList;
        } catch (Exception e) {
            logger.error("Error in generateHisList() {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    @Override
    public boolean deleteOldOutflowEntry(String currentFlow) {
        try {
            logger.info("Old OUTPUT flow records deletion starts ");
            StringBuilder query;

            query = new StringBuilder("Delete from OVRQTVSTS where flow=? ");
            int cnt = super.getEntityManager().createNativeQuery(query.toString()).setParameter(1, currentFlow).executeUpdate();
            logger.info("Total {} REIN records deleted for  flow:{}", cnt, currentFlow);

            logger.info("Old OUTPUT flow records deletion ends : number of records deleted {} ", cnt);

            return true;
        } catch (Exception e) {
            logger.error("Error occured while deleting output flow records  for flow:{} detailed exception :{}", currentFlow, e.getMessage());
            return false;
        }
    }

    @Override
    public List<String> getVehicleForOutputFlow(OutputFlowDetails outputFlow) {
        try {
            logger.info("{} : Entering into getVehicleForOutputFlow ", outputFlow.getFlow());

            String startQuery = "SELECT distinct vhl.vinNo FROM Vehicle vhl where 1=1 ";

            StringBuilder whereClouse = new StringBuilder();
            StringBuilder selectAndFrom = new StringBuilder(startQuery);

            if (outputFlow.getLastRun() != null) {

                if (outputFlow.getAction() != null && outputFlow.getAction().toString().equals("30"))
                    whereClouse.append(" AND vhl.dateModif between (select opfl.lastRun from OutputFlowDetails opfl where opfl.id = "
                            + outputFlow.getId() + ") AND sysdate ");
                else if (outputFlow.getAction() != null && outputFlow.getAction().toString().equals("31"))
                    whereClouse.append(" AND vhl.dateCreation between (select opfl.lastRun from OutputFlowDetails opfl where opfl.id = "
                            + outputFlow.getId() + " ) AND sysdate ");
            } else {

                if (outputFlow.getAction() != null && outputFlow.getAction().toString().equals("30"))
                    whereClouse.append(" AND vhl.dateModif between (sysdate - 1/24) AND sysdate ");
                else if (outputFlow.getAction() != null && outputFlow.getAction().toString().equals("31"))
                    whereClouse.append(" AND vhl.dateCreation between (sysdate - 1/24) AND sysdate ");
            }

            Query finalQuery = this.entityManager.createQuery(selectAndFrom.toString() + whereClouse.toString());

            String loggerInfo = selectAndFrom.toString() + whereClouse.toString();
            logger.info("{} : Query with filters to fetch VIN : {} ", outputFlow.getFlow(), loggerInfo);

            List<String> vehicleList = finalQuery.getResultList();

            return vehicleList;
        } catch (Exception e) {
            logger.error("Error occured while finding records for {} : {} ", outputFlow.getFlow(), e.getMessage());
        }

        return null;
    }

}
