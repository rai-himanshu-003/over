/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.FlowVhlMetadataDTO;
import com.inetpsa.ovr.interfaces.dto.GenericCollectionDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class FlowVhlMetadata.
 */
@Entity
@DynamicUpdate
@Table(name = "OVRQTFLVHLMTDT")
public class FlowVhlMetadata extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @SequenceGenerator(name = "SEQ_GEN", sequenceName = "OVRQTFLVHLMTDT_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")
    @Column(name = "ID")
    private Long id;

    /** The flow id. */
    @Column(name = "FLOW_ID")
    private Long flowId;

    /** The seq. */
    @Column(name = "SEQ")
    private Long seq;

    /** The value. */
    @Column(name = "VALUE")
    private Long value;

    /** The filter. */
    @Column(name = "FILTER")
    private String filter;

    /** The separator. */
    @Column(name = "SEPARATOR")
    private String separator;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the flow id.
     *
     * @return the flow id
     */
    public Long getFlowId() {
        return flowId;
    }

    /**
     * Sets the flow id.
     *
     * @param flowId the new flow id
     */
    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    /**
     * Gets the seq.
     *
     * @return the seq
     */
    public Long getSeq() {
        return seq;
    }

    /**
     * Sets the seq.
     *
     * @param seq the new seq
     */
    public void setSeq(Long seq) {
        this.seq = seq;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Long getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Long value) {
        this.value = value;
    }

    /**
     * Gets the filter.
     *
     * @return the filter
     */
    public String getFilter() {
        return filter;
    }

    /**
     * Sets the filter.
     *
     * @param filter the new filter
     */
    public void setFilter(String filter) {
        this.filter = filter;
    }

    /**
     * Gets the separator.
     *
     * @return the separator
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * Sets the separator.
     *
     * @param separator the new separator
     */
    public void setSeparator(String separator) {
        this.separator = separator;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((filter == null) ? 0 : filter.hashCode());
        result = prime * result + ((flowId == null) ? 0 : flowId.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((separator == null) ? 0 : separator.hashCode());
        result = prime * result + ((seq == null) ? 0 : seq.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        FlowVhlMetadata other = (FlowVhlMetadata) obj;
        if (filter == null) {
            if (other.filter != null)
                return false;
        } else if (!filter.equals(other.filter))
            return false;
        if (flowId == null) {
            if (other.flowId != null)
                return false;
        } else if (!flowId.equals(other.flowId))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (separator == null) {
            if (other.separator != null)
                return false;
        } else if (!separator.equals(other.separator))
            return false;
        if (seq == null) {
            if (other.seq != null)
                return false;
        } else if (!seq.equals(other.seq))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        } else if (!value.equals(other.value))
            return false;
        return true;
    }

    /**
     * Mapto dto.
     *
     * @return the flow static metadata DTO
     */
    public FlowVhlMetadataDTO maptoDto() {
        FlowVhlMetadataDTO flMetadataDTO = new FlowVhlMetadataDTO();
        flMetadataDTO.setFlowId(this.getFlowId());
        flMetadataDTO.setId(this.getId());
        flMetadataDTO.setSeq(this.getSeq());
        flMetadataDTO.setSeparator(this.getSeparator());
        flMetadataDTO.setValue(this.getValue());
        flMetadataDTO.setFilter(this.getFilter());
        return flMetadataDTO;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "FlowVhlMetadata [id=" + id + ", flowId=" + flowId + ", seq=" + seq + ", value=" + value + ", filter=" + filter + ", separator="
                + separator + "]";
    }

    /**
     * Map to gen col.
     *
     * @return the generic collection DTO
     */
    public GenericCollectionDTO mapToGenCol() {
        GenericCollectionDTO genCol = new GenericCollectionDTO();
        genCol.setFlowId(this.getFlowId());
        genCol.setId(this.getId());
        genCol.setSeq(this.getSeq());
        genCol.setSeparator(this.getSeparator());
        genCol.setValue(this.getValue());
        genCol.setFilter(this.getFilter());
        return genCol;
    }

}
