/*
 * Creation : 17 Apr 2020
 */
package com.inetpsa.ovr.interfaces.dto.json;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class OpFlJson.
 */
public class OpFlJson {

    /** The header. */
    @SerializedName("HEADER")
    @Expose
    private OpHeader header;

    /** The vehicules. */
    @SerializedName("VEHICULES")
    @Expose
    private List<OpVehicule> vehicules;

    /** The footer. */
    @SerializedName("FOOTER")
    @Expose
    private OpFooter footer;

    /**
     * Gets the header.
     *
     * @return the header
     */
    public OpHeader getHeader() {
        return header;
    }

    /**
     * Sets the header.
     *
     * @param header the new header
     */
    public void setHeader(OpHeader header) {
        this.header = header;
    }

    /**
     * Gets the vehicules.
     *
     * @return the vehicules
     */
    public List<OpVehicule> getVehicules() {
        return vehicules;
    }

    /**
     * Sets the vehicules.
     *
     * @param vehicules the new vehicules
     */
    public void setVehicules(List<OpVehicule> vehicules) {
        this.vehicules = vehicules;
    }

    /**
     * Gets the footer.
     *
     * @return the footer
     */
    public OpFooter getFooter() {
        return footer;
    }

    /**
     * Sets the footer.
     *
     * @param footer the new footer
     */
    public void setFooter(OpFooter footer) {
        this.footer = footer;
    }

}