/*
 * Creation : 18 Dec 2019
 */
package com.inetpsa.ovr.interfaces.dto.ws;

import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 * The Class ResponseObj.
 */
public class ResponseObj {

    /** The header. */
    @SerializedName(value = "HEADER")
    private Header header;

    /** The vehicules. */
    @SerializedName(value = "VEHICULES")
    private List<Vehicules> vehicules;

    /**
     * Gets the header.
     *
     * @return the header
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the header.
     *
     * @param header the new header
     */
    public void setHeader(Header header) {
        this.header = header;
    }

    /**
     * Gets the vehicules.
     *
     * @return the vehicules
     */
    public List<Vehicules> getVehicules() {
        return vehicules;
    }

    /**
     * Sets the vehicules.
     *
     * @param vehicules the new vehicules
     */
    public void setVehicules(List<Vehicules> vehicules) {
        this.vehicules = vehicules;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ResponseObj [header=" + header + ", vehicules=" + vehicules + "]";
    }

}
