/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.ovr.domain.model.MMVehicleHistory;
import com.inetpsa.ovr.domain.model.TrackChanges;
import com.inetpsa.ovr.interfaces.dto.TrackChangesDto;

/**
 * The Interface MassMovementService.
 */
@Service
public interface MassMovementService {

    Long addTrackChanges(String status);

    void updateTrackChanges(TrackChanges trackChanges);

    Optional<TrackChanges> getById(Long id);

    List<TrackChangesDto> getAllTrackChanges();

    Boolean purgeMMTCData(String folder, Integer purgedatadurationindays);

    Map<String, Integer> findMaxSize(String tableName);

    void addMMHistory(MMVehicleHistory mmVehicleHistory);

}
