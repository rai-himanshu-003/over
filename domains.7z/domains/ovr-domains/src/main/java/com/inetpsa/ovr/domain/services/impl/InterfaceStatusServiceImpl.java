/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.domain.SortOption;
import org.seedstack.business.domain.SortOption.Direction;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.InterfaceStatus;
import com.inetpsa.ovr.domain.repository.InterfaceStatusRepository;
import com.inetpsa.ovr.domain.services.InterfaceStatusService;
import com.inetpsa.ovr.domain.util.OVERConstants;

/**
 * The Class InterfaceStatusServiceImpl.
 */
@Transactional
@JpaUnit("ovr-domain-jpa-unit")
public class InterfaceStatusServiceImpl implements InterfaceStatusService {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(InterfaceStatusServiceImpl.class);

    /** The format. */
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // 2019-07-02 09:05:02

    /** The interface status repository. */
    @Inject
    private InterfaceStatusRepository interfaceStatusRepository;

    /** The specification builder. */
    @Inject
    private SpecificationBuilder specificationBuilder;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceStatusService#getInterfaceStatus(java.lang.String)
     */
    @Override
    public Optional<InterfaceStatus> getInterfaceStatus(String interfaceID) {
        return interfaceStatusRepository.get(interfaceID);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceStatusService#updateInterfaceStatus(com.inetpsa.ovr.domain.model.InterfaceStatus)
     */
    @Override
    public boolean updateInterfaceStatus(InterfaceStatus updateStatus) {
        try {
            logger.info("Entering Update Interface Status");
            Optional<InterfaceStatus> aggregate = interfaceStatusRepository.get(updateStatus.getInterfaceName());

            if (aggregate.isPresent() && aggregate.get() != null) {
                updateStatus.setStatusList(aggregate.get().getStatusList());
                if (aggregate.get().getVersion().equals(updateStatus.getVersion())) {
                    interfaceStatusRepository.update(updateStatus);
                } else {
                    logger.info("Interface {} version {} is not matching with Database version : {} ", updateStatus.getInterfaceName(),
                            updateStatus.getVersion(), aggregate.get().getVersion());
                    return false;
                }

            } else {
                logger.info("Interface {} is not present in Database ", updateStatus.getInterfaceName());
                return false;
            }
        } catch (Exception e) {
            logger.error("Exception in updateInterfaceStatus() method {}", e.getMessage());
        }
        return true;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceStatusService#isOVERTimedOut(java.util.Date, java.lang.String)
     */
    @Override
    public boolean isOVERTimedOut(Date dateMODIF, String ottMaxWaiting) {
        try {

            Integer ottMaxWaitingInt = Integer.parseInt(ottMaxWaiting);
            Date interfaceDate = format.parse(format.format(dateMODIF));
            Date currentDate = format.parse(format.format(new Date()));

            long diffHours = (currentDate.getTime() - interfaceDate.getTime())
                    / (OVERConstants.TIMER60 * OVERConstants.TIMER60 * OVERConstants.TIMER1000);

            if (diffHours >= ottMaxWaitingInt)
                return true;

        } catch (Exception e) {

            logger.error("Batch {} : Error in OVRQTSTSService.isOVERTimedOut {} ", OVERConstants.BATCH_NAME, e.getMessage());
            return false;
        }

        return false;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.ovr.domain.services.InterfaceStatusService#getAllInterfaces()
     */
    @Override
    public List<InterfaceStatus> getAllInterfaces() {
        logger.info("Entering getAllInterfaces");
        List<InterfaceStatus> list = null;

        Specification<InterfaceStatus> spec = specificationBuilder.of(InterfaceStatus.class).property("interfaceName").not().equalTo(null).build();
        SortOption opt = new SortOption();
        opt.add("interfaceName", Direction.ASCENDING);
        list = interfaceStatusRepository.get(spec, opt).collect(Collectors.toList());
        logger.info("Exiting getAllInterfaces");
        return list;
    }

}
