/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.util.List;

import org.seedstack.business.Service;
import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.VehicleHistory;
import com.inetpsa.ovr.domain.model.VehicleHistoryPk;
import com.inetpsa.ovr.interfaces.dto.VehicleDetailsDto;

/**
 * The Interface VehicleHistoryRepository.
 */
@Service
public interface VehicleHistoryRepository extends Repository<VehicleHistory, VehicleHistoryPk> {

    /**
     * Gets the veh hist list.
     *
     * @param vin the vin
     * @return the veh hist list
     */
    List<VehicleDetailsDto> getVehHistList(String vin);

    /**
     * Gets the veh hist list count.
     *
     * @param vin the vin
     * @return the veh hist list count
     */
    long getVehHistListCount(String vin);
}
