/*
 * Creation : 2 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class VehicleError.
 */
@Entity
@Table(name = "OVRQTERR")
public class VehicleError extends BaseAggregateRoot<String> {

    @Identity
    @EmbeddedId
    private VehicleErrorPk vehicleErrorPk;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The err complement. */
    @Column(name = "ERR_COMPLEMENT")
    private String errComplement;

    /** The err description. */
    @Column(name = "ERR_DESCRIPTION")
    private String errDescription;

    /** The err message. */
    @Lob
    @Column(name = "ERR_MESSAGE")
    private String errMessage;

    @Column(name = "FLOWNAME")
    private String flowname;

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        vehicleErrorPk.setDateCreation(LocalDateTime.now());
        userCreation = LoggedUser.get();
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the err complement.
     *
     * @return the err complement
     */
    public String getErrComplement() {
        return errComplement;
    }

    /**
     * Sets the err complement.
     *
     * @param errComplement the new err complement
     */
    public void setErrComplement(String errComplement) {
        this.errComplement = errComplement;
    }

    /**
     * Gets the err description.
     *
     * @return the err description
     */
    public String getErrDescription() {
        return errDescription;
    }

    /**
     * Sets the err description.
     *
     * @param errDescription the new err description
     */
    public void setErrDescription(String errDescription) {
        this.errDescription = errDescription;
    }

    /**
     * Gets the err message.
     *
     * @return the err message
     */
    public String getErrMessage() {
        return errMessage;
    }

    /**
     * Sets the err message.
     *
     * @param errMessage the new err message
     */
    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    /**
     * Gets vehicleErrorPk
     * 
     * @return the vehicleErrorPk
     */
    public VehicleErrorPk getVehicleErrorPk() {
        return vehicleErrorPk;
    }

    /**
     * Sets vehicleErrorPk
     * 
     * @param vehicleErrorPk the vehicleErrorPk
     */
    public void setVehicleErrorPk(VehicleErrorPk vehicleErrorPk) {
        this.vehicleErrorPk = vehicleErrorPk;
    }

    /**
     * Instantiates a new vehicle error.
     */
    public VehicleError() {
        super();

    }

    public String getFlowname() {
        return flowname;
    }

    public void setFlowname(String flowname) {
        this.flowname = flowname;
    }

    /**
     * Instantiates a new vehicle error.
     * 
     * @param vehicleErrorPk the vehicleErrorPk
     * @param userCreation the userCreation
     * @param errComplement the errComplement
     * @param errDescription the errDescription
     * @param errMessage the errMessage
     */
    public VehicleError(VehicleErrorPk vehicleErrorPk, String userCreation, String errComplement, String errDescription, String errMessage) {
        this.vehicleErrorPk = vehicleErrorPk;
        this.userCreation = userCreation;
        this.errComplement = errComplement;
        this.errDescription = errDescription;
        this.errMessage = errMessage;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "VehicleError [vehicleErrorPk=" + vehicleErrorPk + ", userCreation=" + userCreation + ", errComplement=" + errComplement
                + ", errDescription=" + errDescription + ", errMessage=" + errMessage + "]";
    }

}
