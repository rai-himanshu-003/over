/*
 * Creation : 10 Oct 2019
 */
package com.inetpsa.ovr.interfaces.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * The Class InterfaceRulesDto.
 */
public class InterfaceRulesDto implements Serializable {

    /** the serial version Id. */
    private static final long serialVersionUID = -5765568074563706658L;

    /** The vin. */
    private Long id;

    /** The priority. */
    private Integer priority;

    /** The type of filter. */
    private Integer typeOfFilter;

    /** The interface id. */
    private Long interfaceId;

    /** The family of vehicle. */
    private String familyOfVehicle;

    /** The production centre. */
    private String productionCentre;

    /** The country. */
    private String country;

    /** The min ecom date. */
    private Date minEcomDate;

    /** The max ecom date. */
    private Date maxEcomDate;

    /** The date creation. */
    private Date dateCreation;

    /** The version. */
    private Integer version;

    /** The vin. */
    private String vin;

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the priority.
     *
     * @param priority the new priority
     */
    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    /**
     * Gets the family of vehicle.
     *
     * @return the family of vehicle
     */
    public String getFamilyOfVehicle() {
        return familyOfVehicle;
    }

    /**
     * Gets the interface id.
     *
     * @return the interface id
     */
    public Long getInterfaceId() {
        return interfaceId;
    }

    /**
     * Sets the interface id.
     *
     * @param interfaceId the new interface id
     */
    public void setInterfaceId(Long interfaceId) {
        this.interfaceId = interfaceId;
    }

    /**
     * Sets the family of vehicle.
     *
     * @param familyOfVehicle the new family of vehicle
     */
    public void setFamilyOfVehicle(String familyOfVehicle) {
        this.familyOfVehicle = familyOfVehicle;
    }

    /**
     * Gets the production centre.
     *
     * @return the production centre
     */
    public String getProductionCentre() {
        return productionCentre;
    }

    /**
     * Sets the production centre.
     *
     * @param productionCentre the new production centre
     */
    public void setProductionCentre(String productionCentre) {
        this.productionCentre = productionCentre;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the serialversionuid.
     *
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public Date getDateCreation() {
        return dateCreation;
    }

    /**
     * Gets the min ecom date.
     *
     * @return the min ecom date
     */
    public Date getMinEcomDate() {
        return minEcomDate;
    }

    /**
     * Sets the min ecom date.
     *
     * @param minEcomDate the new min ecom date
     */
    public void setMinEcomDate(Date minEcomDate) {
        this.minEcomDate = minEcomDate;
    }

    /**
     * Gets the max ecom date.
     *
     * @return the max ecom date
     */
    public Date getMaxEcomDate() {
        return maxEcomDate;
    }

    /**
     * Sets the max ecom date.
     *
     * @param maxEcomDate the new max ecom date
     */
    public void setMaxEcomDate(Date maxEcomDate) {
        this.maxEcomDate = maxEcomDate;
    }

    /**
     * Sets the date creation.
     *
     * @param dateCreation the new date creation
     */
    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * Gets the type of filter.
     *
     * @return the type of filter
     */
    public Integer getTypeOfFilter() {
        return typeOfFilter;
    }

    /**
     * Sets the type of filter.
     *
     * @param typeOfFilter the new type of filter
     */
    public void setTypeOfFilter(Integer typeOfFilter) {
        this.typeOfFilter = typeOfFilter;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

}
