/*
 * Creation : 15 Jul 2019
 */
package com.inetpsa.ovr.domain.services;

import org.seedstack.business.Service;

/**
 * The Interface OTTFileSequenceService.
 */
@Service
public interface OTTFileSequenceService {

    /**
     * Gets the OTTF ile sequence number.
     *
     * @return the OTTF ile sequence number
     */
    Number getOTTFIleSequenceNumber();

}
