/*
 * Creation : 2 Jul 2019
 */
package com.inetpsa.ovr.domain.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.domain.util.LoggedUser;

/**
 * The Class Vehicle.
 */
@Entity
@DynamicUpdate(value = true)
@Table(name = "OVRQTVHL")
public class Vehicle extends BaseAggregateRoot<String> {

    /** The vin no. */
    @Identity
    @Id
    @Column(name = "VIN")
    private String vinNo;

    /** The current state. */
    @Column(name = "CURRENT_STATE")
    private String currentState;

    /** The ccp. */
    @Column(name = "CCP")
    private String ccp;

    /** The veh. */
    @Column(name = "VEH")
    private String veh;

    /** The date extension. */
    @Column(name = "DATE_EXTENSION")
    private Date dateExtension;

    /** The lcdv 24. */
    @Column(name = "LCDV24")
    private String lcdv24;

    /** The oa. */
    @Column(name = "OA")
    private String oa;

    /** The nrv. */
    @Column(name = "NRE")
    private String nre;

    /** The tvv. */
    @Column(name = "TVV")
    private String tvv;

    /** The model. */
    @Column(name = "V_MODEL")
    private String model;

    /** The model year. */
    @Column(name = "MODELYEAR")
    private String modelYear;

    /** The apvpr. */
    @Column(name = "APVPR")
    private String apvpr;

    /** The up. */
    @Column(name = "UP")
    private String up;

    /** The of. */
    @Column(name = "V_OF")
    private String of;

    /** The date ecom. */
    @Column(name = "DATE_ECOM")
    private Date dateEcom;

    /** The date emon. */
    @Column(name = "DATE_EMON")
    private Date dateEmon;

    /** The date creation. */
    @Column(name = "DATE_CREATION")
    private LocalDateTime dateCreation;

    /** The user creation. */
    @Column(name = "USER_CREATION")
    private String userCreation;

    /** The date modif. */
    @Column(name = "DATE_MODIF")
    private LocalDateTime dateModif;

    /** The user modif. */
    @Column(name = "USER_MODIF")
    private String userModif;

    /** The rpo country. */
    @Column(name = "RPO_COUNTRY")
    private String rpoCountry;

    /** The rpo transmission. */
    @Column(name = "RPO_TRANSMISSION")
    private String rpoTransmission;

    /** The rpo engine. */
    @Column(name = "RPO_ENGINE")
    private String rpoEngine;

    /** The model name. */
    @Column(name = "MODEL_NAME")
    private String modelName;

    /** The market country code. */
    @Column(name = "OV_MARKETCOUNTRYCODE")
    private String marketCountryCode;
    /** The version. */
    @Version
    @Column(name = "VERSION")
    private Integer version;

    /** The modelYearSuffix. */
    @Column(name = "MODELYEAR_SUFFIX")
    private String modelYearSuffix;

    @Transient
    private String usecase;

    // Relationships STARTS----->

    /** The composants. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<Composants> composants;

    /** The references electroniques. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<ReferencesElectroniques> referencesElectroniques;

    /** The composants ov. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<ComposantsOv> composantsOv;

    /** The options. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<Options> options;

    /** The options. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<Options2> options2;

    /** The keys ov. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<KeysOv> keysOv;

    /** The lcdv ott ov. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<LcdvOtt> lcdvOttOv;

    /** The multiple flow status. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private List<MultipleFlowStatus> multipleFlowStatus;

    /** The art lcdv ott. */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "vin")
    private Set<ArtLcdvOtt> artLcdvOtt;

    // Relationships ENDS----->

    /**
     * Pre persist.
     */
    @PrePersist
    public void prePersist() {
        dateCreation = LocalDateTime.now();
        userCreation = LoggedUser.get();
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();
    }

    /**
     * Pre update.
     */
    @PreUpdate
    public void preUpdate() {
        dateModif = LocalDateTime.now();
        userModif = LoggedUser.get();
    }

    /**
     * Gets the composants.
     *
     * @return the composants
     */
    public Set<Composants> getComposants() {
        return composants;
    }

    /**
     * Sets the composants.
     *
     * @param composants the new composants
     */
    public void setComposants(Set<Composants> composants) {
        this.composants = composants;
    }

    /**
     * Gets the references electroniques.
     *
     * @return the references electroniques
     */
    public Set<ReferencesElectroniques> getReferencesElectroniques() {
        return referencesElectroniques;
    }

    /**
     * Sets the references electroniques.
     *
     * @param referencesElectroniques the new references electroniques
     */
    public void setReferencesElectroniques(Set<ReferencesElectroniques> referencesElectroniques) {
        this.referencesElectroniques = referencesElectroniques;
    }

    /**
     * Gets the composants ov.
     *
     * @return the composants ov
     */
    public Set<ComposantsOv> getComposantsOv() {
        return composantsOv;
    }

    /**
     * Sets the composants ov.
     *
     * @param composantsOv the new composants ov
     */
    public void setComposantsOv(Set<ComposantsOv> composantsOv) {
        this.composantsOv = composantsOv;
    }

    /**
     * Sets the options.
     *
     * @param options the new options
     */
    public void setOptions(Set<Options> options) {
        this.options = options;
    }

    /**
     * Sets the lcdv ott ov.
     *
     * @param lcdvOttOv the new lcdv ott ov
     */
    public void setLcdvOttOv(Set<LcdvOtt> lcdvOttOv) {
        this.lcdvOttOv = lcdvOttOv;
    }

    /**
     * Gets the options.
     *
     * @return the options
     */
    public Set<Options> getOptions() {
        return options;
    }

    /**
     * Gets the keys ov.
     *
     * @return the keys ov
     */
    public Set<KeysOv> getKeysOv() {
        return keysOv;
    }

    /**
     * Sets the keys ov.
     *
     * @param keysOv the new keys ov
     */
    public void setKeysOv(Set<KeysOv> keysOv) {
        this.keysOv = keysOv;
    }

    /**
     * Gets the lcdv ott ov.
     *
     * @return the lcdv ott ov
     */
    public Set<LcdvOtt> getLcdvOttOv() {
        return lcdvOttOv;
    }

    /**
     * Gets the lcdv 24.
     *
     * @return the lcdv 24
     */
    public String getLcdv24() {
        return lcdv24;
    }

    /**
     * Sets the lcdv 24.
     *
     * @param lcdv24 the new lcdv 24
     */
    public void setLcdv24(String lcdv24) {
        this.lcdv24 = lcdv24;
    }

    /**
     * Gets the oa.
     *
     * @return the oa
     */
    public String getOa() {
        return oa;
    }

    /**
     * Sets the oa.
     *
     * @param oa the new oa
     */
    public void setOa(String oa) {
        this.oa = oa;
    }

    /**
     * Gets the nre.
     *
     * @return the nre
     */
    public String getNre() {
        return nre;
    }

    /**
     * Sets the nre.
     *
     * @param nre the new nre
     */
    public void setNre(String nre) {
        this.nre = nre;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Sets the tvv.
     *
     * @param tvv the new tvv
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * Gets the model.
     *
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model.
     *
     * @param model the new model
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Gets the model year.
     *
     * @return the model year
     */
    public String getModelYear() {
        return modelYear;
    }

    /**
     * Sets the model year.
     *
     * @param modelYear the new model year
     */
    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    /**
     * Gets the apvpr.
     *
     * @return the apvpr
     */
    public String getApvpr() {
        return apvpr;
    }

    /**
     * Sets the apvpr.
     *
     * @param apvpr the new apvpr
     */
    public void setApvpr(String apvpr) {
        this.apvpr = apvpr;
    }

    /**
     * Gets the up.
     *
     * @return the up
     */
    public String getUp() {
        return up;
    }

    /**
     * Sets the up.
     *
     * @param up the new up
     */
    public void setUp(String up) {
        this.up = up;
    }

    /**
     * Gets the of.
     *
     * @return the of
     */
    public String getOf() {
        return of;
    }

    /**
     * Sets the of.
     *
     * @param of the new of
     */
    public void setOf(String of) {
        this.of = of;
    }

    /**
     * Gets the date ecom.
     *
     * @return the date ecom
     */
    public Date getDateEcom() {
        return dateEcom;
    }

    /**
     * Sets the date ecom.
     *
     * @param dateEcom the new date ecom
     */
    public void setDateEcom(Date dateEcom) {
        this.dateEcom = dateEcom;
    }

    /**
     * Gets the date emon.
     *
     * @return the date emon
     */
    public Date getDateEmon() {
        return dateEmon;
    }

    /**
     * Sets the date emon.
     *
     * @param dateEmon the new date emon
     */
    public void setDateEmon(Date dateEmon) {
        this.dateEmon = dateEmon;
    }

    /**
     * Gets the vin no.
     *
     * @return the vin no
     */
    public String getVinNo() {
        return vinNo;
    }

    /**
     * Sets the vin no.
     *
     * @param vinNo the new vin no
     */
    public void setVinNo(String vinNo) {
        this.vinNo = vinNo;
    }

    /**
     * Gets the current state.
     *
     * @return the current state
     */
    public String getCurrentState() {
        return currentState;
    }

    /**
     * Sets the current state.
     *
     * @param currentState the new current state
     */
    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    /**
     * Gets the date extension.
     *
     * @return the date extension
     */
    public Date getDateExtension() {
        return dateExtension;
    }

    /**
     * Sets the date extension.
     *
     * @param dateExtension the new date extension
     */
    public void setDateExtension(Date dateExtension) {
        this.dateExtension = dateExtension;
    }

    /**
     * Gets the date creation.
     *
     * @return the date creation
     */
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    /**
     * Gets the user creation.
     *
     * @return the user creation
     */
    public String getUserCreation() {
        return userCreation;
    }

    /**
     * Gets the date modif.
     *
     * @return the date modif
     */
    public LocalDateTime getDateModif() {
        return dateModif;
    }

    /**
     * Gets the user modif.
     *
     * @return the user modif
     */
    public String getUserModif() {
        return userModif;
    }

    /**
     * Gets the ccp.
     *
     * @return the ccp
     */
    public String getCcp() {
        return ccp;
    }

    /**
     * Sets the ccp.
     *
     * @param ccp the new ccp
     */
    public void setCcp(String ccp) {
        this.ccp = ccp;
    }

    /**
     * Gets the veh.
     *
     * @return the veh
     */
    public String getVeh() {
        return veh;
    }

    /**
     * Sets the veh.
     *
     * @param veh the new veh
     */
    public void setVeh(String veh) {
        this.veh = veh;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * sets the version.
     *
     * @param version the version
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * Gets the multiple flow status.
     *
     * @return the multiple flow status
     */
    public List<MultipleFlowStatus> getMultipleFlowStatus() {
        return multipleFlowStatus;
    }

    /**
     * Sets the multiple flow status.
     *
     * @param multipleFlowStatus the new multiple flow status
     */
    public void setMultipleFlowStatus(List<MultipleFlowStatus> multipleFlowStatus) {
        this.multipleFlowStatus = multipleFlowStatus;
    }

    /**
     * Gets the rpo country.
     *
     * @return the rpo country
     */
    public String getRpoCountry() {
        return rpoCountry;
    }

    /**
     * Sets the rpo country.
     *
     * @param rpoCountry the new rpo country
     */
    public void setRpoCountry(String rpoCountry) {
        this.rpoCountry = rpoCountry;
    }

    /**
     * Gets the rpo transmission.
     *
     * @return the rpo transmission
     */
    public String getRpoTransmission() {
        return rpoTransmission;
    }

    /**
     * Sets the rpo transmission.
     *
     * @param rpoTransmission the new rpo transmission
     */
    public void setRpoTransmission(String rpoTransmission) {
        this.rpoTransmission = rpoTransmission;
    }

    /**
     * Gets the rpo engine.
     *
     * @return the rpo engine
     */
    public String getRpoEngine() {
        return rpoEngine;
    }

    /**
     * Sets the rpo engine.
     *
     * @param rpoEngine the new rpo engine
     */
    public void setRpoEngine(String rpoEngine) {
        this.rpoEngine = rpoEngine;
    }

    /**
     * Gets the model name.
     *
     * @return the model name
     */
    public String getModelName() {
        return modelName;
    }

    /**
     * Sets the model name.
     *
     * @param modelName the new model name
     */
    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    /**
     * Gets the market country code.
     *
     * @return the market country code
     */
    public String getMarketCountryCode() {
        return marketCountryCode;
    }

    /**
     * Sets the market country code.
     *
     * @param marketCountryCode the new market country code
     */
    public void setMarketCountryCode(String marketCountryCode) {
        this.marketCountryCode = marketCountryCode;
    }

    /**
     * Gets the art lcdv ott.
     *
     * @return the art lcdv ott
     */
    public Set<ArtLcdvOtt> getArtLcdvOtt() {
        return artLcdvOtt;
    }

    /**
     * Sets the art lcdv ott.
     *
     * @param artLcdvOtt the new art lcdv ott
     */
    public void setArtLcdvOtt(Set<ArtLcdvOtt> artLcdvOtt) {
        this.artLcdvOtt = artLcdvOtt;
    }

    /**
     * Gets the options 2.
     *
     * @return the options 2
     */
    public Set<Options2> getOptions2() {
        return options2;
    }

    /**
     * Sets the options 2.
     *
     * @param options2 the new options 2
     */
    public void setOptions2(Set<Options2> options2) {
        this.options2 = options2;
    }

    public String getUsecase() {
        return usecase;
    }

    public void setUsecase(String usecase) {
        this.usecase = usecase;
    }

    public String getModelYearSuffix() {
        return modelYearSuffix;
    }

    public void setModelYearSuffix(String modelYearSuffix) {
        this.modelYearSuffix = modelYearSuffix;
    }

    /**
     * Instantiates a new vehicle.
     *
     * @param vinNo the vin no
     * @param currentState the current state
     * @param ccp the ccp
     * @param veh the veh
     * @param dateExtension the date extension
     * @param userCreation the user creation
     * @param dateCreation the date creation
     * @param version the version
     */
    public Vehicle(String vinNo, String currentState, String ccp, String veh, Date dateExtension, String userCreation, LocalDateTime dateCreation,
            Integer version) {
        super();
        this.vinNo = vinNo;
        this.currentState = currentState;
        this.ccp = ccp;
        this.veh = veh;
        this.dateExtension = dateExtension;
        this.dateCreation = dateCreation;
        this.userCreation = userCreation;
        this.version = version;

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Vehicle [vinNo=" + vinNo + ", currentState=" + currentState + ", ccp=" + ccp + ", veh=" + veh + ", dateExtension=" + dateExtension
                + ", lcdv24=" + lcdv24 + ", oa=" + oa + ", nre=" + nre + ", tvv=" + tvv + ", model=" + model + ", modelYear=" + modelYear + ", apvpr="
                + apvpr + ", up=" + up + ", of=" + of + ", dateEcom=" + dateEcom + ", dateEmon=" + dateEmon + ", dateCreation=" + dateCreation
                + ", userCreation=" + userCreation + ", dateModif=" + dateModif + ", userModif=" + userModif + ", rpoCountry=" + rpoCountry
                + ", rpoTransmission=" + rpoTransmission + ", rpoEngine=" + rpoEngine + ", modelName=" + modelName + ", marketCountryCode="
                + marketCountryCode + ", version=" + version + ", composants=" + composants + ", referencesElectroniques=" + referencesElectroniques
                + ", composantsOv=" + composantsOv + ", options=" + options + ", keysOv=" + keysOv + ", lcdvOttOv=" + lcdvOttOv
                + ", multipleFlowStatus=" + multipleFlowStatus + ", artLcdvOtt=" + artLcdvOtt + "]";
    }

    /**
     * Instantiates a new vehicle.
     */
    public Vehicle() {
        super();

    }

    /**
     * Instantiates a new vehicle.
     *
     * @param multipleFlowStatus the multiple flow status
     */
    public Vehicle(MultipleFlowStatus multipleFlowStatus) {
        super();
        this.multipleFlowStatus = new ArrayList<>();
        this.multipleFlowStatus.add(multipleFlowStatus);
    }

    /**
     * Creates the shallow copy.
     *
     * @param vhl the vhl
     */
    public void createShallowCopy(Vehicle vhl) {
        this.vinNo = vhl.vinNo;
        this.currentState = vhl.currentState;
        this.ccp = vhl.ccp;
        this.veh = vhl.veh;
        this.dateExtension = vhl.dateExtension;
        this.lcdv24 = vhl.lcdv24;
        this.oa = vhl.oa;
        this.nre = vhl.nre;
        this.tvv = vhl.tvv;
        this.model = vhl.model;
        this.modelYear = vhl.modelYear;
        this.apvpr = vhl.apvpr;
        this.up = vhl.up;
        this.of = vhl.of;
        this.dateEcom = vhl.dateEcom;
        this.dateEmon = vhl.dateEmon;
        this.dateCreation = vhl.dateCreation;
        this.userCreation = vhl.userCreation;
        this.dateModif = vhl.dateModif;
        this.userModif = vhl.userModif;
        this.version = vhl.version;
        this.rpoCountry = vhl.rpoCountry;
        this.rpoEngine = vhl.rpoEngine;
        this.rpoTransmission = vhl.rpoTransmission;
        this.modelName = vhl.modelName;
        this.marketCountryCode = vhl.marketCountryCode;

        this.composants = null;
        this.referencesElectroniques = null;
        this.composantsOv = null;
        this.options = null;
        this.keysOv = null;
        this.lcdvOttOv = null;
        this.multipleFlowStatus = null;

    }

}
