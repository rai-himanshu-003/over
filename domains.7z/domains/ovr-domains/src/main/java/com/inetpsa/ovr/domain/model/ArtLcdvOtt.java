/*
 * Creation : 28 Nov 2019
 */
package com.inetpsa.ovr.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.inetpsa.ovr.interfaces.dto.ArtLcdvOttDTO;

/**
 * The Class ArtLcdvOtt.
 */
@Entity
@Table(name = "OVRQTVARTLCDV")
@DynamicUpdate(value = true)
public class ArtLcdvOtt extends BaseAggregateRoot<Long> {

    /** The id. */
    @Identity
    @Id
    @Column(name = "ID")
    private Long id;

    /** The code. */
    @Column(name = "CODE")
    private String code;

    /** The vin. */
    @Column(name = "VIN")
    private String vin;

    /** The family. */
    @Column(name = "FAMILY")
    private String family;

    /** The value. */
    @Column(name = "VALUE")
    private String value;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getId()
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the family.
     *
     * @return the family
     */
    public String getFamily() {
        return family;
    }

    /**
     * Sets the family.
     *
     * @param family the new family
     */
    public void setFamily(String family) {
        this.family = family;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((family == null) ? 0 : family.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        result = prime * result + ((vin == null) ? 0 : vin.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        ArtLcdvOtt other = (ArtLcdvOtt) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (family == null) {
            if (other.family != null)
                return false;
        } else if (!family.equals(other.family))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        } else if (!value.equals(other.value))
            return false;
        if (vin == null) {
            if (other.vin != null)
                return false;
        } else if (!vin.equals(other.vin))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "ArtLcdvOtt [id=" + id + ", code=" + code + ", vin=" + vin + ", family=" + family + ", value=" + value + "]";
    }

    /**
     * Mapto dto.
     *
     * @return the art lcdv ott DTO
     */
    public ArtLcdvOttDTO maptoDto() {

        ArtLcdvOttDTO artLcdvOttDTO = new ArtLcdvOttDTO();
        artLcdvOttDTO.setIdArtLcdvDto(this.getId());
        artLcdvOttDTO.setCodeArtLcdvDto(this.getCode());
        artLcdvOttDTO.setFamilyArtLcdvDto(this.getFamily());
        artLcdvOttDTO.setValueArtLcdvDto(this.getValue());
        artLcdvOttDTO.setVinArtLcdvDto(this.getVin());

        return artLcdvOttDTO;
    }

}
