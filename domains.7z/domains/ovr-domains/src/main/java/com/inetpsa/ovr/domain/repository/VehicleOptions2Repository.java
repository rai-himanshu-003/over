/*
 * Creation : 10 Dec 2019
 */
package com.inetpsa.ovr.domain.repository;

import java.math.BigDecimal;
import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.ovr.domain.model.Options2;

/**
 * The Interface VehicleOptionsRepository.
 */
public interface VehicleOptions2Repository extends Repository<Options2, Long> {
    /**
     * Gets the sequence count.
     *
     * @param size the size
     * @return the sequence count
     */
    List<BigDecimal> getSequenceCount(long size);
}
