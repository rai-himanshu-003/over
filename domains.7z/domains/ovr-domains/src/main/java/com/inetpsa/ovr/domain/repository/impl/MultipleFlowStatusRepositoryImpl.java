/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.ovr.domain.repository.impl;

import org.seedstack.jpa.BaseJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.ovr.domain.model.MultipleFlowStatus;
import com.inetpsa.ovr.domain.repository.MultipleFlowStatusRepository;

/**
 * The Class PsaKeyMappingRepositoryImpl.
 */
public class MultipleFlowStatusRepositoryImpl extends BaseJpaRepository<MultipleFlowStatus, Long> implements MultipleFlowStatusRepository {

    public static final Logger logger = LoggerFactory.getLogger(MultipleFlowStatusRepositoryImpl.class);

}